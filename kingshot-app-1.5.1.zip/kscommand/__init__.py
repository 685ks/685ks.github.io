"""Kingshot Command - one app for every Kingshot bot."""
__version__ = "1.5.1"
