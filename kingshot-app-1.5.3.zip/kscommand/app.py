"""Kingshot Command: one window for Autopilot, every bot, gift codes, stats and the Telegram
remote. Start with `python -m kscommand` (the bot.exe launcher does that)."""
import subprocess
import sys
import threading
import time
from datetime import datetime

from PySide6.QtCore import QEvent, QObject, QPropertyAnimation, QRect, QSize, Qt, QTimer, Signal
from PySide6.QtGui import QAction, QFont, QFontDatabase, QIcon
from PySide6.QtNetwork import QLocalServer, QLocalSocket
from PySide6.QtWidgets import (QApplication, QFrame, QHBoxLayout, QMainWindow, QMenu, QPushButton,
                               QHeaderView, QStackedWidget, QSystemTrayIcon, QVBoxLayout, QWidget)

from kscommand import bots as B
from kscommand import builder as BD
from kscommand import core
from kscommand import emulators as E
from kscommand import learned as L
from kscommand import selfupdate as SU
from kscommand.services import (KINGSHOT, AutopilotBridge, Discovery, Previewer, ProcessManager, Telegram,
                                Watchdog, device, png)
from kscommand.ui import pages, theme
from kscommand.ui.widgets import (PulseDot, Toast, crown_pixmap, label, line_icon, no_emoji,
                                  place_combo_popup, slide_fade_in, calm_inputs, wheel_to_page)

INSTANCE_ID = "KingshotCommand-single-instance"


class Hub(QObject):
    """Shared state and services; pages talk to each other only through these signals."""
    instances_changed = Signal(list, str)
    discovering = Signal(bool)
    frame = Signal(str, object)
    instance_state = Signal(str, str, str)  # name, status, text
    activity = Signal(str, str)  # text, kind ok|bad|warn|info
    autopilot_changed = Signal()
    autostart_tick = Signal(int)
    log_line = Signal(str, str)  # source, text
    telegram_status = Signal(str)
    toast_sig = Signal(str, str)
    download_progress = Signal(int)
    emulators_changed = Signal()
    learned_changed = Signal()
    update_available = Signal(object)  # the published index, when it's newer than what's installed
    characters_progress = Signal(str, int, int, str)  # instance, done, total, text (total 0 = finished)
    characters_changed = Signal()
    builder_status = Signal(str, str, str, str, str)  # template id, instance, block id, running|ok|fail, text
    builder_changed = Signal()  # a Build-a-bot run started or ended
    _emu_log = Signal(str)
    _from_thread = Signal(object)  # run a callable on the GUI thread

    def __init__(self, window):
        super().__init__(window)
        self.window = window
        self.settings = core.load()
        self.instances = []  # [(name, serial)]
        self.procs = ProcessManager(self)
        self.bridge = AutopilotBridge(self)
        self.previewer = Previewer(self)
        self.watchdog = Watchdog(self)
        self.telegram = None
        self._disc = None
        self._autostart_left = 0
        self._autostart_timer = QTimer(self, interval=1000, timeout=self._autostart_step)
        self._from_thread.connect(lambda fn: fn())
        self.toast_sig.connect(self.toast)
        core.LOG_DIR.mkdir(exist_ok=True)
        self._logfile = None

        self.bridge.log.connect(self._engine_log)
        self.bridge.changed.connect(self.autopilot_changed.emit)
        self.procs.line.connect(self._bot_line)
        self.procs.changed.connect(self.autopilot_changed.emit)
        self.previewer.frame.connect(self.frame.emit)
        self.watchdog.event.connect(lambda t: (self.log_line.emit("Watchdog", t), self.activity.emit(t, "warn"),
                                               self.notify(f"⚠ {t}")))
        self.watchdog.minutes = self.settings.keep_alive_min
        self.previewer.start()
        self.watchdog.start()
        self.rediscover = QTimer(self, interval=120_000, timeout=self.discover)
        self.rediscover.start()

        # emulator start/close
        self._char_stops = {}  # instance -> Event while its characters are being learned
        self._detected = []
        self._sessions_done = {}  # instance -> when its last session ended
        self._closing = set()
        self.launcher = E.Launcher(self.emulator_targets, log=self._emu_log.emit)
        self.bridge.launcher = self.launcher
        # learned skills (Teacher lessons Claude turned into steps) hook in where Kingshot opens
        self.launcher.before_game = lambda n, s: L.blocked(self.run_learned("before_game", n, s)) is None
        self.launcher.has_before_game = lambda n: L.has_hook("before_game", n, self.settings.learned_off)
        self.watchdog.before_game = self.launcher.before_game

        def session_start(n, s):
            res = self.run_learned("session_start", n, s)
            if L.blocked(res):
                return False  # a required skill failed: skip the session
            return True if res else None  # None: nothing ran (must not read as a failure)
        self.bridge.session_start = session_start
        if self.settings.update_check:
            QTimer.singleShot(20_000, lambda: self.check_learned(silent=True))
        # Build a bot: block templates, and the startup list that runs before Autopilot
        self.builder = BD.load()
        self.bot_run = None  # {"stop": Event, "names": [...], "tids": [...], "left": n} while one runs
        self.bridge.engine.presets = self._run_presets
        self._emu_log.connect(self._emu_line)
        self.refresh_emulators()
        self.closer = QTimer(self, interval=60_000, timeout=self._close_idle)
        self.closer.start()

    # ---------------------------------------------------------------- logging
    def _write_log(self, src, text):
        try:
            day = datetime.now().strftime("%Y-%m-%d")
            if not self._logfile or self._logfile[0] != day:
                self._logfile = (day, open(core.LOG_DIR / f"{day}.log", "a", encoding="utf-8"))
            self._logfile[1].write(f"{datetime.now():%H:%M:%S} {src}: {text}\n")
            self._logfile[1].flush()
        except OSError:
            pass

    def log(self, src, text):
        self.log_line.emit(src, text)
        self._write_log(src, text)

    def _engine_log(self, text):
        self.log("Autopilot", text)
        t = text.strip()
        if t.startswith("▶"):
            key = t[1:].strip()
            inst = key.split("/")[0]
            self.instance_state.emit(inst, "running", f"Autopilot: session for {key.split('/')[-1]}")
            self.activity.emit(f"Session started · {key}", "info")
        elif t.startswith("■"):
            key, _, summary = t[1:].strip().partition(": ")
            inst = key.split("/")[0]
            self._sessions_done[inst] = time.time()
            self.instance_state.emit(inst, "online", f"Last session: {summary}")
            kind = "ok" if summary and "not running" not in summary and "couldn't" not in summary else "warn"
            self.activity.emit(f"{key.split('/')[-1]} on {inst}: {summary}", kind)
            self.notify(f"{'✅' if kind == 'ok' else '⚠'} {key}: {summary}")
            self.autopilot_changed.emit()
        elif "failed" in t:
            self.activity.emit(t, "bad")

    def _bot_line(self, bot_id, text):
        bot = B.BY_ID.get(bot_id)
        title = bot.title if bot else bot_id
        self.log(title, text)
        if text.startswith("["):
            name, sep, rest = text[1:].partition("] ")
            if sep:
                st = "online" if any(w in rest.lower() for w in B.C.STOP_WORDS) else "running"
                self.instance_state.emit(name, st, f"{title}: {rest}")
        if text.startswith("finished (exit"):
            self.activity.emit(f"{title} {text}", "ok" if "code 0" in text else "warn")
            self.notify(f"{bot.glyph if bot else '🤖'} {title} {text}")
        elif "Traceback" in text or "Error" in text.split(":")[0]:
            self.activity.emit(f"{title}: {text}", "bad")

    # ---------------------------------------------------------------- instances
    def discover(self):
        if self._disc and self._disc.isRunning():
            return
        self.discovering.emit(True)
        self._disc = Discovery(self)
        self._disc.found.connect(self._found)
        self._disc.start()

    def _found(self, insts, err):
        self.discovering.emit(False)
        changed = insts != self.instances
        before = {n for n, _ in self.instances}
        for n, _ in insts:
            if n not in before:
                self.launcher.up_since.setdefault(n, time.time())
        self.instances = insts
        self.previewer.devices = dict(insts)
        if insts:  # remember every instance seen, so the watchdog can bring a crashed game back
            self.watchdog.devices.update(dict(insts))
        if changed or err:
            self.instances_changed.emit(insts, err)
        if err:
            self.log("App", f"discovery: {err}")
        if changed:
            self.log("App", f"instances with Kingshot open: {', '.join(n for n, _ in insts) or 'none'}")
        if self.settings.low_res and insts:
            self.set_resolution(True, quiet=True)
        self._maybe_autostart()

    # ---------------------------------------------------------------- autopilot
    def toggle_autopilot(self):
        self.autostart_cancel()
        if self.bridge.running:
            self.bridge.stop()
            self.watchdog.active = False
            self.toast("Autopilot stopping after the current step", "warn")
        else:
            self.start_autopilot()

    def start_autopilot(self):
        names = [n for n, _ in self.instances]
        if not names and not self.bridge.settings.characters:  # nothing open: the instances set to start
            names = [t.name for t in self.emulator_targets() if t.start]
        added = self.bridge.ensure_characters(names)
        if added:
            self.toast(f"Set up {', '.join(added)} with the everyday jobs", "ok")
        if not self.bridge.settings.characters:
            self.toast("No instance with Kingshot open yet. Open the game, then press Refresh.", "warn")
            return
        self.bridge.start()
        self.watchdog.active = self.settings.keep_alive
        self.toast("Autopilot is running", "ok")
        self.notify("▶ Autopilot started")

    def _maybe_autostart(self):
        if (self.settings.autostart and not self.bridge.running and not self._autostart_timer.isActive()
                and not getattr(self, "_autostart_done", False)
                and (self.instances or self.bridge.settings.characters or self.startup_templates())):
            self._autostart_done = True
            self._autostart_left = max(1, int(self.settings.autostart_delay))
            self.autostart_tick.emit(self._autostart_left)
            self._autostart_timer.start()

    def _autostart_step(self):
        self._autostart_left -= 1
        self.autostart_tick.emit(self._autostart_left)
        if self._autostart_left <= 0:
            self._autostart_timer.stop()
            if self.startup_templates():
                self.run_startup()
            else:
                self.start_autopilot()

    def autostart_now(self):
        self._autostart_left = 1
        self._autostart_step()

    def autostart_cancel(self):
        if self._autostart_timer.isActive():
            self._autostart_timer.stop()
            self.autostart_tick.emit(0)

    def next_session_text(self):
        st, chars = self.bridge.state, [c for c in self.bridge.settings.characters if c.enabled]
        if self.bridge.engine.current:
            return "running"
        times = [st.next_run(c.key) or 0 for c in chars]
        if not times:
            return "—"
        if not self.bridge.running:
            return "paused"
        return pages.fmt_eta(min(times)).replace("in ", "")

    def actions_today(self):
        st = self.bridge.state
        return sum(st.count(c.key, j) for c in self.bridge.settings.characters for j in self.bridge.config.JOBS)

    def run_instance_now(self, name):
        ch = next((c for c in self.bridge.settings.characters if c.instance == name), None)
        if not ch:
            self.bridge.ensure_characters([name])
            ch = next((c for c in self.bridge.settings.characters if c.instance == name), None)
        if ch:
            self.bridge.run_now(ch.key)
            self.watchdog.active = self.settings.keep_alive
            self.toast(f"Session queued for {name}", "ok")

    # ---------------------------------------------------------------- emulators
    def refresh_emulators(self):
        try:
            self._detected = E.detect()
        except Exception as e:  # noqa: BLE001
            self.log("Emulators", f"couldn't list instances: {e}")
            self._detected = []
        self.emulators_changed.emit()

    def emulator_targets(self):
        known = {c.instance for c in self.bridge.settings.characters}
        return E.merge(self.settings.emulators, self._detected, known)

    def set_emulator(self, target, **changes):
        data = target.to_json()
        data.update(changes)
        self.settings.emulators[target.name] = data
        self.save_settings()
        self.emulators_changed.emit()

    def add_shortcut(self, path, name):
        t = E.Target(name=name, kind="shortcut", ident=path, proc=E.shortcut_process(path), start=True)
        self.set_emulator(t)
        self.toast(f"Added {name}", "ok")

    def remove_emulator(self, name):
        self.settings.emulators.pop(name, None)
        self.save_settings()
        self.emulators_changed.emit()

    def _emu_line(self, text):
        self.log("Emulators", text)
        kind = "bad" if text.startswith(("Couldn't", "Don't")) or "didn't" in text else "info"
        self.activity.emit(text, kind)
        if text.startswith(("Starting", "Closed", "Couldn't")) or "didn't" in text:
            self.notify(f"🖥 {text}")

    def start_emulators(self, names=None):
        """Start instances now: the given names, or every one whose Start switch is on."""
        targets = [t for t in self.emulator_targets()
                   if (t.name in names if names else t.start) and t.name not in dict(self.instances)]
        if not targets:
            self.toast("Nothing to start: every instance set to start is already open. "
                       "Pick instances in Settings → Start and close instances." if not names else
                       "Already open", "info")
            return 0

        def work():
            for t in targets:
                threading.Thread(target=self.launcher.ensure, args=(t.name,), kwargs={"force": True},
                                 daemon=True).start()
        work()
        self.toast(f"Starting {', '.join(t.name for t in targets)}", "info")
        QTimer.singleShot(60_000, self.discover)
        QTimer.singleShot(150_000, self.discover)
        return len(targets)

    def close_emulators(self, names=None):
        """Close the given instances, or every open one with a Close switch."""
        open_names = set(dict(self.instances)) | set(self.launcher.up_since)
        targets = [t for t in self.emulator_targets()
                   if (t.name in names if names else t.close) and t.name in open_names]
        for t in targets:
            self._close(t.name)
        return len(targets)

    def _close(self, name):
        if name in self._closing:
            return
        self._closing.add(name)

        def done(_res):
            self._closing.discard(name)
            self.watchdog.devices.pop(name, None)
            self.discover()
        self.in_thread(lambda: self.launcher.close(name), done)

    def _close_idle(self):
        """Every minute: close instances whose sessions are done for a while (Close switch)."""
        if not self.bridge.running:
            return
        eng = self.bridge.engine
        busy = eng.busy_instances() | {k.split("/")[0] for k in eng.running_keys}
        bots_using = set()
        for bot_id in self.procs.running():
            bots_using |= set(self.procs.started.get(bot_id, ((), 0))[0])
        open_names = set(dict(self.instances)) | set(self.launcher.up_since)
        now = time.time()
        for t in self.emulator_targets():
            if t.name not in open_names or t.name in self._closing:
                continue
            chars = [c for c in self.bridge.settings.characters if c.enabled and c.instance == t.name]
            next_due = min((self.bridge.state.next_run(c.key) or 0 for c in chars), default=None)
            if E.due_to_close(t, running=True, busy=busy, bots_using=bots_using,
                              sessions_done=self._sessions_done, next_due=next_due,
                              up_since=self.launcher.up_since, now=now):
                self.log("Emulators", f"{t.name}: sessions done, next one {pages.fmt_eta(next_due)} - closing it")
                self._close(t.name)

    # ---------------------------------------------------------------- build a bot
    def save_builder(self):
        try:
            BD.save(self.builder)
        except OSError as e:
            self.toast(f"Couldn't save your bots: {e}", "bad")

    def startup_templates(self):
        return [t for tid in self.builder.get("startup", []) if (t := BD.find(self.builder, tid))]

    def bot_instances(self, templates):
        """Instances to run templates on: their own lists, else every instance set to Start
        plus every one open now."""
        targets, open_now = self.emulator_targets(), [n for n, _ in self.instances]
        names = []
        for t in templates:
            names += [n for n in BD.instances_for(t, targets, open_now) if n not in names]
        return names

    def run_startup(self):
        tpls = self.startup_templates()
        return self.run_bots(tpls, then_autopilot=self.builder.get("then_autopilot", True), why="Startup bot")

    def _bot_env(self):
        from kscommand import catalogue

        def job_params(name, job, acc):
            from autopilot import config
            chars = [c for c in self.bridge.settings.characters if c.instance == name]
            if acc is not None:
                chars = [c for c in chars if c.kingdom == acc.kingdom and c.name == acc.name] or chars
            ch = next((c for c in chars if c.enabled), chars[0] if chars else None)
            return dict(ch.jobs[job].params) if ch and job in ch.jobs else dict(config.DEFAULT_PARAMS.get(job, {}))

        def record(name, job, n, acc):
            key = next((c.key for c in self.bridge.settings.characters if c.instance == name
                        and (acc is None or (c.kingdom == acc.kingdom and c.name == acc.name))), None)
            if key:
                self.bridge.state.add(key, job, n)
                self.bridge.state.save()

        def discover(name):
            serial = dict(self.instances).get(name)
            if serial:
                return serial
            from intel_adb import adb as A
            devs = A.discover(only=name)
            return devs[0].serial if devs else None

        def notify(text):
            self.log("Build a bot", text)
            self.activity.emit(no_emoji(text), "info")
            self.notify(text)
        return BD.Env(launcher=self.launcher, log=lambda t: self.log("Build a bot", t), notify=notify,
                      before_game=self.launcher.before_game, job_params=job_params, record=record,
                      discover=discover, active=self.bridge.engine.active), catalogue.load()

    def run_bots(self, templates, names=None, then_autopilot=False, why="Build a bot"):
        """Run templates (in order) on each instance, every instance on its own thread. Returns
        the number of instances started."""
        if self.bot_run:
            self.toast("A bot is already running: stop it first", "warn")
            return 0
        bad = [f"{t['name']}: {p}" for t in templates for p in BD.problems(t)]
        if bad:
            self.toast(bad[0], "warn")
            return 0
        names = names or self.bot_instances(templates)
        if not names:
            self.toast("No instance to run on: open one, or switch Start on in Settings → Start and close "
                       "instances", "warn")
            return 0
        env, entries = self._bot_env()
        stop = threading.Event()
        run = {"stop": stop, "names": list(names), "tids": [t["id"] for t in templates], "left": len(names),
               "results": []}
        self.bot_run = run
        label = " → ".join(t["name"] for t in templates)
        self.log("Build a bot", f"{why}: {label} on {', '.join(names)}")
        self.activity.emit(f"{why}: {label} on {', '.join(names)}", "info")

        def status(tid, inst):
            return lambda t_, bid, st, text: self.builder_status.emit(t_, inst, bid, st, no_emoji(text))

        def one(name):
            try:
                res = BD.run_instance(templates, name, env, entries, stop=stop, status=status(None, name))
            except Exception as e:  # noqa: BLE001
                res = [("", "", False, f"error: {e!r}")]
                self.log("Build a bot", f"[{name}] {e!r}")
            run["results"] += [(name, *r) for r in res]
            self._from_thread.emit(lambda: self._bot_done(run, name, then_autopilot))

        for i, name in enumerate(names):
            delay = i * 2  # a short stagger: boots are limited to two at a time anyway
            started = self.bridge.engine.run_exclusive(
                name, lambda n=name, d=delay: (stop.wait(d), None if stop.is_set() else one(n)))
            if not started:
                self.log("Build a bot", f"[{name}] skipped: an Autopilot session is running there")
                run["left"] -= 1
        self.builder_changed.emit()
        if run["left"] <= 0:
            self.bot_run = None
            self.builder_changed.emit()
        return run["left"]

    def _bot_done(self, run, name, then_autopilot):
        run["left"] -= 1
        if run["left"] > 0:
            return
        self.bot_run = None
        ok = [r for r in run["results"] if r[3]]
        text = f"Bot finished: {len(ok)} of {len(run['results'])} runs worked"
        self.activity.emit(text, "ok" if len(ok) == len(run["results"]) else "warn")
        self.notify(f"🧱 {text}")
        self.builder_changed.emit()
        self.discover()
        if then_autopilot and not run["stop"].is_set() and not self.bridge.running:
            QTimer.singleShot(4000, self.start_autopilot)  # after discovery has seen the games

    def _run_presets(self, ch, dev):
        """Session thread: the Build-a-bot templates ticked for this character, after it's logged
        in and before its jobs. Its own choice, so the templates' filters and instance lists don't
        apply. Returns summary bits for the session line."""
        from kscommand.catalogue import Entry
        tpls = [t for tid in ch.bots if (t := BD.find(self.builder, tid))]
        if not tpls:
            return []
        env, entries = self._bot_env()
        env.device_fn = lambda n, s: dev
        acc = next((e for e in entries if e.instance == ch.instance and e.kingdom == ch.kingdom
                    and e.name == ch.name), None) or Entry(player_id="", name=ch.name, tag=ch.tag,
                                                          kingdom=ch.kingdom, power=ch.power, instance=ch.instance)
        if ch.kingdom is None:
            acc = None  # "Logged-in character": whoever is logged in
        env.active.setdefault(ch.instance, ch.key)
        out = []
        for t in tpls:
            ok, msg = BD.Run(t, ch.instance, env, serial=dev.serial, stop=self.bridge.engine._stop, account=acc).run()
            self.bridge.log.emit(f"  bot {t['name']}: {'done' if ok else 'stopped'} - {msg}")
            out.append(f"{t['name']} {'ok' if ok else 'failed'}")
            if msg == "stopped" and self.bridge.engine._stop.is_set():
                break
        try:  # the jobs expect the game in front
            if dev.foreground_package() != BD.KINGSHOT:
                dev._adb("shell", "monkey", "-p", BD.KINGSHOT, "-c", "android.intent.category.LAUNCHER", "1")
                self.bridge.engine._stop.wait(8)
        except Exception:  # noqa: BLE001
            pass
        return out

    def stop_bots(self):
        if self.bot_run:
            self.bot_run["stop"].set()
            self.toast("Stopping the bot after the current step", "warn")

    # ---------------------------------------------------------------- character catalogue
    def learning(self, name):
        return name in self._char_stops

    def learn_characters(self, name, serial=None):
        """Walk every character on one instance and record it in the catalogue (Characters page).
        Autopilot keeps off that instance meanwhile; the first character is logged back in."""
        from kscommand import catalogue as K
        serial = serial or dict(self.instances).get(name)
        if not serial:
            self.toast(f"{name} isn't connected: open Kingshot there and press Refresh", "warn")
            return False
        if name in self._char_stops:
            return False
        stop = threading.Event()
        self._char_stops[name] = stop
        eng = self.bridge.engine

        def emit(done, total, text):
            self.characters_progress.emit(name, done, max(total, 1), no_emoji(text))

        def work():
            res = None
            try:
                dev = device(name, serial)
                if dev.foreground_package() not in (None, "", KINGSHOT):
                    raise RuntimeError("Kingshot isn't in front on this instance")
                res = K.learn(dev, name, log=lambda t: self.log("Characters", f"[{name}] {t}"),
                              progress=emit, stop=stop)
            except K.Stopped:
                res = "stopped"
            except Exception as e:  # noqa: BLE001
                res = e
            self._from_thread.emit(lambda: self._learned_characters(name, res))

        if not eng.run_exclusive(name, work):
            del self._char_stops[name]
            self.toast(f"An Autopilot session is running on {name}. Try again when it's done.", "warn")
            return False
        self.log("Characters", f"[{name}] learning every character")
        self.characters_progress.emit(name, 0, 1, "opening the Governor Profile")
        return True

    def stop_learning(self, name):
        ev = self._char_stops.get(name)
        if ev:
            ev.set()
            self.characters_progress.emit(name, 0, 1, "stopping after this step")

    def _learned_characters(self, name, res):
        from autopilot import characters as CH
        from kscommand import catalogue as K
        self._char_stops.pop(name, None)
        eng = self.bridge.engine
        eng.active.pop(name, None)  # the logged-in character may have changed
        if res == "stopped":
            self.characters_progress.emit(name, 0, 0, "Stopped")
            self.toast(f"Stopped learning characters on {name}", "warn")
        elif isinstance(res, Exception):
            self.characters_progress.emit(name, 0, 0, f"Failed: {res}")
            self.toast(f"Characters on {name}: {res}", "bad")
            self.log("Characters", f"[{name}] failed: {res!r}")
        else:
            read, changes, last = res
            entries = K.load()
            active = None
            if last is not None:
                active = next((e for e in entries if e.instance == name and e.kingdom == last.kingdom
                               and CH.same_name(last.name, e.name)), None)
            if K.sync_autopilot(self.bridge.settings, entries, active):
                self.bridge.save()
                self.autopilot_changed.emit()
            if active is not None:
                ch = next((c for c in self.bridge.settings.characters if c.instance == name
                           and c.kingdom == active.kingdom and CH.same_name(c.name, active.name)), None)
                if ch is not None:
                    eng.active[name] = ch.key
            bits = [f"{len(read)} characters"]
            if changes["new"]:
                bits.append(f"{len(changes['new'])} new")
            if changes["renamed"]:
                bits.append("renamed " + ", ".join(f"{a} to {b}" for a, b in changes["renamed"]))
            no_id = sum(1 for e in read if not e.player_id)
            if no_id:
                bits.append(f"{no_id} without an ID")
            text = ", ".join(bits)
            self.characters_progress.emit(name, 0, 0, f"Done: {text}")
            self.toast(f"{name}: {text}", "ok" if not no_id else "warn")
            self.activity.emit(f"{name}: learned {text}", "ok")
            self.notify(f"{name}: learned {text}")
        self.characters_changed.emit()

    # ---------------------------------------------------------------- learned skills
    @property
    def update_url(self):
        return self.settings.update_url.strip() or L.DEFAULT_UPDATE_URL

    def run_learned(self, when, name, serial):
        """Any thread: play the installed skills for `when` on one instance."""
        found = L.skills(when, name, self.settings.learned_off)
        if not found:
            return []
        self.log("Learned", f"{name}: {', '.join(s.get('title', s['id']) for s in found)}")
        res = L.run_hook(when, name, serial, self.settings.learned_off,
                         log=lambda t: self.log("Learned", t))
        for _, ok, msg in res:
            self.activity.emit(msg, "ok" if ok else "warn")
        return res

    def check_learned(self, silent=False, done=None):
        """Look for a newer learned-skills pack (background). done(index or Exception)."""
        def finish(res):
            if isinstance(res, Exception):
                self.log("Learned", f"update check failed: {res}")
                if not silent:
                    self.toast(f"Couldn't check for updates: {res}", "bad")
            elif res["version"] > L.installed().get("version", 0) or SU.newer(res, self.version):
                app = SU.newer(res, self.version)
                what = []
                if res["version"] > L.installed().get("version", 0):
                    what.append(f"learned skills update {res['version']}")
                if app:
                    what.append(f"Kingshot Command {app['version']}")
                self.log("Updates", f"ready: {', '.join(what)}")
                self.update_available.emit(res)
                self.activity.emit(f"Ready to install: {' and '.join(what)}. Press Update on the Teacher page", "info")
                if app:
                    self.toast(f"Kingshot Command {app['version']} is ready: press Update on the Teacher page", "info")
            elif not silent:
                self.toast("Learned skills are up to date", "ok")
            if done:
                done(res)
        self.in_thread(lambda: L.check(self.update_url), finish)

    def apply_learned(self, done=None, path=None):
        """Download and install the newest pack (or install the zip at `path`)."""
        def work():
            if path:
                return L.install_zip(path), True, None, None
            info = L.check(self.update_url)
            pack, changed = L.update(self.update_url)
            app = SU.newer(info, self.version)
            return pack, changed, app, (SU.prepare(app, core.ROOT) if app else None)

        def finish(res):
            if isinstance(res, Exception):
                self.log("Learned", f"update failed: {res}")
                self.toast(f"Update failed: {res}", "bad")
            else:
                pack, changed, app, staged = res
                names = ", ".join(s.get("title", s["id"]) for s in pack.get("skills", [])) or "none"
                if changed:
                    self.log("Learned", f"installed update {pack['version']}: {names}")
                    self.activity.emit(f"Learned update {pack['version']} installed: {names}", "ok")
                if staged:
                    self.restart_into(app, staged)
                elif changed:
                    self.toast(f"Learned update {pack['version']} installed", "ok")
                else:
                    self.toast("Everything is up to date", "ok")
                self.learned_changed.emit()
            if done:
                done(res)
        self.in_thread(work, finish)

    @property
    def version(self):
        import kscommand
        return kscommand.__version__

    def restart_into(self, app, staged):
        """Hand the prepared app update ((kind, path) from selfupdate.prepare) to the updater and
        quit; it starts the new version."""
        kind, path = staged
        how = "full install" if kind == "installer" else "code update"
        self.log("Updates", f"installing Kingshot Command {app['version']} ({how}) and restarting")
        self.toast(f"Installing Kingshot Command {app['version']}: the app restarts in a moment", "info")
        try:
            SU.hand_over(path, core.ROOT, kind=kind)
        except Exception as e:  # noqa: BLE001
            self.log("Updates", f"couldn't start the updater: {e!r}")
            self.toast(f"App update failed: {e}", "bad")
            return
        QTimer.singleShot(1500, self.window.quit)

    def roll_back_learned(self):
        pack = L.roll_back()
        if pack is None:
            self.toast("There's no earlier update to go back to", "warn")
            return
        self.log("Learned", f"rolled back to update {pack.get('version', 0)}")
        self.toast(f"Back on learned update {pack.get('version', 0)}", "ok")
        self.learned_changed.emit()

    # ---------------------------------------------------------------- helpers
    def toast(self, text, kind="info"):
        Toast(self.window.centralWidget(), text, kind)

    def save_settings(self):
        core.save(self.settings)

    def notify(self, text):
        if self.telegram and self.settings.telegram_events:
            self.telegram.send(text)

    def in_thread(self, fn, done=None):
        def work():
            try:
                res = fn()
            except Exception as e:  # noqa: BLE001
                res = e
            if done:
                try:
                    self._from_thread.emit(lambda: done(res))
                except RuntimeError:  # the window closed meanwhile
                    pass
        threading.Thread(target=work, daemon=True).start()

    def save_screenshot(self, name, send=False):
        serial = dict(self.instances).get(name) or self.watchdog.devices.get(name)
        if not serial:
            self.toast(f"{name} isn't connected", "warn")
            return

        def shot():
            img = device(name, serial).screencap(tries=1)
            core.SHOTS_DIR.mkdir(exist_ok=True)
            path = core.SHOTS_DIR / f"{name}-{datetime.now():%Y%m%d-%H%M%S}.png".replace(" ", "_")
            data = png(img)
            path.write_bytes(data)
            return path, data

        def done(res):
            if isinstance(res, Exception):
                self.toast(f"Screenshot failed: {res}", "bad")
                return
            path, data = res
            if send and self.telegram:
                self.telegram.send_photo(data, name)
            else:
                self.toast(f"Saved {path.name}", "ok")
        self.in_thread(shot, done)

    def set_resolution(self, low, quiet=False):
        names = [n for n, _ in self.instances]
        if not names:
            if not quiet:
                self.toast("No instance found", "warn")
            return
        self.settings.low_res = low
        self.save_settings()
        self.in_thread(lambda: B.C.apply_resolution(names, low),
                       lambda msgs: None if quiet else [self.log("App", m) for m in (msgs if isinstance(msgs, list) else [str(msgs)])]
                       or self.toast("Resolution " + ("lowered" if low else "reset"), "ok"))

    def lighten_emulators(self, undo=False):
        """Lower CPU, RAM, frame rate, screen size and sound on every BlueStacks/MuMu instance
        (kscommand.lean), or put the user's own values back."""
        from kscommand import lean
        lt = lean.Lightener(core.ROOT / "lean_backup.json", log=lambda m: self.log("Emulators", m))
        targets = self.emulator_targets()

        def done(msgs):
            msgs = msgs if isinstance(msgs, list) else [f"Couldn't change emulator settings: {msgs}"]
            for m in msgs:
                self.log("Emulators", m)
            bad = any("close every" in m or "refused" in m or "couldn't" in m.lower() for m in msgs)
            self.toast(" · ".join(msgs), "warn" if bad else "ok")
        self.in_thread(lambda: lt.undo() if undo else lt.lighten(targets), done)

    def release_touches(self):
        def work():
            for n, _ in self.instances:
                subprocess.run([core.python_console(), "-m", "intel_adb.touch", "--release", n], cwd=core.ROOT,
                               capture_output=True, timeout=30, creationflags=core.NO_WINDOW)
        self.in_thread(work, lambda _r: self.toast("Touches released", "ok"))

    def apply_startup(self, on):
        try:
            core.set_start_with_windows(on)
        except OSError as e:
            self.toast(f"Couldn't change start-up: {e}", "bad")

    def set_accent(self, name):
        self.settings.accent = name
        self.save_settings()
        QApplication.instance().setStyleSheet(theme.stylesheet(name))
        self.toast("Accent changed. Some controls update after a restart.", "info")

    # ---------------------------------------------------------------- telegram
    def start_telegram(self):
        if self.telegram:
            self.telegram.stop()
            self.telegram = None
        if not self.settings.telegram_token:
            self.telegram_status.emit("not set up")
            return
        self.telegram = Telegram(self.settings.telegram_token, self.settings.telegram_chat, self)
        self.telegram.status.connect(self.telegram_status.emit)
        self.telegram.command.connect(self._tg_command)
        self.telegram.start()
        self.telegram_status.emit("connecting…")

    def _tg_command(self, chat, cmd, arg):
        tg = self.telegram
        if cmd in ("help", "start") and not arg and cmd == "help":
            tg.send(__import__("kscommand.services", fromlist=["HELP"]).HELP)
        elif cmd == "status":
            lines = [f"Autopilot: {'running' if self.bridge.running else 'stopped'}"
                     f"{' · ' + self.bridge.engine.current if self.bridge.engine.current else ''}",
                     f"Instances: {', '.join(n for n, _ in self.instances) or 'none'}",
                     f"Bots: {', '.join(B.BY_ID[b].title for b in self.procs.running()) or 'none'}",
                     f"Actions today: {self.actions_today()}",
                     f"Next session: {self.next_session_text()}"]
            tg.send("\n".join(lines))
        elif cmd == "start":
            if not self.bridge.running:
                self.start_autopilot()
            tg.send("▶ Autopilot running")
        elif cmd == "stop":
            self.bridge.stop()
            self.procs.stop_all("Telegram /stop")
            self.watchdog.active = False
            tg.send("■ Stopped Autopilot and every bot")
        elif cmd == "shot":
            names = [n for n, _ in self.instances if not arg or arg.lower() in n.lower()]
            if not names:
                tg.send("No such instance")
            for n in names:
                self.save_screenshot(n, send=True)
        elif cmd == "bots":
            tg.send("\n".join(f"{b.glyph} {b.id} - {b.title}" for b in B.BOTS))
        elif cmd == "run":
            bot = B.BY_ID.get(arg.lower())
            names = [n for n, _ in self.instances]
            if not bot or not names:
                tg.send("Usage: /run <bot id> (see /bots), with Kingshot open on an instance")
                return
            opts = B.options_for(bot, self.settings.bot_options.get(bot.id))
            ok = self.procs.start(bot.id, bot.build(names, opts, False, True), names)
            tg.send(f"{bot.glyph} {bot.title} {'started' if ok else 'is already running'}")
        elif cmd == "launch":
            names = [t.name for t in self.emulator_targets() if arg.lower() in t.name.lower()] if arg else None
            n = self.start_emulators(names)
            tg.send(f"🖥 Starting {n} instance(s)" if n else "Nothing to start")
        elif cmd == "close":
            names = [t.name for t in self.emulator_targets() if arg.lower() in t.name.lower()] if arg else None
            n = self.close_emulators(names)
            tg.send(f"🖥 Closing {n} instance(s)" if n else "Nothing to close")
        elif cmd == "redeem" and arg:
            self.window.pages["gift"].redeem(arg)
            tg.send(f"🎁 Redeeming {arg} for {len(self.settings.player_ids)} player(s)…")
        else:
            tg.send(__import__("kscommand.services", fromlist=["HELP"]).HELP)

    def shutdown(self):
        self.stop_bots()
        self.bridge.stop()
        self.procs.stop_all("the app is closing")
        self.previewer.stop()
        self.watchdog.stop()
        if self.telegram:
            self.telegram.stop()
        try:
            self.bridge.state.save()
            self.bridge.save()
        except Exception:
            pass


NAV = [("home", "home", "Home"), ("auto", "auto", "Autopilot"), ("chars", "chars", "Characters"), ("bots", "bots", "Bots"),
       ("build", "build", "Build a bot"), ("gift", "gift", "Gift codes"),
       ("teach", "teach", "Teacher"), ("stats", "stats", "Statistics"), ("map", "map", "Feature map"), ("logs", "logs", "Logs"),
       ("settings", "settings", "Settings")]


class Window(QMainWindow):
    def __init__(self, start_hidden=False):
        super().__init__()
        install_design(QApplication.instance())
        self.setWindowTitle(core.APP_NAME)
        self.setWindowIcon(QIcon(crown_pixmap(256)))
        self.resize(1360, 880)
        self.setMinimumSize(1000, 680)
        root = QWidget()
        root.setObjectName("root")
        self.setCentralWidget(root)
        self.hub = hub = Hub(self)
        h = QHBoxLayout(root)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(0)

        side = QFrame()
        side.setObjectName("sidebar")
        side.setFixedWidth(232)
        sv = QVBoxLayout(side)
        sv.setContentsMargins(16, 20, 16, 16)
        sv.setSpacing(4)
        brand = QHBoxLayout()
        logo = label("")
        logo.setPixmap(crown_pixmap(38, hub.settings.accent))
        brand.addWidget(logo)
        bt = QVBoxLayout()
        bt.setSpacing(0)
        bt.addWidget(label("Kingshot", "brand"))
        bt.addWidget(label("COMMAND", "brandSub"))
        brand.addLayout(bt, 1)
        sv.addLayout(brand)
        sv.addSpacing(18)
        self.nav_wrap = QWidget()
        nv = QVBoxLayout(self.nav_wrap)
        nv.setContentsMargins(0, 0, 0, 0)
        nv.setSpacing(4)
        self.indicator = QFrame(self.nav_wrap)
        self.indicator.setObjectName("navIndicator")
        self.buttons = {}
        for key, glyph, text in NAV:
            b = QPushButton(f"  {text}")
            ic = QIcon()
            ic.addPixmap(line_icon(glyph, 18, theme.C["faint"]), QIcon.Normal, QIcon.Off)
            ic.addPixmap(line_icon(glyph, 18, theme.C["text"]), QIcon.Normal, QIcon.On)
            ic.addPixmap(line_icon(glyph, 18, theme.C["text"]), QIcon.Active, QIcon.Off)
            b.setIcon(ic)
            b.setIconSize(QSize(18, 18))
            b.setObjectName("navBtn")
            b.setCheckable(True)
            b.setAutoExclusive(True)
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda _=False, k=key: self.go(k))
            nv.addWidget(b)
            self.buttons[key] = b
        sv.addWidget(self.nav_wrap)
        sv.addStretch()
        mini = QFrame()
        mini.setObjectName("card")
        mv = QHBoxLayout(mini)
        mv.setContentsMargins(12, 10, 12, 10)
        self.mini_dot = PulseDot("idle", 10)
        mv.addWidget(self.mini_dot)
        mt = QVBoxLayout()
        mt.setSpacing(0)
        self.mini_title = label("Autopilot off", "h2")
        self.mini_sub = label("", "faint")
        mt.addWidget(self.mini_title)
        mt.addWidget(self.mini_sub)
        mv.addLayout(mt, 1)
        sv.addWidget(mini)
        h.addWidget(side)

        self.stack = QStackedWidget()
        self.pages = {
            "home": pages.Dashboard(hub), "auto": pages.AutopilotPage(hub), "chars": pages.CharactersPage(hub),
            "bots": pages.BotsPage(hub), "build": pages.BuilderPage(hub),
            "gift": pages.GiftPage(hub), "teach": pages.TeacherPage(hub), "stats": pages.StatsPage(hub), "map": pages.CoveragePage(hub),
            "logs": pages.LogsPage(hub), "settings": pages.SettingsPage(hub),
        }
        for p in self.pages.values():
            self.stack.addWidget(p)
        h.addWidget(self.stack, 1)
        self._ind_anim = QPropertyAnimation(self.indicator, b"geometry", self)
        self._ind_anim.setDuration(theme.T_SHEET)
        self._ind_anim.setEasingCurve(theme.ease())
        self.current = "home"
        self.buttons["home"].setChecked(True)

        hub.autopilot_changed.connect(self.sync_mini)
        hub.procs.changed.connect(self.sync_mini)
        self.sync_mini()
        self._tray()
        hub.log("App", f"{core.APP_NAME} started from {core.ROOT}")
        QTimer.singleShot(150, self._place_indicator)
        QTimer.singleShot(300, hub.discover)
        if hub.settings.telegram_token:
            QTimer.singleShot(800, hub.start_telegram)
        if hub.settings.first_run:
            hub.settings.first_run = False
            hub.save_settings()
            QTimer.singleShot(1200, lambda: hub.toast("Welcome! Open Kingshot in your emulator. "
                                                      "Autopilot starts on its own once it sees the game.", "info"))
        if not start_hidden:
            self.show()

    def _place_indicator(self, animate=False):
        b = self.buttons[self.current]
        g = QRect(0, b.y() + 10, 3, b.height() - 20)
        if animate:
            self._ind_anim.stop()
            self._ind_anim.setEndValue(g)
            self._ind_anim.start()
        else:
            self.indicator.setGeometry(g)
        self.indicator.raise_()

    def go(self, key):
        if key == self.current:
            return
        self.current = key
        self.buttons[key].setChecked(True)
        page = self.pages[key]
        self.stack.setCurrentWidget(page)
        slide_fade_in(page)
        self._place_indicator(animate=True)
        self.hub.previewer.enabled = key == "home" or not self.isVisible()
        if key == "stats":
            page.reload()

    def sync_mini(self):
        br = self.hub.bridge
        n = len(self.hub.procs.running())
        if br.running:
            self.mini_dot.set_status("running")
            self.mini_title.setText("Autopilot on")
        else:
            self.mini_dot.set_status("running" if n else "idle")
            self.mini_title.setText("Autopilot off")
        self.mini_sub.setText(f"{n} bot(s) running" if n else f"{len(self.hub.instances)} instance(s)")
        if hasattr(self, "tray_toggle"):
            self.tray_toggle.setText("Stop Autopilot" if br.running else "Start Autopilot")
            self.tray.setToolTip(f"{core.APP_NAME} · {self.mini_title.text()}")

    def _tray(self):
        self.tray = QSystemTrayIcon(QIcon(crown_pixmap(64, self.hub.settings.accent)), self)
        m = QMenu()
        show = QAction("Open", self)
        show.triggered.connect(self.bring_up)
        self.tray_toggle = QAction("Start Autopilot", self)
        self.tray_toggle.triggered.connect(self.hub.toggle_autopilot)
        quit_ = QAction("Quit", self)
        quit_.triggered.connect(self.quit)
        m.addAction(show)
        m.addAction(self.tray_toggle)
        m.addSeparator()
        m.addAction(quit_)
        self.tray.setContextMenu(m)
        self.tray.activated.connect(lambda r: self.bring_up() if r == QSystemTrayIcon.Trigger else None)
        if QSystemTrayIcon.isSystemTrayAvailable():
            self.tray.show()
        self.sync_mini()

    def bring_up(self):
        self.showNormal()
        self.raise_()
        self.activateWindow()
        self.hub.previewer.enabled = self.current == "home"

    def closeEvent(self, e):
        if self.hub.settings.minimize_to_tray and QSystemTrayIcon.isSystemTrayAvailable() and not getattr(self, "_quitting", False):
            e.ignore()
            self.hide()
            self.hub.previewer.enabled = False
            if not getattr(self, "_told", False):
                self._told = True
                self.tray.showMessage(core.APP_NAME, "Still running in the tray. Right-click the crown to quit.",
                                      QIcon(crown_pixmap(64)), 4000)
            return
        self.quit()

    def quit(self):
        self._quitting = True
        self.hub.shutdown()
        self.tray.hide()
        QApplication.instance().quit()

    def resizeEvent(self, e):
        super().resizeEvent(e)
        QTimer.singleShot(0, self._place_indicator)


def _already_running():
    s = QLocalSocket()
    s.connectToServer(INSTANCE_ID)
    if s.waitForConnected(300):
        s.write(b"show")
        s.flush()
        s.waitForBytesWritten(300)
        return True
    return False


def _log_crash():
    """Python errors go to logs/crash.log; hard crashes (inside Qt or a C library) leave their
    Python stack in logs/fault.log."""
    import faulthandler
    import traceback
    try:
        core.LOG_DIR.mkdir(exist_ok=True)
        _log_crash.fault = open(core.LOG_DIR / "fault.log", "a", encoding="utf-8")
        faulthandler.enable(_log_crash.fault, all_threads=True)
    except OSError:
        pass

    def hook(t, v, tb):
        try:
            core.LOG_DIR.mkdir(exist_ok=True)
            with open(core.LOG_DIR / "crash.log", "a", encoding="utf-8") as f:
                f.write(f"\n--- {datetime.now()}\n{''.join(traceback.format_exception(t, v, tb))}")
        except OSError:
            pass
        if sys.stderr:
            sys.__excepthook__(t, v, tb)
    sys.excepthook = hook
    threading.excepthook = lambda a: hook(a.exc_type, a.exc_value, a.exc_traceback)


class Typography(QObject):
    """Letter spacing and caps per object name (theme.TRACKING); QSS can't express either. Also
    places every dropdown's popup list under its field."""

    def eventFilter(self, obj, event):
        if event.type() == QEvent.Show and isinstance(obj, QWidget) \
                and obj.metaObject().className() == "QComboBoxPrivateContainer":
            place_combo_popup(obj)  # every dropdown in the app opens under its field
            QTimer.singleShot(0, lambda o=obj: o.isVisible() and place_combo_popup(o))
        if event.type() == QEvent.Wheel and wheel_to_page(obj, event):
            return True  # scrolling past a dropdown or number box scrolls the page, never its value
        if event.type() == QEvent.Polish and isinstance(obj, QWidget):
            calm_inputs(obj)
            spec = theme.TRACKING.get(obj.objectName())
            if spec:
                f = obj.font()
                f.setLetterSpacing(QFont.PercentageSpacing, spec[0])
                if spec[1]:
                    f.setCapitalization(QFont.AllUppercase)
                obj.setFont(f)
            elif isinstance(obj, QHeaderView):
                f = obj.font()
                f.setLetterSpacing(QFont.PercentageSpacing, 110)
                f.setCapitalization(QFont.AllUppercase)
                obj.setFont(f)
        return False


def _load_fonts():
    """Inter ships with the app (OFL), so the type is the same on every PC."""
    from pathlib import Path
    for ttf in sorted((Path(__file__).parent / "fonts").glob("*.ttf")):
        QFontDatabase.addApplicationFont(str(ttf))


def install_design(app):
    """Fonts and label typography; safe to call more than once."""
    if getattr(app, "_typography", None):
        return
    _load_fonts()
    app._typography = Typography(app)
    app.installEventFilter(app._typography)


def main(argv=None):
    argv = sys.argv if argv is None else argv
    _log_crash()
    QApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    app = QApplication(argv)
    app.setApplicationName(core.APP_NAME)
    app.setQuitOnLastWindowClosed(False)
    if _already_running():
        return 0
    server = QLocalServer()
    QLocalServer.removeServer(INSTANCE_ID)
    server.listen(INSTANCE_ID)
    app.setStyleSheet(theme.stylesheet(core.load().accent))
    win = Window(start_hidden="--tray" in argv)
    server.newConnection.connect(lambda: (server.nextPendingConnection(), win.bring_up()))
    shot = next((a.split("=", 1)[1] for a in argv if a.startswith("--screenshot=")), None)
    if shot:  # build check: render every page to PNGs and quit
        _screenshots(win, shot)
        return 0
    return app.exec()


def _screenshots(win, folder):
    from pathlib import Path
    out = Path(folder)
    out.mkdir(parents=True, exist_ok=True)
    app = QApplication.instance()
    win.show()
    for key, _, _ in NAV:
        win.go(key)
        t = time.time()
        while time.time() - t < 1.9:
            app.processEvents()
            time.sleep(0.02)
        win.grab().save(str(out / f"{key}.png"))
    win.quit()


if __name__ == "__main__":
    sys.exit(main())
