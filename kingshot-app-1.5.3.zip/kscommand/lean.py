"""Lighter emulator instances: lowers what each BlueStacks or MuMu instance gets (CPU cores,
RAM, frame rate, screen size, sound) to what a screen bot needs. Kingshot stays the real game on
a real Android; only the emulator's settings change.

Values are only ever lowered: an instance already set below the target keeps its own value.
Everything changed is remembered in app\\lean_backup.json (BlueStacks also gets a copy of
bluestacks.conf next to it), so undo() puts it back.

BlueStacks: bluestacks.conf is rewritten, so every BlueStacks window must be closed first.
MuMu: MuMuManager setting -v N; a running instance picks the change up when it restarts."""
import json
import re
import shutil
import subprocess
import time
from pathlib import Path

from intel_adb import adb as A
from kscommand import emulators as E

# Per instance. Kingshot renders at 702x1248 whatever the screen size (measured), so the screen
# mainly shrinks screenshots; the frame rate and cores are what the CPU feels.
CPUS = 2
RAM_MB = 2048  # enough for Kingshot on Pie 64-bit; raise to 3072 if the game gets killed in the background
FPS = 20  # the bots screenshot every second or so; 60 fps only burns CPU
WIDTH, HEIGHT, DPI = 540, 960, 240  # the bots' native frame

BS_LOWER = {"cpus": CPUS, "ram": RAM_MB, "max_fps": FPS}  # numeric, only lowered
BS_OFF = ("enable_high_fps", "enable_vsync")  # 1 -> 0
BS_GLOBAL = {"bst.mute_all_instances": "1"}

MUMU_LOWER = {"performance_cpu.custom": CPUS, "performance_mem.custom": RAM_MB / 1024, "max_frame_rate": FPS}
MUMU_SET = {"performance_mode": "custom", "vertical_sync": "false", "dynamic_adjust_frame_rate": "true",
            "dynamic_low_frame_rate_limit": "15", "system_volume_close": "true"}


def _num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _fmt(v, like):
    """v written the way the old value was (MuMu keeps "2.000000", BlueStacks "2048")."""
    if like and "." in str(like):
        return f"{float(v):.6f}"
    return str(int(v)) if float(v) == int(v) else str(v)


# ---------------------------------------------------------------- BlueStacks
def bs_plan(text, ids=None):
    """[(key, old, new)] for bluestacks.conf. ids: instance ids to change (default all)."""
    inst = sorted(set(re.findall(r'^bst\.instance\.([^.]+)\.', text, re.M)))
    if ids is not None:
        inst = [i for i in inst if i in ids]
    get = lambda k: (re.search(rf'^{re.escape(k)}="([^"]*)"', text, re.M) or [None, None])[1]
    out = []
    for i in inst:
        p = f"bst.instance.{i}."
        if get(p + "cpus") is None:  # not a real instance block (e.g. leftovers)
            continue
        for k, target in BS_LOWER.items():
            old = get(p + k)
            n = _num(old)
            if n is not None and n > target:
                out.append((p + k, old, _fmt(target, old)))
        for k in BS_OFF:
            old = get(p + k)
            if old not in (None, "0"):
                out.append((p + k, old, "0"))
        w, h = _num(get(p + "fb_width")), _num(get(p + "fb_height"))
        if w and h and w * h > WIDTH * HEIGHT:
            nw, nh = (WIDTH, HEIGHT) if h >= w else (HEIGHT, WIDTH)  # keep the orientation it had
            out += [(p + "fb_width", get(p + "fb_width"), str(nw)), (p + "fb_height", get(p + "fb_height"), str(nh))]
            if (_num(get(p + "dpi")) or 0) > DPI:
                out.append((p + "dpi", get(p + "dpi"), str(DPI)))
    for k, v in BS_GLOBAL.items():
        old = get(k)
        if old is not None and old != v:
            out.append((k, old, v))
    return out


def bs_apply(text, changes):
    for key, _, new in changes:
        text = re.sub(rf'^{re.escape(key)}="[^"]*"', f'{key}="{new}"', text, count=1, flags=re.M)
    return text


def bluestacks_running(runner=subprocess.run):
    try:
        out = runner(["tasklist"], capture_output=True, text=True, creationflags=E.NO_WINDOW).stdout or ""
    except Exception:
        return False
    return any(n in out for n in ("HD-Player.exe", "HD-MultiInstanceManager.exe"))


def _write_conf(conf, text, runner):
    """BlueStacks' conf is sometimes read-only (to stop it rewriting); keep the flag as it was."""
    ro = False
    try:
        ro = "R" in runner(["attrib", str(conf)], capture_output=True, text=True,
                           creationflags=E.NO_WINDOW).stdout[:12]
        if ro:
            runner(["attrib", "-R", str(conf)], capture_output=True, creationflags=E.NO_WINDOW)
    except Exception:
        pass
    try:
        conf.write_text(text, encoding="utf-8", newline="\n")
    finally:
        if ro:
            runner(["attrib", "+R", str(conf)], capture_output=True, creationflags=E.NO_WINDOW)


# ---------------------------------------------------------------- MuMu
def mumu_read(manager, idx, keys, runner=subprocess.run):
    """{key: value} of one MuMu instance (MuMuManager prints JSON)."""
    cmd = [manager, "setting", "-v", str(idx)]
    for k in keys:
        cmd += ["-k", k]
    out = runner(cmd, capture_output=True, timeout=30, creationflags=E.NO_WINDOW).stdout or b""
    out = out.decode("utf-8", errors="ignore") if isinstance(out, bytes) else out
    try:
        data = json.loads(out)
        return {k: str(v) for k, v in data.items()} if isinstance(data, dict) else {}
    except ValueError:
        return dict(re.findall(r'"([\w.]+)"\s*:\s*"([^"]*)"', out))


def mumu_plan(current):
    """{key: new} for one MuMu instance, from its current values."""
    out = {}
    for k, target in MUMU_LOWER.items():
        n = _num(current.get(k))
        if n is None or n > target:
            out[k] = _fmt(target, current.get(k) or ("1.0" if k == "performance_mem.custom" else ""))
    for k, v in MUMU_SET.items():
        if current.get(k) != v:
            out[k] = v
    return out


def mumu_write(manager, idx, values, runner=subprocess.run):
    cmd = [manager, "setting", "-v", str(idx)]
    for k, v in values.items():
        cmd += ["-k", k, "-val", str(v)]
    r = runner(cmd, capture_output=True, timeout=30, creationflags=E.NO_WINDOW)
    return getattr(r, "returncode", 0) == 0


# ---------------------------------------------------------------- both
class Lightener:
    def __init__(self, backup_path, conf_path=None, runner=subprocess.run, log=print):
        self.backup_path = Path(backup_path)
        self.conf = Path(conf_path or A.CONF_PATH)
        self.runner, self.log = runner, log

    def _load(self):
        try:
            return json.loads(self.backup_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {"bluestacks": {}, "mumu": {}}

    def _save(self, data):
        self.backup_path.write_text(json.dumps(data, indent=1), encoding="utf-8")

    def lighten(self, targets):
        """Lower every BlueStacks/MuMu target. Returns [message] for the log."""
        msgs, data = [], self._load()
        bs = [t for t in targets if t.kind == "bluestacks"]
        if bs and self.conf.exists():
            text = self.conf.read_text(encoding="utf-8", errors="ignore")
            changes = bs_plan(text, {t.ident for t in bs})
            if not changes:
                msgs.append("BlueStacks: already light")
            elif bluestacks_running(self.runner):
                msgs.append("BlueStacks: close every BlueStacks window (and the Multi-Instance Manager), "
                            "then press Make lighter again")
            else:
                shutil.copy2(self.conf, self.conf.with_name(f"bluestacks.conf.before_light_{time.strftime('%Y%m%d_%H%M%S')}"))
                for key, old, _ in changes:
                    data["bluestacks"].setdefault(key, old)  # first value seen is the user's own
                _write_conf(self.conf, bs_apply(text, changes), self.runner)
                self._save(data)
                msgs.append(f"BlueStacks: {len(changes)} setting(s) lowered on {len(bs)} instance(s)")
        for t in (t for t in targets if t.kind == "mumu"):
            root, idx = t.ident.rsplit("|", 1)
            man = E.mumu_manager(root)
            try:
                cur = mumu_read(man, idx, list(MUMU_LOWER) + list(MUMU_SET), self.runner)
                new = mumu_plan(cur)
                if not new:
                    msgs.append(f"{t.name}: already light")
                    continue
                if mumu_write(man, idx, new, self.runner):
                    old = data["mumu"].setdefault(t.ident, {})
                    for k in new:
                        if k in cur:
                            old.setdefault(k, cur[k])
                    self._save(data)
                    msgs.append(f"{t.name}: {len(new)} setting(s) lowered (applies when it next starts)")
                else:
                    msgs.append(f"{t.name}: MuMuManager refused the change")
            except Exception as e:  # noqa: BLE001
                msgs.append(f"{t.name}: couldn't change settings: {e}")
        return msgs or ["No BlueStacks or MuMu instances to change"]

    def undo(self):
        msgs, data = [], self._load()
        if data["bluestacks"]:
            if bluestacks_running(self.runner):
                msgs.append("BlueStacks: close every BlueStacks window first, then press Undo again")
            else:
                text = self.conf.read_text(encoding="utf-8", errors="ignore")
                _write_conf(self.conf, bs_apply(text, [(k, None, v) for k, v in data["bluestacks"].items()]),
                            self.runner)
                msgs.append(f"BlueStacks: {len(data['bluestacks'])} setting(s) put back")
                data["bluestacks"] = {}
        for ident, old in list(data["mumu"].items()):
            root, idx = ident.rsplit("|", 1)
            if not old or mumu_write(E.mumu_manager(root), idx, old, self.runner):
                msgs.append(f"MuMu {idx}: {len(old)} setting(s) put back")
                data["mumu"].pop(ident)
            else:
                msgs.append(f"MuMu {idx}: MuMuManager refused the change")
        self._save(data)
        return msgs or ["Nothing to undo"]
