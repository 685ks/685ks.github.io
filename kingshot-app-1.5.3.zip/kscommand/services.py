"""Background work for the window: bot processes, instance discovery, live previews,
the Autopilot engine, the keep-alive watchdog and the Telegram link. Everything talks to
the UI through Qt signals, so no widget is touched off the main thread."""
import threading
import time

import cv2
from PySide6.QtCore import QObject, QProcess, QProcessEnvironment, QThread, Signal

from intel_adb import commands as C
from kscommand import core

KINGSHOT = "com.run.tower.defense"


# ---------------------------------------------------------------- bot processes
class ProcessManager(QObject):
    line = Signal(str, str)  # bot id, text
    instance_state = Signal(str, str)  # instance, idle|running|stopped
    changed = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.procs = {}  # bot id -> QProcess
        self.started = {}  # bot id -> (names, epoch)
        self._buf = {}
        self.stopping = {}  # bot id -> why the app is stopping it (a kill reads as "Crashed")

    def running(self):
        return [b for b, p in self.procs.items() if p.state() != QProcess.NotRunning]

    def start(self, bot_id, argv, names):
        if bot_id in self.running():
            return False
        p = QProcess(self)
        env = QProcessEnvironment.systemEnvironment()
        env.insert("PYTHONUNBUFFERED", "1")
        env.insert("PYTHONIOENCODING", "utf-8")
        env.remove("PYTHONHOME")
        p.setProcessEnvironment(env)
        p.setWorkingDirectory(str(core.ROOT))
        p.setProcessChannelMode(QProcess.MergedChannels)
        p.readyReadStandardOutput.connect(lambda b=bot_id, q=p: self._read(b, q))
        p.finished.connect(lambda code, _st, b=bot_id: self._done(b, code))
        p.errorOccurred.connect(lambda err, b=bot_id: self._error(b, err))
        self.stopping.pop(bot_id, None)
        self.procs[bot_id] = p
        self.started[bot_id] = (list(names), time.time())
        self._buf[bot_id] = ""
        p.start(argv[0], argv[1:])
        for n in names:
            self.instance_state.emit(n, "running")
        self.changed.emit()
        return True

    def _read(self, bot_id, p):
        data = self._buf.get(bot_id, "") + bytes(p.readAllStandardOutput()).decode("utf-8", "replace")
        *lines, self._buf[bot_id] = data.split("\n")
        names = self.started.get(bot_id, ([], 0))[0]
        for ln in lines:
            ln = ln.rstrip("\r")
            if not ln:
                continue
            self.line.emit(bot_id, ln)
            st = C.line_status(ln, names)
            if st:
                self.instance_state.emit(*st)

    def _error(self, bot_id, err):
        if err == QProcess.Crashed and bot_id in self.stopping:
            return  # our own stop, said in _done
        if err == QProcess.FailedToStart:
            self.line.emit(bot_id, "could not start (Python or the bot's files are missing)")
        else:
            self.line.emit(bot_id, f"stopped unexpectedly ({err.name})")

    def _done(self, bot_id, code):
        rest = self._buf.pop(bot_id, "")
        if rest.strip():
            self.line.emit(bot_id, rest.strip())
        why = self.stopping.pop(bot_id, None)
        self.line.emit(bot_id, f"stopped: {why}" if why else f"finished (exit code {code})")
        for n in self.started.get(bot_id, ([], 0))[0]:
            self.instance_state.emit(n, "idle")
        self.changed.emit()

    def stop(self, bot_id, why="you pressed Stop"):
        p = self.procs.get(bot_id)
        if p and p.state() != QProcess.NotRunning:
            self.stopping[bot_id] = why
            p.kill()  # the bots hold no state that needs a clean shutdown

    def stop_all(self, why="you pressed Stop all"):
        for b in list(self.procs):
            self.stop(b, why)


# ---------------------------------------------------------------- discovery
class Discovery(QThread):
    found = Signal(list, str)  # [(name, serial)], error text

    def run(self):
        try:
            from intel_adb import adb
            devs = adb.discover()
            self.found.emit([(d.name, d.serial) for d in devs], "")
        except Exception as e:  # noqa: BLE001 - shown to the user, never fatal
            self.found.emit([], f"{type(e).__name__}: {e}")


def device(name, serial):
    from intel_adb import adb
    return adb.Device(name, serial)


class Previewer(QThread):
    """Screenshots of every known instance, one every `period` s each, while enabled."""
    frame = Signal(str, object)  # name, BGR ndarray (thumbnail)

    def __init__(self, parent=None, period=4.0):
        super().__init__(parent)
        self.devices = {}  # name -> serial
        self.period = period
        self.enabled = True
        self._stop = threading.Event()

    def run(self):
        cache = {}
        while not self._stop.is_set():
            if self.enabled:
                for name, serial in list(self.devices.items()):
                    if self._stop.is_set():
                        break
                    try:
                        dev = cache.get(serial) or cache.setdefault(serial, device(name, serial))
                        img = dev.screencap(tries=1)
                        h = 300
                        thumb = cv2.resize(img, (round(img.shape[1] * h / img.shape[0]), h),
                                           interpolation=cv2.INTER_AREA)
                        self.frame.emit(name, thumb)
                    except Exception:
                        self.frame.emit(name, None)
            self._stop.wait(self.period)

    def stop(self):
        self._stop.set()


# ---------------------------------------------------------------- autopilot
class AutopilotBridge(QObject):
    log = Signal(str)
    changed = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        from autopilot import config, engine, state
        self.config = config
        self.settings = config.load()
        self.state = state.State()
        self.engine = engine.Engine(self.settings, self.state, connect=self._connect)
        self.engine.on_log = self.log.emit
        self.launcher = None  # emulators.Launcher: starts an instance a session needs
        self.session_start = None  # (name, serial) -> truthy if skills ran, False if a required one failed
        self.engine.on_change = self.changed.emit

    @property
    def running(self):
        return self.engine.running

    def _connect(self, instance):
        """Session thread: start the instance first when its "start" switch is on."""
        from autopilot import engine
        if self.launcher:
            try:
                self.launcher.ensure(instance, stop=self.engine._stop)
            except Exception as e:  # noqa: BLE001
                self.log.emit(f"  couldn't start {instance}: {e!r}")
        dev = engine._connect(instance)
        if dev is not None and self.session_start:
            try:
                res = self.session_start(dev.name, dev.serial)
                if res is False:
                    self.log.emit(f"  {instance}: a required learned skill failed - session skipped")
                    return None
                if res and dev.foreground_package() != KINGSHOT:
                    dev._adb("shell", "monkey", "-p", KINGSHOT, "-c", "android.intent.category.LAUNCHER", "1")
                    self.engine._stop.wait(8)  # let the game come back to the front
            except Exception as e:  # noqa: BLE001
                self.log.emit(f"  learned skills on {instance} failed: {e!r}")
        return dev

    def save(self):
        self.config.save(self.settings)

    def start(self):
        self.engine.start()
        self.changed.emit()

    def stop(self):
        self.engine.stop()
        self.changed.emit()

    def run_now(self, key):
        self.engine.run_now(key)

    def ensure_characters(self, instances):
        """No characters yet: one per instance (the logged-in one, no switching), with the
        safe everyday jobs on. Returns the names added."""
        added = []
        known = {c.instance for c in self.settings.characters}
        for name in instances:
            if name in known:
                continue
            ch = self.config.Character(instance=name, name="Logged-in character")
            for j in SAFE_DEFAULT_JOBS:
                ch.jobs[j].enabled = True
            self.settings.characters.append(ch)
            added.append(name)
        if added:
            self.save()
            self.changed.emit()
        return added


# Everyday jobs that never spend diamonds. Arena (buys attempts), Terrors (stamina) and
# Blizzard (event slots) stay off until switched on.
SAFE_DEFAULT_JOBS = ["claim", "rewards", "train", "research", "hunt", "gather", "intel",
                     "alliance", "city", "build"]


# ---------------------------------------------------------------- keep-alive
class Watchdog(QThread):
    """Every few minutes: is Kingshot still in front on each known instance? If not
    (crash, closed, kicked to the home screen), start it again."""
    event = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.devices = {}
        self.minutes = 2
        self.active = False
        self.before_game = None  # (name, serial) -> False to skip the relaunch: learned skills run first
        self._stop = threading.Event()

    def run(self):
        misses = {}
        while not self._stop.wait(max(30, self.minutes * 60)):
            if not self.active:
                continue
            for name, serial in list(self.devices.items()):
                try:
                    dev = device(name, serial)
                    pkg = dev.foreground_package()
                except Exception:
                    continue  # instance off: nothing to relaunch into
                if pkg == KINGSHOT:
                    misses[name] = 0
                    continue
                misses[name] = misses.get(name, 0) + 1
                if misses[name] < 2:  # one miss can be a loading screen or a dialog
                    continue
                try:
                    if self.before_game and self.before_game(name, serial) is False:
                        self.event.emit(f"[{name}] Kingshot not relaunched: a required learned skill failed")
                        continue
                    dev._adb("shell", "monkey", "-p", KINGSHOT, "-c",
                             "android.intent.category.LAUNCHER", "1")
                    self.event.emit(f"[{name}] Kingshot wasn't running ({pkg or 'nothing'} in front) - relaunched")
                    misses[name] = 0
                except Exception as e:
                    self.event.emit(f"[{name}] relaunch failed: {e}")

    def stop(self):
        self._stop.set()


# ---------------------------------------------------------------- telegram
HELP = ("Kingshot Command\n"
        "/status - what is running\n"
        "/start - start Autopilot\n"
        "/stop - stop Autopilot and every bot\n"
        "/shot [instance] - screenshot\n"
        "/bots - bots you can run\n"
        "/run <bot> - start a bot on every instance\n"
        "/redeem <code> - redeem a gift code for all saved players\n"
        "/launch [instance] - start emulator instances\n"
        "/close [instance] - close emulator instances")


class Telegram(QThread):
    """Your own Telegram bot as a remote: notifications out, commands in. Only the chat id
    saved in Settings is obeyed; anyone else just gets told their chat id."""
    command = Signal(str, str, str)  # chat id, command, argument
    status = Signal(str)

    def __init__(self, token, chat, parent=None):
        super().__init__(parent)
        self.token, self.chat = token.strip(), str(chat).strip()
        self._stop = threading.Event()
        self._offset = None

    def api(self, method, timeout=35, files=None, **params):
        import requests
        url = f"https://api.telegram.org/bot{self.token}/{method}"
        r = requests.post(url, data=params, files=files, timeout=timeout)
        return r.json()

    def send(self, text, chat=None):
        if not self.token or not (chat or self.chat):
            return
        threading.Thread(target=self._send, args=(text, chat or self.chat), daemon=True).start()

    def _send(self, text, chat):
        try:
            self.api("sendMessage", timeout=15, chat_id=chat, text=text[:4000])
        except Exception:
            pass

    def send_photo(self, png_bytes, caption=""):
        def go():
            try:
                self.api("sendPhoto", timeout=30, files={"photo": ("shot.png", png_bytes)},
                         chat_id=self.chat, caption=caption)
            except Exception:
                pass
        if self.token and self.chat:
            threading.Thread(target=go, daemon=True).start()

    def run(self):
        if not self.token:
            return
        try:
            me = self.api("getMe", timeout=15)
            self.status.emit(f"connected as @{me['result']['username']}" if me.get("ok")
                             else f"token rejected: {me.get('description')}")
            if not me.get("ok"):
                return
        except Exception as e:
            self.status.emit(f"offline: {e}")
        while not self._stop.is_set():
            try:
                params = {"timeout": 25}
                if self._offset:
                    params["offset"] = self._offset
                res = self.api("getUpdates", **params)
            except Exception:
                self._stop.wait(10)
                continue
            for u in res.get("result", []):
                self._offset = u["update_id"] + 1
                msg = u.get("message") or {}
                text = (msg.get("text") or "").strip()
                chat = str((msg.get("chat") or {}).get("id", ""))
                if not text.startswith("/") or not chat:
                    continue
                if chat != self.chat:
                    self._send(f"Your chat id is {chat}. Paste it into Kingshot Command → Settings → "
                               "Telegram to control the bot from here.", chat)
                    continue
                cmd, _, arg = text[1:].partition(" ")
                self.command.emit(chat, cmd.split("@")[0].lower(), arg.strip())

    def stop(self):
        self._stop.set()


def png(img):
    ok, buf = cv2.imencode(".png", img)
    return buf.tobytes() if ok else b""


# ---------------------------------------------------------------- gift codes
class Redeemer(QThread):
    result = Signal(str, str, str, str)  # code, player id, player name, message
    done = Signal(str)

    def __init__(self, code, players, parent=None):
        super().__init__(parent)
        self.code, self.players = code.strip(), list(players)

    def run(self):
        from giftcode import redeem
        for i, p in enumerate(self.players):
            try:
                res = redeem.redeem_gift_code(p["id"], self.code)
                raw = str(res.get("msg", "Unknown error")).strip(".")
                msg = redeem.RESULT_MESSAGES.get(raw, raw)
            except Exception as e:  # network trouble: report and carry on
                msg = f"error: {e}"
            self.result.emit(self.code, p["id"], p.get("name", ""), msg)
            if i < len(self.players) - 1:
                time.sleep(2)  # the site rate-limits quick bursts
        self.done.emit(self.code)
