"""Learned skills: what Claude makes from your Teacher lessons, delivered as an update you
apply with one click (no reinstall).

A skill pack is one zip:

    pack.json                 {"format": 1, "version": N, "published": ..., "notes": ...,
                               "skills": [skill, ...]}
    templates/<skill>/<name>.png   screen crops at the bots' 540 px reference width

Each skill is a short list of steps the runner below plays on one instance:

    {"id": "proton_vpn", "title": "Start Proton VPN", "when": "before_game",
     "instances": [],                       # empty = every instance
     "steps": [{"do": "open_app", "package": "ch.protonvpn.android"},
               {"do": "wait", "for": "connect", "timeout": 20, "else": "done"},
               {"do": "tap", "on": "connect", "x": 0.49, "y": 0.74}]}

Steps: open_app, require_app, home, back, sleep, type, swipe, long_press, tap (on a template
"on", on a UI text "text" read with uiautomator, or at "x"/"y"), wait (for a template, or
"vpn": true for a connected VPN), stop_if (template "seen", or "vpn": true) and until (repeat
its own "steps" until the condition holds, e.g. tap Connect and Android's VPN OK until the VPN
is up), and distinct (read a UI value such as the VPN server and run its "steps", e.g. Change
server, until no other instance holds the same value). A missed wait/tap fails the skill unless its "else" says "done" or "continue".
A skill with "required": true that fails before the game keeps Kingshot closed on that instance.

"when" says where it runs: "before_game" (every time the app is about to open Kingshot on
an instance: start-up, keep-alive relaunch), "session_start" (before each Autopilot session)
or "manual" (only from the Teacher page). Coordinates are 0..1 of the screen, like lessons.

Updates come from a small index file (latest.json) at settings.update_url:
    {"version": N, "url": "<zip, absolute or relative to latest.json>", "sha256": ..., "notes": ...}
The pack is checked (hash, format, every template present) before it replaces the old one,
and the previous pack is kept so it can be put back."""
import hashlib
import json
import re
import shutil
import subprocess
import threading
import time
import zipfile
from datetime import datetime
from pathlib import Path
from urllib.parse import urljoin
import xml.etree.ElementTree as ET

import cv2
import numpy as np

from kscommand import core

ROOT = core.ROOT / "learned"
PREV = core.ROOT / "learned.prev"
FORMAT = 1
DEFAULT_UPDATE_URL = "https://raw.githubusercontent.com/685ks/685ks.github.io/kingshot-updates/latest.json"
WHENS = ("before_game", "session_start", "manual")
OPS = {"open_app", "require_app", "home", "back", "sleep", "wait", "stop_if", "until", "tap", "long_press",
       "swipe", "type", "distinct"}
REF_W, REF_H = 540, 960
THRESHOLD = 0.82


class PackError(ValueError):
    pass


class Stop(Exception):
    """A step ended the skill early: ok=True means that's fine (nothing to do)."""

    def __init__(self, ok, why):
        super().__init__(why)
        self.ok = ok


# ---------------------------------------------------------------- the installed pack
_lock = threading.Lock()
_cache = {"mtime": None, "pack": None}


def empty():
    return {"format": FORMAT, "version": 0, "published": "", "notes": "", "skills": []}


def installed(root=ROOT):
    """pack.json of the installed pack (an empty pack when there is none)."""
    path = Path(root) / "pack.json"
    try:
        mtime = path.stat().st_mtime
    except OSError:
        return empty()
    with _lock:
        if root == ROOT and _cache["mtime"] == mtime:
            return _cache["pack"]
        try:
            pack = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return empty()
        if root == ROOT:
            _cache.update(mtime=mtime, pack=pack)
        return pack


def skills(when=None, instance=None, disabled=(), root=ROOT):
    """Installed skills, optionally only those that run at `when` on `instance` and aren't
    switched off."""
    out = []
    for s in installed(root).get("skills", []):
        if when and s.get("when") != when:
            continue
        if s.get("id") in disabled:
            continue
        names = [n.lower() for n in s.get("instances") or []]
        if instance and names and instance.lower() not in names:
            continue
        out.append(s)
    return out


def validate(pack, folder=None, check_app=True):
    """Raises PackError when pack.json (and, given the unpacked folder, its templates) is wrong."""
    if not isinstance(pack, dict) or pack.get("format") != FORMAT:
        raise PackError(f"unknown pack format {pack.get('format') if isinstance(pack, dict) else pack!r}")
    if not isinstance(pack.get("version"), int):
        raise PackError("pack has no version number")
    need = pack.get("min_app")
    if check_app and need and _ver(need) > _ver(__import__("kscommand").__version__):
        raise PackError(f"this update needs Kingshot Command {need} or newer: install the new version first")
    seen = set()
    for s in pack.get("skills", []):
        sid = s.get("id")
        if not sid or not str(sid).replace("_", "").isalnum():
            raise PackError(f"bad skill id {sid!r}")
        if sid in seen:
            raise PackError(f"skill {sid} is in the pack twice")
        seen.add(sid)
        if s.get("when") not in WHENS:
            raise PackError(f"{sid}: 'when' must be one of {', '.join(WHENS)}")
        if not s.get("steps"):
            raise PackError(f"{sid}: no steps")
        _validate_steps(sid, s["steps"], folder)


def _validate_steps(sid, steps, folder, where=""):
    for i, st in enumerate(steps, 1):
        if st.get("do") not in OPS:
            raise PackError(f"{sid} step {where}{i}: unknown step {st.get('do')!r}")
        if st["do"] in ("until", "distinct"):
            if not st.get("steps"):
                raise PackError(f"{sid} step {where}{i}: 'until' has no steps")
            _validate_steps(sid, st["steps"], folder, f"{where}{i}.")
        if folder is not None:
            for name in _template_names(st):
                if not (Path(folder) / "templates" / sid / f"{name}.png").is_file():
                    raise PackError(f"{sid} step {where}{i}: template {name}.png is missing")


def _ver(v):
    return tuple(int(x) for x in re.findall(r"\d+", str(v))[:3])


def _template_names(step):
    names = []
    for key in ("for", "on", "seen"):
        v = step.get(key)
        names += v if isinstance(v, list) else [v] if v else []
    return names


def install_zip(path, sha256=None, root=ROOT, prev=PREV):
    """Check a pack zip and make it the installed pack. Returns its pack.json."""
    path = Path(path)
    if sha256:
        got = hashlib.sha256(path.read_bytes()).hexdigest()
        if got.lower() != sha256.lower():
            raise PackError("download is damaged (checksum doesn't match); try again")
    root, prev = Path(root), Path(prev)
    stage = root.with_name(root.name + ".new")
    shutil.rmtree(stage, ignore_errors=True)
    stage.mkdir(parents=True)
    try:
        with zipfile.ZipFile(path) as z:
            for info in z.infolist():
                target = (stage / info.filename).resolve()
                if not str(target).startswith(str(stage.resolve())):
                    raise PackError(f"unsafe path in pack: {info.filename}")
            z.extractall(stage)
        try:
            pack = json.loads((stage / "pack.json").read_text(encoding="utf-8"))
        except (OSError, ValueError) as e:
            raise PackError(f"pack.json unreadable: {e}") from e
        validate(pack, stage)
    except (zipfile.BadZipFile, PackError):
        shutil.rmtree(stage, ignore_errors=True)
        raise
    except zipfile.LargeZipFile as e:
        shutil.rmtree(stage, ignore_errors=True)
        raise PackError(str(e)) from e
    with _lock:
        if root.exists():
            shutil.rmtree(prev, ignore_errors=True)
            root.replace(prev)
        stage.replace(root)
        _cache["mtime"] = None
    return pack


def roll_back(root=ROOT, prev=PREV):
    """Put the previous pack back. Returns its pack.json, or None if there is none."""
    root, prev = Path(root), Path(prev)
    if not (prev / "pack.json").is_file():
        return None
    with _lock:
        tmp = root.with_name(root.name + ".old")
        shutil.rmtree(tmp, ignore_errors=True)
        if root.exists():
            root.replace(tmp)
        prev.replace(root)
        if tmp.exists():
            tmp.replace(prev)
        _cache["mtime"] = None
    return installed(root)


# ---------------------------------------------------------------- updates
def check(url, get=None):
    """The published index: {"version", "url" (absolute), "sha256", "notes", ...}."""
    get = get or _get
    sep = "&" if "?" in url else "?"
    data = json.loads(get(f"{url}{sep}t={int(time.time())}").decode("utf-8"))  # skip stale CDN copies
    if not isinstance(data.get("version"), int) or not data.get("url"):
        raise PackError("update index is missing version or url")
    data["url"] = urljoin(url, data["url"])
    if isinstance(data.get("app"), dict) and data["app"].get("url"):
        data["app"]["url"] = urljoin(url, data["app"]["url"])
    return data


def update(url, root=ROOT, prev=PREV, get=None, force=False):
    """Download and install the published pack when it's newer than the installed one.
    Returns (pack.json, changed)."""
    get = get or _get
    info = check(url, get)
    have = installed(root)
    if info["version"] <= have.get("version", 0) and not force:
        return have, False
    tmp = Path(root).with_name("learned-download.zip")
    tmp.write_bytes(get(info["url"]))
    try:
        pack = install_zip(tmp, info.get("sha256"), root, prev)
    finally:
        tmp.unlink(missing_ok=True)
    return pack, True


def _get(url):
    import requests
    r = requests.get(url, timeout=30, headers={"Cache-Control": "no-cache"})
    r.raise_for_status()
    return r.content


# ---------------------------------------------------------------- running a skill
_VPN_UP = (re.compile(r"type: VPN\[[^\]]*\], state: CONNECTED"),  # Android 9 (BlueStacks Pie)
           re.compile(r"ni\{VPN CONNECTED"),  # Android 10+
           re.compile(r"\bVPN\b[^\n]{0,80}\bCONNECTED/CONNECTED"))
UI_DUMP = "/sdcard/ksc_ui.xml"


def vpn_up(dumpsys):
    """Whether `dumpsys connectivity` lists a connected VPN network."""
    return any(p.search(dumpsys) for p in _VPN_UP)


def tun_up(ip_link):
    """Whether `ip -o link` shows a tun interface that is up (fallback for odd dumpsys output)."""
    return any(re.search(r"^\d+: tun\d+[:@].*<[^>]*\bUP\b", line) for line in ip_link.splitlines())


def find_value(xml, pattern, package=None):
    """Text of the first UI node (in `package`) that fully matches the regex `pattern`."""
    try:
        root = ET.fromstring(xml)
    except ET.ParseError:
        return None
    rx = re.compile(pattern)
    for node in root.iter("node"):
        if package and node.get("package") != package:
            continue
        text = (node.get("text") or "").strip()
        if text and rx.fullmatch(text):
            return text
    return None


# values instances hold that must differ between them (e.g. the VPN server): shared by every
# skill run in this app, and saved so it survives a restart
STATE_PATH = core.ROOT / "learned_state.json"
_state_lock = threading.Lock()  # one instance at a time compares and changes
_state = {}


def _load_state(path):
    if not _state:
        try:
            _state.update(json.loads(Path(path).read_text(encoding="utf-8")))
        except (OSError, ValueError):
            pass
    return _state


def _save_state(path):
    try:
        Path(path).write_text(json.dumps(_state, indent=1), encoding="utf-8")
    except OSError:
        pass


def find_text(xml, texts, package=None):
    """Centre (device px) of the first enabled UI node whose text is one of `texts`
    (case-insensitive), optionally only in `package`."""
    try:
        root = ET.fromstring(xml)
    except ET.ParseError:
        return None
    want = {t.lower() for t in texts}
    for node in root.iter("node"):
        if package and node.get("package") != package:
            continue
        if (node.get("text") or "").strip().lower() not in want or node.get("enabled") == "false":
            continue
        m = re.match(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", node.get("bounds", ""))
        if m:
            x1, y1, x2, y2 = map(int, m.groups())
            return (x1 + x2) // 2, (y1 + y2) // 2
    return None


class Runner:
    """Plays one skill's steps on a device (intel_adb.adb.Device, 540 px reference frame)."""

    def __init__(self, skill, device, root=ROOT, log=print, sleep=time.sleep, clock=time.monotonic, stop=None):
        self.skill, self.dev = skill, device
        self.folder = Path(root) / "templates" / skill["id"]
        self.log, self.sleep, self.clock = log, sleep, clock
        self.stop = stop
        self._tpl = {}
        self._tapped = {}  # id(step) -> when it last tapped (for "cooldown")

    # ---- what's on screen
    def template(self, name):
        if name not in self._tpl:
            img = cv2.imdecode(np.fromfile(str(self.folder / f"{name}.png"), np.uint8), cv2.IMREAD_COLOR)
            if img is None:
                raise PackError(f"template {name}.png is missing")
            self._tpl[name] = img
        return self._tpl[name]

    def find(self, img, names, threshold=THRESHOLD):
        """(name, (x, y)) of the first template seen on img, or None."""
        for name in names if isinstance(names, list) else [names]:
            tpl = self.template(name)
            if tpl.shape[0] > img.shape[0] or tpl.shape[1] > img.shape[1]:
                continue
            res = cv2.matchTemplate(img, tpl, cv2.TM_CCOEFF_NORMED)
            _, val, _, loc = cv2.minMaxLoc(res)
            if val >= threshold:
                return name, (loc[0] + tpl.shape[1] // 2, loc[1] + tpl.shape[0] // 2)
        return None

    def _out(self, *args, timeout=15):
        try:
            return (self.dev._adb(*args, timeout=timeout) or b"").decode(errors="ignore")
        except Exception:  # noqa: BLE001
            return ""

    def screen(self):
        """A screenshot, or None. Some apps (VPNs, banking) block screenshots: then only UI text works."""
        try:
            img = self.dev.screencap()
        except Exception:  # noqa: BLE001
            return None
        return img if img is not None and getattr(img, "size", 0) else None

    def vpn_connected(self):
        if vpn_up(self._out("shell", "dumpsys", "connectivity", timeout=20)):
            return True
        if tun_up(self._out("shell", "ip", "-o", "link")):
            return True
        return bool(re.search(r"(^|\s)tun\d+(\s|$)", self._out("shell", "ls", "/sys/class/net")))

    def ui_value(self, pattern, package=None):
        self._out("shell", "uiautomator", "dump", UI_DUMP, timeout=20)
        return find_value(self._out("shell", "cat", UI_DUMP), pattern, package)

    def ui_text(self, texts, package=None):
        """Device-px centre of a UI text (uiautomator), or None."""
        self._out("shell", "uiautomator", "dump", UI_DUMP, timeout=20)
        return find_text(self._out("shell", "cat", UI_DUMP), texts if isinstance(texts, list) else [texts], package)

    def holds(self, st):
        """The condition of a wait / stop_if / until step, checked once."""
        if st.get("vpn") and self.vpn_connected():
            return True
        if st.get("ui") and self.ui_text(st["ui"], st.get("package")):
            return True
        names = st.get("for") or st.get("seen")
        if not names:
            return False
        img = self.screen()
        if img is None:
            return False
        hit = self.find(img, names)
        return (not hit) if st.get("gone") else hit

    def look(self, st, timeout):
        """Check the step's condition until it holds or `timeout` s pass."""
        end = self.clock() + timeout
        while True:
            self._check_stop()
            hit = self.holds(st)
            if hit:
                return hit
            if self.clock() >= end:
                return None
            self.sleep(float(st.get("every", 0.7)))

    def _check_stop(self):
        if self.stop is not None and self.stop.is_set():
            raise Stop(False, "stopped")

    def _height(self):
        img = self.screen()
        return img.shape[0] if img is not None else REF_H

    def _outcome(self, st, why):
        """What a missed wait/tap does: 'fail' (default), 'done' (fine, nothing to do) or 'continue'."""
        policy = st.get("else", "fail")
        if policy == "continue":
            return
        raise Stop(policy == "done", st.get("say") or why)

    # ---- playing
    def run(self):
        """Plays every step. Returns (ok, message)."""
        title = self.skill.get("title", self.skill["id"])
        i = 0
        try:
            for i, st in enumerate(self.skill["steps"], 1):
                self._check_stop()
                self.step(st)
                if st.get("pause", 0.6):
                    self.sleep(st.get("pause", 0.6))
        except Stop as e:
            return e.ok, f"{title}: {e}"
        except Exception as e:  # noqa: BLE001
            return False, f"{title}: step {i} failed ({e})"
        return True, f"{title}: done"

    def step(self, st):
        op = st["do"]
        d = self.dev
        if op == "require_app":
            if "package:" not in self._out("shell", "pm", "path", st["package"]):
                raise Stop(True, f"{st['package']} isn't installed on this instance - skipped")
        elif op == "open_app":
            d._adb("shell", "monkey", "-p", st["package"], "-c", "android.intent.category.LAUNCHER", "1",
                   timeout=20)
        elif op == "home":
            d._adb("shell", "input", "keyevent", "3")
        elif op == "back":
            d.back()
        elif op == "sleep":
            self.sleep(float(st.get("seconds", 1)))
        elif op == "wait":
            if not self.look(st, float(st.get("timeout", 10))):
                what = "a connected VPN" if st.get("vpn") else st.get("for")
                self._outcome(st, f"{'still saw' if st.get('gone') else 'never saw'} {what}")
        elif op == "stop_if":
            if self.look(st, float(st.get("timeout", 0))):
                raise Stop(True, st.get("say") or "nothing to do")
        elif op == "until":
            end = self.clock() + float(st.get("timeout", 60))
            while not self.holds(st):
                self._check_stop()
                if self.clock() >= end:
                    return self._outcome(st, f"gave up after {st.get('timeout', 60)} s")
                for sub in st["steps"]:
                    self._check_stop()
                    self.step(sub)
                self.sleep(float(st.get("every", 2)))
        elif op in ("tap", "long_press"):
            last = self._tapped.get(id(st))
            if last is not None and self.clock() - last < float(st.get("cooldown", 0)):
                return None
            spot = self.where(st)
            if spot is None:
                return self._outcome(st, f"couldn't find {st.get('on') or st.get('text')}")
            raw, (x, y) = spot
            ms = int(float(st.get("seconds", 1)) * 1000)
            if raw:  # device pixels from the UI tree
                if op == "tap":
                    d._adb("shell", "input", "tap", str(x), str(y))
                else:
                    d._adb("shell", "input", "swipe", str(x), str(y), str(x), str(y), str(ms))
            elif op == "tap":
                d.tap(x, y, jitter=st.get("jitter", 2))
            else:
                d.swipe(x, y, x, y, ms)
            self._tapped[id(st)] = self.clock()
        elif op == "distinct":
            self.distinct(st)
        elif op == "swipe":
            h = self._height()
            d.swipe(st["x"] * REF_W, st["y"] * h, st["x2"] * REF_W, st["y2"] * h, int(st.get("ms", 400)))
        elif op == "type":
            d.type_text(st["text"])
        return None

    def distinct(self, st, state_path=None):
        """Make a UI value (e.g. the VPN server "Switzerland #11") differ from what the other
        instances hold: run the "steps" (e.g. Change server) until it does, up to "tries" times."""
        state_path = state_path or getattr(self, "state_path", STATE_PATH)
        key, me = st.get("key", self.skill["id"]), getattr(self.dev, "name", "")
        max_age = float(st.get("max_age_hours", 12)) * 3600
        settle = float(st.get("settle", 30))
        with _state_lock:
            vals = _load_state(state_path).setdefault(key, {})
            value = self._read_value(st, settle)
            if value is None:
                return self._outcome(st, "couldn't read the current value")
            for attempt in range(int(st.get("tries", 4)) + 1):
                now = time.time()
                taken = {v["value"] for n, v in vals.items() if n != me and now - v.get("t", 0) < max_age}
                if value not in taken:
                    break
                if attempt == int(st.get("tries", 4)):
                    vals[me] = {"value": value, "t": now}
                    _save_state(state_path)
                    return self._outcome(st, f"still on {value} like another instance after "
                                             f"{st.get('tries', 4)} changes")
                self.log(f"  [{me}] {value} is already used by another instance - changing")
                for sub in st["steps"]:
                    self._check_stop()
                    self.step(sub)
                end = self.clock() + settle
                new = None
                while self.clock() < end:  # wait for the new value (and the VPN, if asked) to settle
                    self.sleep(2)
                    self._check_stop()
                    new = self._read_value(st, 0)
                    if new and new != value and (not st.get("vpn") or self.vpn_connected()):
                        break
                value = new or value
            vals[me] = {"value": value, "t": time.time()}
            _save_state(state_path)
            self.log(f"  [{me}] {st.get('label', key)}: {value}")

    def _read_value(self, st, timeout):
        end = self.clock() + timeout
        while True:
            v = self.ui_value(st["pattern"], st.get("package"))
            if v or self.clock() >= end:
                return v
            self.sleep(1)

    def where(self, st):
        """(device_px, (x, y)) to tap: a UI text, then a template, then the lesson's x/y."""
        end = self.clock() + float(st.get("timeout", 8))
        while True:
            self._check_stop()
            if st.get("text"):
                p = self.ui_text(st["text"], st.get("package"))
                if p:
                    return True, p
            if st.get("on"):
                img = self.screen()
                hit = self.find(img, st["on"]) if img is not None else None
                if hit:
                    return False, hit[1]
            if not st.get("text") and not st.get("on"):
                return False, (st["x"] * REF_W, st["y"] * self._height())
            if self.clock() >= end:
                break
            self.sleep(0.7)
        if st.get("x") is not None and st.get("fallback_xy"):
            return False, (st["x"] * REF_W, st["y"] * self._height())
        return None


def run_skill(skill, device, log=print, stop=None, root=ROOT, **kw):
    ok, msg = Runner(skill, device, root=root, log=log, stop=stop, **kw).run()
    log(f"[{device.name}] {msg}")
    return ok, msg


def run_hook(when, name, serial, disabled=(), log=print, stop=None, device_fn=None, root=ROOT):
    """Run every installed skill for `when` on one instance, in pack order. Never raises.
    Returns [(skill id, ok, message)]."""
    found = skills(when, name, disabled, root)
    if not found:
        return []
    if device_fn is None:
        from intel_adb import adb as A
        device_fn = A.Device
    out = []
    for s in found:
        try:
            dev = device_fn(name, serial)
            ok, msg = run_skill(s, dev, log=log, stop=stop, root=root)
        except Exception as e:  # noqa: BLE001
            ok, msg = False, f"{s.get('title', s['id'])}: {e}"
            log(f"[{name}] {msg}")
        out.append((s["id"], ok, msg))
        if not ok and s.get("required"):
            break  # later skills may depend on it; the caller keeps the game closed
    return out


def blocked(results, root=ROOT):
    """The message of a failed skill marked "required" in run_hook()'s results, else None."""
    req = {s["id"] for s in installed(root).get("skills", []) if s.get("required")}
    return next((msg for sid, ok, msg in results if not ok and sid in req), None)


def has_hook(when, name, disabled=(), root=ROOT):
    return bool(skills(when, name, disabled, root))


# ---------------------------------------------------------------- building packs (Claude's side)
def crop(frame, x, y, w=120, h=56):
    """A template around a 0..1 point of a 540 px lesson frame (path or BGR image)."""
    img = frame if isinstance(frame, np.ndarray) else cv2.imdecode(np.fromfile(str(frame), np.uint8),
                                                                    cv2.IMREAD_COLOR)
    ih, iw = img.shape[:2]
    cx, cy = round(x * iw), round(y * ih)
    x0, y0 = max(0, cx - w // 2), max(0, cy - h // 2)
    return img[y0:min(ih, y0 + h), x0:min(iw, x0 + w)].copy()


def build_pack(skill_dirs, version, out_dir, notes="", base_url="", min_app=None):
    """Pack skill folders (each: skill.json + templates/*.png) into
    out_dir/kingshot-skills-<version>.zip and out_dir/latest.json. Returns (zip, index)."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    skills_ = []
    zpath = out_dir / f"kingshot-skills-{version}.zip"
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for d in map(Path, skill_dirs):
            s = json.loads((d / "skill.json").read_text(encoding="utf-8"))
            skills_.append(s)
            for png in sorted((d / "templates").glob("*.png")):
                z.write(png, f"templates/{s['id']}/{png.name}")
        pack = {"format": FORMAT, "version": int(version),
                "published": datetime.now().astimezone().isoformat(timespec="seconds"),
                "notes": notes, "min_app": min_app or __import__("kscommand").__version__, "skills": skills_}
        z.writestr("pack.json", json.dumps(pack, indent=2))
    # validate what we wrote, exactly as the app will
    check_dir = out_dir / ".check"
    shutil.rmtree(check_dir, ignore_errors=True)
    with zipfile.ZipFile(zpath) as z:
        z.extractall(check_dir)
    try:
        validate(pack, check_dir, check_app=False)
    finally:
        shutil.rmtree(check_dir, ignore_errors=True)
    index = {"version": int(version), "published": pack["published"], "notes": notes, "min_app": pack["min_app"],
             "skills": [{"id": s["id"], "title": s.get("title", s["id"]), "when": s["when"]} for s in skills_],
             "url": base_url + zpath.name, "sha256": hashlib.sha256(zpath.read_bytes()).hexdigest()}
    try:  # keep the app entry (selfupdate) that the same feed carries
        prev = json.loads((out_dir / "latest.json").read_text(encoding="utf-8"))
        if prev.get("app"):
            index["app"] = prev["app"]
    except (OSError, ValueError):
        pass
    (out_dir / "latest.json").write_text(json.dumps(index, indent=2), encoding="utf-8")
    return zpath, index


def main(argv=None):
    """python -m kscommand.learned build OUT VERSION SKILL_DIR... [--notes TEXT]"""
    import argparse
    p = argparse.ArgumentParser(prog="python -m kscommand.learned")
    sub = p.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("build")
    b.add_argument("out")
    b.add_argument("version", type=int)
    b.add_argument("skills", nargs="+")
    b.add_argument("--notes", default="")
    a = p.parse_args(argv)
    zpath, index = build_pack(a.skills, a.version, a.out, a.notes)
    print(zpath)
    print(json.dumps(index, indent=2))


if __name__ == "__main__":
    main()
