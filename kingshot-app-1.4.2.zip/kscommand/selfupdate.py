"""One-click updates of the app itself (the Python code in app\\), from the same feed as the
learned skills.

latest.json carries an "app" entry next to the skills:
    "app": {"version": "1.4.3", "url": "kingshot-app-1.4.3.zip", "sha256": ..., "notes": ...}

The zip holds the code folders exactly as they sit in app\\ (kscommand, autopilot, intel_adb, ...)
plus app_files.json, the list of every file in it. Updating:

1. download, check the hash, unpack to app\\update\\stage and check it really is that version;
2. copy this file to a temp folder and start it as a separate process, then the app quits;
3. that process waits for the app to exit, copies the new files over the old ones (each old file
   is kept in app\\update\\backup first), deletes files the previous version shipped that the new
   one doesn't, and starts the app again. Anything you made yourself (settings, stats, logs,
   lessons, learned skills) is never touched, because only files listed in a version's
   app_files.json are ever replaced or removed.
4. If copying fails half way, the backup is put back and the old version starts.

Only code changes travel this way: a new Python, Qt or other library still needs bot.exe."""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path

MANIFEST = "app_files.json"
CODE = ("kscommand", "autopilot", "intel_adb", "bear_adb", "terror_adb", "caravan_adb", "cesares_adb",
        "fishing_adb", "gather_adb", "journey_adb", "pouch_adb", "giftcode")
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
DETACHED = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)


class UpdateError(RuntimeError):
    pass


def ver(v):
    import re
    return tuple(int(x) for x in re.findall(r"\d+", str(v))[:3])


def newer(info, current):
    """The feed's app entry when it is newer than `current`, else None."""
    app = (info or {}).get("app")
    if app and app.get("version") and app.get("url") and ver(app["version"]) > ver(current):
        return app
    return None


# ---------------------------------------------------------------- download and stage
def stage(app, root, get=None):
    """Download the app zip, check it and unpack it to root/update/stage. Returns that folder."""
    from kscommand import learned
    get = get or learned._get
    upd = Path(root) / "update"
    upd.mkdir(parents=True, exist_ok=True)
    data = get(app["url"])
    if app.get("sha256") and hashlib.sha256(data).hexdigest().lower() != app["sha256"].lower():
        raise UpdateError("download is damaged (checksum doesn't match); try again")
    zpath = upd / "download.zip"
    zpath.write_bytes(data)
    folder = upd / "stage"
    shutil.rmtree(folder, ignore_errors=True)
    folder.mkdir()
    try:
        with zipfile.ZipFile(zpath) as z:
            for name in z.namelist():
                if not str((folder / name).resolve()).startswith(str(folder.resolve())):
                    raise UpdateError(f"unsafe path in update: {name}")
            z.extractall(folder)
    except zipfile.BadZipFile as e:
        raise UpdateError(f"update isn't a zip: {e}") from e
    finally:
        zpath.unlink(missing_ok=True)
    check_stage(folder, app["version"])
    return folder


def check_stage(folder, version):
    folder = Path(folder)
    try:
        files = json.loads((folder / MANIFEST).read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        raise UpdateError(f"update has no file list ({e})") from e
    missing = [f for f in files if not (folder / f).is_file()]
    if missing:
        raise UpdateError(f"update is missing {missing[0]}")
    init = folder / "kscommand" / "__init__.py"
    if not init.is_file() or f'"{version}"' not in init.read_text(encoding="utf-8"):
        raise UpdateError(f"update doesn't contain version {version}")
    return files


# ---------------------------------------------------------------- apply (runs outside the app)
def apply(folder, root, log=print):
    """Copy the staged files over root. Old copies go to root/update/backup; on any error they
    are put back and the error is raised."""
    folder, root = Path(folder), Path(root)
    new = json.loads((folder / MANIFEST).read_text(encoding="utf-8"))
    try:
        old = json.loads((root / MANIFEST).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        old = []
    backup = root / "update" / "backup"
    shutil.rmtree(backup, ignore_errors=True)
    backup.mkdir(parents=True)
    touched = []  # (relative path, existed before)
    try:
        for rel in [*new, MANIFEST]:
            dst = root / rel
            existed = dst.exists()
            if existed:
                (backup / rel).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(dst, backup / rel)
            touched.append((rel, existed))
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(folder / rel, dst)
        for rel in set(old) - set(new):  # shipped before, gone now
            dst = root / rel
            if dst.is_file():
                (backup / rel).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(dst, backup / rel)
                touched.append((rel, True))
                dst.unlink()
        for d in {Path(rel).parent for rel in new}:
            shutil.rmtree(root / d / "__pycache__", ignore_errors=True)  # stale bytecode
    except Exception:
        log("update failed - putting the old files back")
        restore(root, touched)
        raise
    log(f"updated {len(new)} files")
    shutil.rmtree(folder, ignore_errors=True)


def restore(root, touched):
    root, backup = Path(root), Path(root) / "update" / "backup"
    for rel, existed in reversed(touched):
        dst = root / rel
        try:
            if existed:
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(backup / rel, dst)
            elif dst.exists():
                dst.unlink()
        except OSError:
            pass


def wait_for_exit(pid, timeout=60):
    """Wait until process `pid` is gone (Windows: WaitForSingleObject)."""
    if os.name == "nt":
        import ctypes
        k = ctypes.windll.kernel32
        h = k.OpenProcess(0x00100000, False, int(pid))  # SYNCHRONIZE
        if h:
            k.WaitForSingleObject(h, int(timeout * 1000))
            k.CloseHandle(h)
        time.sleep(0.5)
        return
    end = time.time() + timeout
    while time.time() < end:
        try:
            os.kill(int(pid), 0)
        except OSError:
            return
        time.sleep(0.3)


# ---------------------------------------------------------------- hand-over from the app
def launcher(root):
    exe = Path(root).parent / "Kingshot Command.exe"
    return exe if exe.exists() else None


def hand_over(folder, root, pid=None, popen=subprocess.Popen):
    """Start the updater outside the app (the caller then quits)."""
    tmp = Path(tempfile.mkdtemp(prefix="ksc-update-"))
    script = tmp / "ksc_selfupdate.py"
    shutil.copy2(__file__, script)
    exe = Path(sys.executable)
    relaunch = launcher(root)
    cmd = [str(exe), "-I", str(script), "apply", "--pid", str(pid or os.getpid()), "--stage", str(folder),
           "--root", str(root)]
    if relaunch:
        cmd += ["--relaunch", str(relaunch)]
    popen(cmd, cwd=str(tmp), creationflags=NO_WINDOW | DETACHED, close_fds=True)
    return cmd


def _main(argv=None):
    import argparse
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("apply")
    a.add_argument("--pid", type=int)
    a.add_argument("--stage", required=True)
    a.add_argument("--root", required=True)
    a.add_argument("--relaunch")
    b = sub.add_parser("build")  # Claude's side: zip app\ code for the feed
    b.add_argument("app_dir")
    b.add_argument("out_dir")
    b.add_argument("--notes", default="")
    args = p.parse_args(argv)
    if args.cmd == "build":
        zpath, entry = build(args.app_dir, args.out_dir, args.notes)
        print(zpath)
        print(json.dumps(entry, indent=2))
        return 0
    root = Path(args.root)
    logf = root / "logs" / "update.log"
    logf.parent.mkdir(parents=True, exist_ok=True)

    def log(msg):
        with open(logf, "a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {msg}\n")
    code = 0
    try:
        if args.pid:
            wait_for_exit(args.pid)
        apply(args.stage, root, log)
    except Exception as e:  # noqa: BLE001
        log(f"update failed: {e!r}")
        code = 1
    if args.relaunch:
        subprocess.Popen([args.relaunch], creationflags=DETACHED, close_fds=True)
    return code


# ---------------------------------------------------------------- building (Claude's side)
def build(app_dir, out_dir, notes=""):
    """Zip the code folders of a staged app\\ into out_dir/kingshot-app-<version>.zip. Returns
    (zip, feed entry)."""
    app_dir, out_dir = Path(app_dir), Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    init = (app_dir / "kscommand" / "__init__.py").read_text(encoding="utf-8")
    version = init.split("__version__ = ", 1)[1].split()[0].strip("\"'")
    files = sorted(p.relative_to(app_dir).as_posix() for d in CODE if (app_dir / d).is_dir()
                   for p in (app_dir / d).rglob("*") if p.is_file() and "__pycache__" not in p.parts)
    if (app_dir / "BOTS-README.md").is_file():
        files.append("BOTS-README.md")
    zpath = out_dir / f"kingshot-app-{version}.zip"
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for rel in files:
            z.write(app_dir / rel, rel)
        z.writestr(MANIFEST, json.dumps(files, indent=0))
    entry = {"version": version, "url": zpath.name, "notes": notes,
             "sha256": hashlib.sha256(zpath.read_bytes()).hexdigest()}
    return zpath, entry


if __name__ == "__main__":
    sys.exit(_main())
