"""Excavate Treasure mini-game: tap the pale sand squares until both treasures are found."""
import cv2
import numpy as np

AREA = (430, 900)  # y range of the dig grid (540x960 screen)


def sand_squares(img):
    """Centres of undug sand squares, top to bottom then left to right."""
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    mask = ((hsv[..., 1] < 70) & (hsv[..., 2] > 200)).astype(np.uint8) * 255
    mask[:AREA[0]] = 0
    mask[AREA[1]:] = 0
    mask = cv2.erode(mask, np.ones((5, 5), np.uint8))  # split squares that touch
    n, _, stats, cents = cv2.connectedComponentsWithStats(mask)
    pts = [(int(round(cents[k][0])), int(round(cents[k][1])))
           for k in range(1, n) if 1500 <= stats[k][4] <= 4000]
    return sorted(pts, key=lambda p: (p[1] // 20, p[0]))
