"""Auto Journey helper: the game's own Auto Journey travels; this answers the choices with the
guide's best option, plays the mini-games, and turns Auto back on when a mini-game stops it.

Start it with the Journey screen open:
    python -m journey_adb.journey [--only Falkor] [--dry-run]
"""
import argparse
import json
import os
import subprocess
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import cv2

from intel_adb import adb, timer
from intel_adb.vision import Vision
from journey_adb import chests, cooking, digging, guide

TEMPLATE_DIR = Path(__file__).parent / "templates"
DEBUG_DIR = Path(__file__).parent / "debug"
VIDEO_DIR = Path(__file__).parent / "chest_videos"
CALIBRATION = Path(__file__).parent / "cooking_calibration.json"
RECORD_DIR = Path(__file__).parent / "minigame_recordings"
RECORD_KEYWORDS = ("fish",)  # mini-games the bot can't play yet: hand over and record
RECORD_MAX = 5 * 60

TEAL = ((80, 120, 150), (100, 255, 255))  # HSV range of choice buttons
AUTO_BUTTON = (473, 930)
STORY_TAP = (230, 530)  # the speech bubble / story text (manual journeys)
MANUAL_PAUSE = 0.8  # s between taps when moving a manual journey on
AUTO_START = (270, 640)  # teal "start N journeys" button on the Auto Journey popup
# "Tap anywhere to exit/close"; the dark one is over the blurred cooking result (Primary
# 2026-10-18: the bot sat on a "Perfect" result because only the light versions were known)
EXIT_TEMPLATES = ("tap_to_exit", "tap_to_close", "tap_to_exit_dark")
TAP_ON = (270, 700)  # any spot works for "Tap anywhere to ..."
TICK = 1.0
IDLE_LIMIT = 120  # s with Auto off and nothing to do -> finished
MAX_RESTARTS = 3  # Auto turned on but never ran -> out of journeys
FILM_SECONDS = 9
RPS_HANDS = ((150, 633), (270, 633), (390, 633))  # scissors, rock, paper (orange circles)
RPS_SHOW = (270, 762)


def find_buttons(img):
    """Teal choice buttons below the scene: [((x, y, w, h), text)], top to bottom."""
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, *TEAL)
    mask[:440] = 0
    n, _, stats, _ = cv2.connectedComponentsWithStats(mask)
    out = []
    for k in range(1, n):
        x, y, w, h, _ = stats[k]
        if w > 100 and 20 < h < 70:
            out.append(((int(x), int(y), int(w), int(h)), _read(img[y + 6:y + h - 6, x + 10:x + w - 10])))
    return sorted(out, key=lambda b: b[0][1])


def _read(crop):
    if not timer.available() or crop.size == 0:
        return ""
    g = cv2.cvtColor(cv2.resize(crop, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC), cv2.COLOR_BGR2GRAY)
    _, b = cv2.threshold(g, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)
    try:
        return timer.pytesseract.image_to_string(b, config="--psm 7").strip()
    except Exception:
        return ""


def read_story(img):
    """Text of the log/speech area, for the few encounters whose buttons are ambiguous."""
    return _read(img[440:900, 0:540]) if timer.available() else ""


def film(device, seconds, start_tap):
    """Film the screen at 60 fps while tapping Start; returns per-frame chest x positions."""
    VIDEO_DIR.mkdir(parents=True, exist_ok=True)
    path = VIDEO_DIR / f"{device.name.replace('#', '')}_{time.strftime('%Y%m%d_%H%M%S')}.h264"
    wm = device._adb("shell", "wm", "size").decode(errors="ignore")
    size_args, crop = chests.record_plan(wm)
    with open(path, "wb") as out:
        proc = subprocess.Popen([adb.ADB_PATH, "-s", device.serial, "exec-out", "screenrecord",
                                 "--output-format=h264", *size_args,
                                 "--time-limit", str(seconds), "-"],
                                stdout=out, stderr=subprocess.DEVNULL, creationflags=adb.NO_WINDOW)
        time.sleep(0.8)  # recorder start-up
        start_tap()
        proc.wait(timeout=seconds + 10)
    vision = Vision(TEMPLATE_DIR)
    return [chests.chest_xs(vision, f) for f in chests.frames_from_video(path, crop)]


def film_clip(device, seconds):
    """Frames (540 wide) of a screenrecord clip of `seconds`, filmed right now."""
    VIDEO_DIR.mkdir(parents=True, exist_ok=True)
    path = VIDEO_DIR / f"cook_{device.name.replace('#', '')}_{time.strftime('%Y%m%d_%H%M%S')}.h264"
    wm = device._adb("shell", "wm", "size").decode(errors="ignore")
    size_args, crop = chests.record_plan(wm)
    with open(path, "wb") as out:
        proc = subprocess.Popen([adb.ADB_PATH, "-s", device.serial, "exec-out", "screenrecord",
                                 "--output-format=h264", *size_args,
                                 "--time-limit", str(max(1, int(seconds + 0.999))), "-"],
                                stdout=out, stderr=subprocess.DEVNULL, creationflags=adb.NO_WINDOW)
        proc.wait(timeout=seconds + 15)
    return list(chests.frames_from_video(path, crop))


class Journey:
    def __init__(self, device, vision, sleep=time.sleep, clock=time.monotonic,
                 buttons_fn=find_buttons, gold_fn=chests.gold_slot, narration_fn=read_story,
                 film_fn=None, follow_fn=chests.follow, needle_fn=cooking.needle,
                 zone_fn=cooking.zone, calib_path=CALIBRATION, sand_fn=digging.sand_squares,
                 record_dir=RECORD_DIR, play_fish=True, clip_fn=None, analyse_fn=None):
        self.d, self.v, self.sleep, self.clock = device, vision, sleep, clock
        self.play_fish = play_fish  # False: hand fishing to the player and record it
        self.buttons_fn, self.gold_fn, self.narration_fn = buttons_fn, gold_fn, narration_fn
        self.film_fn = film_fn
        self.follow_fn = follow_fn
        self.needle_fn, self.zone_fn, self.calib_path = needle_fn, zone_fn, Path(calib_path)
        self.latency = self._load_latency()
        self.cook_delay = self._load_value("cook_delay", cooking.DEFAULT_DELAY)
        self.cook_at = None  # clock time "Cook" was tapped
        self.cook_clip, self.cook_thread = {}, None
        self.clip_fn = clip_fn or (lambda secs: film_clip(self.d, secs))
        self.analyse_fn = analyse_fn or (lambda clip, z: cooking.analyse_stop(
            [cooking.needle(f) for f in clip], z))
        self.sand_fn = sand_fn
        self.stats = {"choices": 0, "unknown": 0, "chests": 0, "chests_won": 0, "cooking": 0, "digs": 0}
        self.record_dir = Path(record_dir)
        self.last_logged = None

    def tap(self, x, y):
        self.d.tap(x, y, jitter=2)

    def save_debug(self, img, tag):
        try:
            DEBUG_DIR.mkdir(parents=True, exist_ok=True)
            cv2.imwrite(str(DEBUG_DIR / f"{self.d.name.replace('#', '')}_{tag}_{time.strftime('%H%M%S')}.png"), img)
        except Exception:
            pass

    def _load_latency(self):
        try:
            return float(json.loads(self.calib_path.read_text()).get(self.d.name, cooking.LATENCY))
        except (OSError, ValueError, AttributeError):
            return cooking.LATENCY

    def _load_value(self, name, default):
        try:
            return float(json.loads(self.calib_path.read_text()).get(f"{self.d.name}:{name}", default))
        except (OSError, ValueError, AttributeError):
            return default

    def _save_value(self, name, value):
        try:
            data = json.loads(self.calib_path.read_text()) if self.calib_path.exists() else {}
        except (OSError, ValueError):
            data = {}
        data[f"{self.d.name}:{name}"] = round(value, 3)
        try:
            self.calib_path.write_text(json.dumps(data, indent=2))
        except OSError:
            pass

    def _save_latency(self):
        try:
            data = json.loads(self.calib_path.read_text()) if self.calib_path.exists() else {}
        except (OSError, ValueError):
            data = {}
        data[self.d.name] = round(self.latency, 3)
        try:
            self.calib_path.write_text(json.dumps(data, indent=2))
        except OSError:
            pass

    def play_cooking(self, img):
        if self.cook_at is not None and not self.d.dry_run:
            return self.play_cooking_timed(img)
        x, z = self.needle_fn(img), self.zone_fn(img)
        wait = cooking.wait_for(x, z, latency=self.latency)
        if self.d.dry_run:
            self.d.log(f"(dry-run) cooking: needle {x}, zone {z}, would wait {wait}s")
            return
        if wait is None:  # needle not readable: try the next screenshot
            return
        self.sleep(wait)
        self.tap(*cooking.STOP_BUTTON)
        self.sleep(0.3)
        stopped = self.needle_fn(self.d.screencap())
        self.latency = cooking.recalibrate(self.latency, stopped, z)
        self._save_latency()
        self.stats["cooking"] += 1
        inside = stopped is not None and z[0] <= stopped <= z[1]
        self.d.log(f"cooking: stopped at {stopped} (zone {z}) - {'PERFECT' if inside else 'off'}; "
                   f"timing now {self.latency:.2f}s")

    def play_cooking_timed(self, img):
        """The needle always moves the same way from the moment Cook is tapped (user): tap Stop
        exactly cooking.COOK_DELAY after it - one fixed value for every character and instance,
        never learnt or changed (user, 2026-10-12)."""
        z = self.zone_fn(img)
        target = self.cook_at + cooking.COOK_DELAY
        self.cook_at = None
        self.sleep(max(0.0, target - self.clock()))
        self.tap(*cooking.STOP_BUTTON)
        self.sleep(0.3)
        x = self.needle_fn(self.d.screencap())  # for the log only - nothing is adjusted
        self.stats["cooking"] += 1
        inside = x is not None and z is not None and z[0] <= x <= z[1]
        self.d.log(f"cooking: Stop {cooking.COOK_DELAY:.2f}s after Cook - needle at {x} "
                   f"(zone {z}) {'PERFECT' if inside else 'off'}")

    def play_dig(self, img):
        squares = self.sand_fn(img)
        if self.d.dry_run:
            self.d.log(f"(dry-run) excavate: {len(squares)} sand squares")
            return
        self.d.log(f"excavate: digging {len(squares)} squares")
        for _ in range(40):  # each tap may end the game early (both treasures found)
            if not squares:
                break
            self.tap(*squares[0])
            self.sleep(0.4)
            img = self.d.screencap()
            if not self.v.has(img, "dig_title"):
                break
            squares = self.sand_fn(img)
        self.stats["digs"] += 1

    # ---- one screen ------------------------------------------------------
    def step(self, img):
        """Handle one screenshot. Returns True if the bot did something."""
        if self.v.has(img, "chat_title"):  # chat open: its Send button is teal too - never touch
            return False
        if any(self.v.has(img, n) for n in EXIT_TEMPLATES):  # result screens ("Perfect" etc.)
            self.tap(*TAP_ON)
            return True
        if self.v.has(img, "attack_dummy"):  # Boxing Dummy encounter: just attack
            if self.d.dry_run:
                return False
            self.d.log("boxing dummy: attack")
            self.tap(*self.v.find(img, "attack_dummy"))
            return True
        if self.v.has(img, "auto_popup"):
            self.d.log("starting Auto Journey")
            self.tap(*AUTO_START)
            return True
        if self.v.has(img, "rps_title"):  # Rock-Paper-Scissors: pick a hand, then Show
            if self.d.dry_run:
                return False
            import random
            hand = random.choice(RPS_HANDS)
            self.d.log(f"rock-paper-scissors: picking {('scissors', 'rock', 'paper')[RPS_HANDS.index(hand)]}")
            self.tap(*hand)
            self.sleep(0.6)
            self.tap(*RPS_SHOW)
            return True
        if self.v.has(img, "dig_title"):
            self.play_dig(img)
            return not self.d.dry_run
        if self.v.has(img, "cook_stop"):
            self.play_cooking(img)
            return not self.d.dry_run
        if self.v.has(img, "wheel_draw"):
            self.d.log("prize wheel: draw")
            self.tap(*self.v.find(img, "wheel_draw"))
            return True
        buttons = self.buttons_fn(img)
        gold = self.gold_fn(img) if buttons else None
        if gold is not None and len(buttons) == 1:
            self.play_chests(gold, buttons[0][0])
            return True
        texts = " ".join(t for _, t in buttons).lower()
        fish_btn = next((b for b, t in buttons if "fish" in t.lower()), None)
        if fish_btn is not None and self.play_fish:
            self.play_fishing(fish_btn)
            return not self.d.dry_run
        if any(k in texts for k in RECORD_KEYWORDS):
            self.record_for_player(img, texts)
            return True
        if buttons:
            return self.answer(img, buttons)
        return False

    def answer(self, img, buttons):
        texts = [t for _, t in buttons]
        story = ""
        if sum(guide.is_good(t) for t in texts) > 1:
            story = self.narration_fn(img)
        i, known = guide.pick(texts, story)
        key = tuple(texts)
        if self.d.dry_run:
            if key != self.last_logged:
                self.d.log(f"(dry-run) choice {texts} -> {texts[i]!r}{'' if known else ' (not in guide)'}")
                self.last_logged = key
            return False
        self.stats["choices"] += 1
        if known:
            self.d.log(f"choice {texts} -> {texts[i]!r}")
        else:
            self.stats["unknown"] += 1
            self.d.log(f"choice {texts} not in the guide -> {texts[i]!r} (screenshot saved)")
            self.save_debug(img, "unknown_choice")
        x, y, w, h = buttons[i][0]
        self.tap(x + w // 2, y + h // 2)
        if texts[i].strip().lower() == "cook":
            self.cook_at = self.clock()  # cooking starts now: Stop goes a fixed delay later
        return True

    def start_cook_clip(self):
        """Film from Cook until just after the planned Stop (the recorder needs ~1 s to start)."""
        import threading
        self.cook_clip = {}
        secs = self.cook_delay + 2.0

        def film():
            try:
                self.cook_clip["frames"] = self.clip_fn(secs)
            except Exception as e:
                self.d.log(f"cooking: couldn't film ({e!r})")
        self.cook_thread = threading.Thread(target=film, daemon=True)
        self.cook_thread.start()

    def play_fishing(self, start_box):
        """Fishing: tap Start Fishing, then steer the hook into fish until 10 are caught."""
        from journey_adb import fishing
        if self.d.dry_run:
            self.d.log("(dry-run) fishing: would play it")
            return
        x, y, w, h = start_box
        self.d.log("fishing: playing (goal: 10 fish)")
        self.tap(x + w // 2, y + h // 2)
        self.sleep(4)  # 3-2-1 countdown
        over = lambda img: (any(self.v.has(img, n) for n in EXIT_TEMPLATES) or self.v.has(img, "auto_banner")  # noqa: E731
                            or self.v.has(img, "next_stop"))
        caught = fishing.play(self.d, over, log=self.d.log, sleep=self.sleep)
        self.d.log(f"fishing: done ({caught} fish)")
        self.stats["fishing"] = self.stats.get("fishing", 0) + 1

    def record_for_player(self, img, what):
        """A mini-game the bot can't play yet: don't touch anything, record the screen while
        the player plays it, and carry on once the journey screen is back."""
        name = next(k for k in RECORD_KEYWORDS if k in what)
        folder = self.record_dir / f"{name}_{self.d.name.replace('#', '')}_{time.strftime('%Y%m%d_%H%M%S')}"
        self.d.log(f"{name}ing mini-game: not playing it - recording while you play")
        saved, last, left = 0, None, False
        end = self.clock() + RECORD_MAX
        while self.clock() < end:
            if not isinstance(img, str):
                small = cv2.cvtColor(cv2.resize(img, (90, 160)), cv2.COLOR_BGR2GRAY).astype("int16")
                if last is None or abs(small - last).mean() > 4:
                    folder.mkdir(parents=True, exist_ok=True)
                    cv2.imwrite(str(folder / f"{saved:04d}.jpg"), img, [cv2.IMWRITE_JPEG_QUALITY, 85])
                    saved, last = saved + 1, small
            on_journey = self.v.has(img, "auto_banner") or self.v.has(img, "next_stop")
            if not on_journey:
                left = True  # the mini-game has started
            elif left:
                break  # back on the journey screen: done
            self.sleep(0.4)
            img = self.d.screencap()
        self.stats["recorded"] = self.stats.get("recorded", 0) + 1
        self.d.log(f"{name}ing done - recorded {saved} frames in {folder}")

    def play_chests(self, gold, start_box):
        x, y, w, h = start_box
        start = lambda: self.tap(x + w // 2, y + h // 2)  # noqa: E731
        if self.d.dry_run:
            self.d.log(f"(dry-run) chest game: gold starts in slot {gold}")
            return
        self.d.log(f"chest game: gold in slot {gold}, filming the shuffle")
        film_fn = self.film_fn or (lambda s: film(self.d, s, start))
        frames = film_fn(FILM_SECONDS)
        if self.film_fn:  # injected recorder doesn't tap; tap Start ourselves
            start()
        slot = self.follow_fn(frames, gold)
        self.sleep(0.5)
        self.tap(chests.SLOTS[slot], chests.CHEST_Y)
        self.stats["chests"] += 1
        self.sleep(1.5)
        won = self.gold_fn(self.d.screencap()) == slot
        self.stats["chests_won"] += int(won)
        self.d.log(f"chest game: picked slot {slot} ({len(frames)} frames) - {'WON' if won else 'missed'}")

    # ---- loop --------------------------------------------------------------
    def run(self, max_minutes=180):
        end = self.clock() + max_minutes * 60
        last_busy = self.clock()
        restarts = 0
        manual = False  # set once Auto is seen locked: this account plays by hand
        while self.clock() < end:
            img = self.d.screencap()
            if self.step(img):
                last_busy = self.clock()
            elif (manual or self.v.has(img, "auto_locked") or self.v.has(img, "idle_locked")) \
                    and not self.d.dry_run \
                    and not self.v.has(img, "auto_banner"):
                # Auto Journey not unlocked on this account: move the story on by hand
                manual = True
                pos = self.v.find(img, "next_stop")
                skip = self.v.find(img, "skip_button")
                if skip:
                    self.tap(*skip)  # cutscene
                elif pos:
                    self.d.log("manual journey: Next Stop")
                    self.tap(*pos)
                else:
                    self.tap(*STORY_TAP)  # reveals the next line / the choice buttons
                last_busy = self.clock()
                self.sleep(MANUAL_PAUSE)
            elif self.v.has(img, "auto_banner"):
                last_busy = self.clock()
                restarts = 0
            elif self.v.has(img, "next_stop") and not self.d.dry_run:
                if restarts >= MAX_RESTARTS:
                    self.d.log("Auto Journey won't start (out of journeys?) - stopping")
                    break
                restarts += 1
                self.d.log("Auto Journey is off - turning it back on")
                self.tap(*AUTO_BUTTON)
                last_busy = self.clock()
            elif self.clock() - last_busy > IDLE_LIMIT:
                self.d.log("nothing to do for a while - stopping")
                break
            self.sleep(TICK)
        self.d.log(f"finished: {self.stats}")
        return self.stats


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--only", action="append")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--minutes", type=float, default=180)
    args = ap.parse_args(argv)
    devices = adb.discover(only=args.only, dry_run=args.dry_run)
    if not devices:
        print("No running Kingshot instances found.")
        return
    print(f"Journey on: {', '.join(d.name for d in devices)}", flush=True)

    def one(d):
        try:
            return Journey(d, Vision(TEMPLATE_DIR)).run(args.minutes)
        except Exception as e:
            d.log(f"error: {e!r}")

    with ThreadPoolExecutor(max_workers=len(devices)) as pool:
        list(pool.map(one, devices))


if __name__ == "__main__":
    main()
