"""Cooking mini-game: a needle sweeps right along the bar at a steady speed; tap Stop while it
is in the pale-yellow zone for "Perfect".

The needle always moves the same way, so the bot reads its position once, waits the time it
needs to reach the zone centre, and taps. Afterwards it reads where the needle froze and
nudges the timing for next time.
"""
import numpy as np
import cv2

BAND = (620, 720)  # y range of the bar (540x960 screen)
SPEED = 150.0  # px/s, measured from the recording
LATENCY = 0.25  # s between a screenshot being taken and a tap landing (self-calibrated)
STOP_BUTTON = (270, 815)


def _runs(cols):
    """Contiguous runs of True in a 1-D bool array -> [(start, end)]."""
    runs, start = [], None
    for x, on in enumerate(cols):
        if on and start is None:
            start = x
        elif not on and start is not None:
            runs.append((start, x - 1))
            start = None
    if start is not None:
        runs.append((start, len(cols) - 1))
    return runs


def zone(img):
    """(left, right) x of the pale-yellow "Perfect" block; fire glow makes short side runs,
    the block is the longest run."""
    hsv = cv2.cvtColor(img[BAND[0]:BAND[1]], cv2.COLOR_BGR2HSV)
    pale = ((hsv[..., 0] >= 22) & (hsv[..., 0] <= 35) & (hsv[..., 1] > 60) & (hsv[..., 1] < 170)
            & (hsv[..., 2] > 230)).sum(axis=0) >= 3
    merged = []
    for r in _runs(pale):  # the needle can split the block in two: join across small gaps
        if merged and r[0] - merged[-1][1] <= 15:
            merged[-1] = (merged[-1][0], r[1])
        else:
            merged.append(r)
    return max(merged, key=lambda r: r[1] - r[0]) if merged else None


def needle(img):
    """x of the white needle on the bar, or None."""
    hsv = cv2.cvtColor(img[BAND[0]:BAND[1]], cv2.COLOR_BGR2HSV)
    white = ((hsv[..., 1] < 40) & (hsv[..., 2] > 235)).sum(axis=0) >= 6
    runs = [r for r in _runs(white) if r[1] - r[0] <= 40]  # the needle is narrow (wider when tilted at the ends)
    if not runs:
        return None
    lo, hi = runs[0]
    return (lo + hi) / 2


def wait_for(x, zone_lr, speed=SPEED, latency=LATENCY):
    """Seconds to wait before tapping Stop, 0 = tap now, None = needle not seen."""
    if x is None or zone_lr is None:
        return None
    centre = (zone_lr[0] + zone_lr[1]) / 2
    return max(0.0, (centre - x) / speed - latency)


def recalibrate(latency, stopped_x, zone, speed=SPEED, damping=0.5):
    """Where the needle froze tells whether we tapped late (right of centre) or early."""
    if stopped_x is None or zone is None:
        return latency
    error_s = (stopped_x - (zone[0] + zone[1]) / 2) / speed
    return float(np.clip(latency + damping * error_s, 0.0, 1.0))


# ---- fixed delay after "Cook" (user: the needle always moves the same way) ----------------
DEFAULT_DELAY = 3.0  # (old learnt start value - no longer used)
COOK_DELAY = 2.32  # s from tapping Cook to tapping Stop. FIXED: the same for every character,
# instance and cooking game (user, 2026-10-12). Measured: 3.00 s -> needle at 400-405 on both
# Primary and Falkor; 2.42 s -> 330 (PERFECT, zone 299-337); zone centre ~318 -> 2.32 s.
MAX_STEP = 0.4  # s: most the delay moves after one game
GAIN = 0.8


def analyse_stop(xs, zone_lr, fps=60):
    """From a clip around the Stop tap (needle x per frame, None when unreadable):
    (x where the needle froze, timing error in seconds: + = tapped late, - = early)."""
    seq = [x for x in xs]
    while seq and seq[-1] is None:  # blur after the result
        seq.pop()
    if len(seq) < 6 or zone_lr is None:
        return None, None
    end = len(seq) - 1
    start = end
    while start > 0 and seq[start - 1] is not None and abs(seq[start - 1] - seq[end]) <= 2:
        start -= 1
    if end - start < 2 or start < 3:
        return None, None
    before = [seq[i] - seq[i - 1] for i in range(max(1, start - 6), start)
              if seq[i] is not None and seq[i - 1] is not None]
    if not before:
        return None, None
    v = float(np.median(before))
    if abs(v) < 1:
        return None, None
    x = seq[end]
    centre = (zone_lr[0] + zone_lr[1]) / 2
    return x, (x - centre) / (v * fps)


def new_delay(delay, error_s, gain=GAIN, cap=MAX_STEP):
    if error_s is None:
        return delay
    return delay - float(np.clip(gain * error_s, -cap, cap))
