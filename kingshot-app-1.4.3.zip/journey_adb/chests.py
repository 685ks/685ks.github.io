"""Chest shell game: the gold chest closes, the three chests shuffle, pick the gold one.

The shuffle is too fast for screenshots, so it is filmed with `adb screenrecord` (60 fps)
and each chest is followed frame by frame. Chests slide along one row and pass through each
other, so tracks keep their velocity while two chests overlap.
"""
from itertools import permutations

import cv2
import numpy as np

SLOTS = (146, 270, 396)  # resting x of the three chests (540-wide screen)
ROW = (0, 440, 540, 120)  # x, y, w, h band the chests move in
CHEST_Y = 498
REST_TOL = 3  # px: chests this close to their slots are at rest
MOVE_MIN = 8  # px a chest must have moved before the move is read


def gold_slot(img):
    """Slot index of the gold (orange) chest on the start screen, or None."""
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    hues = []
    for x in SLOTS:
        p = hsv[430:520, x - 30:x + 30].reshape(-1, 3)
        p = p[p[:, 1] > 120]
        hues.append(float(np.median(p[:, 0])) if len(p) else 999)
    orange = [i for i, h in enumerate(hues) if 5 <= h <= 35]
    return orange[0] if len(orange) == 1 else None


def chest_xs(vision, frame):
    return [x for x, _ in vision.find_all(frame, "chest_closed", 0.6, min_dist=40, region=ROW)]


def move_from_offsets(d):
    """Which slot each chest is heading to, from its offset early in a move.
    All chests of one move arrive together, so a chest going two slots moves twice as fast:
    the offsets are proportional to (target - start). Returns perm with perm[slot] = target."""
    best, best_err = None, float("inf")
    for perm in permutations(range(3)):
        if perm == (0, 1, 2):
            continue
        want = [SLOTS[perm[i]] - SLOTS[i] for i in range(3)]
        k = sum(a * b for a, b in zip(d, want)) / sum(b * b for b in want)
        if k <= 0:
            continue
        err = sum((a - k * b) ** 2 for a, b in zip(d, want))
        if err < best_err:
            best, best_err = perm, err
    return best


def _at_rest(dets):
    return len(dets) == 3 and all(abs(a - b) <= REST_TOL for a, b in zip(sorted(dets), SLOTS))


def follow(frames_xs, start_slot):
    """frames_xs: per frame, the detected chest x positions. Returns the final slot of the
    chest that started in `start_slot`. Each move begins with all three chests resting in
    their slots; its first frames (before the chests blur and overlap) give the move."""
    slot = start_slot
    resting = True
    for dets in frames_xs:
        if _at_rest(dets):
            resting = True
            continue
        if not resting or len(dets) != 3:
            continue
        d = [a - b for a, b in zip(sorted(dets), SLOTS)]
        if max(abs(x) for x in d) < MOVE_MIN:
            continue  # barely started: wait for a clearer frame
        perm = move_from_offsets(d)
        if perm:
            slot = perm[slot]
        resting = False
    return slot


def record_plan(wm_size_output):
    """screenrecord args and the crop that holds the game. With a display override (the app's
    Low resolution button) the game is drawn in the top-left corner of the physical screen, so
    record at native size and crop it out; otherwise record straight at 540x960."""
    import re
    sizes = [(int(w), int(h)) for w, h in re.findall(r"(\d+)x(\d+)", wm_size_output)]
    if len(sizes) >= 2 and sizes[-1] != sizes[0]:
        return [], sizes[-1]
    return ["--size", "540x960"], None


def fit_frame(frame, crop):
    if crop:
        frame = frame[:crop[1], :crop[0]]
    if frame.shape[1] != 540:
        frame = cv2.resize(frame, (540, round(frame.shape[0] * 540 / frame.shape[1])))
    return frame


def frames_from_video(path, crop=None):
    cap = cv2.VideoCapture(str(path))
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        yield fit_frame(frame, crop)
    cap.release()
