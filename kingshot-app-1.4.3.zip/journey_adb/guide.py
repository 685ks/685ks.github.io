"""Best journey answers, from https://kingshotmastery.com/masters/journey-choices.

Every encounter pays the same item whichever button you pick, just a different amount; these
are the buttons that pay more. "Either" encounters are not listed (any button is fine).
"""
import difflib
import re

ANSWERS = {
    # general
    "Old friend wants to trade": "Trade",
    "Sorting stolen goods": "I'll help you",
    "Struggling survivor": "Offer help",
    "Caravan vs. bandits": "Drive bandits away",
    "Wounded lion": "Give food",
    "Lost merchant": "Give directions",
    "Survivor needs a hand": "Help out",
    "Survivor chased by a beast": "Step in",
    "Orphanage supplies": "Donate supplies",
    "Found treasure": "Keep it all",
    "Bandit roadblock": "Clear roadblock",
    "Fallen signpost": "Fix sign",
    "Elite rebels / bandits": "Fight",
    "Cesare's camp": "Face them head-on",
    "Mercenaries": "Suggest flanking",
    "Viking champion": "Come on, fight me!",
    "Dangerous beast": "Leave",
    "Transporter captain": "Pay full price",
    "Quinn's locked chest": "Disarm the trap",
    "Beast blocks the path": "Fight!",
    # Valora
    "Valora trade": "Trade resources",
    "Valora pile of items": "Pass",
    "Troubled merchant": "I won't pretend I didn't see that",
    "The dark flask": "Get it elsewhere",
    "Olive's uneasy feeling": "...Is that all?",
    "Dark shadow, foul odor": "Flank it",
    "The whining cub": "Focus on the beast",
    "First-aid tent": "Think of a way forward",
    # Pan
    "Pan pile of items": "Look at items",
    # Roman
    "Roman group portrait": "Help craft",
    "Petra asks what Quinn wants": "Come lend a hand. We've got work to do.",
    "Shady stranger": "Walk away",
    "The training pits": "Money, of course",
    "Recruiting Long Fei": "Fine. Money talks.",
    # Cassia
    "Cassia sort the loot": "Sort loot",
    "Shattered soldiers": "Share your rations",
    "Petra's wares": "Buy",
    "Lone Viking marauder": "Find out yourself",
    # Guinevere
    "Guinevere tidy up": "Help Tidy Up",
    "Mysterious stranger": "Move On",
    "Ambushed squad": "Ignore It. Focus on Guinevere.",
    "Recruiting help": "We don't need anyone else",
    "Swordland Showdown focus": "Focus on the Swordland Showdown",
    # Wilson
    "Wilson sort loot": "Help sort loot",
    "Road blocked by soldiers": "Identify Yourself As Quinn the Ranger",
    "Fake merchants": "Leave Them Be",
    "Wilson's claim": "Trust Wilson",
    "Emergency in the camp": "Stay Out of It",
    "Grid's explanation": "Believe Her",
    "Questioning Grid": "Think for Yourself",
    # Aena
    "Aena resource exchange": "Exchange Resources",
    "Aena sorting work": "Lend a Hand",
    "Feeding the caravan": "Share Your Food",
    "Aena needs a hand": "I've Got Things To Do",
    "Ruins ahead": "Keep Moving",
    "Reporting your findings": "Insist on Opening the Crate",
    "Petra and the dangerous cargo": "Request Reinforcements",
    # Isnor
    "Copper ore sold out": "Rather Not",
    "Earthquakes at the ruins": "Investigate the Earthquakes",
    "Mining accident tracks": "Stop Here for Now",
    "Ask around again": "Keep Asking Around",
    "Black Vulture mine": "Investigate Further",
    # mini-games and single-button prompts
    "Mini-game": "Start Game",
    "Prize wheel": "Draw prize",
}

# Answers that are also the *wrong* button of other encounters ("Fix sign / Leave").
# When one of these and a more specific answer are both on screen, take the specific one -
# unless the encounter is the one where the generic answer is the right call.
GENERIC = {"leave", "pass", "walk away", "move on", "keep moving", "stay out of it", "rather not"}
GENERIC_WINS = {"leave": ("dangerous",)}  # "Dangerous beast": leave beats fight


def norm(text):
    return re.sub(r"[^a-z' ]", "", text.lower().replace("’", "'")).strip()


GOOD = {norm(a) for a in ANSWERS.values()}


def is_good(option):
    o = norm(option)
    return bool(o) and (o in GOOD or bool(difflib.get_close_matches(o, GOOD, n=1, cutoff=0.85)))


def pick(options, narration=""):
    """Index of the button to tap, and whether it came from the guide (or needed no choosing)."""
    if len(options) == 1:  # "Start Cooking", "Dig", ...: one button is not a choice
        return 0, True
    good =[i for i, o in enumerate(options) if is_good(o)]
    if len(good) > 1:
        story = narration.lower()
        for i in good:
            o = norm(options[i])
            if o in GENERIC_WINS and any(k in story for k in GENERIC_WINS[o]):
                return i, True
        specific = [i for i in good if norm(options[i]) not in GENERIC]
        good = specific or good
    if good:
        return good[0], True
    return 0, False  # not in the guide: first button (same item either way, maybe less of it)
