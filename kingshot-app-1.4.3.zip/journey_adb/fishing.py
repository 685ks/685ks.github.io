"""Journey fishing mini-game (recorded 2026-10-09 on Falkor, tests/fixtures/fishing).

The hook sinks on a line inside a bubble shield (HUD "2/2"); bumping fish pops the shields,
then the hook is reeled up and every fish it touches on the way up is caught (HUD "x/10").
User: the goal is 10 fish, not depth - so the bot steers into fish the whole time.

Vision: the line is a thin low-saturation thread hanging from the top of the screen; the
hook is at its lower end. Fish are orange puffers."""
import cv2
import numpy as np

BAND = (58, 118)  # rows the line always crosses: under the pause button, above the hook
X_MIN = 140  # HUD on the left
FISH_MIN_AREA = 600


def _low_sat(img):
    """Thin grey pixels: grey with blue water 6 px to both sides (fish bellies are wide)."""
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    m = (hsv[:, :, 1] < 90) & (hsv[:, :, 2] > 50) & (hsv[:, :, 2] < 215)
    side = np.zeros_like(m)
    side[:, 6:-6] = m[:, :-12] | m[:, 12:]
    return m & ~side


def line_x(img, mask=None):
    """x of the fishing line, or None."""
    mask = _low_sat(img) if mask is None else mask
    y0, y1 = BAND
    counts = mask[y0:y1, X_MIN:].sum(axis=0).astype(float)
    counts = np.convolve(counts, np.ones(3), "same")
    x = int(np.argmax(counts))
    return X_MIN + x if counts[x] > (y1 - y0) * 0.3 else None


def hook(img):
    """(x, y) of the hook: the glowing dot at the end of the line (green while sinking,
    yellow/red while reeling in), searched in a strip around the line."""
    x = line_x(img)
    if x is None:
        return None
    x0 = max(0, x - 14)
    strip = img[:, x0:x + 15]
    hsv = cv2.cvtColor(strip, cv2.COLOR_BGR2HSV)
    h = hsv[:, :, 0]
    glow = (hsv[:, :, 2] > 225) & (hsv[:, :, 1] > 110) & ~((h >= 8) & (h <= 22)) & ~((h >= 84) & (h <= 110))  # not fish orange, not the cyan shield
    glow[:BAND[0]] = False
    n, _, st, cen = cv2.connectedComponentsWithStats(glow.astype(np.uint8))
    dots = [(x0 + int(cen[k][0]), int(cen[k][1])) for k in range(1, n) if 6 <= st[k][4] <= 300]
    return max(dots, key=lambda d: d[1]) if dots else None


def fish(img):
    """Centres of the orange puffers on screen."""
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    m = cv2.inRange(hsv, (8, 130, 170), (24, 255, 255))
    m[:140, :140] = 0  # HUD
    n, _, st, cen = cv2.connectedComponentsWithStats(m)
    return [(int(cen[k][0]), int(cen[k][1])) for k in range(1, n) if st[k][4] >= FISH_MIN_AREA]


SHIELD_BOX = (50, 12, 85, 28)  # HUD "2/2" (bubble shields)
FISH_BOX = (50, 54, 85, 28)  # HUD "3/10"
HOLD_Y = 760  # height of the drags
DRAG_MS = 150
DRAG_MAX = 480  # px: longest drag (screen is 540 wide)
MAX_SECONDS = 120


def hud(img, box):
    """(n, of) from a HUD counter like "3/10", or None."""
    import re
    from intel_adb import timer
    if not timer.available():
        return None
    x, y, w, h = box
    g = cv2.cvtColor(cv2.resize(img[y:y + h, x:x + w], None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC),
                     cv2.COLOR_BGR2GRAY)
    _, b = cv2.threshold(g, 160, 255, cv2.THRESH_BINARY_INV)
    try:
        text = timer.pytesseract.image_to_string(b, config="--psm 7 -c tessedit_char_whitelist=0123456789/")
    except Exception:
        return None
    m = re.search(r"(\d+)\s*/\s*(\d+)", text)
    return (int(m.group(1)), int(m.group(2))) if m else None


def play(device, is_over, log=print, sleep=None, clock=None):
    """Steer the hook into fish until the round ends (`is_over(img)` - back on the journey
    screen). Dragging moves the hook sideways by the drag distance (user, 2026-10-09); how
    many hook pixels per finger pixel is learnt from the hook's movement after each drag."""
    import time
    sleep = sleep or time.sleep
    clock = clock or time.monotonic
    end = clock() + MAX_SECONDS
    rising, last_hud, caught = False, 0.0, 0
    gain, pending = 1.0, None  # hook px per finger px (learnt), last drag (hook x, finger dx)
    while clock() < end:
        img = device.screencap()
        if is_over(img):
            break
        if clock() - last_hud > 1.0:  # HUD read is slow: about once a second
            last_hud = clock()
            shields, got = hud(img, SHIELD_BOX), hud(img, FISH_BOX)
            if got:
                caught = got[0]
            rising = rising or (shields is not None and shields[0] == 0) or caught > 0
            if got and got[0] >= got[1]:
                log(f"fishing: {got[0]}/{got[1]} fish")
        h = hook(img)
        if h is None:
            sleep(0.15)
            continue
        if pending is not None:  # learn how far the hook moves per pixel dragged
            moved = h[0] - pending[0]
            if abs(pending[1]) > 20 and moved * pending[1] > 0:
                gain = min(3.0, max(0.3, 0.6 * gain + 0.4 * moved / pending[1]))
            pending = None
        tx = target(img, rising)
        if tx is not None and abs(tx - h[0]) > 12:
            want = (tx - h[0]) / gain  # finger distance for that hook distance
            want = max(-DRAG_MAX, min(DRAG_MAX, want))
            x0 = 270 - want / 2  # drag across the middle of the screen
            device.swipe(int(x0), HOLD_Y, int(x0 + want), HOLD_Y, DRAG_MS)
            pending = (h[0], want)
        else:
            sleep(0.1)
    return caught


def target(img, rising):
    """x to steer the hook to: the nearest fish ahead of it (below while sinking, above
    while being reeled up). Fish already on the hook are ignored. None = nothing ahead."""
    h = hook(img)
    if h is None:
        return None
    hx, hy = h
    best, best_d = None, None
    for fx, fy in fish(img):
        dy = (hy - fy) if rising else (fy - hy)
        if dy < 40 or (abs(fx - hx) < 50 and abs(fy - hy) < 70):
            continue  # behind the hook, or already caught on it
        d = dy + 1.5 * abs(fx - hx)  # closest ahead, favouring small sideways moves
        if best_d is None or d < best_d:
            best, best_d = fx, d
    return best
