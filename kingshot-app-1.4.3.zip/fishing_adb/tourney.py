"""Fishing Tournament bot (recorded on Falkor 2026-10-13).

Start on the Fishing Tournament screen. While free Regular Fishing attempts are left
(counter "6/10"): buy the Kit Upgrades it can afford (Line first, then Hook, then Sinker -
fishing silver only), cast, steer the hook clear of fish on the way down to reach full
depth, then into fish on the way up, and Retreat from the Haul. Never Ocean Prospector,
never the Haul's Fishing Voucher, never Special Items.

    python -m fishing_adb.tourney [--only Falkor] [--dry-run]
"""
import argparse
import re
import time
from pathlib import Path

import collections
import threading

import cv2
import numpy as np

from intel_adb import adb, timer
from intel_adb.stream import Stream
from intel_adb.touch import Touch
from intel_adb.vision import Vision
from fishing_adb import predict, vision as fv
from fishing_adb.steering import Steering

TEMPLATE_DIR = Path(__file__).parent / "templates"
DEBUG_DIR = Path(__file__).parent / "debug"

REGULAR = (388, 893)  # Regular Fishing (costs one of the free attempts)
KIT_CARD = (112, 605)  # the Line card: opens Kit Upgrades
KIT_CLOSE = (491, 371)
KIT_COLUMNS = {"line": 110, "hook": 270, "sinker": 430}  # Line first: depth = better fish
KIT_BUTTON_Y = 603
RETREAT = (160, 840)
GO_FISH = (270, 813)  # "Continuing will resume the previous stage" screen
ATTEMPTS_BOX = (360, 822, 445, 852)
CATCH_BOX = (55, 52, 128, 80)
DEPTH_BOX = (40, 94, 130, 122)
FINGER_Y = 600  # the hook follows the finger's x; its y doesn't matter
SINK_Y = 400  # hook above this = still sinking
ROUND_TIMEOUT = 240  # s
MAX_BUYS = 30
POLL = 0.5
CATCH_W = 30  # px around the hook's tip that catch a fish
LANE_HOLD = 0.2  # s a chosen lane is kept before another may replace it
REGIONS = {"pause": (465, 0, 540, 75), "haul_title": (170, 95, 370, 215)}  # where they sit
MIN_DEPTH = 8  # m: below this the hook is still dropping in from the cast
TOP_Y = 200
TOP_FRAMES = 20
LOW_FRAMES = 15  # frames in a row with the hook low = reeling in (stream: ~0.15 s)
SEEN = 0.7  # screens score 0.77-1.0 (Primary, downscaled from a bigger screen: 0.77);
            # the wrong screen <= 0.55


def ocr(img, box, whitelist="0123456789/"):
    x0, y0, x1, y1 = box
    crop = img[y0:y1, x0:x1]
    if not timer.available() or crop.size == 0:
        return ""
    gray = cv2.cvtColor(cv2.resize(crop, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC), cv2.COLOR_BGR2GRAY)
    try:
        return timer.pytesseract.image_to_string(gray, config=f"--psm 7 -c tessedit_char_whitelist={whitelist}")
    except Exception:
        return ""


def fraction(text):
    """(n, of) from "6/10", or None."""
    m = re.search(r"(\d+)\s*/\s*(\d+)", text or "")
    return (int(m.group(1)), int(m.group(2))) if m else None


def kit_button(img, x):
    """'buy' when the column's upgrade button is teal with a white price, 'poor' when the
    price is red (not enough silver), None when there is no button ("Reach Lv. N ...")."""
    region = img[KIT_BUTTON_Y - 22:KIT_BUTTON_Y + 22, x - 58:x + 58]
    hsv = cv2.cvtColor(region, cv2.COLOR_BGR2HSV)
    teal = cv2.inRange(hsv, (80, 120, 150), (100, 255, 255)).mean() / 255
    if teal < 0.3:
        return None
    red = cv2.inRange(hsv, (0, 150, 150), (8, 255, 255)) | cv2.inRange(hsv, (172, 150, 150), (180, 255, 255))
    return "poor" if red.sum() / 255 > 25 else "buy"


class Counters:
    """Reads the depth and catch counters, on a worker thread when live (OCR ~0.2 s would
    freeze the steering)."""

    def __init__(self, bot, threaded):
        self.bot = bot
        self.out = []
        self.lock = threading.Lock()
        self.threaded = threaded
        self.busy = False

    def _work(self, img):
        depth = fraction(self.bot.read(img, DEPTH_BOX))
        got = self.bot.catch_count(img)
        with self.lock:
            self.out.append((depth, got))
            self.busy = False

    def feed(self, img):
        if not self.threaded:
            return self._work(img)
        with self.lock:
            if self.busy:
                return
            self.busy = True
        threading.Thread(target=self._work, args=(img.copy(),), daemon=True).start()

    def results(self):
        with self.lock:
            out, self.out = self.out, []
        return out


class Tourney:
    def __init__(self, device, vision, sleep=time.sleep, clock=time.monotonic, touch=None,
                 read=ocr, hook_fn=None, pick_fn=None, stream=None):
        self.d, self.v, self.sleep, self.clock = device, vision, sleep, clock
        self.touch = touch
        self.read = read
        self.hook_fn = hook_fn or fv.hook
        self.pick_fn = pick_fn  # None: the predictive picker (fishing_adb/predict.py)
        self.tracker = predict.Tracker()
        self.rounds = 0
        self.bought = 0
        self.upgraded = False  # checked Kit Upgrades since the last round
        self.stream = stream  # live video frames for the rounds (intel_adb.stream.Stream)
        self.frame_t = 0.0
        self.capacity = self.last_catch = None
        self.target = None
        self.hold_until, self.last_y = 0.0, 120
        self.steering = None

    def shot(self):
        return self.d.screencap()

    def seen(self, img, name):
        box = REGIONS.get(name)
        if box is not None and isinstance(img, np.ndarray):  # fixed spot: ~1 ms instead of ~57
            x0, y0, x1, y1 = box
            img = img[y0:y1, x0:x1]
        return self.v.has(img, name, SEEN)

    def attempts(self, img):
        got = fraction(self.read(img, ATTEMPTS_BOX))
        return got[0] if got else None

    # ---- kit -----------------------------------------------------------
    def upgrade(self):
        """On the Kit Upgrades popup: buy what's affordable, Line > Hook > Sinker."""
        for _ in range(MAX_BUYS):
            img = self.shot()
            if not self.seen(img, "kit_title"):
                break
            pick = next((k for k, x in KIT_COLUMNS.items() if kit_button(img, x) == "buy"), None)
            if not pick:
                break
            self.d.tap(KIT_COLUMNS[pick], KIT_BUTTON_Y)
            self.bought += 1
            self.d.log(f"fishing: upgraded {pick}")
            self.sleep(1.2)
        self.d.tap(*KIT_CLOSE)
        self.sleep(1)

    # ---- a round -------------------------------------------------------
    def frame(self):
        """Newest live frame (video stream, ~100/s) or a screenshot (~2/s on Primary)."""
        if self.stream is not None:
            got = self.stream.latest(newer_than=self.frame_t, timeout=1.0)
            if got is not None:
                img, self.frame_t = got
                return img
        return self.shot()

    def catch_count(self, img):
        """(caught, capacity) from the HUD, or None. Trusted only when it reads the same twice
        in a row with the capacity seen at the start (seen live: "0/11" read as "3/1")."""
        got = fraction(self.read(img, CATCH_BOX))
        if not got or got[0] > got[1]:
            return None
        if self.capacity is None and got[0] == 0 and got[1] >= 5:
            self.capacity = got[1]
        if got[1] != self.capacity:
            return None
        same = got == self.last_catch
        self.last_catch = got
        return got if same else None

    def steer(self, img, det, sinking, t):
        """Pick a lane (kept for a moment, so the hook doesn't zigzag) and let the steering
        model put the hook there (fishing_adb/steering.py)."""
        st = self.steering
        hx = st.observe(t, det[0] if det else None)
        if hx is None:
            hx = det[0] if det else 270
        y = det[1] if det else self.last_y
        aim_from = st.hook_final()
        aim_from = hx if aim_from is None else aim_from
        finger = getattr(self.touch, "down_at", None)
        if self.pick_fn is None:  # predictive: where fish will cross the hook's depth
            self.tracker.update(t, predict.objects(img, hook=(hx, y), finger=finger))
        if self.target is None or t >= self.hold_until:
            if self.pick_fn is None and sinking:  # dodge: the whole trip to the lane must be clear
                new = predict.pick_lane_path(self.tracker, y, int(aim_from), True, self.target)
            elif self.pick_fn is None:  # reeling in: the lane with the most fish coming
                # only a fish under the hook's tip is caught (seen live: fish level with
                # the hook but 60 px aside were missed): aim narrow, no safety margin
                score = predict.lane_marks(self.tracker, y, sinking, hook_w=CATCH_W, margin=0)
                new = predict.pick_lane(score, int(aim_from), sinking, self.target)
            else:
                new = self.pick_fn(img, (int(aim_from), y), sinking, finger, self.target)
            if new != self.target:
                self.target = new
                self.hold_until = t + LANE_HOLD
        st.steer(t, self.target)
        return hx

    def play_round(self):
        """From the cast until the Haul shows. Returns True when it got to the Haul."""
        end = self.clock() + ROUND_TIMEOUT
        last = (270, 120)
        sinking = True
        low = 0  # frames in a row with the hook low on screen
        deepest = 0  # m, from the HUD depth counter
        top = 0  # frames with the hook settled near the top while sinking
        reel_votes = 0
        full = False
        self.capacity, self.last_catch = None, None
        self.target, self.hold_until, self.last_y = None, 0.0, 120
        self.steering = Steering(self.touch, FINGER_Y)
        self.tracker = predict.Tracker()
        settled = 0  # frames with the hook seen near the top: from then on it follows the finger
        next_count = 0
        self.counters = Counters(self, threaded=self.stream is not None)
        t0 = self.clock()
        try:
            while self.clock() < end:
                img = self.frame()
                if self.seen(img, "haul_title"):
                    return True
                if not self.seen(img, "pause"):  # countdown / cast / catch animations
                    continue  # keep the finger where it is: lifting it makes the hook jump
                det = self.hook_fn(img)  # the hook's glow on the line, or None
                h = det or last
                low = low + 1 if h[1] >= SINK_Y else 0
                top += h[1] < TOP_Y and deepest >= MIN_DEPTH  # settled near the top, sinking
                settled += det is not None and det[1] < TOP_Y
                last = h
                self.last_y = h[1]
                if self.clock() >= next_count:  # OCR is slow (~0.2 s): once a second, off-thread
                    next_count = self.clock() + 1.0
                    self.counters.feed(img)
                for depth, got in self.counters.results():
                    if depth and depth[0] <= depth[1]:
                        if sinking and depth[0] < deepest - 2 and deepest >= MIN_DEPTH:
                            reel_votes += 1
                        elif depth[0] >= deepest:
                            reel_votes = 0  # misread: still going down
                        deepest = max(deepest, depth[0])
                    if not sinking and not full and got and got[0] >= got[1]:
                        full = True
                        self.d.log(f"fishing: hook full ({got[0]}/{got[1]})")
                # reeling in: the depth counter went back up, or (between reads) the hook has
                # been low on screen for a while once we're properly down
                # (a dive starts with the hook low on screen too, before it settles at the top)
                if sinking and (reel_votes >= 2 or (top >= TOP_FRAMES and low >= LOW_FRAMES)):
                    sinking = False
                    self.target = None
                    self.tracker = predict.Tracker()  # the sea now scrolls the other way
                    self.d.log(f"fishing: reeling in from {deepest} m")
                if full:
                    self.steering.release()
                    continue
                if sinking and settled < 3:  # still dropping in from the cast: it won't follow yet
                    continue
                t = self.clock()
                hx = self.steer(img, det, sinking, t)
                st = self.steering
                self.trace(f"{t - t0:7.2f} {'down' if sinking else 'up  '} seen={det} hook={hx and round(hx)} "
                           f"target={self.target} finger={st.finger and round(st.finger)} "
                           f"k={st.k:.2f} offset={st.offset and round(st.offset)}")
            return False
        finally:
            try:
                self.steering.release()
            except Exception as e:  # never hide the real error behind this one
                self.d.log(f"fishing: couldn't lift the finger ({e})")
            self.trace(f"touch pipe reopened {getattr(self.touch, 'reopens', 0)} time(s) so far")
            self.trace(None)

    def trace(self, line):
        """Per-round decision log (fishing_adb/debug/trace_<instance>.txt) for diagnosis."""
        try:
            DEBUG_DIR.mkdir(parents=True, exist_ok=True)
            path = DEBUG_DIR / f"trace_{self.d.name}.txt"
            with open(path, "a", encoding="utf-8") as f:
                f.write("--- round end\n" if line is None else line + "\n")
        except Exception:
            pass

    # ---- main loop -----------------------------------------------------
    def run(self, max_rounds=10):
        unknown = 0
        while self.rounds < max_rounds:
            img = self.shot()
            if self.seen(img, "haul_title"):
                self.d.log("fishing: haul - retreat")
                self.d.tap(*RETREAT)  # never the Fishing Voucher
                self.upgraded = False
                self.sleep(2)
                continue
            if self.seen(img, "kit_title"):
                self.upgrade()
                self.upgraded = True
                continue
            if self.seen(img, "go_fish"):  # a stage left unfinished: resuming costs no attempt
                self.d.log("fishing: resuming the unfinished stage (Go Fish)")
                self.d.tap(*GO_FISH)
                self.sleep(2)
                continue
            if self.seen(img, "pause"):  # a round is already running: take it over
                unknown = 0
                self.d.log("fishing: a round is running - taking over")
                if self.play_round():
                    self.rounds += 1
                continue
            if self.seen(img, "tourney_title"):
                unknown = 0
                if not self.upgraded:
                    self.d.tap(*KIT_CARD)
                    self.sleep(1.2)
                    if not self.seen(self.shot(), "kit_title"):
                        self.upgraded = True  # no popup: nothing to do there
                    continue
                left = self.attempts(img)
                if left is None:
                    self.d.log("fishing: can't read the attempts counter - stopping")
                    break
                if left <= 0:
                    self.d.log("fishing: no free attempts left")
                    break
                self.d.log(f"fishing: cast ({left} free attempt(s) left)")
                self.d.tap(*REGULAR)
                self.sleep(2)
                if self.play_round():
                    self.rounds += 1
                continue
            unknown += 1
            if unknown >= 20:  # ~10 s on a screen we don't know (a purchase popup?): stop
                self.save_debug(img, "unknown")
                self.d.log("fishing: unknown screen - stopping, nothing tapped")
                break
            self.sleep(POLL)
        self.d.log(f"fishing: finished - {self.rounds} round(s), {self.bought} upgrade(s)")
        return self.rounds

    def save_debug(self, img, tag):
        try:
            DEBUG_DIR.mkdir(parents=True, exist_ok=True)
            cv2.imwrite(str(DEBUG_DIR / f"{self.d.name}_{tag}_{time.strftime('%H%M%S')}.png"), img)
        except Exception:
            pass


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--only", default="Falkor")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--rounds", type=int, default=10)
    args = ap.parse_args(argv)
    adb.ADB_GAP = 0
    devices = adb.discover(only=args.only, dry_run=args.dry_run)
    if not devices:
        print(f"Kingshot is not open on {args.only!r}.")
        return
    dev = devices[0]
    print(f"Fishing Tournament on {dev.name}{' (dry run)' if args.dry_run else ''}", flush=True)
    with Touch(dev) as touch, Stream(dev) as stream:
        Tourney(dev, Vision(TEMPLATE_DIR), touch=touch, stream=stream).run(args.rounds)


if __name__ == "__main__":
    main()
