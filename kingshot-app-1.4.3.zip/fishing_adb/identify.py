"""Which catalogue entry (and so how many stars) an object in the sea is.

The in-game sprites are the catalogue pictures, bigger and facing either way. Each object's
pixels are compared with every catalogue picture scaled to the object's size, both ways
round: colour difference over the overlap plus how well the outlines agree."""
import json
from pathlib import Path

import cv2
from intel_adb.vision import imread as _imread
import numpy as np

from fishing_adb.catalogue import CAT_DIR

SIZE = 32  # comparison grid
MAX_SCORE = 0.95  # worse than this: unknown (deep water tints fish: right matches score up to ~0.9)
# colour make-up decides (size/facing free); outline and aspect break ties. Tested on the
# Falkor/Primary frames: puffer, small blue fish, flatfish, red bream, coral right.
W_COLOR, W_SHAPE, W_ASPECT, W_HIST = 0.0, 0.3, 0.2, 1.0


def _hist(pic, mask):
    """Hue x saturation x brightness make-up of the object's pixels (size and facing free)."""
    hsv = cv2.cvtColor(pic, cv2.COLOR_BGR2HSV)
    h = cv2.calcHist([hsv], [0, 1, 2], (mask > 127).astype(np.uint8), [18, 4, 4], [0, 180, 0, 256, 0, 256])
    return cv2.normalize(h, None, 1, 0, cv2.NORM_L1).flatten()


def _prep(pic, mask):
    ys, xs = np.where(mask > 0)
    if len(xs) < 10:
        return None
    x0, x1, y0, y1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
    pic, mask = pic[y0:y1, x0:x1], mask[y0:y1, x0:x1]
    lab = cv2.cvtColor(cv2.resize(pic, (SIZE, SIZE), interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2LAB).astype(np.float32)
    m = cv2.resize(mask, (SIZE, SIZE), interpolation=cv2.INTER_AREA) > 127
    return lab, m, (x1 - x0) / max(1, (y1 - y0))


class Catalogue:
    def __init__(self, cat_dir=CAT_DIR):
        self.entries = []
        self.hists = []
        for e in json.loads((Path(cat_dir) / "index.json").read_text(encoding="utf-8")):
            pic = _imread(str(Path(cat_dir) / e["file"]))
            mask = _imread(str(Path(cat_dir) / e["file"].replace(".png", "_mask.png")), 0)
            if pic is None or mask is None:
                continue
            self.hists.append(_hist(pic, mask))
            for flip in (False, True):
                p = _prep(cv2.flip(pic, 1) if flip else pic, cv2.flip(mask, 1) if flip else mask)
                if p:
                    self.entries.append((e, *p, len(self.hists) - 1))
        self.labs = np.stack([x[1] for x in self.entries])
        self.masks = np.stack([x[2] for x in self.entries])
        self.aspects = np.array([x[3] for x in self.entries])
        self.hist_of = np.array([x[4] for x in self.entries])
        self.H = np.stack(self.hists)

    def identify(self, pic, mask):
        """(entry, score) of the best match, or (None, score) if nothing is close enough."""
        p = _prep(pic, mask)
        if p is None:
            return None, 1.0
        lab, m, aspect = p
        both = self.masks & m[None]
        union = self.masks | m[None]
        iou = both.sum(axis=(1, 2)) / np.maximum(union.sum(axis=(1, 2)), 1)
        diff = np.abs(self.labs - lab[None]).mean(axis=3)  # per pixel
        cdiff = (diff * both).sum(axis=(1, 2)) / np.maximum(both.sum(axis=(1, 2)), 1) / 100.0
        adiff = np.abs(np.log(self.aspects / max(aspect, 1e-3)))
        hh = _hist(pic, mask)
        bhat = np.sqrt(np.clip(1 - np.sqrt(self.H * hh[None]).sum(axis=1), 0, 1))[self.hist_of]  # 0 same .. 1 different
        score = W_COLOR * cdiff + W_SHAPE * (1 - iou) + W_ASPECT * adiff + W_HIST * bhat
        k = int(np.argmin(score))
        e = self.entries[k][0]
        return (e if score[k] <= MAX_SCORE else None), float(score[k])
