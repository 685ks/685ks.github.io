"""Steering the Fishing Tournament hook by dragging a held finger.

Measured on Primary 2026-10-13 (fishing_adb/frames/trace_primary_1210.txt): while a finger
is held, the hook sits at  K * finger_x + offset  about LAG s later (K 1.46, LAG 0.26 s,
median error 4 px). The offset is new every time a finger goes down.

So instead of chasing the hook: aim the finger straight at the spot that puts the hook in
its lane, slide it there at a capped speed, and keep the offset up to date from the hook
positions actually seen. A seen position far from where the hook must be (a glow on a
fish, a rock edge) is ignored, and while the hook is hidden the model says where it is."""
import collections

K = 1.46  # hook px per finger px
LAG = 0.26  # s between a finger move and the hook showing it on the stream
SPEED = 700.0  # finger px/s at most (hook ~1000 px/s): quick, but no teleports
GRIP_X = 270  # where the finger goes down (again)
FINGER_MIN, FINGER_MAX = 30, 510
TRUST = 60  # px: a detection further than this from the model is not the hook
REACQUIRE_S = 3.0  # s of detections far from the model before believing them instead
OFFSET_N = 9  # recent offset samples (median)
DEADBAND = 6  # px of hook error not worth moving for
SETTLE = 0.25  # s the finger must have been still before a frame counts for learning


class Steering:
    def __init__(self, touch, finger_y, k=K, lag=LAG, speed=SPEED):
        self.touch = touch
        self.y = finger_y
        self.k, self.lag, self.speed = k, lag, speed
        self.finger = None  # where our finger is now (None = not down)
        self.history = collections.deque(maxlen=400)  # (t, finger_x) since the last grip
        self.points = collections.deque(maxlen=60)  # settled (finger, hook) pairs of this grip
        self.offset = None
        self.rejected_since = None
        self.last_t = None

    # ---- model ---------------------------------------------------------
    def finger_at(self, t):
        """Where the finger was at time t (the history is in time order)."""
        if not self.history:
            return None
        if t <= self.history[0][0]:
            return self.history[0][1]
        prev = self.history[0]
        for item in self.history:
            if item[0] >= t:
                t0, x0 = prev
                t1, x1 = item
                return x0 if t1 == t0 else x0 + (x1 - x0) * (t - t0) / (t1 - t0)
            prev = item
        return self.history[-1][1]

    def hook_now(self, t):
        """Where the hook is on screen now (what the stream shows), from the model."""
        f = self.finger_at(t - self.lag)
        return None if f is None or self.offset is None else self.k * f + self.offset

    def hook_final(self):
        """Where the hook ends up once the latest finger move shows."""
        return None if self.finger is None or self.offset is None else self.k * self.finger + self.offset

    def observe(self, t, hook_x):
        """A detected hook x on the frame shown at time t (None = not seen). Returns the
        hook x to trust for this frame, or None."""
        if hook_x is None or self.finger is None:
            return self.hook_now(t)
        f = self.finger_at(t - self.lag)
        model = self.hook_now(t)
        if model is not None and abs(hook_x - model) > TRUST:
            if self.rejected_since is None:
                self.rejected_since = t
            if t - self.rejected_since < REACQUIRE_S:
                return model  # a glow on a fish, a rock edge... (seen live for 1.6 s)
            self.points.clear()  # far off for this long: the model is wrong, re-learn it
        self.rejected_since = None
        # learn only from frames where the finger had been still for a while: then the hook
        # has caught up, whatever the exact delay
        if self.offset is None or self.steady(t):
            self.points.append((f, hook_x))
            self.learn_k()
            # offset from the latest settled points, with the current k
            recent = list(self.points)[-OFFSET_N:]
            offs = sorted(h - self.k * ff for ff, h in recent)
            self.offset = offs[len(offs) // 2]
        return hook_x

    def steady(self, t):
        """The finger didn't move in the SETTLE s before the frame's moment (t - lag)."""
        a = self.finger_at(t - self.lag - SETTLE)
        b = self.finger_at(t - self.lag)
        return a is not None and abs(a - b) < 1.0 and self.history and self.history[0][0] <= t - self.lag - SETTLE

    def learn_k(self):
        """Fit hook = k*finger + c over the settled points of this grip, once the finger
        has been at clearly different places; pulled toward the measured K."""
        if len(self.points) < 6:
            return
        fs = [f for f, _ in self.points]
        if max(fs) - min(fs) < 40:
            return
        n = len(self.points)
        mf = sum(fs) / n
        mh = sum(h for _, h in self.points) / n
        sxx = sum((f - mf) ** 2 for f in fs)
        sxy = sum((f - mf) * (h - mh) for f, h in self.points)
        k = sxy / sxx
        if 0.5 <= k <= 3.0:
            self.k = 0.7 * k + 0.3 * K

    # ---- finger --------------------------------------------------------
    def _down(self, t, x):
        self.touch.down(x, self.y)
        self.finger = x
        self.history.clear()
        self.history.append((t, x))

    def grip(self, t, hook_x=None):
        """Put the finger down (again) in the middle. The hook stays where it is, so the
        new offset follows from where it is now."""
        keep = self.hook_final() if hook_x is None else hook_x
        if self.finger is not None:
            self.touch.up()
        self._down(t, GRIP_X)
        self.points.clear()
        self.rejected_since = None
        self.offset = None if keep is None else keep - self.k * GRIP_X

    def steer(self, t, target_x):
        """Move the finger toward the spot that puts the hook at target_x."""
        if self.finger is None:
            self.grip(t)
            self.last_t = t
            return
        dt = 0.0 if self.last_t is None else max(0.0, min(0.1, t - self.last_t))
        self.last_t = t
        if self.offset is None:  # don't know where the hook is relative to the finger yet
            self.history.append((t, self.finger))
            return
        want = (target_x - self.offset) / self.k
        if not FINGER_MIN <= want <= FINGER_MAX:  # out of room: grip again in the middle
            self.grip(t)
            want = (target_x - self.offset) / self.k
        if abs(want - self.finger) * self.k <= DEADBAND:
            self.history.append((t, self.finger))
            return
        step = max(-self.speed * dt, min(self.speed * dt, want - self.finger))
        self.finger += step
        self.finger = min(max(self.finger, FINGER_MIN), FINGER_MAX)
        self.touch.move(self.finger, self.y)
        self.history.append((t, self.finger))

    def release(self):
        if self.finger is not None:
            self.touch.up()
        self.finger = None
        self.history.clear()
        self.offset = None
