"""Fishing Tournament round vision (recorded on Falkor 2026-10-13, fishing_adb/frames).

The hook hangs on a thin line from the top of the screen and has a bright green glow on
top. Sinking, it sits near the top (y ~100-150) with the sea scrolling up past it; reeling
in, it sits near the bottom. Water is a saturated blue (hue ~95-110, saturation > 200);
fish, crabs, rocks and weed are everything else."""
import cv2
import numpy as np

HUD = (0, 0, 140, 130)  # x0, y0, x1, y1: shields / catch / depth counters, top left
PAUSE = (480, 0, 540, 60)


def _glow(hsv):
    h, s, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
    return ((h >= 40) & (h <= 62) & (s >= 50) & (v >= 200)).astype(np.uint8)


def _line_above(hsv, x, y, span=40):
    """Share of the rows above (x, y) that look like the line: less saturated than the
    water a few px to each side."""
    y0 = max(0, y - span)
    if y0 >= y - 4:
        return 0.0
    s = hsv[y0:y - 4, :, 1].astype(int)
    hits = 0
    for row in s:
        c = row[max(0, x - 2):x + 3].min()
        sides = max(row[max(0, x - 9)], row[min(len(row) - 1, x + 9)])
        hits += c < sides - 40
    return hits / max(1, (y - 4 - y0))


def line_x(img, rows=(0, 90), min_share=0.5):
    """x of the line: a thin column less saturated than the water either side of it,
    over most of `rows`. None if not seen (e.g. under the HUD)."""
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    s = hsv[rows[0]:rows[1], :, 1].astype(np.int16)
    side = np.maximum(np.roll(s, 7, axis=1), np.roll(s, -7, axis=1))
    thin = (s < side - 40) & (s < 200)
    cols = thin.sum(axis=0).astype(float)
    cols[:3] = cols[-3:] = 0
    x0, y0, x1, y1 = HUD
    if rows[0] < y1:
        cols[x0:x1] = 0
    cols = np.convolve(cols, np.ones(3), "same")
    x = int(np.argmax(cols))
    return x if cols[x] >= (rows[1] - rows[0]) * min_share else None


def hook(img):
    """(x, y) of the hook's green glow, or None."""
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    m = _glow(hsv)
    x0, y0, x1, y1 = HUD
    m[y0:y1, x0:x1] = 0
    n, _, st, cen = cv2.connectedComponentsWithStats(m)
    lx = line_x(img)  # the hook hangs on the line: green weed doesn't
    best = None
    for k in range(1, n):
        w, h, area = st[k][2], st[k][3], st[k][4]
        if not (12 <= area <= 260 and w <= 24 and h <= 26):
            continue
        x, y = int(cen[k][0]), int(cen[k][1])
        if lx is not None and abs(x - lx) > 14:
            continue
        score = _line_above(hsv, x, int(st[k][1]))
        if score >= 0.5 and (best is None or score > best[0]):
            best = (score, (x, y))
    return best[1] if best else None


X_RANGE = (150, 490)  # keep the hook here: clear of the HUD and the screen edges
HOOK_W = 56  # px the hook (with its shield) covers
LOOK = 450  # px ahead of the hook that count
WALL_H = 150  # px: an edge blob this tall is a rock/weed wall, not a fish
MOVE_COST = 0.6
KEEP_RATIO = 1.5  # keep the current lane unless the best is this much better...
KEEP_MARGIN = 60  # ...plus this (lane-score units)
FINGER_R = 26  # px around our own finger that are ignored (Android touch dot)  # how much a px of sideways travel weighs against a px of fish


def free_objects(ob):
    """The obstacle mask without rock / weed walls: tall blobs touching a side edge.
    (A fish swimming in from the side is short, and stays.)"""
    n, lab, st, _ = cv2.connectedComponentsWithStats(ob)
    w = ob.shape[1]
    keep = np.zeros(n, bool)
    for k in range(1, n):
        x, _, bw, bh, _ = st[k]
        keep[k] = not ((x <= 3 or x + bw >= w - 3) and bh > WALL_H)
    return keep[lab].astype(np.uint8)


def lane_scores(ob, hook_xy, sinking):
    """Per-column amount of objects in the hook's path, nearer rows weighing more."""
    hx, hy = hook_xy
    h = ob.shape[0]
    if sinking:
        y0, y1 = min(h, hy + 30), min(h, hy + LOOK)
        dist = np.arange(y0, y1) - hy
    else:
        y0, y1 = max(0, hy - LOOK), max(0, hy - 30)
        dist = hy - np.arange(y0, y1)
    if y1 <= y0:
        return np.zeros(ob.shape[1])
    wts = 1.0 / (1.0 + dist / 120.0)
    cols = (ob[y0:y1].astype(float) * wts[:, None]).sum(axis=0)
    return np.convolve(cols, np.ones(HOOK_W), "same")


def pick_x(img, hook_xy, sinking, finger=None, keep=None):
    """Where to steer: sinking, the clearest lane (shields last); reeling in, the lane with
    the most fish. `keep`: the lane we're steering to - kept unless another is clearly
    better, so the hook doesn't zigzag. `finger`: where our own finger is - with Android's
    touch dots on (while recording) its dot would look like a fish."""
    hx = min(max(hook_xy[0], X_RANGE[0]), X_RANGE[1])
    ob = free_objects(obstacles(img))
    if finger is not None:
        cv2.circle(ob, (int(finger[0]), int(finger[1])), FINGER_R, 0, -1)
    score = lane_scores(ob, (hx, hook_xy[1]), sinking)
    xs = np.arange(X_RANGE[0], X_RANGE[1] + 1)
    travel = MOVE_COST * np.abs(xs - hx)
    if sinking:
        cost = score[xs] + travel
        best = int(xs[np.argmin(cost)])
        if keep is not None and X_RANGE[0] <= keep <= X_RANGE[1]:
            kc = score[keep] + MOVE_COST * abs(keep - hx)
            if kc <= cost.min() * KEEP_RATIO + KEEP_MARGIN:
                return int(keep)
        return best
    gain = score[xs] - travel
    best = int(xs[np.argmax(gain)])
    if keep is not None and X_RANGE[0] <= keep <= X_RANGE[1]:
        kg = score[keep] - MOVE_COST * abs(keep - hx)
        if kg >= gain.max() / KEEP_RATIO - KEEP_MARGIN:
            return int(keep)
    return best if gain.max() > score[hx] * 0.5 + 50 else hx


def obstacles(img):
    """1 where something other than open water is (fish, crabs, rocks, weed, items).
    Water changes from light cyan near the surface to dark blue deep down, so each row is
    compared with its own typical (median) colour: fish differ in hue, are much less
    saturated (grey/white) or much brighter/darker. Background silhouettes are only a bit
    darker and stay water."""
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV).astype(np.int16)
    h, s, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
    med = np.median(hsv[:, 140:], axis=1)  # skip the HUD column
    mh, ms, mv = med[:, 0:1], med[:, 1:2], med[:, 2:3]
    m = ((np.abs(h - mh) > 9) | (s < ms - 50) | (np.abs(v - mv) > 45)).astype(np.uint8)
    # thin things (the fishing line, streaks) would join every fish into one blob: drop them
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((8, 8), np.uint8))
    x0, y0, x1, y1 = HUD
    m[y0:y1, x0:x1] = 0
    x0, y0, x1, y1 = PAUSE
    m[y0:y1, x0:x1] = 0
    return m
