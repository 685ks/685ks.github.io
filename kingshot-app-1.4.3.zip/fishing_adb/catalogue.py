"""The fish catalogue: every catchable thing's picture and star count, cut from a recording
of the in-game catalogue (Falkor 2026-10-13, all seasons - user: "all the fish that exist").

    python -m fishing_adb.catalogue VIDEO START END   -> fishing_adb/catalogue/*.png + index.json
"""
import json
import sys
from pathlib import Path

import cv2
import numpy as np

CAT_DIR = Path(__file__).parent / "catalogue"
CARD_W = (95, 125)  # px, a card in the 540-wide frame
CARD_H = (105, 140)
STAR_STRIP = 30  # px at the card's top holding the stars


def frame540(f):
    if f.shape[1] >= 1080 and f[f.shape[0] // 2:, f.shape[1] // 2:].max() < 10:
        f = f[: f.shape[0] // 2, : f.shape[1] // 2]
    return cv2.resize(f, (540, round(f.shape[0] * 540 / f.shape[1])))


def cards(img):
    """Fully visible catalogue cards: [(x, y, w, h)]."""
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    light = cv2.inRange(hsv, (85, 25, 170), (105, 160, 255))  # the cards' pale blue
    light = cv2.morphologyEx(light, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    n, _, st, _ = cv2.connectedComponentsWithStats(light)
    out = []
    for k in range(1, n):
        x, y, w, h, a = st[k]
        if CARD_W[0] <= w <= CARD_W[1] and CARD_H[0] <= h <= CARD_H[1] and a > 0.5 * w * h:
            if y > 2 and y + h < img.shape[0] - 2:
                out.append((int(x), int(y), int(w), int(h)))
    return out


def stars(card):
    """Stars along the card's top edge. They touch each other, so count by the width of the
    yellow run: 1 star 18 px, each more ~10.7 px (measured: 18, 28, 40, 50, 61)."""
    hsv = cv2.cvtColor(card[:STAR_STRIP], cv2.COLOR_BGR2HSV)
    m = cv2.inRange(hsv, (14, 100, 140), (30, 255, 255))
    cols = np.where(m.sum(axis=0) > 0)[0]
    if len(cols) == 0:
        return 0
    width = cols.max() - cols.min() + 1
    if width < 12:
        return 0
    return int(round((width - 18) / 10.75)) + 1


def icon(card):
    """The picture under the stars, and a mask of its pixels (not the card's pale blue)."""
    pic = card[STAR_STRIP:, 4:-4]
    hsv = cv2.cvtColor(pic, cv2.COLOR_BGR2HSV)
    bg = cv2.inRange(hsv, (80, 20, 150), (108, 200, 255))
    mask = cv2.morphologyEx(255 - bg, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    return pic, mask


def signature(pic, mask):
    small = cv2.resize(cv2.bitwise_and(pic, pic, mask=mask), (24, 24), interpolation=cv2.INTER_AREA)
    return small.astype(np.int16)


def build(video, t0, t1, step=0.25, out_dir=CAT_DIR):
    out_dir.mkdir(parents=True, exist_ok=True)
    cap = cv2.VideoCapture(str(video))
    seen = []  # signatures already saved
    index = []
    t = t0
    while t < t1:
        cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000)
        ok, f = cap.read()
        t += step
        if not ok:
            break
        img = frame540(f)
        for x, y, w, h in cards(img):
            card = img[y:y + h, x:x + w]
            n = stars(card)
            if not 1 <= n <= 5:
                continue
            pic, mask = icon(card)
            if mask.mean() / 255 < 0.03:
                continue  # empty / not-yet-caught card
            sig = signature(pic, mask)
            if any(np.abs(sig - s).mean() < 12 for s in seen):
                continue
            seen.append(sig)
            name = f"{len(index):03d}_{n}star.png"
            cv2.imwrite(str(out_dir / name), pic)
            cv2.imwrite(str(out_dir / name.replace(".png", "_mask.png")), mask)
            index.append({"file": name, "stars": n, "t": round(t - step, 2)})
    (out_dir / "index.json").write_text(json.dumps(index, indent=1), encoding="utf-8")
    return index


if __name__ == "__main__":
    idx = build(sys.argv[1], float(sys.argv[2]), float(sys.argv[3]))
    from collections import Counter
    print(len(idx), "entries", dict(sorted(Counter(e["stars"] for e in idx).items())))
