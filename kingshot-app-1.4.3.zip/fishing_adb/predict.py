"""Where fish will be: track the blobs from frame to frame and project them forward.

Seen live (Primary 2026-10-14): both shields went to puffers drifting sideways into the
hook, which never were "in the lane below" on the (0.26 s old) frame the bot saw. So each
object gets a velocity, and the lane cost / value counts where it will cross the hook's
depth, not where it was."""
import cv2
import numpy as np

MATCH_DIST = 70  # px: the same object between two frames (fast scroll ~300-400 px/s)
MIN_AREA = 120
SMOOTH = 0.5  # weight of the newest velocity measurement
HORIZON = 1.6  # s ahead that count
MARGIN = 6  # px kept clear around a fish


def blobs(mask, min_area=None):
    """[(cx, cy, w, h, area, (x, y, w, h))] of the objects in a 0/1 mask."""
    min_area = MIN_AREA if min_area is None else min_area
    n, _, st, cen = cv2.connectedComponentsWithStats(mask)
    return [(float(cen[k][0]), float(cen[k][1]), int(st[k][2]), int(st[k][3]), int(st[k][4]),
             (int(st[k][0]), int(st[k][1]), int(st[k][2]), int(st[k][3])))
            for k in range(1, n) if st[k][4] >= min_area]


class Tracker:
    def __init__(self):
        self.tracks = []  # dicts: x, y, w, h, vx, vy, t, seen
        self.scroll = None  # typical vertical speed of everything (the sea scrolling)

    def update(self, t, objs):
        new = []
        used = set()
        for obj in objs:
            cx, cy, w, h, area = obj[:5]
            box = obj[5] if len(obj) > 5 else None
            best, bd = None, MATCH_DIST
            for i, tr in enumerate(self.tracks):
                if i in used:
                    continue
                dt = t - tr["t"]
                if dt <= 0 or dt > 0.5:
                    continue
                px, py = tr["x"] + tr["vx"] * dt, tr["y"] + tr["vy"] * dt  # where it should be
                d = abs(px - cx) + abs(py - cy)
                if d < bd and 0.4 < area / max(tr["area"], 1) < 2.5:
                    best, bd = i, d
            if best is None:
                vy0 = self.scroll if self.scroll is not None else 0.0
                new.append({"x": cx, "y": cy, "w": w, "h": h, "area": area, "vx": 0.0, "vy": vy0, "t": t, "seen": 1,
                            "box": box})
                continue
            used.add(best)
            tr = self.tracks[best]
            dt = t - tr["t"]
            vx, vy = (cx - tr["x"]) / dt, (cy - tr["y"]) / dt
            a = SMOOTH if tr["seen"] > 1 else 1.0
            tr.update(x=cx, y=cy, w=w, h=h, area=area, t=t, seen=tr["seen"] + 1, box=box,
                      vx=(1 - a) * tr["vx"] + a * vx, vy=(1 - a) * tr["vy"] + a * vy)
            new.append(tr)
        self.tracks = new
        moving = [tr["vy"] for tr in new if tr["seen"] >= 3]
        if len(moving) >= 3:
            self.scroll = float(np.median(moving))
        return new

    def lane_scores(self, hook_y, lag, sinking, width=540, hook_w=56):
        """Per-column cost (sinking) or value (reeling): every tracked object adds where its
        path crosses the hook's depth within HORIZON s, nearer in time weighing more.
        `lag`: how old the frame is - the objects have moved on by then."""
        score = np.zeros(width)
        for tr in self.tracks:
            if tr["seen"] < 2 and self.scroll is None:
                continue
            vy = tr["vy"] if tr["seen"] >= 2 else self.scroll
            y_now = tr["y"] + vy * lag
            x_now = tr["x"] + tr["vx"] * lag
            half_h = tr["h"] / 2 + 20
            dy = y_now - hook_y
            if abs(dy) <= half_h:  # level with the hook right now
                t_hit = 0.0
            elif (sinking and dy > 0 and vy < -1) or (not sinking and dy < 0 and vy > 1):
                t_hit = (abs(dy) - half_h) / abs(vy)  # coming toward the hook
            else:
                continue  # moving away / passed
            if t_hit > HORIZON:
                continue
            # it stays level with the hook for ~(height/speed): sweep its x over that time
            stay = (tr["h"] + 40) / max(abs(vy), 50)
            xs = [x_now + tr["vx"] * (t_hit + f * stay) for f in (0.0, 0.5, 1.0)]
            lo = int(max(0, min(xs) - tr["w"] / 2 - hook_w / 2 - MARGIN))
            hi = int(min(width, max(xs) + tr["w"] / 2 + hook_w / 2 + MARGIN))
            if hi <= lo:
                continue
            weight = tr["area"] / (0.25 + t_hit)
            score[lo:hi] += weight
        return score


TRAVEL = 0.004  # cost per px of sideways travel, lane_marks units
KEEP = 1.0  # keep the current lane unless the best is this much better...
KEEP_ADD = 2.0  # ...plus this (tuned offline on the Falkor + Primary dives)


HOOK_BLOB_DX, HOOK_BLOB_W, HOOK_BLOB_H = 26, 72, 110  # the hook + shield's own outline


def objects(img, hook=None, finger=None, mask=None, min_area=None):
    """Tracked-object candidates on a frame, without the hook itself and our finger's dot.
    `mask`: the frame's object mask if already computed."""
    from fishing_adb import vision as fv
    out = []
    for b in blobs(fv.free_objects(fv.obstacles(img)) if mask is None else mask, min_area):
        cx, cy = b[0], b[1]
        if (hook is not None and abs(cx - hook[0]) < HOOK_BLOB_DX and -15 < cy - hook[1] < 75
                and b[2] <= HOOK_BLOB_W and b[3] <= HOOK_BLOB_H):
            continue  # just the hook (+ shield): a fish touching it makes a bigger blob and stays
            # (seen live: ignoring 40 px around the hook dropped a puffer the moment it hit)
        if finger is not None and abs(cx - finger[0]) < 30 and abs(cy - finger[1]) < 30:
            continue
        out.append(b)
    return out


def pick_lane(score, hook_x, sinking, keep=None, x_range=(150, 490)):
    """Lowest predicted cost (sinking) / highest value (reeling), with a small travel cost
    and a preference for the lane we're already heading to (all in lane_marks units:
    roughly "object-moments" level with the hook)."""
    xs = np.arange(x_range[0], x_range[1] + 1)
    hx = min(max(hook_x, x_range[0]), x_range[1])
    travel = TRAVEL * np.abs(xs - hx)
    if sinking:
        cost = score[xs] + travel
        best = int(xs[np.argmin(cost)])
        if keep is not None and x_range[0] <= keep <= x_range[1]:
            if score[keep] + TRAVEL * abs(keep - hx) <= cost.min() * KEEP + KEEP_ADD:
                return int(keep)
        return best
    gain = score[xs] - travel
    best = int(xs[np.argmax(gain)])
    if gain.max() <= 0:
        return int(keep) if keep is not None else int(hx)
    if keep is not None and x_range[0] <= keep <= x_range[1]:
        if (score[keep] - TRAVEL * abs(keep - hx)) * KEEP + KEEP_ADD >= gain.max():
            return int(keep)
    return best


SHARED_VY = True
WINDOW = (0.3, 1.1)  # s after the frame was taken: when the lane we pick now matters


def lane_marks(tracker, hook_y, sinking, width=540, hook_w=56, window=None, step=0.1, margin=None):
    """Per-column count of (object, moment) pairs where a tracked object will be level with
    the hook in that column, over `window` s after the frame was taken."""
    lo_t, hi_t = window or WINDOW
    score = np.zeros(width)
    taus = np.arange(lo_t, hi_t + 1e-9, step)
    for tr in tracker.tracks:
        # the sea scrolls past at one speed for everything: the shared estimate is steadier
        vy = tracker.scroll if (SHARED_VY and tracker.scroll is not None) else (tr["vy"] if tr["seen"] >= 2 else tracker.scroll)
        if vy is None:
            continue
        ys = tr["y"] + vy * taus
        xs = tr["x"] + tr["vx"] * taus
        level = np.abs(ys - hook_y) <= tr["h"] / 2 + 25
        m = MARGIN if margin is None else margin
        for x in xs[level]:
            lo = int(max(0, x - tr["w"] / 2 - hook_w / 2 - m))
            hi = int(min(width, x + tr["w"] / 2 + hook_w / 2 + m))
            if hi > lo:
                score[lo:hi] += (1 + tr["area"] / 2000) * tr.get("value", 1.0)
    return score


HOOK_SPEED = 1000.0  # px/s the hook moves at most (finger speed x 1.46)
REACT = 0.26  # s before a new aim starts moving the hook (stream + touch lag)


def occupancy(tracker, hook_y, taus, width=540, hook_w=56):
    """occ[i, x] > 0: at time taus[i] after the frame, something is level with the hook in
    column x (widened by the hook's half width and MARGIN)."""
    occ = np.zeros((len(taus), width))
    for tr in tracker.tracks:
        vy = tracker.scroll if (SHARED_VY and tracker.scroll is not None) else (tr["vy"] if tr["seen"] >= 2 else tracker.scroll)
        if vy is None:
            continue
        for i, tau in enumerate(taus):
            y = tr["y"] + vy * tau
            if abs(y - hook_y) > tr["h"] / 2 + 25:
                continue
            x = tr["x"] + tr["vx"] * tau
            lo = int(max(0, x - tr["w"] / 2 - hook_w / 2 - MARGIN))
            hi = int(min(width, x + tr["w"] / 2 + hook_w / 2 + MARGIN))
            if hi > lo:
                occ[i, lo:hi] += 1
    return occ


def pick_lane_path(tracker, hook_y, hook_x, sinking, keep=None, x_range=(150, 490), step=20,
                   horizon=1.2, dt=0.05):
    """Pick the lane whose whole trip is clear: the hook keeps its place for REACT s, then
    moves at HOOK_SPEED to the lane and stays - every moment of that path is checked against
    where the objects will be (seen live: the hook crossed a puffer on its way to a lane
    that was clear at the end)."""
    taus = np.arange(0.0, horizon + 1e-9, dt)
    occ = occupancy(tracker, hook_y, taus)
    best, best_cost = None, None
    lanes = list(range(x_range[0], x_range[1] + 1, step))
    if keep is not None and x_range[0] <= keep <= x_range[1]:
        lanes.append(int(keep))
    for lane in lanes:
        xs = np.where(taus < REACT, hook_x,
                      hook_x + np.clip((taus - REACT) * HOOK_SPEED, 0, abs(lane - hook_x)) * np.sign(lane - hook_x))
        xs = np.clip(xs.astype(int), 0, occ.shape[1] - 1)
        hit = occ[np.arange(len(taus)), xs]
        # sooner collisions matter more; a little cost for moving at all
        cost = float((hit * (1.5 - taus / horizon)).sum()) + PATH_TRAVEL * abs(lane - hook_x)
        if lane == keep:
            cost -= PATH_KEEP
        if not sinking:
            cost = -cost + 2 * PATH_TRAVEL * abs(lane - hook_x)  # reeling: we want the fish
        if best_cost is None or cost < best_cost:
            best, best_cost = lane, cost
    return int(best)


PATH_TRAVEL = 0.002
PATH_KEEP = 0.3

