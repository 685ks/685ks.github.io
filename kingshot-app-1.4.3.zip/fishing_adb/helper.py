"""Fishing helper: you steer, it shows. Read-only - never taps or touches the game.

Over the BlueStacks game picture it draws, live:
  - a box around every fish / item in the sea, coloured by its stars
    (1 grey, 2 green, 3 blue, 4 purple, 5 gold; white "?" = not recognised),
  - a guide line: where the hook should be. Sinking: the lane whose whole trip stays clear of
    fish (fishing_adb/predict.py). Reeling in: the lane worth the most points coming down.

    python -m fishing_adb.helper [--only Primary]
"""
import argparse
import ctypes
import queue
import threading
import time
from collections import Counter
from ctypes import wintypes

import cv2

from intel_adb import adb
from intel_adb.stream import Stream
from intel_adb.vision import Vision
from fishing_adb import identify, predict, tourney, vision as fv

STAR_COLORS = {1: "#a0a0a0", 2: "#3cc83c", 3: "#2d8cff", 4: "#c040ff", 5: "#ffc800"}
UNKNOWN_COLOR = "#ffffff"
GUIDE_COLOR = "#00ff66"
POINTS = {1: 10, 2: 25, 3: 40, 4: 70, 5: 110}  # Haul: 1* 10, 3* 40, 4* 70 (2*/5* estimated)
STREAM_LAG = 0.08  # s the stream is behind the screen: boxes are drawn where things are now
                  # (--lag to tune: boxes trailing their fish = raise it, leading = lower it)
MIN_AREA = 50  # px: small fish count too (the bot's 120 skipped the little red/blue ones)
IDENTIFY_EVERY = 0.3  # s between re-identifications of one object
SURE = 0.6  # match score below this: thick box; above (up to identify.MAX_SCORE): thin, "?"
KEY = "#010203"  # the overlay's transparent colour
REF_W, REF_H = 540, 960


# ---- where the game picture is on screen ---------------------------------
_u = ctypes.windll.user32 if hasattr(ctypes, "windll") else None
_EnumProc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM) if _u else None


def _text(h):
    b = ctypes.create_unicode_buffer(256)
    _u.GetWindowTextW(h, b, 256)
    return b.value


def _rect(h):
    r = wintypes.RECT()
    _u.GetWindowRect(h, ctypes.byref(r))
    return r.left, r.top, r.right - r.left, r.bottom - r.top


def game_rect(instance):
    """Screen rect (x, y, w, h) of the instance's game picture: the 'HD-Player' child of the
    BlueStacks window titled with the instance's name. None if not found / minimised."""
    tops = []
    _u.EnumWindows(_EnumProc(lambda h, l: tops.append(h) or True), 0)
    for h in tops:
        if _u.IsWindowVisible(h) and _text(h) == instance and not _u.IsIconic(h):
            kids = []
            _u.EnumChildWindows(h, _EnumProc(lambda c, l: kids.append(c) or True), 0)
            best = None
            for c in kids:
                if _text(c) == "HD-Player" and _u.IsWindowVisible(c):
                    best = _rect(c)
            if best is None:
                return None
            x, y, w, h_ = best
            # the Android picture is 9:16 inside it (centred)
            if w / h_ > 9 / 16:
                nw = round(h_ * 9 / 16)
                return x + (w - nw) // 2, y, nw, h_
            nh = round(w * 16 / 9)
            return x, y + (h_ - nh) // 2, w, nh
    return None


# ---- what to draw ----------------------------------------------------------
class Analyzer:
    """Frames in, drawing instructions out (in the 540x960 reference frame)."""

    def __init__(self, vision, catalogue):
        self.v, self.cat = vision, catalogue
        self.tracker = predict.Tracker()
        self.hook = None
        self.sinking = True
        self.high = self.low = 0
        self.target = None
        self.hold_until = 0.0

    def reset(self):
        self.__init__(self.v, self.cat)

    def in_round(self, img):
        x0, y0, x1, y1 = tourney.REGIONS["pause"]
        return self.v.has(img[y0:y1, x0:x1], "pause", tourney.SEEN)

    def label(self, img, mask, tr, t):
        """Identify a tracked object now and then; it keeps the answer it got most often."""
        if t - tr.get("id_t", -9) < IDENTIFY_EVERY or tr.get("box") is None:
            return
        tr["id_t"] = t
        x, y, w, h = tr["box"]
        if x <= 2 or x + w >= REF_W - 2:
            tr["edge"] = True  # cut off by the screen edge (or a rock): don't guess
            return
        tr["edge"] = False
        pic = img[y:y + h, x:x + w]
        m = (mask[y:y + h, x:x + w] * 255).astype("uint8")
        if not pic.size or m.sum() == 0:
            return
        e, score = self.cat.identify(pic, m)
        votes = tr.setdefault("votes", Counter())
        if e is not None:
            votes[e["stars"]] += 1 if score > SURE else 2
            tr["score"] = min(score, tr.get("score", 9))
        stars = votes.most_common(1)[0][0] if votes else None
        tr["stars"] = stars
        tr["value"] = POINTS.get(stars, 10) / 10.0

    def update(self, img, t):
        if not self.in_round(img):
            if self.hook is not None:
                self.reset()
            return None
        h = fv.hook(img) or self.hook
        self.hook = h
        if h is not None:  # sinking: hook near the top; reeling in: lower, coming up
            if h[1] < 200:
                self.high += 1
                self.low = 0
            elif h[1] >= 400:
                self.low += 1
            if self.sinking and self.high >= 10 and self.low >= 10:
                self.sinking = False
                self.tracker = predict.Tracker()
                self.target = None
        mask = fv.free_objects(fv.obstacles(img))
        self.tracker.update(t, predict.objects(img, hook=h, mask=mask, min_area=MIN_AREA))
        for tr in self.tracker.tracks:
            self.label(img, mask, tr, t)
        guide = None
        if h is not None:
            if self.target is None or t >= self.hold_until:
                if self.sinking:
                    new = predict.pick_lane_path(self.tracker, h[1], h[0], True, self.target)
                else:
                    score = predict.lane_marks(self.tracker, h[1], False, hook_w=tourney.CATCH_W, margin=0)
                    new = predict.pick_lane(score, h[0], False, self.target)
                if new != self.target:
                    self.target, self.hold_until = new, t + tourney.LANE_HOLD
            guide = (self.target, h[1])
        boxes = []
        for tr in self.tracker.tracks:
            if tr.get("edge") or tr["seen"] < 2:
                continue
            x = tr["x"] + tr["vx"] * STREAM_LAG
            y = tr["y"] + tr["vy"] * STREAM_LAG
            stars = tr.get("stars")
            sure = tr.get("score", 9) <= SURE
            boxes.append((x - tr["w"] / 2, y - tr["h"] / 2, x + tr["w"] / 2, y + tr["h"] / 2, stars, sure))
        return {"boxes": boxes, "guide": guide, "sinking": self.sinking}


# ---- the overlay window --------------------------------------------------
def draw_on(img, d):
    """Render a drawing onto a frame (offline checks / screenshots)."""
    o = img.copy()
    if not d:
        return o
    for x0, y0, x1, y1, stars, sure in d["boxes"]:
        c = STAR_COLORS.get(stars, UNKNOWN_COLOR).lstrip("#")
        bgr = (int(c[4:6], 16), int(c[2:4], 16), int(c[0:2], 16))
        cv2.rectangle(o, (int(x0), int(y0)), (int(x1), int(y1)), bgr, 3 if sure else 1)
        cv2.putText(o, f"{stars}*" if stars else "?", (int(x0), int(y0) - 3), 0, 0.5, bgr, 2)
    if d["guide"] and d["guide"][0] is not None:
        gx, gy = d["guide"]
        cv2.line(o, (gx, 0), (gx, REF_H), (102, 255, 0), 2)
        cv2.circle(o, (gx, int(gy)), 18, (102, 255, 0), 3)
    return o


class Overlay:
    def __init__(self, instance):
        import tkinter as tk
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)  # screen pixels, like BlueStacks
        except Exception:
            pass
        self.instance = instance
        self.root = tk.Tk()
        self.root.overrideredirect(True)
        self.root.attributes("-topmost", True)
        self.root.configure(bg=KEY)
        self.root.attributes("-transparentcolor", KEY)
        self.canvas = tk.Canvas(self.root, bg=KEY, highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)
        self.root.update_idletasks()
        hwnd = self.hwnd = _u.GetParent(self.root.winfo_id())
        GWL_EXSTYLE = -20
        style = _u.GetWindowLongW(hwnd, GWL_EXSTYLE)
        # layered + transparent = clicks go straight through to the game; toolwindow = no taskbar
        _u.SetWindowLongW(hwnd, GWL_EXSTYLE, style | 0x80000 | 0x20 | 0x80 | 0x08000000)
        self.rect = None
        self.drawings = queue.Queue(maxsize=1)
        self.root.after(30, self.tick)

    def place(self):
        r = game_rect(self.instance)
        if r != self.rect:
            self.rect = r
            if r is None:
                self.root.withdraw()
            else:
                self.root.deiconify()
                self.canvas.configure(width=r[2], height=r[3])
                # "+-1919" = x -1919 from the left (an instance on a monitor left of the main one)
                self.root.geometry(f"{r[2]}x{r[3]}+{r[0]}+{r[1]}")
                self.root.update_idletasks()
                self.root.attributes("-topmost", True)

    def tick(self):
        if int(time.monotonic() * 2) != getattr(self, "_last_place", None):
            self._last_place = int(time.monotonic() * 2)
            self.place()
        try:
            d = self.drawings.get_nowait()
        except queue.Empty:
            d = "same"
        if d != "same" and self.rect:
            self.render(d)
        self.root.after(30, self.tick)

    def render(self, d):
        c = self.canvas
        c.delete("all")
        if not d:
            return
        sx, sy = self.rect[2] / REF_W, self.rect[3] / REF_H
        for x0, y0, x1, y1, stars, sure in d["boxes"]:
            col = STAR_COLORS.get(stars, UNKNOWN_COLOR)
            c.create_rectangle(x0 * sx, y0 * sy, x1 * sx, y1 * sy, outline=col, width=3 if sure else 1)
            c.create_text(x0 * sx, y0 * sy - 2, text=f"{stars}★" if stars else "?", fill=col, anchor="sw",
                          font=("Segoe UI", max(8, int(11 * sx)), "bold"))
        if d["guide"] and d["guide"][0] is not None:
            gx, gy = d["guide"]
            c.create_line(gx * sx, 0, gx * sx, REF_H * sy, fill=GUIDE_COLOR, width=3, dash=(8, 4))
            r = 18 * sx
            c.create_oval(gx * sx - r, gy * sy - r, gx * sx + r, gy * sy + r, outline=GUIDE_COLOR, width=3)

    def show(self, d):
        try:
            self.drawings.get_nowait()
        except queue.Empty:
            pass
        self.drawings.put_nowait(d)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--only", default="Primary")
    ap.add_argument("--lag", type=float, default=STREAM_LAG, help="s the boxes are moved ahead")
    a = ap.parse_args(argv)
    globals()["STREAM_LAG"] = a.lag
    devices = adb.discover(only=a.only)
    if not devices:
        print(f"Kingshot is not open on {a.only!r}.")
        return
    dev = devices[0]
    if game_rect(dev.name) is None:
        print(f"Can't find the BlueStacks window titled {dev.name!r} on screen (minimised?).", flush=True)
    print(f"Fishing helper on {dev.name}: you steer, follow the green line. Never taps.", flush=True)
    analyzer = Analyzer(Vision(tourney.TEMPLATE_DIR), identify.Catalogue())
    overlay = Overlay(dev.name)
    stop = threading.Event()

    def work():
        with Stream(dev) as stream:
            last = 0.0
            while not stop.is_set():
                got = stream.latest(newer_than=last, timeout=1.0)
                if got is None:
                    continue
                img, last = got
                try:
                    overlay.show(analyzer.update(img, last))
                except Exception as e:  # keep going; show nothing for this frame
                    print(f"helper: {e!r}", flush=True)

    threading.Thread(target=work, daemon=True).start()
    try:
        overlay.root.mainloop()
    finally:
        stop.set()


if __name__ == "__main__":
    main()
