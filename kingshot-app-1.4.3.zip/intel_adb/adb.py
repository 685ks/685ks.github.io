"""BlueStacks instance discovery and ADB device control."""
import random
import re
import socket
import subprocess
import threading
import time
from pathlib import Path

import cv2
import numpy as np

import os
import shutil


def find_adb():
    """adb to use: $KS_ADB, then BlueStacks' and MuMu's own, then one shipped next to the
    app (platform-tools/), then adb on PATH. BlueStacks' first: mixing adb versions makes
    them kill each other's server."""
    env = os.environ.get("KS_ADB")
    if env and Path(env).exists():
        return env
    pf = [Path(os.environ.get(v, d)) for v, d in (("ProgramFiles", r"C:\Program Files"),
                                                   ("ProgramFiles(x86)", r"C:\Program Files (x86)"))]
    candidates = []
    for base in pf:
        candidates += [base / "BlueStacks_nxt" / "HD-Adb.exe", base / "BlueStacks" / "HD-Adb.exe",
                       base / "Netease" / "MuMuPlayer" / "nx_main" / "adb.exe",
                       base / "Netease" / "MuMuPlayer-12.0" / "shell" / "adb.exe",
                       base / "Netease" / "MuMu Player 12" / "shell" / "adb.exe"]
    candidates.append(Path(__file__).resolve().parent.parent / "platform-tools" / "adb.exe")
    for c in candidates:
        if c.exists():
            return str(c)
    return shutil.which("adb") or str(candidates[0])


ADB_PATH = find_adb()
CONF_PATH = Path(os.environ.get("KS_BLUESTACKS_CONF", r"C:\ProgramData\BlueStacks_nxt\bluestacks.conf"))
KINGSHOT_PACKAGE = "com.run.tower.defense"
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)  # no console flash per adb call
REF_WIDTH = 540  # screenshots are scaled to this width; templates are captured at it

ADB_GAP = 0.15  # s between ADB commands across all instances (eases emulator lag)

_print_lock = threading.Lock()
ADB_PARALLEL = 3  # ADB commands running at once across all instances (more = faster, more CPU)
_adb_lock = threading.BoundedSemaphore(ADB_PARALLEL)
_gap_lock = threading.Lock()
_device_locks = {}  # serial -> lock: one command at a time per instance
_last_adb = [0.0]


def parse_conf(text):
    """[(display_name, status_adb_port)]. Stale entries can share a status port with a
    live instance; keep one per port, preferring the instance whose own adb_port matches."""
    names, ports, own = {}, {}, {}
    for m in re.finditer(r'bst\.instance\.([^.]+)\.display_name="([^"]*)"', text):
        names[m.group(1)] = m.group(2)
    for m in re.finditer(r'bst\.instance\.([^.]+)\.status\.adb_port="(\d+)"', text):
        ports[m.group(1)] = int(m.group(2))
    for m in re.finditer(r'bst\.instance\.([^.]+)\.adb_port="(\d+)"', text):
        own[m.group(1)] = int(m.group(2))
    by_port = {}
    for i in names:
        if i not in ports:
            continue
        port = ports[i]
        if port not in by_port or (own.get(i) == port and own.get(by_port[port]) != port):
            by_port[port] = i
    keep = set(by_port.values())
    return [(names[i], ports[i]) for i in names if i in keep]


def decode_raw(data):
    """`screencap` without -p: a 12- or 16-byte header (width, height, format[, colour space])
    then RGBA pixels. Returns a BGR image, or None if the data doesn't look like that."""
    if len(data) < 16:
        return None
    w, h, fmt = np.frombuffer(data[:12], np.uint32)
    if fmt != 1 or not (0 < w <= 8192 and 0 < h <= 8192):  # 1 = RGBA_8888
        return None
    header = len(data) - int(w) * int(h) * 4
    if header not in (12, 16):
        return None
    px = np.frombuffer(data, np.uint8, offset=header).reshape(int(h), int(w), 4)
    return cv2.cvtColor(px, cv2.COLOR_RGBA2BGR)


class Device:
    def __init__(self, name, serial, runner=subprocess.run, dry_run=False):
        self.name = name
        self.serial = serial
        self.runner = runner
        self.dry_run = dry_run
        self.scale = 1.0  # device px per reference px, set by screencap()
        self.off_x = 0  # device px left of the game picture (landscape screens, see screencap)
        self.raw_ok = True  # raw screencap works on this device (switches off on first failure)

    def _adb(self, *args, timeout=15):
        cmd = [ADB_PATH, "-s", self.serial, *args]
        dev_lock = _device_locks.setdefault(self.serial, threading.Lock())
        with dev_lock, _adb_lock:
            with _gap_lock:  # commands still start ADB_GAP apart (eases emulator lag)
                wait = _last_adb[0] + ADB_GAP - time.monotonic()
                if wait > 0:
                    time.sleep(wait)
                _last_adb[0] = time.monotonic()
            return self.runner(cmd, capture_output=True, timeout=timeout, creationflags=NO_WINDOW).stdout

    def log(self, msg):
        with _print_lock:
            print(f"[{self.name}] {msg}", flush=True)

    def screencap(self, tries=3):
        """A screenshot. A frozen / lagging emulator can make one take over 15 s (seen live
        2026-10-17): wait and try again instead of failing."""
        for attempt in range(tries):
            try:
                return self._screencap()
            except subprocess.TimeoutExpired:
                if attempt == tries - 1:
                    raise
                self.log("screenshot timed out (emulator busy) - retrying")
                time.sleep(3 * (attempt + 1))

    def _screencap(self):
        # raw frames skip the emulator's PNG compression (faster); PNG is the fallback
        img = decode_raw(self._adb("exec-out", "screencap")) if self.raw_ok else None
        if img is None:
            self.raw_ok = False
            data = self._adb("exec-out", "screencap", "-p")
            img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
        if img is None:
            raise RuntimeError("screencap returned no image")
        h, w = img.shape[:2]
        if w > h:  # landscape screen (Google Play Games emulator): the game is a centred portrait strip
            gw = round(h * 9 / 16)
            self.off_x = (w - gw) // 2
            img = img[:, self.off_x:self.off_x + gw]
        else:
            self.off_x = 0
        self.scale = img.shape[1] / REF_WIDTH
        if self.scale != 1.0:
            img = cv2.resize(img, (REF_WIDTH, round(img.shape[0] / self.scale)),
                             interpolation=cv2.INTER_AREA)
        return img

    def tap(self, x, y, jitter=3):
        x += random.randint(-jitter, jitter)
        y += random.randint(-jitter, jitter)
        dx, dy = round(x * self.scale) + self.off_x, round(y * self.scale)
        if self.dry_run:
            self.log(f"(dry-run) tap {dx},{dy}")
            return
        self._adb("shell", "input", "tap", str(dx), str(dy))

    def taps(self, points, jitter=2):
        """Several taps in ONE adb call (fast): [(x, y), ...] in reference coordinates."""
        if not points:
            return
        cmds = []
        for x, y in points:
            x += random.randint(-jitter, jitter)
            y += random.randint(-jitter, jitter)
            cmds.append(f"input tap {round(x * self.scale)} {round(y * self.scale)}")
        if self.dry_run:
            self.log(f"(dry-run) taps {points}")
            return
        self._adb("shell", "; ".join(cmds))

    def back(self):
        if self.dry_run:
            self.log("(dry-run) back")
            return
        self._adb("shell", "input", "keyevent", "4")

    def type_text(self, text):
        """Type into the focused field (digits/letters only - `input text` breaks on spaces)."""
        safe = "".join(ch for ch in str(text) if ch.isalnum())
        if self.dry_run:
            self.log(f"(dry-run) type {safe}")
            return
        self._adb("shell", "input", "text", safe)

    def swipe(self, x1, y1, x2, y2, ms=400):
        pts = [str(round(v * self.scale) + (self.off_x if i % 2 == 0 else 0)) for i, v in enumerate((x1, y1, x2, y2))]
        if self.dry_run:
            self.log(f"(dry-run) swipe {' '.join(pts)}")
            return
        self._adb("shell", "input", "swipe", *pts, str(ms))

    def foreground_package(self):
        out = self._adb("shell", "dumpsys", "window").decode(errors="ignore")
        m = re.search(r"mCurrentFocus=Window\{\S+ \S+ ([^/\s}]+)", out)
        return m.group(1) if m else None

    def set_low_res(self):
        """Android display override to the bots' native 540x960 @ 240 dpi: screenshots are a
        quarter of the data and need no downscaling. It does NOT lighten the game itself -
        Kingshot always renders at 702x1248 and scales to the screen (measured). Undo with
        reset_res(); BlueStacks' own setting is untouched."""
        self._adb("shell", "wm", "size", f"{REF_WIDTH}x{REF_WIDTH * 16 // 9}")
        self._adb("shell", "wm", "density", "240")

    def reset_res(self):
        self._adb("shell", "wm", "size", "reset")
        self._adb("shell", "wm", "density", "reset")

    def size(self):
        out = self._adb("shell", "wm", "size").decode(errors="ignore")
        sizes = re.findall(r"(\d+)x(\d+)", out)
        w, h = sizes[-1]  # override size (listed last) wins
        return int(w), int(h)


def port_open(port, timeout=0.3):
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=timeout):
            return True
    except OSError:
        return False


_PLAYERS_PS = (
    "$p = Get-Process HD-Player -ErrorAction SilentlyContinue | Select-Object Id, MainWindowTitle;"
    "$l = Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue |"
    " Where-Object { $p.Id -contains $_.OwningProcess } | Select-Object OwningProcess, LocalPort;"
    "@{procs=@($p); listen=@($l)} | ConvertTo-Json -Depth 3 -Compress"
)


def find_players(runner=subprocess.run):
    """Running BlueStacks players as [(window title, [listening ports])], straight from
    Windows - the ports they really use, whatever the config says."""
    import json
    out = runner(["powershell", "-NoProfile", "-Command", _PLAYERS_PS], capture_output=True,
                 timeout=20, creationflags=NO_WINDOW).stdout
    data = json.loads(out.decode(errors="ignore") or "{}")
    ports = {}
    for c in data.get("listen") or []:
        ports.setdefault(c["OwningProcess"], []).append(int(c["LocalPort"]))
    return [((p.get("MainWindowTitle") or "").strip(), sorted(ports.get(p["Id"], [])))
            for p in data.get("procs") or [] if ports.get(p["Id"])]


def _connect(name, port, package, runner, dry_run):
    serial = f"127.0.0.1:{port}"
    try:
        runner([ADB_PATH, "connect", serial], capture_output=True, timeout=5, creationflags=NO_WINDOW)
        dev = Device(name, serial, runner=runner, dry_run=dry_run)
        return dev if dev.foreground_package() == package else None
    except Exception:
        return None


GOOGLE_PLAY = ("Google Play", 6520)  # Google Play Games on PC Developer Emulator


def discover(package=KINGSHOT_PACKAGE, runner=subprocess.run, only=None,
             dry_run=False, conf_text=None, port_check=port_open, players_fn=None, google_play=None):
    """BlueStacks instances with Kingshot open, plus the Google Play Games developer
    emulator ("Google Play", port 6520) when it runs Kingshot. google_play=None: look for it
    unless a test config (conf_text) is given."""
    if google_play is None:
        google_play = conf_text is None
    devices = _discover_bluestacks(package, runner, only, dry_run, conf_text, port_check, players_fn)
    name, port = GOOGLE_PLAY
    wanted = {n.lower() for n in ([only] if isinstance(only, str) else only or [])}
    if google_play and (not wanted or name.lower() in wanted) and port_check(port):
        serial = f"127.0.0.1:{port}"
        try:  # its connection often comes up "offline" first: reconnect once when it isn't ready
            state = runner([ADB_PATH, "-s", serial, "get-state"], capture_output=True, timeout=5,
                           creationflags=NO_WINDOW).stdout
            if b"device" not in (state or b""):
                runner([ADB_PATH, "disconnect", serial], capture_output=True, timeout=5, creationflags=NO_WINDOW)
        except Exception:
            pass
        for attempt in range(3):  # it takes a moment to go from "offline" to ready
            dev = _connect(name, port, package, runner, dry_run)
            if dev:
                devices.append(dev)
                break
            if runner is subprocess.run:
                time.sleep(2)
    if google_play:  # same switch: real discovery only, not with a test config
        devices += _discover_mumu(package, runner, wanted, dry_run, port_check)
        devices += _discover_other(package, runner, wanted, dry_run, {d.serial for d in devices})
    return devices


def _discover_other(package, runner, wanted, dry_run, known):
    """Anything else `adb devices` lists (LDPlayer, Nox, Lumo, a phone on USB) that has
    Kingshot open. Named by its model, e.g. "SM-G991B (emulator-5554)"."""
    try:
        out = runner([ADB_PATH, "devices", "-l"], capture_output=True, timeout=10,
                     creationflags=NO_WINDOW).stdout.decode(errors="ignore")
    except Exception:
        return []
    devices = []
    for line in out.splitlines()[1:]:
        parts = line.split()
        if len(parts) < 2 or parts[1] != "device" or parts[0] in known:
            continue
        serial = parts[0]
        ports = {k.rsplit(":", 1)[1] for k in known if k.startswith("127.0.0.1:")}
        if serial.startswith("emulator-") and str(int(serial[9:]) + 1) in ports:
            continue  # same instance as 127.0.0.1:<port+1>, already found
        model = next((p.split(":", 1)[1] for p in parts if p.startswith("model:")), "Android")
        name = f"{model.replace('_', ' ')} ({serial})"
        if wanted and name.lower() not in wanted and serial.lower() not in wanted:
            continue
        try:
            dev = Device(name, serial, runner=runner, dry_run=dry_run)
            if dev.foreground_package() == package:
                devices.append(dev)
        except Exception:
            continue
    return devices


def _mumu_vms():
    """vms folder of the installed MuMu (MuMu 12 installs as MuMuPlayer-12.0, older as MuMuPlayer)."""
    base = Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Netease"
    for name in ("MuMuPlayer-12.0", "MuMuPlayer", "MuMu Player 12"):
        if (base / name / "vms").is_dir():
            return base / name / "vms"
    return base / "MuMuPlayer" / "vms"


MUMU_VMS = _mumu_vms()
MUMU_DEFAULT_NAME = "Android Device"  # what MuMu calls an instance nobody renamed


def mumu_instances(vms=MUMU_VMS):
    """MuMu Player instances as [(name, adb port)] from their config files. The name is the
    one set in MuMu's multi-instance manager ("MuMu N" while it's still "Android Device")."""
    import json
    out = []
    for i, vm in enumerate(sorted(vms.glob("*/configs"))):
        try:
            port = int(json.loads((vm / "vm_config.json").read_text(encoding="utf-8"))
                       ["vm"]["nat"]["port_forward"]["adb"]["host_port"])
        except Exception:
            continue
        try:
            name = json.loads((vm / "extra_config.json").read_text(encoding="utf-8")).get("playerName", "")
        except Exception:
            name = ""
        if not name or name == MUMU_DEFAULT_NAME:
            name = f"MuMu {vm.parent.name.rsplit('-', 1)[-1]}"
        out.append((name, port))
    return out


def _discover_mumu(package, runner, wanted, dry_run, port_check, vms=MUMU_VMS):
    devices = []
    for name, port in mumu_instances(vms):
        if wanted and name.lower() not in wanted:
            continue
        if port_check(port):
            dev = _connect(name, port, package, runner, dry_run)
            if dev:
                devices.append(dev)
    return devices


def _discover_bluestacks(package, runner, only, dry_run, conf_text, port_check, players_fn):
    if conf_text is None:
        try:
            conf_text = CONF_PATH.read_text(errors="ignore")
        except OSError:  # no BlueStacks on this PC
            conf_text = ""
    if isinstance(only, str):
        only = [only]
    wanted = {n.lower() for n in only} if only else None
    conf = parse_conf(conf_text)

    # 1) ask Windows which players are running and which ports they listen on
    try:
        players = (players_fn or find_players)()
    except Exception:
        players = []
    if players:
        by_port = {}
        for name, p in conf:
            by_port[p] = by_port[p + 1] = name
        devices = []
        for title, ports in players:
            name = title or next((by_port[p] for p in ports if p in by_port), f"BlueStacks {ports[0]}")
            if wanted and name.lower() not in wanted:
                continue
            for port in ports:
                dev = _connect(name, port, package, runner, dry_run)
                if dev:
                    devices.append(dev)
                    break
        return devices

    # 2) fallback: ports from bluestacks.conf (and +1, used when the configured one was busy)
    devices = []
    for name, conf_port in conf:
        if wanted and name.lower() not in wanted:
            continue
        # BlueStacks sometimes listens one port above its config (e.g. 5556 for 5555) when
        # the configured port was busy at start-up; instance ports are 10 apart, so +1 is safe
        for port in (conf_port, conf_port + 1):
            if not port_check(port):
                continue
            serial = f"127.0.0.1:{port}"
            try:
                runner([ADB_PATH, "connect", serial], capture_output=True, timeout=5,
                       creationflags=NO_WINDOW)
                dev = Device(name, serial, runner=runner, dry_run=dry_run)
                if dev.foreground_package() == package:
                    devices.append(dev)
                    break
            except Exception:
                continue
    return devices
