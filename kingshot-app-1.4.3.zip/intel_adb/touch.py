"""A held, moving finger on a BlueStacks instance (Android 9 has no `input motionevent`).

Writes multi-touch events straight to the "BlueStacks Virtual Touch" device (0..32767 on
both axes) as raw `input_event` structs through one long-lived `adb shell dd`.
(`sendevent` takes ~50 ms per event on Primary: a drag fell seconds behind. `cat` dies: adb
hands the data over in odd-sized chunks and the device refuses part-events; `dd obs=24`
re-blocks them into whole events. Measured: 50/50 moves arrive, ~1-2 ms each.)
Always call up() (or use `with`) - a finger left down stays down; if the process is killed,
`python -m intel_adb.touch --release NAME` lifts it.

    python -m intel_adb.touch --release Primary
"""
import argparse
import re
import struct
import subprocess
import threading

from intel_adb import adb

TOUCH_NAME = "BlueStacks Virtual Touch"
RAW_MAX = 32767
EV_SYN, EV_KEY, EV_ABS = 0, 1, 3
BTN_TOUCH = 330
ABS_MT_SLOT, ABS_MT_X, ABS_MT_Y, ABS_MT_ID = 47, 53, 54, 57
NO_ID = -1  # tracking id of a lifted finger


def find_touch_device(getevent_text, name=TOUCH_NAME):
    """/dev/input/eventN of the named device in `getevent -pl` output, or None."""
    dev = None
    for line in getevent_text.splitlines():
        m = re.match(r"add device \d+: (\S+)", line)
        if m:
            dev = m.group(1)
        elif dev and f'"{name}"' in line:
            return dev
    return None


def pack_events(events, fmt="<qqHHi"):
    """Raw input_event structs: struct timeval (zero - the kernel stamps them), type, code, value."""
    return b"".join(struct.pack(fmt, 0, 0, t, c, v) for t, c, v in events)


class Touch:
    def __init__(self, device, width=adb.REF_WIDTH, height=adb.REF_WIDTH * 16 // 9, popen=subprocess.Popen):
        """Coordinates are in the bots' 540-wide reference frame."""
        self.d = device
        self.w, self.h = width, height
        self.dry = getattr(device, "dry_run", False)
        self.down_at = None
        self.touch_id = 0
        self.reopens = 0  # times the adb pipe broke and was reopened
        self.lock = threading.Lock()
        self.proc = None
        self.node = None
        self.fmt = "<qqHHi"
        if not self.dry:
            out = device._adb("shell", "getevent", "-pl").decode(errors="ignore")
            self.node = find_touch_device(out)
            if not self.node:
                raise RuntimeError(f"no '{TOUCH_NAME}' input device on {device.name}")
            arch = device._adb("shell", "uname", "-m").decode(errors="ignore")
            self.fmt = "<qqHHi" if "64" in arch else "<llHHi"
            self.popen = popen
            self._open()

    def _open(self):
        size = struct.calcsize(self.fmt)
        # -T: never a terminal - it would read bytes in the event data as Ctrl-C and the like
        self.proc = self.popen([adb.ADB_PATH, "-s", self.d.serial, "shell", "-T",
                                f"dd of={self.node} ibs=4096 obs={size} 2>/dev/null"],
                               stdin=subprocess.PIPE, stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL, creationflags=adb.NO_WINDOW)

    def _raw(self, x, y):
        rx = round(min(max(x, 0), self.w - 1) / (self.w - 1) * RAW_MAX)
        ry = round(min(max(y, 0), self.h - 1) / (self.h - 1) * RAW_MAX)
        return rx, ry

    def _send(self, events):
        if self.dry:
            return
        data = pack_events(events, self.fmt)
        with self.lock:
            for attempt in (1, 2):
                try:
                    self.proc.stdin.write(data)
                    self.proc.stdin.flush()
                    return
                except OSError:
                    if attempt == 2:
                        raise
                    old, self.proc = self.proc, None
                    pipe, old.stdin = old.stdin, None
                    try:  # close the dead pipe ourselves: left to the garbage collector it
                        pipe.close()  # prints "Exception ignored ... Invalid argument"
                    except OSError:
                        pass
                    try:
                        old.kill()
                    except Exception:
                        pass
                    self.reopens += 1
                    self._open()  # the adb pipe broke: open a new one and send again

    def down(self, x, y):
        if self.down_at is not None:
            return self.move(x, y)
        rx, ry = self._raw(x, y)
        self.touch_id = self.touch_id % 60000 + 1  # a new finger gets a new tracking id
        self._send([(EV_ABS, ABS_MT_SLOT, 0), (EV_ABS, ABS_MT_ID, self.touch_id), (EV_ABS, ABS_MT_X, rx),
                    (EV_ABS, ABS_MT_Y, ry), (EV_KEY, BTN_TOUCH, 1), (EV_SYN, 0, 0)])
        self.down_at = (x, y)

    def move(self, x, y):
        if self.down_at is None:
            return self.down(x, y)
        if (round(x), round(y)) == tuple(map(round, self.down_at)):
            return
        rx, ry = self._raw(x, y)
        self._send([(EV_ABS, ABS_MT_SLOT, 0), (EV_ABS, ABS_MT_X, rx), (EV_ABS, ABS_MT_Y, ry), (EV_SYN, 0, 0)])
        self.down_at = (x, y)

    def up(self):
        if self.down_at is None:
            return
        self._send([(EV_ABS, ABS_MT_SLOT, 0), (EV_ABS, ABS_MT_ID, NO_ID), (EV_KEY, BTN_TOUCH, 0), (EV_SYN, 0, 0)])
        self.down_at = None

    def close(self):
        try:
            self.up()
        finally:
            if self.proc:
                try:
                    self.proc.stdin.close()
                    self.proc.wait(timeout=3)
                except Exception:
                    self.proc.kill()
                self.proc = None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()


SLOTS = 16  # touch slots to clear (ABS_MT_SLOT max is 15 on BlueStacks)


def release(device, popen=subprocess.Popen):
    """Clear every finger left behind on `device` - pressed or hovering (white dot that won't
    go). Re-sending "lifted" alone does nothing when the device already holds that value
    (repeats are dropped), so each slot first gets a fresh id while not pressed (a hover,
    never a tap), then is lifted."""
    t = Touch(device, popen=popen)
    events = [(EV_KEY, BTN_TOUCH, 0), (EV_SYN, 0, 0)]
    for slot in range(SLOTS):
        events += [(EV_ABS, ABS_MT_SLOT, slot), (EV_ABS, ABS_MT_ID, 50000 + slot), (EV_SYN, 0, 0),
                   (EV_ABS, ABS_MT_ID, NO_ID), (EV_SYN, 0, 0)]
    events += [(EV_ABS, ABS_MT_SLOT, 0), (EV_SYN, 0, 0)]
    t._send(events)
    t.down_at = None
    t.close()


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--release", required=True, help="instance name")
    a = ap.parse_args(argv)
    for d in adb.discover(only=a.release):
        release(d)
        print(f"[{d.name}] finger released", flush=True)


if __name__ == "__main__":
    main()
