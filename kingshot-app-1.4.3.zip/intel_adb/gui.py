"""Small window to run the Intel and Bear bots: pick instances, Start / Stop, live log.

    pythonw -m intel_adb.gui      (the Desktop shortcut runs this)
"""
import json
import os
import queue
import re
import subprocess
import sys
import threading
import time
import tkinter as tk
from datetime import datetime, timedelta, timezone
from pathlib import Path
from tkinter import ttk

from intel_adb.commands import *  # noqa: F401,F403 (command builders live there now)
from intel_adb.commands import ROOT, SETTINGS  # noqa: F401


class App:
    def __init__(self, root):
        self.root = root
        self.proc = None
        self.lines = queue.Queue()
        self.checks = {}  # name -> BooleanVar
        self.formations = {}  # name -> StringVar ("1".."8"), the terror formation
        self.raider_forms = {}  # name -> StringVar ("" = as is, "1".."8"), Cesares Raider flag
        self.intel_forms = {}  # name -> StringVar ("Eq", "1".."8"), the intel formation
        self.bear_forms = {}  # name -> StringVar ("1-6", "2,4"...), bear joiners, used in turn
        self.state = {}  # name -> "idle" | "starting" | "running" | "stopped"
        self.dots = {}  # name -> (dot label, text label)
        self.at_once_for = {}  # name -> StringVar: terror rallies at once for this instance ("" = global)
        self.redo = None  # names -> command of the last bot started (for per-instance restart)
        self.redo_what = ""
        self.solo = {}  # name -> process restarted on its own
        self.settings = load_settings()
        root.title("Kingshot Bots")
        root.geometry("920x740")
        root.minsize(480, 380)

        top = ttk.Frame(root, padding=8)
        top.pack(fill="x")
        ttk.Label(top, text="Instances with Kingshot open", font=("Segoe UI", 10, "bold")).pack(side="left")
        self.refresh_btn = ttk.Button(top, text="Refresh", command=self.refresh)
        self.refresh_btn.pack(side="right")

        self.inst_frame = ttk.Frame(root, padding=(12, 0))
        self.inst_frame.pack(fill="x")
        self.status = ttk.Label(self.inst_frame, text="")
        self.status.pack(anchor="w")

        opts = ttk.Frame(root, padding=8)
        opts.pack(fill="x")
        ttk.Label(opts, text="Stagger (s):").pack(side="left")
        self.stagger = tk.StringVar(value="5")
        ttk.Spinbox(opts, from_=0, to=60, width=4, textvariable=self.stagger).pack(side="left", padx=(4, 16))
        ttk.Label(opts, text="Start:").pack(side="left")
        self.delay = tk.StringVar(value=DELAY_CHOICES[0])
        ttk.Combobox(opts, values=DELAY_CHOICES, width=15, textvariable=self.delay).pack(side="left", padx=(4, 16))
        self.pending = None  # root.after id of a delayed start
        self.dry = tk.BooleanVar(value=False)
        ttk.Checkbutton(opts, text="Dry run (no taps)", variable=self.dry).pack(side="left")
        self.record = tk.BooleanVar(value=False)
        ttk.Checkbutton(opts, text="Record video", variable=self.record).pack(side="left", padx=(8, 0))
        self.rec_proc = None
        self.rec_dir = None
        self.stop_btn = ttk.Button(opts, text="Stop", command=self.stop, state="disabled")
        self.stop_btn.pack(side="right")
        self.bear_btn = ttk.Button(opts, text="Start Bear", command=self.start_bear)
        self.bear_btn.pack(side="right", padx=4)
        self.start_btn = ttk.Button(opts, text="Start Intel", command=self.start)
        self.start_btn.pack(side="right", padx=4)

        intel = ttk.Frame(root, padding=(8, 0, 8, 8))
        intel.pack(fill="x")
        ttk.Label(intel, text="Intel - rebel bounties:").pack(side="left")
        self.bounties = tk.StringVar(value=self.settings.get("bounties", "Only if likely to prevail"))
        ttk.Combobox(intel, values=BOUNTIES, width=22, state="readonly",
                     textvariable=self.bounties).pack(side="left", padx=4)
        self.grey = tk.BooleanVar(value=self.settings.get("attack_grey", True))
        ttk.Checkbutton(intel, text="Attack grey (finished) pins", variable=self.grey).pack(side="left", padx=8)
        self.bounties.trace_add("write", lambda *_: self.save_intel_options())
        self.grey.trace_add("write", lambda *_: self.save_intel_options())

        terr = ttk.Frame(root, padding=(8, 0, 8, 8))
        terr.pack(fill="x")
        ttk.Label(terr, text="Terror rallies:").pack(side="left")
        self.rallies = tk.StringVar(value="5")
        ttk.Spinbox(terr, from_=1, to=250, width=4, textvariable=self.rallies).pack(side="left", padx=4)
        ttk.Label(terr, text="at once:").pack(side="left", padx=(6, 0))
        self.at_once = tk.StringVar(value=str(self.settings.get("terror_at_once", 1)))
        ttk.Spinbox(terr, from_=1, to=6, width=3, textvariable=self.at_once).pack(side="left", padx=4)
        self.at_once.trace_add("write", lambda *_: self.save_intel_options())
        self.meat = tk.BooleanVar(value=self.settings.get("use_meat", False))
        ttk.Checkbutton(terr, text="Use meat", variable=self.meat).pack(side="left", padx=4)
        self.meat.trace_add("write", lambda *_: self.save_intel_options())
        self.one_troop = tk.BooleanVar(value=self.settings.get("terror_one_troop", False))
        ttk.Checkbutton(terr, text="1 troop", variable=self.one_troop).pack(side="left", padx=4)
        self.one_troop.trace_add("write", lambda *_: self.save_intel_options())
        self.terror_btn = ttk.Button(terr, text="Start Terror", command=self.start_terror)
        self.terror_btn.pack(side="left", padx=4)
        self.journey_btn = ttk.Button(terr, text="Start Journey", command=self.start_journey)
        self.journey_btn.pack(side="right", padx=4)
        self.pouch_btn = ttk.Button(terr, text="Start Pouch", command=self.start_pouch)
        self.pouch_btn.pack(side="right", padx=4)
        self.fishing_btn = ttk.Button(terr, text="Start Fishing", command=self.start_fishing)
        self.fishing_btn.pack(side="right", padx=4)
        self.helper_btn = ttk.Button(terr, text="Fishing helper", command=self.start_helper)
        self.helper_btn.pack(side="right", padx=4)

        res = ttk.Frame(root, padding=(8, 0, 8, 8))
        res.pack(fill="x")
        ttk.Label(res, text="Ticked instances:").pack(side="left")
        ttk.Button(res, text="Low resolution", command=lambda: self.set_res(True)).pack(side="left", padx=4)
        ttk.Button(res, text="Reset resolution", command=lambda: self.set_res(False)).pack(side="left")
        ttk.Button(res, text="Release fingers", command=self.release_fingers).pack(side="left", padx=4)
        self.finders_btn = ttk.Button(res, text="Start Finders", command=self.start_finders)
        self.finders_btn.pack(side="right", padx=4)
        self.caravan_btn = ttk.Button(res, text="Start Caravan", command=self.start_caravan)
        self.caravan_btn.pack(side="right", padx=4)
        self.cesares_btn = ttk.Button(res, text="Start Cesares", command=self.start_cesares)
        self.cesares_btn.pack(side="right", padx=4)
        self.raider_btn = ttk.Button(res, text="Start Raider", command=self.start_raider)
        self.raider_btn.pack(side="right", padx=4)

        daily = ttk.Frame(root, padding=(8, 0, 8, 8))
        daily.pack(fill="x")
        ttk.Label(daily, text="Daily:").pack(side="left")
        saved_jobs = self.settings.get("daily_jobs", [k for k, _ in DAILY_JOBS])
        self.daily_vars = {}
        for key, label in DAILY_JOBS:
            var = tk.BooleanVar(value=key in saved_jobs)
            var.trace_add("write", lambda *_: self.save_daily())
            ttk.Checkbutton(daily, text=label, variable=var).pack(side="left", padx=2)
            self.daily_vars[key] = var
        self.daily_btn = ttk.Button(daily, text="Start Daily", command=self.start_daily)
        self.daily_btn.pack(side="right", padx=4)
        self.hunt_level = tk.StringVar(value=str(self.settings.get("hunt_level", "Highest")))
        ttk.Combobox(daily, values=["Highest"] + [str(i) for i in range(1, 31)], width=7,
                     state="readonly", textvariable=self.hunt_level).pack(side="right")
        ttk.Label(daily, text="hunt up to Lv").pack(side="right", padx=(8, 2))
        self.hunt_level.trace_add("write", lambda *_: self.save_daily())

        log_frame = ttk.Frame(root, padding=(8, 0, 8, 8))
        log_frame.pack(fill="both", expand=True)
        self.log = tk.Text(log_frame, font=("Consolas", 9), wrap="none", state="disabled")
        scroll = ttk.Scrollbar(log_frame, command=self.log.yview)
        self.log.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        self.log.pack(fill="both", expand=True)

        root.protocol("WM_DELETE_WINDOW", self.close)
        root.after(100, self.pump)
        self.refresh()

    # ---- instances -----------------------------------------------------
    def set_res(self, low):
        chosen = [n for n, v in self.checks.items() if v.get()]
        if not chosen:
            self.write("Tick at least one instance.\n")
            return
        self.write(("Setting low resolution" if low else "Resetting resolution") + f" on {len(chosen)}…\n")

        def work():
            for m in apply_resolution(chosen, low):
                self.lines.put(m + "\n")
        threading.Thread(target=work, daemon=True).start()

    def refresh(self):
        self.refresh_btn.configure(state="disabled")
        self.status.configure(text="Searching for BlueStacks instances…")
        for w in self.inst_frame.winfo_children():
            if w is not self.status:
                w.destroy()
        self.checks.clear()
        self.formations.clear()
        self.intel_forms.clear()
        self.bear_forms.clear()
        self.dots.clear()
        self.at_once_for.clear()

        def work():
            try:
                from intel_adb.adb import discover
                names = [d.name for d in discover()]
                err = None
            except Exception as e:
                names, err = [], e
            self.root.after(0, lambda: self.show_instances(names, err))

        threading.Thread(target=work, daemon=True).start()

    def show_instances(self, names, err):
        self.refresh_btn.configure(state="normal")
        if err:
            self.status.configure(text=f"Could not search: {err}")
        elif not names:
            self.status.configure(text="None found. Open Kingshot in BlueStacks, then Refresh.")
        else:
            self.status.configure(text=f"{len(names)} found")
        saved = self.settings.get("presets", {})
        if names:
            ttk.Label(self.inst_frame, text="Formation per instance: Intel (Eq = Equalize), Terror (1-8), Bear joiners in turn (e.g. 1-6)",
                      foreground="#666").pack(anchor="w")
        for n in names:
            row = ttk.Frame(self.inst_frame)
            row.pack(fill="x")
            var = tk.BooleanVar(value=True)
            dot = tk.Label(row, text="●", fg="#bbbbbb", width=2, font=("Segoe UI", 11))
            dot.pack(side="left")
            ttk.Checkbutton(row, text=n, variable=var, width=26).pack(side="left")
            txt = tk.Label(row, text="idle", fg="#888888", width=8, anchor="w", font=("Segoe UI", 8))
            txt.pack(side="left")
            ttk.Button(row, text="Restart", width=7, command=lambda n=n: self.restart_one(n)).pack(side="left", padx=(0, 6))
            self.dots[n] = (dot, txt)
            self.state.setdefault(n, "idle")
            self.paint(n)
            form = tk.StringVar(value=str(saved.get(n, DEFAULT_FORMATION)))
            box = ttk.Combobox(row, values=INTEL_FORMATIONS, width=3, state="readonly", textvariable=form)
            box.pack(side="right")
            ttk.Label(row, text="terror").pack(side="right", padx=4)
            aon = tk.StringVar(value=str(self.settings.get("terror_at_once_for", {}).get(n, "")))
            ttk.Spinbox(row, from_=0, to=6, width=2, textvariable=aon).pack(side="right", padx=(0, 4))
            ttk.Label(row, text="x").pack(side="right")
            aon.trace_add("write", lambda *_: self.save_formations())
            self.at_once_for[n] = aon
            bform = tk.StringVar(value=str(self.settings.get("bear_formations", {}).get(n, "8")))
            ttk.Combobox(row, values=BEAR_FORMATIONS, width=5,
                         textvariable=bform).pack(side="right", padx=(0, 12))
            ttk.Label(row, text="bear").pack(side="right", padx=4)
            bform.trace_add("write", lambda *_: self.save_formations())
            self.bear_forms[n] = bform
            iform = tk.StringVar(value=str(self.settings.get("intel_presets", {}).get(n, "Eq")))
            ttk.Combobox(row, values=INTEL_FORMATIONS, width=3, state="readonly",
                         textvariable=iform).pack(side="right", padx=(0, 12))
            ttk.Label(row, text="intel").pack(side="right", padx=4)
            rform = tk.StringVar(value=str(self.settings.get("raider_flags", {}).get(n, "")))
            ttk.Combobox(row, values=RAIDER_FLAGS, width=2, state="readonly",
                         textvariable=rform).pack(side="right", padx=(0, 12))
            ttk.Label(row, text="raider").pack(side="right", padx=4)
            rform.trace_add("write", lambda *_: self.save_formations())
            self.raider_forms[n] = rform
            form.trace_add("write", lambda *_: self.save_formations())
            iform.trace_add("write", lambda *_: self.save_formations())
            self.checks[n] = var
            self.formations[n] = form
            self.intel_forms[n] = iform

    def save_formations(self):
        presets = self.settings.setdefault("presets", {})
        presets.update({n: (int(v.get()) if v.get().isdigit() else v.get()) for n, v in self.formations.items()})
        intel = self.settings.setdefault("intel_presets", {})
        intel.update({n: v.get() for n, v in self.intel_forms.items()})
        self.settings["terror_at_once_for"] = {n: v.get() for n, v in self.at_once_for.items() if v.get().strip()}
        bear_f = self.settings.setdefault("bear_formations", {})
        bear_f.update({n: v.get() for n, v in self.bear_forms.items()})
        raider_f = self.settings.setdefault("raider_flags", {})
        raider_f.update({n: v.get() for n, v in self.raider_forms.items()})
        save_settings(self.settings)

    def _at_once_for(self, names):
        out = {}
        for n in names:
            v = self.at_once_for.get(n)
            if v is not None and v.get().strip().isdigit() and int(v.get()) > 0:
                out[n] = int(v.get())
        return out

    def _at_once(self):
        try:
            return max(1, int(self.at_once.get()))
        except ValueError:
            return 1

    def save_intel_options(self):
        self.settings["bounties"] = self.bounties.get()
        self.settings["attack_grey"] = bool(self.grey.get())
        self.settings["use_meat"] = bool(self.meat.get())
        if hasattr(self, "one_troop"):
            self.settings["terror_one_troop"] = bool(self.one_troop.get())
        if hasattr(self, "at_once"):
            try:
                self.settings["terror_at_once"] = max(1, int(self.at_once.get()))
            except ValueError:
                pass
        save_settings(self.settings)

    # ---- run -----------------------------------------------------------
    def start(self):
        chosen = [n for n, v in self.checks.items() if v.get()]
        if not chosen:
            self.write("Tick at least one instance.\n")
            return
        try:
            stagger = max(0.0, float(self.stagger.get()))
        except ValueError:
            stagger = 5.0
        presets = {n: (int(self.intel_forms[n].get()) if self.intel_forms[n].get().isdigit() else None)
                   for n in chosen}
        cmd = build_command(chosen, stagger, self.dry.get(), len(chosen) == len(self.checks),
                            presets=presets, bounties=self.bounties.get(), attack_grey=self.grey.get())
        self.remember("Intel", chosen, lambda ns: build_command(
            ns, 0, self.dry.get(), False, presets={k: presets.get(k) for k in ns},
            bounties=self.bounties.get(), attack_grey=self.grey.get()))
        self.clear()
        self.write(f"Starting on {len(chosen)} instance(s)…\n")
        self.launch(cmd)

    def start_bear(self):
        chosen = [n for n, v in self.checks.items() if v.get()] or ["Primary"]
        self.clear()
        self.write("Starting Bear bot…\n")
        forms = {n: v.get() for n, v in self.bear_forms.items()}
        self.redo = None  # one-instance / paired bots: restart them with their own button
        self.launch(build_bear_command(chosen, self.dry.get(), forms))

    def start_terror(self):
        chosen = [n for n, v in self.checks.items() if v.get()]
        if not chosen:
            self.write("Tick at least one instance.\n")
            return
        try:
            rallies = max(1, int(self.rallies.get()))
        except ValueError:
            rallies = 5
        try:
            stagger = max(0.0, float(self.stagger.get()))
        except ValueError:
            stagger = 5.0
        self.clear()
        self.write(f"Starting Terror x{rallies} on {len(chosen)} instance(s)…\n")
        self.remember("Terror", chosen, lambda ns: build_terror_command(
            ns, rallies, 0, self.dry.get(), False, {n: self.formations[n].get() for n in ns},
            use_meat=self.meat.get(), at_once=self._at_once(), at_once_for=self._at_once_for(ns),
            one_troop=self.one_troop.get()))
        self.launch(build_terror_command(chosen, rallies, stagger, self.dry.get(),
                                         len(chosen) == len(self.checks),
                                         {n: self.formations[n].get() for n in chosen},
                                         use_meat=self.meat.get(), at_once=self._at_once(),
                                         at_once_for=self._at_once_for(chosen),
                                         one_troop=self.one_troop.get()))

    def start_journey(self):
        chosen = [n for n, v in self.checks.items() if v.get()]
        if not chosen:
            self.write("Tick at least one instance.\n")
            return
        self.clear()
        self.write("Starting Journey helper - have the Journey screen open...\n")
        self.remember("Journey", chosen, lambda ns: build_journey_command(ns, self.dry.get(), False))
        self.launch(build_journey_command(chosen, self.dry.get(), len(chosen) == len(self.checks)))

    def save_daily(self):
        self.settings["daily_jobs"] = [k for k, v in self.daily_vars.items() if v.get()]
        if hasattr(self, "hunt_level"):
            self.settings["hunt_level"] = self.hunt_level.get()
        save_settings(self.settings)

    def start_daily(self):
        chosen = [n for n, v in self.checks.items() if v.get()]
        jobs = [k for k, v in self.daily_vars.items() if v.get()]
        if not chosen or not jobs:
            self.write("Tick at least one instance and one daily job.\n")
            return
        forms = {n: self.intel_forms[n].get() for n in chosen if n in self.intel_forms}
        self.clear()
        self.write(f"Daily jobs on {len(chosen)} instance(s) at once: {', '.join(jobs)}. "
                   "Hunting uses each instance's intel formation.\n")
        self.remember("Daily", chosen, lambda ns: build_daily_command(
            ns, jobs, self.dry.get(), {k: forms.get(k) for k in ns}, self.hunt_level.get()))
        self.launch(build_daily_command(chosen, jobs, self.dry.get(), forms, self.hunt_level.get()))

    def start_caravan(self):
        chosen = [n for n, v in self.checks.items() if v.get()]
        if not chosen:
            self.write("Tick at least one instance.\n")
            return
        self.clear()
        self.write("Caravans: collect finished ones, refresh new ones to gold (up to 1,500 diamonds "
                   "each: free, 100-500), then Escort. Leave the game on the city / world map.\n")
        self.remember("Caravan", chosen, lambda ns: build_caravan_command(ns, self.dry.get()))
        self.launch(build_caravan_command(chosen, self.dry.get()))

    def start_cesares(self):
        chosen = [n for n, v in self.checks.items() if v.get()]
        if not chosen:
            self.write("Tick at least one instance.\n")
            return
        self.clear()
        self.write("Cesares boss: for each \"Cesares Captain found!\" card in Alliance chat (Lv. 1-5), "
                   "tap its coordinates, Attack with 1 infantry (no heroes), then wait for the next "
                   "level. Only taps the card's coordinates in chat - never types.\n")
        self.remember("Cesares", chosen, lambda ns: build_cesares_command(ns, self.dry.get()))
        self.launch(build_cesares_command(chosen, self.dry.get()))

    def start_raider(self):
        chosen = [n for n, v in self.checks.items() if v.get()]
        if not chosen:
            self.write("Tick at least one instance.\n")
            return
        self.clear()
        flags = {n: self.raider_forms[n].get() for n in chosen if n in self.raider_forms}
        self.write("Cesares Raider: Scout + Attack each level with the instance's raider flag and Diana "
                   "(8 stamina). Request Help on 15, 20, 25, 24, 23 (then 22, 21, 19, 18, 17 with more "
                   "accords). Up to 468 stamina a day, spread over the event's days; never uses meat. "
                   "Keeps running - leave it on.\n")
        self.remember("Raider", chosen, lambda ns: build_raider_command(ns, self.dry.get(), flags))
        self.launch(build_raider_command(chosen, self.dry.get(), flags))

    def start_helper(self):
        chosen = [n for n, v in self.checks.items() if v.get()] or ["Primary"]
        self.clear()
        self.write("Fishing helper: you steer, follow the green line. Boxes: 1* grey, 2* green, "
                   "3* blue, 4* purple, 5* gold, ? unknown. It never taps. Stop closes it.\n")
        self.redo = None  # one-instance / paired bots: restart them with their own button
        self.launch(build_helper_command(chosen))

    def start_fishing(self):
        chosen = [n for n, v in self.checks.items() if v.get()] or ["Falkor"]
        self.touch_target = build_fishing_command(chosen, False)[-1]  # finger to lift on Stop
        self.clear()
        self.write("Fishing Tournament: open its screen in the game first. Free attempts only, "
                   "upgrades Line > Hook > Sinker, always Retreat.\n")
        self.redo = None  # one-instance / paired bots: restart them with their own button
        self.launch(build_fishing_command(chosen, self.dry.get()))

    def start_pouch(self):
        chosen = [n for n, v in self.checks.items() if v.get()]
        if not chosen:
            self.write("Tick at least one instance.\n")
            return
        self.clear()
        self.write("Watching for Lucky Pouches - leave the game on the world map...\n")
        self.remember("Pouch", chosen, lambda ns: build_pouch_command(ns, self.dry.get(), False))
        self.launch(build_pouch_command(chosen, self.dry.get(), len(chosen) == len(self.checks)))

    def start_finders(self):
        chosen = [n for n, v in self.checks.items() if v.get()]
        if not chosen:
            self.write("Tick at least one instance.\n")
            return
        self.clear()
        self.write("Finder's Fusion: get each team into a round (Ready) - the bots tap as soon as it "
                   "starts.\n" + ("Rows: " + ", ".join(f"{n} = {r}" for n, r in zip(chosen, ["top", "bottom"]))
                                  if len(chosen) > 1 else f"{chosen[0]} takes all rows") + "\n")
        self.redo = None  # one-instance / paired bots: restart them with their own button
        self.launch(build_finders_command(chosen))

    # ---- live status ---------------------------------------------------------
    def paint(self, n):
        if n not in self.dots:
            return
        sym, col, text = STATUS_LOOK[self.state.get(n, "idle")]
        dot, txt = self.dots[n]
        dot.configure(text=sym, fg=col)
        txt.configure(text=text, fg=col)

    def set_state(self, n, st):
        if self.state.get(n) != st:
            self.state[n] = st
            self.paint(n)

    def remember(self, what, chosen, make):
        self.redo, self.redo_what = make, what
        for n in self.state:
            self.set_state(n, "starting" if n in chosen else "idle")

    def restart_one(self, n):
        """Run the last started bot again for this instance only."""
        if self.redo is None:
            self.write(f"[{n}] nothing to restart - start a bot (Intel, Terror, Daily, Caravan, "
                       "Journey, Pouch) first\n")
            return
        old = self.solo.get(n)
        if old and old.poll() is None:
            subprocess.run(["taskkill", "/PID", str(old.pid), "/T", "/F"], capture_output=True,
                           creationflags=NO_WINDOW)
        self.write(f"[{n}] restarting {self.redo_what} on this instance only\n")
        env = dict(os.environ, PYTHONIOENCODING="utf-8")
        proc = subprocess.Popen(self.redo([n]), cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                creationflags=NO_WINDOW, env=env)
        self.solo[n] = proc
        self.set_state(n, "starting")
        self.stop_btn.configure(state="normal")

        def read():
            for raw in proc.stdout:
                self.lines.put(raw.decode("utf-8", errors="replace"))
            proc.wait()
            self.lines.put(("solo_done", n))
        threading.Thread(target=read, daemon=True).start()

    def start_recording(self):
        chosen = [n for n, v in self.checks.items() if v.get()]
        if not (self.record.get() and chosen):
            return
        self.rec_dir = Path(ROOT) / "recordings" / time.strftime("%Y-%m-%d_%H%M%S")
        self.rec_proc = subprocess.Popen(build_record_command(chosen, self.rec_dir), cwd=ROOT,
                                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                         creationflags=NO_WINDOW)
        self.write(f"Recording to {self.rec_dir}\n")

    def stop_recording(self):
        if self.rec_proc is None:
            return
        proc, folder = self.rec_proc, self.rec_dir
        self.rec_proc = None
        try:
            folder.mkdir(parents=True, exist_ok=True)
            (folder / "STOP").touch()  # the recorder saves the last chunk, then exits
        except Exception:
            pass

        def finish():
            try:
                proc.wait(timeout=90)
            except Exception:
                subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"],
                               capture_output=True, creationflags=NO_WINDOW)
            self.lines.put(f"Recording saved: {folder}\n")
        threading.Thread(target=finish, daemon=True).start()

    def launch(self, cmd):
        """Start the bot now, or after the delay chosen under "Start:" (Stop cancels the wait)."""
        try:
            wait = delay_seconds(self.delay.get(), datetime.now(timezone.utc))
        except ValueError:
            self.write(f"Start delay {self.delay.get()!r} not understood - use seconds or "
                       f"one of the list. Not started.\n")
            return
        if wait <= 0:
            self._launch(cmd)
            return
        at = datetime.now(timezone.utc) + timedelta(seconds=wait)
        self.write(f"Waiting {fmt_wait(wait)} - starts at {at:%H:%M:%S} UTC. Stop cancels.\n")
        self.set_buttons("disabled")
        self.stop_btn.configure(state="normal")

        def go():
            self.pending = None
            self._launch(cmd)
        self.pending = self.root_after(int(wait * 1000), go)

    def root_after(self, ms, fn):
        return self.stop_btn.after(ms, fn)

    def set_buttons(self, state):
        for b in (self.start_btn, self.bear_btn, self.terror_btn, self.journey_btn, self.pouch_btn,
                  self.fishing_btn, self.helper_btn, self.caravan_btn, self.daily_btn,
                  self.cesares_btn, self.raider_btn, self.finders_btn):
            b.configure(state=state)

    def _launch(self, cmd):
        self.start_recording()
        env = dict(os.environ, PYTHONIOENCODING="utf-8")
        self.proc = subprocess.Popen(cmd, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                     creationflags=NO_WINDOW, env=env)
        self.start_btn.configure(state="disabled")
        self.bear_btn.configure(state="disabled")
        self.terror_btn.configure(state="disabled")
        self.journey_btn.configure(state="disabled")
        self.pouch_btn.configure(state="disabled")
        self.fishing_btn.configure(state="disabled")
        self.helper_btn.configure(state="disabled")
        self.caravan_btn.configure(state="disabled")
        self.daily_btn.configure(state="disabled")
        self.cesares_btn.configure(state="disabled")
        self.raider_btn.configure(state="disabled")
        self.finders_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")
        threading.Thread(target=self.read_output, args=(self.proc,), daemon=True).start()

    def read_output(self, proc):
        for raw in proc.stdout:
            self.lines.put(raw.decode("utf-8", errors="replace"))
        proc.wait()
        self.lines.put(None)

    def stop(self):
        if self.pending is not None:  # a delayed start that hasn't begun: just cancel it
            self.stop_btn.after_cancel(self.pending)
            self.pending = None
            self.write("Delayed start cancelled.\n")
            for n in self.state:
                if self.state[n] == "starting":
                    self.set_state(n, "idle")
            if self.proc is None:
                self.set_buttons("normal")
                self.stop_btn.configure(state="disabled")
            return
        for n, proc in list(self.solo.items()):
            if proc.poll() is None:
                subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"], capture_output=True,
                               creationflags=NO_WINDOW)
            self.set_state(n, "stopped")
        self.solo.clear()
        if self.proc and self.proc.poll() is None:
            subprocess.run(["taskkill", "/PID", str(self.proc.pid), "/T", "/F"],
                           capture_output=True, creationflags=NO_WINDOW)
            self.write("\nStopped.\n")
            self.release_touch()
        self.stop_recording()

    def release_fingers(self):
        """Clear touches a bot left behind (a white dot that won't go) on the ticked instances."""
        chosen = [n for n, v in self.checks.items() if v.get()]
        if not chosen:
            self.write("Tick at least one instance.\n")
            return
        self.write(f"Releasing fingers on {', '.join(chosen)}…\n")

        def work():
            for name in chosen:
                r = subprocess.run([python_exe(), "-m", "intel_adb.touch", "--release", name], cwd=ROOT,
                                   capture_output=True, creationflags=NO_WINDOW, timeout=60)
                out = r.stdout.decode(errors="ignore").strip()
                self.lines.put((out or f"[{name}] not found (is Kingshot open?)") + "\n")
        threading.Thread(target=work, daemon=True).start()

    def release_touch(self):
        """A killed fishing bot can't lift its finger: do it for it."""
        name, self.touch_target = getattr(self, "touch_target", None), None
        if not name:
            return

        def work():
            subprocess.run([python_exe(), "-m", "intel_adb.touch", "--release", name], cwd=ROOT,
                           capture_output=True, creationflags=NO_WINDOW, timeout=60)
            self.lines.put(f"[{name}] finger lifted\n")
        threading.Thread(target=work, daemon=True).start()

    def pump(self):
        try:
            while True:
                line = self.lines.get_nowait()
                if isinstance(line, tuple):  # a restarted instance's process ended
                    n = line[1]
                    if self.state.get(n) in ("running", "starting"):
                        self.set_state(n, "stopped")
                    self.write(f"[{n}] restarted run ended\n")
                    continue
                if line is None:
                    for n, st in self.state.items():  # the run is over: nothing left running
                        solo = self.solo.get(n)
                        if st in ("running", "starting") and not (solo and solo.poll() is None):
                            self.set_state(n, "stopped")
                    self.write("\nDone.\n")
                    self.stop_recording()
                    self.start_btn.configure(state="normal")
                    self.bear_btn.configure(state="normal")
                    self.terror_btn.configure(state="normal")
                    self.journey_btn.configure(state="normal")
                    self.pouch_btn.configure(state="normal")
                    self.fishing_btn.configure(state="normal")
                    self.helper_btn.configure(state="normal")
                    self.caravan_btn.configure(state="normal")
                    self.daily_btn.configure(state="normal")
                    self.cesares_btn.configure(state="normal")
                    self.raider_btn.configure(state="normal")
                    self.finders_btn.configure(state="normal")
                    self.stop_btn.configure(state="disabled")
                    self.proc = None
                else:
                    got = line_status(line, self.state)
                    if got:
                        self.set_state(*got)
                    self.write(line)
        except queue.Empty:
            pass
        self.root.after(100, self.pump)

    # ---- log -----------------------------------------------------------
    def write(self, text):
        try:  # keep a copy on disk: logs/bots_YYYY-MM-DD.log
            logs = Path(ROOT) / "logs"
            logs.mkdir(exist_ok=True)
            with open(logs / f"bots_{time.strftime('%Y-%m-%d')}.log", "a", encoding="utf-8") as f:
                f.write(text)
        except Exception:
            pass
        self.log.configure(state="normal")
        self.log.insert("end", text)
        self.log.see("end")
        self.log.configure(state="disabled")

    def clear(self):
        self.log.configure(state="normal")
        self.log.delete("1.0", "end")
        self.log.configure(state="disabled")

    def close(self):
        self.stop()
        self.root.destroy()


def main():
    os.chdir(ROOT)
    root = tk.Tk()
    try:
        root.iconbitmap(str(ROOT / "intel_adb" / "icon.ico"))
    except tk.TclError:
        pass
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
