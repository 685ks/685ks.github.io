"""Template matching on BGR screenshots."""
from pathlib import Path

import cv2
import numpy as np

def imread(path, flags=cv2.IMREAD_COLOR):
    """cv2.imread that also opens non-ASCII paths on Windows. None when unreadable."""
    try:
        return cv2.imdecode(np.fromfile(str(path), np.uint8), flags)
    except (OSError, ValueError):
        return None


class Vision:
    def __init__(self, template_dir, threshold=0.8, scales=()):
        """scales: extra template sizes to try when the exact size misses (e.g. 0.9, 1.1).
        Off by default - screenshots are normalised to 540 wide, and each extra size costs
        a full match on every miss (5 sizes = 5x the CPU)."""
        self.template_dir = Path(template_dir)
        self.threshold = threshold
        self.scales = tuple(scales)
        self._cache = {}

    def template(self, name):
        if name not in self._cache:
            path = self.template_dir / f"{name}.png"
            try:  # imdecode: cv2.imread can't open non-ASCII paths on Windows
                img = cv2.imdecode(np.fromfile(str(path), np.uint8), cv2.IMREAD_COLOR)
            except OSError:
                img = None
            if img is None:
                raise FileNotFoundError(f"Missing template: {path}")
            self._cache[name] = img
        return self._cache[name]

    def _match(self, img, tpl):
        th, tw = tpl.shape[:2]
        if th > img.shape[0] or tw > img.shape[1]:
            return None
        return cv2.matchTemplate(img, tpl, cv2.TM_CCOEFF_NORMED)

    def find(self, img, name, threshold=None):
        t = self.threshold if threshold is None else threshold
        base = self.template(name)
        for scale in (1.0,) + self.scales:
            tpl = base if scale == 1.0 else cv2.resize(base, None, fx=scale, fy=scale)
            res = self._match(img, tpl)
            if res is None:
                continue
            _, max_val, _, max_loc = cv2.minMaxLoc(res)
            if max_val >= t:
                h, w = tpl.shape[:2]
                return (max_loc[0] + w // 2, max_loc[1] + h // 2)
        return None

    def find_all(self, img, name, threshold=None, min_dist=20, gray=False, region=None):
        """All matches, top-to-bottom. gray=True matches shape regardless of colour;
        region=(x, y, w, h) limits the search."""
        t = self.threshold if threshold is None else threshold
        tpl = self.template(name)
        ox = oy = 0
        if region:
            ox, oy, rw, rh = region
            img = img[oy:oy + rh, ox:ox + rw]
        if gray:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            tpl = cv2.cvtColor(tpl, cv2.COLOR_BGR2GRAY)
        res = self._match(img, tpl)
        if res is None:
            return []
        ys, xs = np.where(res >= t)
        order = np.argsort(-res[ys, xs])
        h, w = tpl.shape[:2]
        kept = []
        for i in order:
            p = (ox + int(xs[i]) + w // 2, oy + int(ys[i]) + h // 2)
            if all((p[0] - k[0]) ** 2 + (p[1] - k[1]) ** 2 >= min_dist ** 2 for k in kept):
                kept.append(p)
        return sorted(kept, key=lambda p: (p[1], p[0]))

    def has(self, img, name, threshold=None):
        return self.find(img, name, threshold) is not None

    def saturation(self, img, pos, r=14, mask=None):
        """Saturation around pos. With mask=<template name>: median over the pixels where
        that template is coloured (not its white icon), so an overlapping neighbour or a
        check mark barely moves it. Otherwise: 90th percentile of a (2r x 2r) box."""
        x, y = pos
        if mask is None:
            patch = img[max(0, y - r):y + r, max(0, x - r):x + r]
            return float(np.percentile(cv2.cvtColor(patch, cv2.COLOR_BGR2HSV)[..., 1], 90))
        t = cv2.cvtColor(self.template(mask), cv2.COLOR_BGR2GRAY)
        h, w = t.shape
        x0, y0 = x - w // 2, y - h // 2
        patch = img[y0:y0 + h, x0:x0 + w]
        if patch.shape[:2] != t.shape:
            return 0.0
        sat = cv2.cvtColor(patch, cv2.COLOR_BGR2HSV)[..., 1]
        return float(np.median(sat[t < 200]))

    def white_fraction(self, img, pos, mask):
        """Share of the template's white (icon) pixels that are near-white in img at pos.
        Real pins ~0.85-1.0; cloud edges that match the shape in grayscale ~0."""
        t = cv2.cvtColor(self.template(mask), cv2.COLOR_BGR2GRAY)
        h, w = t.shape
        x0, y0 = pos[0] - w // 2, pos[1] - h // 2
        patch = img[y0:y0 + h, x0:x0 + w]
        if patch.shape[:2] != t.shape:
            return 0.0
        hsv = cv2.cvtColor(patch, cv2.COLOR_BGR2HSV)
        white = (hsv[..., 1] < 60) & (hsv[..., 2] > 215)
        return float(white[t >= 200].mean())
