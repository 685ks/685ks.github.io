"""1-troop marches (user's trick, 2026-10-17): on the Deploy screen tap Clear All, then "+"
once on an Infantry row (any tier). The single soldier is injured in the fight, and a march
whose troops are all injured goes straight home - no walk back. Infantry because a single
cavalry or archer can survive and walk home.

Rows are found by their troop-type badge (shield = infantry) at the left of the portrait;
the row's "+" sits at a fixed offset from it."""
from pathlib import Path

import cv2

from intel_adb.vision import Vision

TEMPLATES = Path(__file__).parent / "templates"
ROWS = (0, 150, 80, 810)  # x, y, w, h where the troop badges can be (below the heroes)
PLUS_OFFSET = (462, 40)  # badge centre -> its row's "+"
COUNT_BOX = (280, -13, 88, 25)  # badge centre -> the amount box "207" (x, y, w, h)
ONE_MIN = 0.8  # "1" in the amount box: 1.0 screencap, 0.88 video; other amounts <= 0.51
_vision = None


def _v():
    global _vision
    if _vision is None:
        _vision = Vision(TEMPLATES)
    return _vision


def amount_is_one(img, badge):
    """The row's amount box shows exactly "1" (template from a real 1-troop Deploy screen).
    None when it can't be checked (no pixels)."""
    if not hasattr(img, "shape"):
        return None
    x, y = badge[0] + COUNT_BOX[0], badge[1] + COUNT_BOX[1]
    box = img[max(0, y - 4):y + COUNT_BOX[3] + 5, max(0, x - 4):x + COUNT_BOX[2] + 6]
    t = _v().template("amount_one")
    if box.shape[0] < t.shape[0] or box.shape[1] < t.shape[1]:
        return None
    return float(cv2.matchTemplate(box, t, cv2.TM_CCOEFF_NORMED).max()) >= ONE_MIN


def set_one_troop(device, shot, sleep, log=None):
    """On the Deploy screen: Clear All, then one Infantry. True when the amount reads 1 (or
    can't be read but the taps went in); False when there's no infantry row / Clear All."""
    v = _v()
    img = shot()
    clear = v.find(img, "clear_all", 0.8)
    if clear is None:
        log and log("1-troop: no Clear All button")
        return False
    device.tap(*clear)
    sleep(0.5)
    img = shot()
    rows = v.find_all(img, "troop_infantry", 0.8, region=ROWS)
    if not rows:
        log and log("1-troop: no Infantry row on the Deploy screen")
        return False
    badge = min(rows, key=lambda p: p[1])
    device.tap(badge[0] + PLUS_OFFSET[0], badge[1] + PLUS_OFFSET[1], jitter=1)
    sleep(0.4)
    if amount_is_one(shot(), badge) is False:
        log and log("1-troop: the Infantry amount isn't 1 - not deploying like this")
        return False
    return True
