"""Run Intel missions on every BlueStacks instance with Kingshot open.

    python -m intel_adb.run_intel                 # all instances
    python -m intel_adb.run_intel --only "685 #7"  # one instance
    python -m intel_adb.run_intel --dry-run       # report detected pins, no taps
"""
import argparse
import time
from concurrent.futures import ThreadPoolExecutor

from intel_adb import intel_flow
from intel_adb.adb import discover
from intel_adb.intel_flow import TEMPLATE_DIR, Result
from intel_adb.vision import Vision

REF_ASPECT = 540 / 960
TYPES = ("beast", "camp", "conquest", "gold", "glaives", "claimed", "skipped")


def _safe(run_fn, dev, vision, delay=0, sleep=time.sleep, opts=None):
    sleep(delay)  # staggered start so instances aren't in step
    try:
        return run_fn(dev, vision, **(opts or {}))
    except Exception as e:
        return Result(dev.name, {}, f"error: {e}")


def main(argv=None, discover_fn=discover, run_fn=intel_flow.run, sleep=time.sleep):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--only", action="append",
                    help="BlueStacks instance display name; repeat for several")
    ap.add_argument("--dry-run", action="store_true", help="detect pins only, never tap")
    ap.add_argument("--stagger", type=float, default=5,
                    help="seconds between starting each instance (default 5)")
    ap.add_argument("--preset-for", action="append", default=[], metavar="NAME=N",
                    help="formation flag 1-8 for an instance's Intel marches (else Equalize)")
    ap.add_argument("--bounties", default="Only if likely to prevail",
                    choices=["Never", "Only if likely to prevail", "Always"])
    ap.add_argument("--no-grey", action="store_true", help="leave grey (finished) pins alone")
    args = ap.parse_args(argv)

    presets = {}
    for item in args.preset_for:
        name, _, num = item.rpartition("=")
        if name and num.isdigit() and 1 <= int(num) <= 8:
            presets[name] = int(num)
    devices = discover_fn(only=args.only, dry_run=args.dry_run)
    if not devices:
        print("No running Kingshot instances found.")
        return []
    print(f"Running Intel on {len(devices)} instance(s): {', '.join(d.name for d in devices)}")
    for d in devices:
        try:
            w, h = d.size()
        except Exception as e:
            d.log(f"WARNING could not read screen size ({e!r}); continuing")
            continue
        if abs(w / h - REF_ASPECT) > 0.01:
            d.log(f"WARNING resolution {w}x{h} is not 9:16 portrait; templates may not match")

    with ThreadPoolExecutor(max_workers=len(devices)) as pool:
        # one Vision per worker: its template cache is not shared across threads
        futures = [pool.submit(_safe, run_fn, d, Vision(TEMPLATE_DIR), i * args.stagger, sleep,
                               {"preset": presets.get(d.name), "bounties": args.bounties,
                                "attack_grey": not args.no_grey})
                   for i, d in enumerate(devices)]
        results = [f.result() for f in futures]

    width = max(len(r.name) for r in results)
    print("\n" + "instance".ljust(width) + " | " + " ".join(f"{t:>8}" for t in TYPES) + " | result")
    for r in results:
        print(r.name.ljust(width) + " | " + " ".join(f"{r.done.get(t, 0):>8}" for t in TYPES)
              + f" | {r.reason}")
    return results


if __name__ == "__main__":
    main()
