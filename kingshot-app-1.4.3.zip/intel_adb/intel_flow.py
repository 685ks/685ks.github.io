"""Per-instance Intel mission loop.

Screen-driven: tap a coloured pin, then keep tapping whichever known button is on
screen (View / Attack / Conquer / Deploy / Fight / Skip / Tap-to-exit) until the
mission is deployed, fought or claimed.
"""
import time
from dataclasses import dataclass, field
from pathlib import Path

import cv2

from intel_adb import popups, timer

DEBUG_DIR = Path(__file__).parent / "debug"
TEMPLATE_DIR = Path(__file__).parent / "templates"

PIN_TYPES = {"pin_paw": "beast", "pin_swords": "conquest", "pin_tent": "camp", "pin_rebel": "gold",
             "pin_glaives": "glaives"}  # glaives = orange teardrop, skull icon (Golden Glaives)
PIN_THRESHOLD = {"pin_paw": 0.76, "pin_swords": 0.76, "pin_tent": 0.76, "pin_rebel": 0.65,
                 "pin_glaives": 0.76}
MAP_REGION = (0, 140, 540, 720)  # x, y, w, h — excludes the top bar and bottom stamina bar
CHECK_THRESHOLD = 0.65  # checked pins >= 0.75, unchecked <= 0.35
MIN_WHITE_ICON = 0.5  # pins: white icon pixels >= 0.85 present; clouds ~0
PIN_MERGE_DIST = 25
GREY_SATURATION = 120  # pin-ring median saturation: grey <= 56 even overlapped, coloured >= 205
MAP_TARGET = (270, 520)  # where the game centres a target when a pin jumps to the world map

NO_MARCH_KINDS = ("conquest", "camp")  # can be done while every march slot is busy
BOUNTY_TITLES = ("rebel_title", "rebel_title_map")  # popup proves it is a bounty, whatever the pin looked like
EXIT_BUTTONS = ("tap_to_exit", "tap_to_exit_2")
ACTION_BUTTONS = ("view_button", "attack_button", "conquer_button", "rescue_button")

MAX_PIN_ATTEMPTS = 3
MAX_RECOVERIES = 5  # consecutive; any success resets
MAX_ACTIONS_PER_PIN = 2  # deploys/fights on one pin (lost fights, slow marches)
AWAIT_TIMEOUT = 10 * 60  # s to wait for a check when the march timer could not be read
AWAIT_MARGIN = 30  # s added to 2x march time (battle + lag)
AWAIT_POLL = 15
FOUGHT_COOLDOWN = 15
MARCH_WAIT_UNKNOWN = 60  # s to hold march missions when slots are full but none are ours
UNKNOWN_TRIP = 120  # s assumed for a round trip when the march timer could not be read
RETURN_MARGIN = 10  # s at the target (battle) on top of 2x march time
# a fixed formation's heroes are away until its march is home: Attack on the next beast
# then only jumps to the map (Falkor 2026-10-11, 1/6 slots busy). Equalize sends in parallel.
PRESET_MARCHES = 1
NO_TROOPS_COOLDOWN = 60
BATTLE_TIMEOUT = 120
MAX_RUNTIME = 45 * 60


def claim_all_ready(vision, img):
    """Claim All is on screen *and lit*: the locked one looks the same, only darker."""
    pos = vision.find(img, "claim_all")
    if pos is None:
        return False
    if isinstance(img, str):  # fake screens in tests have no pixels
        return True
    x, y = pos
    patch = cv2.cvtColor(img[y - 10:y + 10, x - 70:x + 70], cv2.COLOR_BGR2HSV)
    return float(patch[..., 2].mean()) > 150


@dataclass
class Result:
    name: str
    done: dict = field(default_factory=dict)
    reason: str = ""


class Stuck(Exception):
    pass


PRESET_X = {1: 40, 2: 95, 3: 151, 4: 207, 5: 265, 6: 321, 7: 377, 8: 433}  # formation flags
PRESET_Y = 92


def read_marching(vision, img):
    """(busy, total) from the map's "Marching 5/6" panel, or None when it isn't readable."""
    import re
    pos = vision.find(img, "marching_label")
    if not pos or not timer.available():
        return None
    x, y = pos
    crop = img[max(0, y - 11):y + 11, x + 70:x + 132]
    g = cv2.cvtColor(cv2.resize(crop, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC), cv2.COLOR_BGR2GRAY)
    try:
        text = timer.pytesseract.image_to_string(g, config="--psm 7 -c tessedit_char_whitelist=0123456789/")
    except Exception:
        return None
    m = re.search(r"(\d)\s*/\s*(\d)", text)
    if not m:
        return None
    busy, total = int(m.group(1)), int(m.group(2))
    return (busy, total) if 0 <= busy <= total <= 8 else None


class Flow:
    def __init__(self, device, vision, sleep, clock, debug_dir, poll=1.0,
                 read_timer=timer.read_march_time, preset=None,
                 bounties="Only if likely to prevail", attack_grey=True, max_marches=None,
                 read_marching=read_marching):
        self.d, self.v = device, vision
        self.read_timer = read_timer
        self.preset = preset  # formation flag 1-8 on the Deploy screen; None = Equalize
        self.bounties = bounties  # Rebel bounties: "Never" | "Only if likely to prevail" | "Always"
        self.attack_grey = attack_grey  # grey (finished) pins without a reward check
        self.march_secs = None  # march time read from the last Deploy screen
        self.sleep, self.clock, self.poll = sleep, clock, poll
        self.debug_dir = Path(debug_dir)
        self.result = Result(device.name)
        self.cooldown = {}  # pos -> time until which the pin is skipped
        self.attempts = {}  # pos -> failed attempts
        self.actions = {}  # pos -> deploys/fights sent at this pin
        self.awaiting = {}  # pos -> deadline: troops sent, waiting for the check mark
        self.marching_to = {}  # pos -> time our march there is home; kept even if the pin hides
        self.empty_scans = 0
        self.claim_all_dead = False
        self.bounty = False
        self.recoveries = 0
        self.blocked = 0
        self.marches = []  # return times of our marches still out
        self.capacity = max_marches  # march slots: from settings, else learned at "queue full"
        self.read_marching = read_marching
        self.others = None  # marches out that aren't ours (gathering...), from the counter
        self.march_blocked_until = 0  # full, but none of the busy marches are ours
        self.used_march = False  # last mission sent a march (Deploy screen), not a rescue

    # ---- helpers -------------------------------------------------------
    def shot(self):
        return self.d.screencap()

    def tap_template(self, img, name):
        pos = self.v.find(img, name)
        if pos is None:
            return False
        self.d.tap(*pos)
        return True

    def _key(self, pos, table):
        for k in table:
            if abs(k[0] - pos[0]) + abs(k[1] - pos[1]) <= PIN_MERGE_DIST:
                return k
        return pos

    def save_debug(self, img, tag):
        self.debug_dir.mkdir(parents=True, exist_ok=True)
        path = self.debug_dir / f"{self.d.name}_{tag}_{time.strftime('%Y%m%d_%H%M%S')}.png"
        try:
            ok = cv2.imwrite(str(path), img)
        except Exception:
            ok = False
        if not ok:
            path.touch()
        self.d.log(f"debug screenshot: {path}")

    def back(self):
        """Android Back, then cancel Kingshot's "Quit game?" if Back opened it."""
        self.d.back()
        self.sleep(1)
        img = self.shot()
        if self.v.has(img, "quit_game"):
            self.d.log("cancelled Quit game dialog")
            self.tap_template(img, "cancel_button")

    def count(self, kind):
        self.result.done[kind] = self.result.done.get(kind, 0) + 1

    # ---- screens -------------------------------------------------------
    def find_pins(self, img):
        """All pins (coloured and grey: user wants every one attacked) as
        [(pos, pin_name, checked)], top-to-bottom. checked = reward waiting."""
        pins = []
        for name in PIN_TYPES:
            for pos in self.v.find_all(img, name, PIN_THRESHOLD[name], gray=True, region=MAP_REGION):
                if self.v.white_fraction(img, pos, name) < MIN_WHITE_ICON:
                    continue
                checked = self.has_check(img, pos)
                if not checked and not self.attack_grey and                         self.v.saturation(img, pos, mask=name) < GREY_SATURATION:
                    continue  # grey and already done: switched off
                if any(abs(p[0] - pos[0]) + abs(p[1] - pos[1]) <= PIN_MERGE_DIST for p, _, _ in pins):
                    continue
                pins.append((pos, name, checked))
        return sorted(pins, key=lambda p: (p[0][1], p[0][0]))

    def has_check(self, img, pos):
        """Green check at the pin's top-right = reward waiting (grey pins included)."""
        x, y = pos
        region = (max(0, x - 5), max(0, y - 40), 50, 50)
        return bool(self.v.find_all(img, "check_mark", CHECK_THRESHOLD, region=region))

    def open_intel(self):
        unknown = 0
        for _ in range(10):
            img = self.shot()
            if self.v.has(img, "intel_screen"):
                return img
            self.note_marching(img)
            if self.v.has(img, "quit_game"):
                self.tap_template(img, "cancel_button")
            elif any(self.tap_template(img, b) for b in
                     EXIT_BUTTONS + ("skip_button", "close_button", "world_button", "intel_icon")):
                unknown = 0
            else:
                unknown += 1  # often just a screen transition: wait before pressing Back
                if unknown >= 3:
                    self.back()
                    unknown = 0
            self.sleep(1.5)
        raise Stuck("could not reach the Intel screen")

    def handle_mission(self, kind):
        """After tapping a pin. Returns deployed / fought / claimed / march_full /
        no_troops / too_strong / blocked / stuck."""
        attacked = False
        unknown = 0
        intel_frames = 0
        last = None
        repeats = 0
        self.bounty = kind == "gold"
        self.march_secs = None
        self.used_march = False
        equalized = False
        map_tapped = False
        for _ in range(15):
            self.sleep(self.poll)
            img = self.shot()
            if not self.bounty and any(self.v.has(img, t) for t in BOUNTY_TITLES):
                self.bounty = True
            if self.bounty and self.bounties == "Never" and not any(self.v.has(img, b) for b in EXIT_BUTTONS):
                self.back()  # a bounty after all (pin looked like something else)
                return "too_strong"
            for b in EXIT_BUTTONS:
                if self.tap_template(img, b):
                    return "claimed"
            if self.v.has(img, "march_full"):
                self.tap_template(img, "close_button") or self.back()
                return "march_full"
            if self.v.has(img, "no_soldiers"):  # every soldier is already out marching
                self.back()
                return "no_troops"
            if self.v.has(img, "deploy_button"):
                if not equalized and self.preset in PRESET_X:
                    self.d.tap(PRESET_X[self.preset], PRESET_Y)  # the chosen formation
                    equalized = True
                    continue  # re-read the screen: the verdict can change
                if not equalized and self.tap_template(img, "equalize_button"):
                    equalized = True  # send only this march's share of the troops
                    continue  # re-read the screen: the verdict can change
                if self.bounty and self.bounties != "Always" and not self.v.has(img, "likely_to_prevail"):
                    self.back()
                    return "too_strong"
                self.march_secs = self.read_timer(img)
                self.tap_template(img, "deploy_button")
                self.sleep(self.poll * 1.5)
                after = self.shot()
                if popups.handle_confirm(self.d, self.v, after):  # "not enough Archer" warning
                    self.sleep(self.poll * 1.5)
                    after = self.shot()
                if self.v.has(after, "deploy_button"):  # game refused the deploy
                    self.save_debug(after, "deploy_refused")
                    return "blocked"
                self.used_march = True
                return "deployed"
            if self.tap_template(img, "fight_button"):
                return "fought" if self.wait_battle() else "stuck"
            tapped = next((b for b in ("skip_button",) + ACTION_BUTTONS
                           if self.tap_template(img, b)), None)
            if tapped:
                attacked = attacked or tapped in ("attack_button", "conquer_button", "rescue_button")
                repeats = repeats + 1 if tapped == last else 0
                last = tapped
                unknown = 0
                if repeats >= 2:
                    return "stuck"
                continue
            if (last is None and not map_tapped and not self.v.has(img, "intel_screen")
                    and self.v.has(img, "intel_icon")):
                # pin jumped to the world map without a popup (e.g. a camp whose rescue
                # party has arrived): tap the centred target to finish it
                self.d.tap(*MAP_TARGET)
                map_tapped = True
                continue
            if last == "rescue_button" and self.v.has(img, "intel_icon"):
                return "deployed"  # Rescue sends an Explore party straight from the popup
            if self.v.has(img, "intel_screen") and not attacked:
                intel_frames += 1
                if intel_frames >= 2:
                    return "stuck"  # popup never opened
                continue
            unknown += 1
            if attacked and unknown >= 5:
                self.save_debug(img, "after_attack")
                return "blocked"
            if unknown >= 6:
                return "stuck"
        return "stuck"

    def wait_battle(self):
        end = self.clock() + BATTLE_TIMEOUT
        while self.clock() < end:
            self.sleep(2)
            img = self.shot()
            for b in EXIT_BUTTONS:
                if self.tap_template(img, b):
                    return True
        return False

    # ---- main loop -----------------------------------------------------
    def run(self):
        start = self.clock()
        if self.d.dry_run:
            return self.dry_run()
        while self.clock() - start < MAX_RUNTIME:
            try:
                img = self.open_intel()
            except Stuck as e:
                if self.recover(str(e)):
                    return self.finish("abandoned")
                continue
            if not self.claim_all_dead and claim_all_ready(self.v, img):
                self.tap_template(img, "claim_all")  # collects every checked reward at once
                self.sleep(self.poll * 1.5)
                after = self.shot()
                if any(self.tap_template(after, b) for b in EXIT_BUTTONS):
                    self.count("claimed")
                    self.d.log("Claim All")
                    continue
                # nothing happened (locked): collect checked pins one by one from now on
                self.claim_all_dead = True
                self.d.log("Claim All did nothing - collecting rewards one by one")
                img = after
            now = self.clock()
            pins_now = self.find_pins(img)
            for k in list(self.awaiting):  # pin gone = its reward was collected
                if not any(abs(k[0] - p[0]) + abs(k[1] - p[1]) <= PIN_MERGE_DIST for p, _, _ in pins_now):
                    del self.awaiting[k]
            for k, deadline in list(self.awaiting.items()):
                if deadline <= now:  # march never reported back: stop waiting, don't re-attack
                    del self.awaiting[k]
                    self.attempts[self._key(k, self.attempts)] = MAX_PIN_ATTEMPTS
                    self.d.log(f"gave up waiting for pin at {k}")
            self.marches = [t for t in self.marches if t > now]
            marches_free = self.march_free(now)
            ready = []
            checked_set = {p for p, _, c in pins_now if c}
            checked_at = checked_set.__contains__
            for p, n, checked in pins_now:
                if not checked and self.bounties == "Never" and PIN_TYPES[n] == "gold":
                    continue  # rebel bounties switched off
                if checked:  # reward waiting: always collect
                    ready.append((p, n))
                    continue
                if not marches_free and PIN_TYPES[n] not in NO_MARCH_KINDS:
                    continue  # every march slot is out: wait for one to come back
                if self._key(p, self.awaiting) in self.awaiting:
                    continue  # our troops are on it; wait for the check
                if self.marching_to.get(self._key(p, self.marching_to), 0) > now:
                    continue  # pin hid and came back: our march there isn't home yet
                if self.attempts.get(self._key(p, self.attempts), 0) >= MAX_PIN_ATTEMPTS:
                    continue
                if self.cooldown.get(self._key(p, self.cooldown), 0) <= now:
                    ready.append((p, n))
            if not ready:
                if (self.awaiting or self.marches or self.march_blocked_until > now
                        or any(t > now for t in self.cooldown.values())):
                    wake = [t for t in self.marches + [self.march_blocked_until] if t > now]
                    self.sleep(min([AWAIT_POLL] + [max(1, t - now) for t in wake]))
                    continue
                # pins hidden under a just-claimed one only show once its animation ends
                self.empty_scans += 1
                if self.empty_scans < 2:
                    self.sleep(3)
                    continue
                return self.finish("no_missions")
            self.empty_scans = 0
            # rewards first, then march missions while a slot is free (they travel while we
            # work), then conquests and camps - which need no march slot
            ready.sort(key=lambda pn: (not checked_at(pn[0]),
                                       (PIN_TYPES[pn[1]] in NO_MARCH_KINDS) == marches_free))
            pos, name = ready[0]
            kind = PIN_TYPES[name]
            self.d.tap(*pos)
            outcome = self.handle_mission(kind)
            if self.bounty:
                kind = "gold"
            self.d.log(f"{kind} at {pos}: {outcome}")
            if outcome == "blocked":
                self.blocked += 1
                self.back()
                if self.blocked >= 2:
                    return self.finish("no_meat")
                continue
            if outcome != "stuck":
                self.recoveries = 0
            if outcome in ("deployed", "fought"):
                self.blocked = 0
                self.count(kind)
                if outcome == "deployed" and self.used_march:
                    trip = 2 * self.march_secs + RETURN_MARGIN if self.march_secs else UNKNOWN_TRIP
                    self.marches.append(self.clock() + trip)  # slot frees when troops are home
                    self.marching_to[self._key(pos, self.marching_to)] = self.clock() + trip
                if outcome == "deployed":  # march: result arrives later as a check mark
                    # there and back = 2x march time; the check usually shows on arrival
                    wait = (2 * self.march_secs + AWAIT_MARGIN) if self.march_secs else AWAIT_TIMEOUT
                    self.awaiting[self._key(pos, self.awaiting)] = self.clock() + wait
                    if self.march_secs:
                        self.d.log(f"march {self.march_secs}s, waiting up to {wait}s for the result")
                else:  # fight resolved on the spot: a win shows a check right away
                    self.cooldown[self._key(pos, self.cooldown)] = self.clock() + FOUGHT_COOLDOWN
                k = self._key(pos, self.actions)
                self.actions[k] = self.actions.get(k, 0) + 1
                if self.actions[k] >= MAX_ACTIONS_PER_PIN:
                    self.attempts[self._key(pos, self.attempts)] = MAX_PIN_ATTEMPTS
            elif outcome == "claimed":
                self.count("claimed")
                self.awaiting.pop(self._key(pos, self.awaiting), None)
            elif outcome in ("march_full", "no_troops"):
                self.learn_capacity()
                if outcome == "no_troops":
                    k = self._key(pos, self.attempts)
                    self.attempts[k] = self.attempts.get(k, 0) + 1
                    self.cooldown[self._key(pos, self.cooldown)] = self.clock() + NO_TROOPS_COOLDOWN
            elif outcome == "too_strong":
                self.count("skipped")
                self.attempts[self._key(pos, self.attempts)] = MAX_PIN_ATTEMPTS  # never retry
            else:  # stuck
                k = self._key(pos, self.attempts)
                self.attempts[k] = self.attempts.get(k, 0) + 1
                self.back()
                if self.recover(f"{kind} mission stuck"):
                    return self.finish("abandoned")
        return self.finish("timeout")

    def note_marching(self, img):
        """On the map: read "Marching N/M" - M is this account's slots, and N minus our own
        marches is everything else that is out (gatherers last hours, so it's stable)."""
        try:
            got = self.read_marching(self.v, img)
        except Exception:
            got = None
        if not got:
            return
        busy, total = got
        own = len([t for t in self.marches if t > self.clock()])
        self.capacity = total
        self.others = max(0, busy - own)

    def march_free(self, now):
        if self.march_blocked_until > now:
            return False
        own = len([t for t in self.marches if t > now])
        if self.preset in PRESET_X and own >= PRESET_MARCHES:
            return False
        if self.capacity is None:
            return True
        return own + (self.others or 0) < self.capacity

    def learn_capacity(self):
        """The game says no march can go out: our marches out now = this account's slots."""
        now = self.clock()
        out = len([t for t in self.marches if t > now])
        if out:
            if self.capacity != out:
                self.d.log(f"march slots: {out}")
            self.capacity = out
        else:  # busy with marches we didn't send (gathering etc.)
            self.march_blocked_until = now + MARCH_WAIT_UNKNOWN

    def recover(self, why):
        """Returns True when the instance should be abandoned."""
        self.recoveries += 1
        self.d.log(f"recovery {self.recoveries}/{MAX_RECOVERIES}: {why}")
        if self.recoveries >= MAX_RECOVERIES:
            self.save_debug(self.shot(), "abandoned")
            return True
        return False

    def dry_run(self):
        img = self.shot()
        if not self.v.has(img, "intel_screen"):
            self.d.log("(dry-run) not on the Intel screen; open it to see detected pins")
        else:
            pins = self.find_pins(img)
            counts = {}
            for _, n, _ in pins:
                counts[PIN_TYPES[n]] = counts.get(PIN_TYPES[n], 0) + 1
            self.d.log(f"(dry-run) active pins: {counts or 'none'} at {[p for p, _, _ in pins]}")
        return self.finish("dry_run")

    def finish(self, reason):
        self.result.reason = reason
        self.d.log(f"finished: {reason} {self.result.done}")
        return self.result


def run(device, vision, sleep=time.sleep, clock=time.monotonic, debug_dir=DEBUG_DIR,
        read_timer=timer.read_march_time, preset=None, bounties="Only if likely to prevail",
        attack_grey=True, max_marches=None, read_marching=read_marching):
    try:
        return Flow(device, vision, sleep, clock, debug_dir, read_timer=read_timer,
                    preset=preset, bounties=bounties, attack_grey=attack_grey,
                    max_marches=max_marches, read_marching=read_marching).run()
    except Exception as e:  # never take down the other workers
        device.log(f"error: {e!r}")
        return Result(device.name, {}, f"error: {e}")
