"""Bot command lines and helpers shared by the GUIs (no tkinter here, so any front end can
import them)."""
import json
import re
import subprocess
import sys
from datetime import timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
SETTINGS = ROOT / "gui_settings.json"
FORMATIONS = [str(i) for i in range(1, 9)]
DEFAULT_FORMATION = "6"  # "Ter"


def load_settings(path=SETTINGS):
    try:
        data = json.loads(Path(path).read_text())
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def save_settings(data, path=SETTINGS):
    try:
        Path(path).write_text(json.dumps(data, indent=2))
    except OSError:
        pass


def python_exe():
    """python.exe next to the running interpreter (the shortcut starts pythonw.exe)."""
    exe = Path(sys.executable)
    console = exe.with_name("python.exe")
    return str(console if console.exists() else exe)


BOUNTIES = ["Never", "Only if likely to prevail", "Always"]
INTEL_FORMATIONS = ["Eq"] + FORMATIONS  # Eq = Equalize
BEAR_FORMATIONS = ["8", "1-6", "1-5", "1-4", "1-3", "1-2", "1"]  # editable: any list like 2,4,6


def build_command(names, stagger, dry_run, all_selected, presets=None,
                  bounties="Only if likely to prevail", attack_grey=True):
    cmd = [python_exe(), "-u", "-m", "intel_adb.run_intel", "--stagger", str(stagger)]
    if not all_selected:  # with everything ticked, let the bot pick up every instance itself
        for n in names:
            cmd += ["--only", n]
    for n, p in (presets or {}).items():
        if p:
            cmd += ["--preset-for", f"{n}={p}"]
    if bounties != "Only if likely to prevail":
        cmd += ["--bounties", bounties]
    if not attack_grey:
        cmd.append("--no-grey")
    if dry_run:
        cmd.append("--dry-run")
    return cmd


def build_bear_command(names, dry_run, formations=None):
    """Bear bot runs on one account: the ticked one, or Primary when several are ticked.
    formations: {instance: "1-6"} - joiner formations, used in turn."""
    target = names[0] if len(names) == 1 else "Primary"
    cmd = [python_exe(), "-u", "-m", "bear_adb.bear", "--only", target]
    if (formations or {}).get(target):
        cmd += ["--formations", str(formations[target])]
    if dry_run:
        cmd.append("--dry-run")
    return cmd


def build_terror_command(names, rallies, stagger, dry_run, all_selected, presets=None, use_meat=False,
                         at_once=1, at_once_for=None, one_troop=False):
    cmd = [python_exe(), "-u", "-m", "terror_adb.terror", "--rallies", str(rallies),
           "--stagger", str(stagger), "--at-once", str(at_once)]
    if not all_selected:
        for n in names:
            cmd += ["--only", n]
    for n, p in (presets or {}).items():
        cmd += ["--preset-for", f"{n}={p}"]
    for n, k in (at_once_for or {}).items():
        cmd += ["--at-once-for", f"{n}={k}"]
    if one_troop:
        cmd.append("--one-troop")
    if use_meat:
        cmd.append("--use-meat")
    if dry_run:
        cmd.append("--dry-run")
    return cmd


def build_journey_command(names, dry_run, all_selected):
    cmd = [python_exe(), "-u", "-m", "journey_adb.journey"]
    if not all_selected:
        for n in names:
            cmd += ["--only", n]
    if dry_run:
        cmd.append("--dry-run")
    return cmd


def build_record_command(names, folder):
    cmd = [python_exe(), "-u", "-m", "autopilot.record_video", str(folder)]
    for n in names:
        cmd += ["--only", n]
    return cmd


def build_finders_command(names):
    """Finder's Fusion: the ticked instances in list order - 1st = top row, 2nd = bottom."""
    cmd = [python_exe(), "-u", "-m", "autopilot.finders_play"]
    for n in names:
        cmd += ["--only", n]
    return cmd


def build_fishing_command(names, dry_run):
    """Fishing Tournament runs on one account: the ticked one, or Falkor when several are."""
    target = names[0] if len(names) == 1 else "Falkor"
    cmd = [python_exe(), "-u", "-m", "fishing_adb.tourney", "--only", target]
    if dry_run:
        cmd.append("--dry-run")
    return cmd


def build_helper_command(names):
    """Fishing helper (read-only overlay) on one instance: the ticked one, or Primary."""
    target = names[0] if len(names) == 1 else "Primary"
    return [python_exe(), "-u", "-m", "fishing_adb.helper", "--only", target]


def build_caravan_command(names, dry_run):
    cmd = [python_exe(), "-u", "-m", "caravan_adb.caravan"]
    for n in names:
        cmd += ["--only", n]
    if dry_run:
        cmd.append("--dry-run")
    return cmd


def build_cesares_command(names, dry_run):
    cmd = [python_exe(), "-u", "-m", "cesares_adb.boss"]
    for n in names:
        cmd += ["--only", n]
    if dry_run:
        cmd.append("--dry-run")
    return cmd


DELAY_CHOICES = ["now", "in 10 min", "in 30 min", "in 1 h", "after 00:00 UTC"]
MIDNIGHT_MARGIN = 30  # s after 00:00 UTC: let the daily reset finish


def delay_seconds(choice, now):
    """Start delay in seconds: 'now' / '' / '0' -> 0, 'in 10 min', 'in 1 h', 'after 00:00 UTC'
    (until just after the next UTC midnight) or a plain number of seconds."""
    t = (choice or "").strip().lower()
    if t in ("", "now", "0"):
        return 0
    if "00:00" in t or "midnight" in t:
        nxt = (now + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
        return (nxt - now).total_seconds() + MIDNIGHT_MARGIN
    m = re.fullmatch(r"(?:in\s*)?(\d+(?:\.\d+)?)\s*(s|sec|m|min|h|hr|hour)?s?", t)
    if not m:
        raise ValueError(choice)
    n, unit = float(m.group(1)), (m.group(2) or "s")
    return n * {"s": 1, "sec": 1, "m": 60, "min": 60, "h": 3600, "hr": 3600, "hour": 3600}[unit]


def fmt_wait(seconds):
    h, rest = divmod(int(seconds), 3600)
    return f"{h} h {rest // 60} min" if h else f"{rest // 60} min {rest % 60} s"


RAIDER_FLAGS = ["", "1", "2", "3", "4", "5", "6", "7", "8"]


def build_raider_command(names, dry_run, flags=None):
    cmd = [python_exe(), "-u", "-m", "cesares_adb.raider"]
    for n in names:
        cmd += ["--only", n]
    for n, f in (flags or {}).items():
        if str(f).isdigit():
            cmd += ["--preset-for", f"{n}={f}"]
    if dry_run:
        cmd.append("--dry-run")
    return cmd


DAILY_JOBS = [("mail", "Mail"), ("meat", "Meat"), ("conquest", "Conquest"), ("troops", "Troops"),
              ("heal", "Heal"), ("research", "Research"), ("hunt", "Hunt beasts")]


def build_daily_command(names, jobs, dry_run, formations=None, hunt_level="Highest"):
    """Autopilot jobs once, on the ticked instances at the same time. hunt_level: hunt beasts
    up to this level ("Highest" = whatever is unlocked)."""
    cmd = [python_exe(), "-u", "-m", "autopilot.run_jobs", "--jobs", ",".join(jobs),
           "--hunt-level", str(hunt_level)]
    for n in names:
        cmd += ["--only", n]
    for n, f in (formations or {}).items():
        if str(f).isdigit():
            cmd += ["--formation-for", f"{n}={f}"]
    if dry_run:
        cmd.append("--dry-run")
    return cmd


STOP_WORDS = ("finished", "giving up", "stopping", "stopped", "error", "done:", "no running",
              "is not open", "couldn't open", "out of stamina")
STATUS_LOOK = {"idle": ("●", "#bbbbbb", "idle"), "running": ("●", "#1e9e3a", "running"),
               "stopped": ("●", "#c0392b", "stopped"), "starting": ("●", "#d4a017", "starting")}


def line_status(line, names):
    """(instance, 'running' | 'stopped') from a bot log line "[name] ...", or None."""
    if not line.startswith("["):
        return None
    name, sep, rest = line[1:].partition("] ")
    if not sep or name not in names:
        return None
    rest = rest.lower()
    return name, ("stopped" if any(w in rest for w in STOP_WORDS) else "running")


def build_pouch_command(names, dry_run, all_selected):
    cmd = [python_exe(), "-u", "-m", "pouch_adb.pouch"]
    if not all_selected:
        for n in names:
            cmd += ["--only", n]
    if dry_run:
        cmd.append("--dry-run")
    return cmd


def apply_resolution(names, low, discover_fn=None):
    """Set (low=True) or reset the display override on the named instances. Returns log lines."""
    if discover_fn is None:
        from intel_adb.adb import discover as discover_fn
    msgs = []
    for d in discover_fn(only=names):
        try:
            d.set_low_res() if low else d.reset_res()
            msgs.append(f"[{d.name}] {'low resolution set' if low else 'resolution reset'}")
        except Exception as e:
            msgs.append(f"[{d.name}] failed: {e}")
    return msgs or ["No matching instances with Kingshot open."]


