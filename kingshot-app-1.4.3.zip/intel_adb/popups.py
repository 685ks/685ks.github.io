"""Popups that can appear after tapping Deploy, shared by the Intel, Bear and Terror bots.

The formation warning ("This Formation does not have enough Archer! ... Proceed anyway?") has
the same "Confirmation" title and teal button position as Kingshot's "Quit game?" dialog -
whose teal button quits. The two are told apart by the button's own label: Deploy vs Confirm.
"""
import cv2

from intel_adb import timer

TITLE_THRESHOLD = 0.7  # template comes from an upscaled screenshot: allow a little blur
BUTTON_AREA = (270, 520, 250, 160)  # x, y, w, h where the teal button sits (540x960)


def _teal_button(img, area=BUTTON_AREA):
    x0, y0, w, h = area
    hsv = cv2.cvtColor(img[y0:y0 + h, x0:x0 + w], cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, (80, 120, 150), (100, 255, 255))
    n, _, stats, _ = cv2.connectedComponentsWithStats(mask)
    boxes = [stats[k] for k in range(1, n) if stats[k][2] > 100 and 30 < stats[k][3] < 80]
    if not boxes:
        return None
    bx, by, bw, bh, _ = max(boxes, key=lambda s: s[4])
    return x0 + int(bx), y0 + int(by), int(bw), int(bh)


def _label(img, box):
    x, y, w, h = box
    crop = img[y + 6:y + h - 6, x + 10:x + w - 10]
    g = cv2.cvtColor(cv2.resize(crop, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC), cv2.COLOR_BGR2GRAY)
    _, b = cv2.threshold(g, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)
    try:
        return timer.pytesseract.image_to_string(b, config="--psm 7").strip().lower()
    except Exception:
        return ""


def confirm_deploy_button(vision, img):
    """Centre of the warning's Deploy button, or None (no warning, or it's the Quit dialog)."""
    if not timer.available():
        return None  # can't read the label: never risk tapping the Quit dialog
    if vision.has(img, "quit_game") or not vision.has(img, "confirm_title", TITLE_THRESHOLD):
        return None
    box = _teal_button(img)
    if box is None or "deploy" not in _label(img, box):
        return None
    x, y, w, h = box
    return x + w // 2, y + h // 2


def handle_confirm(device, vision, img, finder=None):
    """Tap Deploy on the formation warning if it is showing. Returns True if it was."""
    pos = (finder or confirm_deploy_button)(vision, img)
    if pos is None:
        return False
    device.log("formation warning - deploying anyway")
    device.tap(*pos, jitter=2)
    return True
