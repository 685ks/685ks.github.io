"""Read the march time shown above the Deploy button (e.g. "00:00:37")."""
import re
from pathlib import Path

import cv2

def find_tesseract():
    """$KS_TESSERACT, the usual install folders, a copy next to the app, or PATH."""
    import os
    import shutil
    env = os.environ.get("KS_TESSERACT")
    if env and Path(env).exists():
        return Path(env)
    for c in (Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Tesseract-OCR" / "tesseract.exe",
              Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Tesseract-OCR" / "tesseract.exe",
              Path(__file__).resolve().parent.parent / "tesseract" / "tesseract.exe"):
        if c.exists():
            return c
    found = shutil.which("tesseract")
    return Path(found) if found else Path(r"C:\Program Files\Tesseract-OCR\tesseract.exe")


TESSERACT = find_tesseract()
TIMER_REGION = (385, 850, 85, 26)  # x, y, w, h on the 540x960 Deploy screen

try:
    import pytesseract
    pytesseract.pytesseract.tesseract_cmd = str(TESSERACT)
except ImportError:  # OCR is optional: without it the bot falls back to a fixed wait
    pytesseract = None


def available():
    return pytesseract is not None and TESSERACT.exists()


def parse_hms(text):
    """'00:00:37' -> 37, '0:45' -> 45, '002306' -> 1386 (OCR dropped the colons);
    None when it isn't a time."""
    bare = text.strip()
    if re.fullmatch(r"\d{6}", bare):
        h, m, s = int(bare[:2]), int(bare[2:4]), int(bare[4:])
        return h * 3600 + m * 60 + s if m < 60 and s < 60 else None
    parts = re.findall(r"\d+", text)
    if not 2 <= len(parts) <= 3 or ":" not in text:
        return None
    secs = 0
    for p in parts:
        secs = secs * 60 + int(p)
    return secs


def read_march_time(img):
    """March time in seconds from a Deploy screen, or None if it can't be read."""
    if not available():
        return None
    x, y, w, h = TIMER_REGION
    crop = img[y:y + h, x:x + w]
    gray = cv2.cvtColor(cv2.resize(crop, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC),
                        cv2.COLOR_BGR2GRAY)
    try:
        text = pytesseract.image_to_string(
            gray, config="--psm 7 -c tessedit_char_whitelist=0123456789:")
    except Exception:
        return None
    return parse_hms(text)
