"""Live screen frames from an instance at video rate (screencap takes ~0.4 s on Primary).

`screenrecord` writes an h264 stream to stdout; a local socket hands it to OpenCV's
built-in FFmpeg decoder (no extra packages). A reader thread keeps only the newest frame,
so latest() never returns a stale one. screenrecord stops by itself after 180 s - the
stream restarts it."""
import socket
import subprocess
import threading
import time

import cv2

from intel_adb import adb

TIME_LIMIT = 180


class Stream:
    def __init__(self, device, size=(540, 960), bitrate="4M"):
        self.d = device
        self.size = size
        self.bitrate = bitrate
        self.frame = None
        self.frame_t = 0.0
        self.count = 0
        self.stop_ev = threading.Event()
        self.lock = threading.Lock()
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def _serve(self, srv, proc):
        conn, _ = srv.accept()
        try:
            while not self.stop_ev.is_set():
                data = proc.stdout.read1(65536) if hasattr(proc.stdout, "read1") else proc.stdout.read(4096)
                if not data:
                    break
                conn.sendall(data)
        except OSError:
            pass
        finally:
            conn.close()

    def _run(self):
        while not self.stop_ev.is_set():
            srv = socket.socket()
            srv.bind(("127.0.0.1", 0))
            srv.listen(1)
            port = srv.getsockname()[1]
            proc = subprocess.Popen(
                [adb.ADB_PATH, "-s", self.d.serial, "exec-out", "screenrecord", "--output-format=h264",
                 "--size", f"{self.size[0]}x{self.size[1]}", "--bit-rate", self.bitrate,
                 "--time-limit", str(TIME_LIMIT), "-"],
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, creationflags=adb.NO_WINDOW)
            relay = threading.Thread(target=self._serve, args=(srv, proc), daemon=True)
            relay.start()
            cap = cv2.VideoCapture(f"tcp://127.0.0.1:{port}", cv2.CAP_FFMPEG)
            try:
                while not self.stop_ev.is_set():
                    ok, f = cap.read()
                    if not ok:
                        break
                    if f.shape[1] != adb.REF_WIDTH:
                        f = cv2.resize(f, (adb.REF_WIDTH, round(f.shape[0] * adb.REF_WIDTH / f.shape[1])))
                    with self.lock:
                        self.frame, self.frame_t = f, time.monotonic()
                        self.count += 1
            finally:
                cap.release()
                proc.kill()
                srv.close()

    def latest(self, newer_than=0.0, timeout=2.0):
        """Newest frame (BGR, 540 wide) received after `newer_than` (monotonic), or None."""
        end = time.monotonic() + timeout
        while time.monotonic() < end:
            with self.lock:
                if self.frame is not None and self.frame_t > newer_than:
                    return self.frame, self.frame_t
            time.sleep(0.005)
        return None

    def close(self):
        self.stop_ev.set()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
