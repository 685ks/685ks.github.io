"""Save ADB screenshots for cropping templates, or check templates against captures.

    python -m intel_adb.capture "685 #7" intel_screen
    python -m intel_adb.capture --check
"""
import argparse
import time
from pathlib import Path

import cv2
from intel_adb.vision import imread as _imread

from intel_adb.adb import discover
from intel_adb.vision import Vision

HERE = Path(__file__).parent
CAPTURE_DIR = HERE / "captures"
TEMPLATE_DIR = HERE / "templates"


def capture(name, label=None):
    devices = discover(only=name)
    if not devices:
        raise SystemExit(f"No running Kingshot instance named {name!r}")
    img = devices[0].screencap()
    CAPTURE_DIR.mkdir(exist_ok=True)
    path = CAPTURE_DIR / f"{name}_{label or time.strftime('%H%M%S')}.png"
    cv2.imwrite(str(path), img)
    print(f"{path}  ({img.shape[1]}x{img.shape[0]})")


def check():
    vision = Vision(TEMPLATE_DIR)
    caps = sorted(CAPTURE_DIR.glob("*.png"))
    for tpl in sorted(TEMPLATE_DIR.glob("*.png")):
        best = (0.0, None)
        for cap in caps:
            img = _imread(str(cap))
            res = vision._match(img, vision.template(tpl.stem))
            if res is not None and res.max() > best[0]:
                best = (float(res.max()), cap.name)
        print(f"{tpl.stem:20s} {best[0]:.3f}  {best[1]}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("name", nargs="?")
    ap.add_argument("label", nargs="?")
    ap.add_argument("--check", action="store_true")
    args = ap.parse_args()
    if args.check:
        check()
    elif args.name:
        capture(args.name, args.label)
    else:
        ap.error("give an instance name or --check")


if __name__ == "__main__":
    main()
