"""Turn off BlueStacks extras (ads, promotions, telemetry, uploads, AI, notifications, the
key-controls overlay) in bluestacks.conf. Performance settings (CPU, RAM, FPS) are untouched.

    python -m intel_adb.bs_extras            # show what would change
    python -m intel_adb.bs_extras --apply    # change it (BlueStacks must be fully closed)

A backup is written next to the file first. The file's read-only flag (it is set on this PC,
which stops BlueStacks rewriting it) is put back afterwards."""
import argparse
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

CONF = Path(r"C:\ProgramData\BlueStacks_nxt\bluestacks.conf")

GLOBAL_OFF = [  # 1 -> 0
    "bst.feature.programmatic_ads", "bst.feature.show_gp_ads", "bst.feature.show_programmatic_ads_preference",
    "bst.feature.send_programmatic_ads_boot_stats", "bst.feature.send_programmatic_ads_click_stats",
    "bst.feature.app_install_stats", "bst.feature.usage_stats", "bst.feature.send_auto_record_stats",
    "bst.feature.send_internal_notification_stats", "bst.feature.send_nowbux_login_boot_stats",
    "bst.feature.auto_upload_nowgg_moments", "bst.feature.auto_upload_nowgg_recording",
    "bst.feature.nowgg_cloud_upload_enabled", "bst.feature.nowgg_login_popup", "bst.feature.nowbux",
    "bst.feature.blueai", "bst.feature.show_ai_highlights", "bst.feature.show_moments",
    "bst.feature.show_cloud_instance", "bst.feature.show_sdk_gp_popup", "bst.feature.show_guest_signin",
    "bst.feature.enable_mobile_notification", "bst.feature.smart_downloads",
    "bst.feature.show_boot_banner_preference", "bst.key_controls_overlay_enabled",
]
INSTANCE_OFF = [  # per instance, 1 -> 0
    "enable_notifications", "game_controls_enabled",
]


def plan(text):
    """[(key, old, new)] for every setting that would change."""
    changes = []
    for key in GLOBAL_OFF:
        m = re.search(rf'^{re.escape(key)}="([^"]*)"', text, re.M)
        if m and m.group(1) != "0":
            changes.append((key, m.group(1), "0"))
    for m in re.finditer(r'^(bst\.instance\.[^.]+\.(' + "|".join(INSTANCE_OFF) + r'))="([^"]*)"', text, re.M):
        if m.group(3) not in ("0", "-1"):
            changes.append((m.group(1), m.group(3), "0"))
    return changes


def apply(text, changes):
    for key, _, new in changes:
        text = re.sub(rf'^{re.escape(key)}="[^"]*"', f'{key}="{new}"', text, count=1, flags=re.M)
    return text


def bluestacks_running():
    out = subprocess.run(["tasklist"], capture_output=True, text=True).stdout
    return any(n in out for n in ("HD-Player.exe", "HD-MultiInstanceManager.exe", "BlueStacks"))


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--conf", default=str(CONF))
    a = ap.parse_args(argv)
    conf = Path(a.conf)
    text = conf.read_text(encoding="utf-8", errors="ignore")
    changes = plan(text)
    for key, old, new in changes:
        print(f"{key}: {old} -> {new}")
    print(f"{len(changes)} setting(s) to change")
    if not a.apply or not changes:
        return 0
    if bluestacks_running():
        print("BlueStacks is still running - close every instance and the Multi-Instance Manager first.")
        return 1
    backup = conf.with_name(f"bluestacks.conf.backup_{time.strftime('%Y%m%d_%H%M%S')}")
    shutil.copy2(conf, backup)
    was_readonly = subprocess.run(["attrib", str(conf)], capture_output=True, text=True).stdout[:12].find("R") >= 0
    subprocess.run(["attrib", "-R", str(conf)], check=True)
    try:
        conf.write_text(apply(text, changes), encoding="utf-8", newline="\n")
    finally:
        if was_readonly:
            subprocess.run(["attrib", "+R", str(conf)], check=True)
    print(f"done - backup: {backup}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
