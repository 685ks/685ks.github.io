import csv
from pathlib import Path

CSV_PATH = Path(__file__).resolve().parents[1] / 'all_pages_player_ids.csv'

def main():
    to_remove = {'site', 'source_url', 'note'}
    rows = []
    with CSV_PATH.open(newline='', encoding='utf-8-sig') as f:
        reader = csv.reader(f)
        try:
            header = next(reader)
        except StopIteration:
            return
        # normalize header: remove BOM, surrounding quotes and whitespace
        normalized = [h.strip().lstrip('\ufeff').strip('"').strip() for h in header]
        keep_indices = [i for i,h in enumerate(normalized) if h not in to_remove]
        new_header = [normalized[i] for i in keep_indices]
        rows.append(new_header)
        for r in reader:
            # pad row if shorter
            if len(r) < len(header):
                r += [''] * (len(header) - len(r))
            rows.append([r[i] for i in keep_indices])

    # Write back to same file
    with CSV_PATH.open('w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f, quoting=csv.QUOTE_ALL)
        for r in rows:
            writer.writerow(r)

if __name__ == '__main__':
    main()
