"""Gift code redemption against the official Kingshot gift code site (no Flask needed)."""
import hashlib
import json
import time

import requests

LOGIN_URL = "https://kingshot-giftcode.centurygame.com/api/player"
REDEEM_URL = "https://kingshot-giftcode.centurygame.com/api/gift_code"
WOS_ENCRYPT_KEY = "mN4!pQs6JrYwV9"
DELAY = 7
MAX_RETRIES = 1

RESULT_MESSAGES = {
    "SUCCESS": "Successfully redeemed",
    "RECEIVED": "Already redeemed",
    "SAME TYPE EXCHANGE": "Successfully redeemed (same type)",
    "TIME ERROR": "Code has expired",
    "TIMEOUT RETRY": "Server requested retry",
    "USED": "Claim limit reached, unable to claim",
}

def encode_data(data):
    secret = WOS_ENCRYPT_KEY
    sorted_keys = sorted(data.keys())
    encoded_data = "&".join([
        f"{key}={json.dumps(data[key]) if isinstance(data[key], dict) else data[key]}" for key in sorted_keys
    ])
    return {"sign": hashlib.md5(f"{encoded_data}{secret}".encode()).hexdigest(), **data}

def make_request(url, payload):
    for attempt in range(MAX_RETRIES):
        try:
            response = requests.post(url, json=payload, timeout=20)
            if response.status_code == 200:
                response_data = response.json()
                msg_content = response_data.get("msg", "")
                if isinstance(msg_content, str) and msg_content.strip('.') == "TIMEOUT RETRY":
                    time.sleep(DELAY)
                    continue
                return response
        except Exception:
            time.sleep(DELAY)
    return None

def redeem_gift_code(fid, cdk):
    if not str(fid).strip().isdigit():
        return {"msg": "Invalid FID format"}
    fid = str(fid).strip()
    login_payload = encode_data({"fid": fid, "time": int(time.time() * 1000)})
    login_resp = make_request(LOGIN_URL, login_payload)
    if not login_resp:
        return {"msg": "Login request failed after retries"}
    login_data = login_resp.json()
    if login_data.get("code") != 0:
        return {"msg": f"Login failed: {login_data.get('msg', 'Unknown login error')}"}
    redeem_payload = encode_data({"fid": fid, "cdk": cdk, "time": int(time.time() * 1000)})
    redeem_resp = make_request(REDEEM_URL, redeem_payload)
    if not redeem_resp:
        return {"msg": "Redemption request failed after retries"}
    return redeem_resp.json()

