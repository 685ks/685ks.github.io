from flask import Flask, render_template_string, request
import os
import requests
import time
import hashlib
import json
from datetime import datetime

from giftcode.redeem import (DELAY, LOGIN_URL, MAX_RETRIES, REDEEM_URL, RESULT_MESSAGES,  # noqa: F401
                             encode_data, make_request, redeem_gift_code)

app = Flask(__name__)

form_html = '''
<!doctype html>
<html lang="en">
  <head>
    <title>Gift Code Redeemer</title>
    <style>
      body { font-family: Arial, sans-serif; margin: 40px; }
      .container { max-width: 400px; margin: auto; }
      input, button { width: 100%; margin: 8px 0; padding: 8px; }
      .result { margin-top: 20px; font-weight: bold; }
    </style>
  </head>
  <body>
    <div class="container">
      <h2>Redeem Gift Code</h2>
      <form method="post">
        <label>Player ID:</label>
        <input type="text" name="fid" required>
        <label>Gift Code:</label>
        <input type="text" name="code" required>
        <button type="submit">Redeem</button>
      </form>
      {% if result %}
        <div class="result">Result: {{ result }}</div>
      {% endif %}
    </div>
  </body>
</html>
'''

@app.route('/', methods=['GET', 'POST'])
def index():
    result = None
    if request.method == 'POST':
        fid = request.form.get('fid')
        code = request.form.get('code')
        response = redeem_gift_code(fid, code)
        raw_msg = response.get('msg', 'Unknown error').strip('.')
        result = RESULT_MESSAGES.get(raw_msg, raw_msg)
    return render_template_string(form_html, result=result)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5000)))
