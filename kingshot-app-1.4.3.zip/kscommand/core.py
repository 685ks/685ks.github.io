"""Paths, the app's own settings and small helpers shared by every page."""
import json
import os
import subprocess
import sys
import threading
from dataclasses import asdict, dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent  # the folder holding intel_adb, autopilot, ...
SETTINGS_PATH = ROOT / "ksc_settings.json"
LOG_DIR = ROOT / "logs"
SHOTS_DIR = ROOT / "screenshots"
COVERAGE_PATH = Path(__file__).with_name("coverage.json")
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
APP_NAME = "Kingshot Command"


@dataclass
class AppSettings:
    autostart: bool = True  # start Autopilot a few seconds after the app opens
    autostart_delay: int = 10  # s of countdown (Cancel stops it)
    keep_alive: bool = True  # relaunch Kingshot when it crashed or was closed
    keep_alive_min: int = 2  # minutes between checks
    start_with_windows: bool = False
    minimize_to_tray: bool = True
    low_res: bool = False  # 540x960 display override on every instance
    accent: str = "Steel"
    telegram_token: str = ""
    telegram_chat: str = ""  # only this chat may command the bot
    telegram_events: bool = True  # notify on session results, errors, crashes
    player_ids: list = field(default_factory=list)  # gift codes: [{"id": "123", "name": "Main"}]
    redeemed: dict = field(default_factory=dict)  # code -> [player ids done]
    bot_options: dict = field(default_factory=dict)  # bot id -> {option: value}
    emulators: dict = field(default_factory=dict)  # instance name -> emulators.Target fields
    update_url: str = ""  # learned-skills index (latest.json); empty = learned.DEFAULT_UPDATE_URL
    update_check: bool = True  # look for new learned skills when the app opens
    learned_off: list = field(default_factory=list)  # learned skill ids switched off
    first_run: bool = True


_lock = threading.Lock()


def load():
    try:
        data = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return AppSettings()
    base = asdict(AppSettings())
    return AppSettings(**{k: data.get(k, v) for k, v in base.items()})


def save(s):
    with _lock:
        tmp = SETTINGS_PATH.with_suffix(".tmp")
        tmp.write_text(json.dumps(asdict(s), indent=2), encoding="utf-8")
        tmp.replace(SETTINGS_PATH)


def coverage():
    try:
        return json.loads(COVERAGE_PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []


def reveal(path):
    """Show a file (selected) or folder in Explorer; xdg-open elsewhere."""
    path = Path(path)
    try:
        if os.name == "nt":
            if path.is_file():
                subprocess.Popen(["explorer", "/select,", str(path)])
            else:
                os.startfile(str(path))
        else:
            subprocess.Popen(["xdg-open", str(path.parent if path.is_file() else path)],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError:
        pass


def python_console():
    """python.exe next to the running interpreter (the app itself runs on pythonw.exe)."""
    exe = Path(sys.executable)
    console = exe.with_name("python.exe")
    return str(console if console.exists() else exe)


def set_start_with_windows(on):
    """HKCU Run entry for the launcher next to the python folder. No-op off Windows."""
    if os.name != "nt":
        return False
    import winreg
    launcher = ROOT.parent / f"{APP_NAME}.exe"
    key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run",
                         0, winreg.KEY_SET_VALUE)
    with key:
        if on:
            winreg.SetValueEx(key, APP_NAME, 0, winreg.REG_SZ, f'"{launcher}" --tray')
        else:
            try:
                winreg.DeleteValue(key, APP_NAME)
            except FileNotFoundError:
                pass
    return True


def tool_status():
    """{'adb': path or None, 'ocr': path or None} as the bots will see them."""
    from intel_adb import adb, timer
    adb_path = adb.find_adb()
    ocr = timer.find_tesseract()
    return {"adb": adb_path if Path(adb_path).exists() or adb_path == "adb" else None,
            "ocr": str(ocr) if ocr.exists() else None}


PLATFORM_TOOLS_URL = "https://dl.google.com/android/repository/platform-tools-latest-windows.zip"
TESSERACT_URL = ("https://github.com/UB-Mannheim/tesseract/releases/download/v5.4.0.20240606/"
                 "tesseract-ocr-w64-setup-5.4.0.20240606.exe")


def download(url, dest, progress=None):
    import requests
    with requests.get(url, stream=True, timeout=60) as r:
        r.raise_for_status()
        total = int(r.headers.get("Content-Length") or 0)
        done = 0
        tmp = Path(str(dest) + ".part")
        with open(tmp, "wb") as f:
            for chunk in r.iter_content(1 << 16):
                f.write(chunk)
                done += len(chunk)
                if progress and total:
                    progress(done / total)
        tmp.replace(dest)


def install_adb(progress=None):
    """Google's platform-tools into <app>/platform-tools (adb.exe). Returns the adb path."""
    import zipfile
    zpath = ROOT / "platform-tools.zip"
    download(PLATFORM_TOOLS_URL, zpath, progress)
    with zipfile.ZipFile(zpath) as z:
        z.extractall(ROOT)
    zpath.unlink(missing_ok=True)
    from intel_adb import adb
    adb.ADB_PATH = adb.find_adb()
    return adb.ADB_PATH


def install_ocr(progress=None):
    """Tesseract (UB Mannheim build), silent per-user install to %LOCALAPPDATA%\\Programs."""
    exe = ROOT / "tesseract-setup.exe"
    download(TESSERACT_URL, exe, progress)
    target = Path(os.environ.get("LOCALAPPDATA", str(ROOT))) / "Programs" / "Tesseract-OCR"
    # NSIS wants /D= last and unquoted, even with spaces: pass one command string
    subprocess.run(f'"{exe}" /S /D={target}', timeout=600, creationflags=NO_WINDOW)
    exe.unlink(missing_ok=True)
    from intel_adb import timer
    timer.TESSERACT = timer.find_tesseract()
    try:
        timer.pytesseract.pytesseract.tesseract_cmd = str(timer.TESSERACT)
    except AttributeError:
        pass
    return str(timer.TESSERACT) if timer.TESSERACT.exists() else None
