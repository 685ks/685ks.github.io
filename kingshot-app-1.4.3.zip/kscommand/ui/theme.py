"""Colours, type, motion and the app-wide stylesheet.

Values come from Ks's tools-site design system (tokens.css / tokens.json): near-black navy, a
steel-blue accent, hairline white borders, glass panels, and gold kept for Truegold and "you".
Qt paints opaque colours faster, so the white-alpha fills and lines are pre-mixed over --bg."""

from PySide6.QtCore import QEasingCurve

# (accent, gradient partner). Steel is the design system's --neon / --neon-lo pair; Truegold is
# --gold for people who want the warm look.
ACCENTS = {
    "Steel": ("#8fb8d8", "#3d5a73"),
    "Truegold": ("#d9c08a", "#7d6a43"),
}
DEFAULT_ACCENT = "Steel"

C = {
    "bg": "#07090d",        # --bg
    "sky_top": "#06080c",
    "sky_bottom": "#0a0d13",
    "glow": "#111823",      # sky glow
    "panel": "#0b0e14",     # --bg-sheet, sidebar
    "card": "#0d1015",      # --fill (white 2.5%) over --bg
    "card2": "#101216",     # --fill-input (white 3.5%)
    "focus": "#16181c",     # --fill-focus (white 6%)
    "line": "#25272b",      # --line (white 12%)
    "line2": "#1b1d21",     # --line2 (white 8%)
    "ink": "#effcff",       # --ink, body text
    "text": "#e6eef5",      # --neon-hi, headings and values
    "muted": "#a3b3c2",
    "faint": "#76869a",
    "dim": "#7d8ea0",       # --title-dim
    "on_accent": "#0b0f14",
    "accent": "#8fb8d8",    # --neon
    "accent_lo": "#3d5a73",
    "accent_hi": "#b5d3ea",
    "gold": "#d9c08a",
    "ok": "#8fe0a8",
    "warn": "#f0c674",
    "bad": "#ff9db0",
    "info": "#8fb8d8",
}

FONT = '"Inter", "Segoe UI Variable Text", "Segoe UI", "Noto Sans", sans-serif'

# Letter spacing (percent of normal) and caps for small labels, which QSS can't express.
# Keyed by object name; applied by the Polish filter in app.py.
TRACKING = {
    "eyebrow": (124, True),
    "statLabel": (122, True),
    "fieldLabel": (122, True),
    "brandSub": (130, True),
    "chip": (108, True), "chipOk": (108, True), "chipWarn": (108, True), "chipBad": (108, True),
    "pageTitle": (97, False),
    "heroTitle": (96.5, False),
    "statValue": (98, False),
    "h2": (99, False),
}

# Durations from the motion tokens (ms).
T_HOVER, T_FOCUS, T_SHEET, T_POP, T_REVEAL, T_BAR = 200, 250, 300, 600, 1000, 1600


# Qt's BezierSpline curves crash PySide6 6.8 on Windows (access violation when an animation
# copies one, seen in fault.log), so the token curves map to Qt's built-in ones instead.
def ease():
    """The house curve, cubic-bezier(.2,.8,.2,1): a strong ease-out."""
    return QEasingCurve(QEasingCurve.OutQuint)


def spring():
    """The number-pop curve, cubic-bezier(.3,1.6,.5,1): overshoots, then settles."""
    c = QEasingCurve(QEasingCurve.OutBack)
    c.setOvershoot(1.4)
    return c


def hop():
    """Loading diamonds, cubic-bezier(.5,0,.5,1)."""
    return QEasingCurve(QEasingCurve.InOutSine)


def accent(name):
    return ACCENTS.get(name, ACCENTS[DEFAULT_ACCENT])


def tint(hex_colour, alpha):
    """rgba() string for a status colour at `alpha` (0..1), for QSS fills and borders."""
    h = hex_colour.lstrip("#")
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    return f"rgba({r},{g},{b},{alpha})"


def stylesheet(accent_name=DEFAULT_ACCENT):
    a1, a2 = accent(accent_name)
    c = C

    def status_chip(name, col):
        return (f"#{name} {{ background: {tint(col, .07)}; border: 1px solid {tint(col, .4)}; border-radius: 10px;"
                f" padding: 3px 10px; color: {col}; font-size: 10.5px; font-weight: 600; }}")

    return f"""
* {{ font-family: {FONT}; font-size: 13.5px; }}
QWidget {{ color: {c['ink']}; background: transparent; }}
QMainWindow {{ background: {c['bg']}; }}
#root {{ background: qradialgradient(cx:0.6, cy:0.65, radius:0.9, fx:0.6, fy:0.65,
         stop:0 {c['glow']}, stop:0.55 {c['sky_bottom']}, stop:1 {c['sky_top']}); }}
#sidebar {{ background: {c['panel']}; border-right: 1px solid {c['line2']}; }}
#brand {{ font-size: 16px; font-weight: 700; color: {c['text']}; }}
#brandSub {{ color: {a1}; font-size: 10px; font-weight: 600; }}
#navBtn {{ text-align: left; padding: 10px 14px; border: 1px solid transparent; border-radius: 10px;
           background: transparent; color: {c['muted']}; font-size: 13.5px; font-weight: 500; }}
#navBtn:hover {{ background: {c['card']}; color: {c['text']}; }}
#navBtn:checked {{ color: {c['text']}; background: {c['focus']}; border-color: {c['line2']}; font-weight: 600; }}
#navIndicator {{ background: {a1}; border-radius: 1px; }}
#pin {{ background: {a1}; border-radius: 4px; }}
#eyebrow {{ color: {a1}; font-size: 12px; font-weight: 600; }}
#pageTitle {{ font-size: 30px; font-weight: 700; color: {c['text']}; }}
#pageSub {{ color: {c['muted']}; font-size: 14px; }}
#card {{ background: {c['card']}; border: 1px solid {c['line']}; border-radius: 14px; }}
#card:hover {{ border-color: #33363b; }}
#hero {{ border-radius: 18px; border: 1px solid {c['line']};
         background: qradialgradient(cx:0.85, cy:0.5, radius:1.1, fx:0.85, fy:0.5,
                     stop:0 #141c28, stop:0.6 {c['panel']}, stop:1 {c['panel']}); }}
#heroTitle {{ font-size: 34px; font-weight: 700; color: {c['text']}; }}
#muted {{ color: {c['muted']}; }}
#faint {{ color: {c['faint']}; font-size: 12px; }}
#gold {{ color: {c['gold']}; font-weight: 600; }}
#h2 {{ font-size: 17px; font-weight: 600; color: {c['text']}; }}
#h3 {{ font-size: 14px; font-weight: 600; color: {c['text']}; }}
#statValue {{ font-size: 28px; font-weight: 700; color: {c['text']}; }}
#statLabel, #fieldLabel {{ color: {c['faint']}; font-size: 10px; font-weight: 600; }}
#chip {{ background: {c['card2']}; border: 1px solid {c['line']}; border-radius: 10px; padding: 3px 10px;
         color: {c['muted']}; font-size: 10.5px; font-weight: 600; }}
{status_chip('chipOk', c['ok'])}
{status_chip('chipWarn', c['warn'])}
{status_chip('chipBad', c['bad'])}
QPushButton {{ background: {c['card2']}; border: 1px solid {c['line']}; border-radius: 12px; color: {c['text']};
               padding: 8px 15px; font-size: 14px; font-weight: 600; }}
QPushButton:hover {{ border-color: {a1}; background: {c['focus']}; }}
QPushButton:pressed {{ background: {c['line2']}; }}
QPushButton:disabled {{ color: {c['faint']}; border-color: {c['line2']}; }}
QPushButton#primary {{ border: 1px solid {c['text']}; color: {c['on_accent']}; background: {c['text']}; }}
QPushButton#primary:hover {{ background: #ffffff; border-color: #ffffff; }}
QPushButton#primary:pressed {{ background: {c['muted']}; }}
QPushButton#danger {{ border: 1px solid {tint(c['bad'], .4)}; color: {c['bad']}; background: {tint(c['bad'], .06)}; }}
QPushButton#danger:hover {{ border-color: {c['bad']}; background: {tint(c['bad'], .12)}; }}
QPushButton#ghost {{ background: transparent; border: 1px solid transparent; color: {c['muted']}; padding: 6px 8px;
                     border-radius: 10px; }}
QPushButton#ghost:hover {{ color: {c['text']}; border-color: {c['line']}; }}
QPushButton#instChip {{ border-radius: 15px; padding: 5px 13px; color: {c['muted']}; font-size: 12.5px; }}
QPushButton#instChip:checked {{ color: {c['on_accent']}; border: 1px solid {c['text']}; background: {c['text']}; }}
QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox, QTimeEdit, QPlainTextEdit, QTextEdit {{
    background: {c['card2']}; border: 1px solid {c['line']}; border-radius: 12px; padding: 7px 11px;
    color: {c['ink']}; font-size: 14px; selection-background-color: {c['accent_lo']}; selection-color: {c['ink']}; }}
QSpinBox, QDoubleSpinBox, QTimeEdit {{ padding: 4px 8px; min-height: 24px; }}
QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus, QTimeEdit:focus, QPlainTextEdit:focus,
QTextEdit:focus {{ border-color: {a1}; background: {c['focus']}; }}
QLineEdit:hover, QSpinBox:hover, QDoubleSpinBox:hover, QComboBox:hover, QTimeEdit:hover {{ border-color: #3a3d42; }}
QComboBox::drop-down {{ border: none; width: 24px; }}
QComboBox QAbstractItemView {{ background: {c['panel']}; border: 1px solid {c['line']}; padding: 4px;
    selection-background-color: {c['focus']}; selection-color: {c['text']}; outline: none; }}
QSpinBox::up-button, QSpinBox::down-button, QDoubleSpinBox::up-button, QDoubleSpinBox::down-button,
QTimeEdit::up-button, QTimeEdit::down-button {{ width: 16px; border: none; }}
QScrollArea {{ border: none; }}
QScrollBar:vertical {{ background: transparent; width: 10px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: {c['line']}; border-radius: 3px; min-height: 30px; }}
QScrollBar::handle:vertical:hover {{ background: {c['accent_lo']}; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; width: 0; }}
QScrollBar::add-page, QScrollBar::sub-page {{ background: transparent; }}
QScrollBar:horizontal {{ background: transparent; height: 10px; margin: 2px; }}
QScrollBar::handle:horizontal {{ background: {c['line']}; border-radius: 3px; min-width: 30px; }}
QTableWidget, QListWidget, QTreeWidget {{ background: {c['card']}; border: 1px solid {c['line']}; border-radius: 14px;
    gridline-color: {c['line2']}; alternate-background-color: {c['panel']}; outline: none; }}
QTableWidget::item, QListWidget::item {{ padding: 6px; border-radius: 6px; }}
QTableWidget::item:hover, QListWidget::item:hover {{ background: {c['card2']}; }}
QTableWidget::item:selected, QListWidget::item:selected {{ background: {c['focus']}; color: {c['text']}; }}
QHeaderView {{ background: transparent; }}
QHeaderView::section {{ background: {c['panel']}; color: {c['faint']}; border: none; border-bottom: 1px solid {c['line']};
    padding: 9px 8px; font-weight: 600; font-size: 10.5px; }}
QTableCornerButton::section {{ background: {c['panel']}; border: none; }}
QToolTip {{ background: {c['panel']}; color: {c['ink']}; border: 1px solid {c['line']}; padding: 7px 9px; border-radius: 10px; }}
QMenu {{ background: {c['panel']}; border: 1px solid {c['line']}; padding: 6px; border-radius: 12px; }}
QMenu::item {{ padding: 7px 18px; border-radius: 8px; }}
QMenu::item:selected {{ background: {c['focus']}; }}
QMenu::separator {{ height: 1px; background: {c['line2']}; margin: 4px 8px; }}
QProgressBar {{ background: {c['focus']}; border: none; border-radius: 5px; max-height: 10px; text-align: center;
    color: transparent; }}
QProgressBar::chunk {{ border-radius: 5px; background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 {a2}, stop:1 {a1}); }}
QCheckBox {{ spacing: 8px; }}
QCheckBox::indicator {{ width: 16px; height: 16px; border-radius: 5px; border: 1px solid {c['line']}; background: {c['card2']}; }}
QCheckBox::indicator:checked {{ background: {a1}; border-color: {a1}; }}
#console {{ font-family: "Cascadia Mono", "Consolas", "DejaVu Sans Mono", monospace; font-size: 12.5px;
            background: #05070a; border: 1px solid {c['line']}; border-radius: 14px; }}
#banner {{ background: {tint(c['warn'], .06)}; border: 1px solid {tint(c['warn'], .35)}; border-radius: 12px; }}
#toast {{ background: {c['panel']}; border: 1px solid {c['line']}; border-radius: 12px; }}
"""
