"""Every standalone bot the app can launch: what it is, its options, and its command line
(built by intel_adb.commands, the same builders the old Tk window used)."""
from dataclasses import dataclass, field

from intel_adb import commands as C


@dataclass
class Opt:
    key: str
    label: str
    kind: str  # "int" | "choice" | "bool" | "text" | "per_instance" (a choice per instance: {name: value})
    default: object
    choices: list = field(default_factory=list)
    lo: int = 0
    hi: int = 999
    help: str = ""


@dataclass
class Bot:
    id: str
    title: str
    glyph: str
    blurb: str
    category: str
    build: object  # (names, opts, dry_run, all_selected) -> argv
    options: list = field(default_factory=list)
    single: bool = False  # runs on one instance only (the first ticked)
    tags: tuple = ()


def _one(names):
    return names[:1]


FORMS = [str(i) for i in range(1, 9)]
FORMATIONS = ["Equalize"] + FORMS


def per_instance(value, names, default):
    """{name: choice} for the given instances from a saved per-instance map."""
    value = value if isinstance(value, dict) else {}
    return {n: str(value.get(n, default)) for n in names}


def _intel_presets(names, value):
    return {n: int(v) for n, v in per_instance(value, names, "Equalize").items() if v.isdigit()}


def _terror_presets(names, value):
    return {n: ("Eq" if v == "Equalize" else v) for n, v in per_instance(value, names, "6").items()}

BOTS = [
    Bot("intel", "Intel missions", "🛰", "Clears intel pins on the world map: rebels, bounties, "
        "rescues and beasts, with formation presets per instance.", "Combat",
        lambda n, o, d, a: C.build_command(n, o["stagger"], d, a, presets=_intel_presets(n, o["formation"]),
                                           bounties=o["bounties"], attack_grey=o["grey"]),
        [Opt("formation", "Formation", "per_instance", "Equalize", FORMATIONS,
             help="Formation flag each instance marches with; Equalize spreads troops evenly"),
         Opt("stagger", "Stagger between instances (s)", "int", 5, lo=0, hi=60),
         Opt("bounties", "Rebel bounties", "choice", "Only if likely to prevail", C.BOUNTIES),
         Opt("grey", "Attack grey (finished) pins", "bool", True)], tags=("daily",)),
    Bot("bear", "Bear Hunt", "🐻", "Launches your own Bear Trap rally and joins others' with a "
        "round robin of formations. Start it a minute before the trap opens.", "Combat",
        lambda n, o, d, a: C.build_bear_command(_one(n), d, {n[0]: o["formations"]} if n else None),
        [Opt("formations", "Joiner formations (used in turn)", "choice", "1-6", C.BEAR_FORMATIONS)],
        single=True, tags=("event",)),
    Bot("terror", "Terror rallies", "💀", "Searches Terrors, holds rallies, Equalize formations, "
        "several rallies at once and coordinate claims.", "Combat",
        lambda n, o, d, a: C.build_terror_command(n, o["rallies"], o["stagger"], d, a,
                                                  presets=_terror_presets(n, o["formation"]),
                                                  use_meat=o["meat"], at_once=o["at_once"],
                                                  one_troop=o["one_troop"]),
        [Opt("formation", "Formation", "per_instance", "6", FORMATIONS,
             help="Formation flag each instance rallies with (6 is the game's 'Ter' preset)"),
         Opt("rallies", "Rallies", "int", 5, lo=1, hi=250),
         Opt("at_once", "Rallies at once", "int", 1, lo=1, hi=6),
         Opt("stagger", "Stagger (s)", "int", 5, lo=0, hi=60),
         Opt("meat", "Use meat for stamina", "bool", False),
         Opt("one_troop", "Send 1 troop (fill only)", "bool", False)], tags=("daily",)),
    Bot("daily", "Daily sweep", "☀", "Runs the Autopilot jobs once on every ticked instance at the "
        "same time: mail, meat, conquest, troops, heal, research, hunt.", "Daily",
        lambda n, o, d, a: C.build_daily_command(n, [k for k, _ in C.DAILY_JOBS if o.get(k, True)], d,
                                                 hunt_level=o["hunt_level"]),
        [*(Opt(k, label, "bool", True) for k, label in C.DAILY_JOBS),
         Opt("hunt_level", "Hunt beasts up to", "choice", "Highest", ["Highest", *map(str, range(1, 31))])],
        tags=("daily",)),
    Bot("caravan", "Caravans", "🐪", "Collects caravans, refreshes to gold (diamond-capped) and "
        "escorts.", "Economy", lambda n, o, d, a: C.build_caravan_command(n, d), tags=("daily",)),
    Bot("journey", "Journey event", "🧭", "Journey chests, cooking and the digging/fishing "
        "mini-games.", "Events", lambda n, o, d, a: C.build_journey_command(n, d, a), tags=("event",)),
    Bot("pouch", "Red pouch", "🧧", "Opens red pouches during the Red Pouch event.", "Events",
        lambda n, o, d, a: C.build_pouch_command(n, d, a), tags=("event",)),
    Bot("cesares", "Cesares boss", "👑", "Cesares boss from alliance chat cards with 1 infantry.",
        "Events", lambda n, o, d, a: C.build_cesares_command(n, d), tags=("event",)),
    Bot("raider", "Cesares Raider", "⚔", "Cesares Raider: Fury levels, Diana and the help plan.",
        "Events", lambda n, o, d, a: C.build_raider_command(n, d), tags=("event",)),
    Bot("fishing", "Fishing tournament", "🎣", "Plays the fishing tournament: vision, steering "
        "and catch prediction.", "Events", lambda n, o, d, a: C.build_fishing_command(_one(n), d),
        single=True, tags=("event",)),
    Bot("helper", "Fishing helper", "🔭", "Read-only overlay that predicts fish while you play "
        "yourself.", "Events", lambda n, o, d, a: C.build_helper_command(_one(n)), single=True),
    Bot("finders", "Finder's Fusion", "🔍", "Finder's Fortune team mode: taps the listed items from "
        "learnt maps (1st ticked = top row).", "Events", lambda n, o, d, a: C.build_finders_command(n),
        tags=("event",)),
]

BY_ID = {b.id: b for b in BOTS}


def options_for(bot, saved):
    """Saved option values, defaults filled in."""
    saved = saved or {}
    return {o.key: saved.get(o.key, {} if o.kind == "per_instance" else o.default) for o in bot.options}
