"""Teacher mode: record what you do on one instance (every tap and swipe, with the screen
before and after it), then pack it into one zip to hand to Claude, who turns it into a job.

Touches come from `adb shell getevent -lt` (the emulator's touch device, scaled to 0..1);
screens from screencap whenever the picture changes or a touch happened. Read-only: the
recorder never taps."""
import json
import re
import subprocess
import threading
import time
import zipfile
from datetime import datetime
from pathlib import Path

import cv2
import numpy as np

from intel_adb import adb as A
from kscommand import core

ROOT = core.ROOT / "teacher"
FRAME_W = 540  # frames are stored at the bots' reference width
CHANGE = 3.0  # mean grey difference on a thumbnail that counts as a new screen
TAP_MOVE = 0.02  # a touch that moved less than 2% of the screen is a tap
LONG_PRESS = 0.6  # s


# ---------------------------------------------------------------- touch events
def axis_ranges(getevent_pl):
    """{device: (max_x, max_y)} from `getevent -pl`, for devices with multi-touch axes."""
    out, dev = {}, None
    for line in getevent_pl.splitlines():
        m = re.match(r"add device \d+: (\S+)", line)
        if m:
            dev = m.group(1)
            continue
        m = re.search(r"(ABS_MT_POSITION_[XY]|ABS_[XY])\b.*?max (\d+)", line)
        if dev and m:
            x, y = out.get(dev, (None, None))
            if m.group(1).endswith("X"):
                x = x or int(m.group(2))
            else:
                y = y or int(m.group(2))
            out[dev] = (x, y)
    return {d: r for d, r in out.items() if r[0] and r[1]}


class Gestures:
    """Turns `getevent -lt` lines into taps, long presses and swipes (coordinates 0..1)."""

    LINE = re.compile(r"(/dev/input/event\d+):\s+(\w+)\s+(\w+)\s+(\w+)")

    def __init__(self, ranges, emit, clock=time.time):
        self.ranges, self.emit, self.clock = ranges, emit, clock
        self.down = None  # (t, [(t, x, y), ...]) while a finger is down
        self.x = self.y = None
        self.dev = None

    def feed(self, line):
        m = self.LINE.search(line)
        if not m:
            return
        dev, typ, code, val = m.groups()
        if dev not in self.ranges:
            return
        mx, my = self.ranges[dev]
        v = int(val, 16) if re.fullmatch(r"[0-9a-fA-F]+", val) else val
        if code in ("ABS_MT_POSITION_X", "ABS_X"):
            self.x = v / mx
        elif code in ("ABS_MT_POSITION_Y", "ABS_Y"):
            self.y = v / my
        elif code == "ABS_MT_TRACKING_ID":
            if v == 0xFFFFFFFF or v == "ffffffff":
                self._up()
            elif self.down is None:
                self.down = (self.clock(), [])
        elif code == "BTN_TOUCH":
            if val == "DOWN" and self.down is None:
                self.down = (self.clock(), [])
            elif val == "UP":
                self._up()
        elif code == "SYN_REPORT" and self.down is not None and self.x is not None and self.y is not None:
            self.down[1].append((self.clock(), self.x, self.y))

    def _up(self):
        if self.down is None:
            return
        t0, pts = self.down
        self.down = None
        if not pts:
            return
        t1 = self.clock()
        (_, x0, y0), (_, x1, y1) = pts[0], pts[-1]
        moved = max(abs(x1 - x0), abs(y1 - y0))
        dur = t1 - t0
        if moved < TAP_MOVE:
            g = {"kind": "long_press" if dur >= LONG_PRESS else "tap", "x": round(x0, 4), "y": round(y0, 4)}
        else:
            step = max(1, len(pts) // 12)  # keep the path short
            path = [(round(x, 4), round(y, 4)) for _, x, y in pts[::step]] + [(round(x1, 4), round(y1, 4))]
            g = {"kind": "swipe", "x": round(x0, 4), "y": round(y0, 4), "x2": round(x1, 4), "y2": round(y1, 4),
                 "path": path}
        g.update(t=round(t0, 3), duration=round(dur, 3))
        self.emit(g)


# ---------------------------------------------------------------- recorder
def _thumb(img):
    return cv2.cvtColor(cv2.resize(img, (90, 160)), cv2.COLOR_BGR2GRAY).astype(np.int16)


def slug(text):
    s = re.sub(r"[^A-Za-z0-9]+", "-", text).strip("-")
    return s[:40] or "lesson"


class Recorder:
    """Records one instance until stop(). Callbacks run on the recorder's threads."""

    def __init__(self, name, serial, title, notes="", out_root=ROOT, popen=subprocess.Popen,
                 device=None, on_update=None, interval=0.5):
        self.name, self.serial, self.title, self.notes = name, serial, title, notes
        self.dev = device or A.Device(name, serial)
        self.popen = popen
        self.on_update = on_update or (lambda rec: None)
        self.interval = interval
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        self.folder = Path(out_root) / f"{stamp}_{slug(title)}"
        (self.folder / "frames").mkdir(parents=True, exist_ok=True)
        self.gestures, self.frames = [], []  # frames: [(t, filename)]
        self.started = time.time()
        self.error = ""
        self.last_img = None
        self._stop = threading.Event()
        self._want_frame = threading.Event()
        self._lock = threading.Lock()
        self._proc = None
        self._threads = []

    # ---- control
    def start(self):
        for fn in (self._touch_loop, self._frame_loop):
            th = threading.Thread(target=fn, daemon=True)
            th.start()
            self._threads.append(th)
        return self

    def stop(self):
        self._stop.set()
        self._want_frame.set()
        if self._proc:
            try:
                self._proc.kill()
            except Exception:
                pass
        for th in self._threads:
            th.join(timeout=10)
        self._write()
        return self.folder

    @property
    def seconds(self):
        return time.time() - self.started

    # ---- touches
    def _touch_loop(self):
        try:
            pl = self.dev._adb("shell", "getevent", "-pl").decode(errors="ignore")
            ranges = axis_ranges(pl)
            if not ranges:
                raise RuntimeError("no touch device found")
            parser = Gestures(ranges, self._gesture)
            self._proc = self.popen([A.ADB_PATH, "-s", self.serial, "shell", "getevent", "-lt"],
                                    stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                    creationflags=A.NO_WINDOW)
            for raw in iter(self._proc.stdout.readline, b""):
                if self._stop.is_set():
                    break
                parser.feed(raw.decode(errors="ignore"))
        except Exception as e:  # recording frames still works without touches
            self.error = f"touches aren't recorded on this instance ({e})"
            self.on_update(self)

    def _gesture(self, g):
        with self._lock:
            before = [f for t, f in self.frames if t <= g["t"]]
            g["frame_before"] = before[-1] if before else None
            g["step"] = len(self.gestures) + 1
            self.gestures.append(g)
        self._want_frame.set()  # grab the screen the touch led to
        self.on_update(self)

    # ---- screens
    def _frame_loop(self):
        last = None
        pending_after = []  # gestures waiting for their "after" frame
        while not self._stop.is_set():
            t0 = time.time()
            try:
                img = self.dev.screencap(tries=1)
            except Exception:
                img = None
            if img is not None:
                h, w = img.shape[:2]
                if w != FRAME_W:
                    img = cv2.resize(img, (FRAME_W, round(h * FRAME_W / w)), interpolation=cv2.INTER_AREA)
                th = _thumb(img)
                with self._lock:
                    pending_after += [g for g in self.gestures if "frame_after" not in g and g not in pending_after]
                if last is None or np.abs(th - last).mean() > CHANGE or pending_after:
                    name = f"{len(self.frames) + 1:04d}.jpg"
                    ok, buf = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, 82])
                    if ok:
                        (self.folder / "frames" / name).write_bytes(buf.tobytes())
                        with self._lock:
                            self.frames.append((t0, name))
                            for g in pending_after:
                                if g["t"] <= t0:
                                    g["frame_after"] = name
                            pending_after = [g for g in pending_after if "frame_after" not in g]
                        last = th
                        self.last_img = img
                        self.on_update(self)
            self._want_frame.wait(max(0.0, self.interval - (time.time() - t0)))
            self._want_frame.clear()

    # ---- output
    def _write(self):
        size = None
        try:
            size = list(self.dev.size())
        except Exception:
            pass
        meta = {
            "title": self.title, "notes": self.notes, "instance": self.name, "serial": self.serial,
            "started": datetime.fromtimestamp(self.started).isoformat(timespec="seconds"),
            "seconds": round(self.seconds, 1), "screen_size": size, "frame_width": FRAME_W,
            "coordinates": "x and y are 0..1 of the screen; multiply by 540 and 960 for the bots' reference frame",
            "app": f"Kingshot Command {__import__('kscommand').__version__}",
            "touch_error": self.error, "steps": len(self.gestures), "frames": len(self.frames),
        }
        (self.folder / "lesson.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
        with open(self.folder / "steps.jsonl", "w", encoding="utf-8") as f:
            for g in self.gestures:
                f.write(json.dumps(g) + "\n")
        annotate(self.folder, self.gestures)


def annotate(folder, gestures):
    """steps/NNN.jpg: the screen before each touch, with the touch drawn on it."""
    out = Path(folder) / "steps"
    out.mkdir(exist_ok=True)
    for g in gestures:
        src = g.get("frame_before") or g.get("frame_after")
        if not src:
            continue
        img = cv2.imdecode(np.fromfile(str(Path(folder) / "frames" / src), np.uint8), cv2.IMREAD_COLOR)
        if img is None:
            continue
        h, w = img.shape[:2]
        p0 = (round(g["x"] * w), round(g["y"] * h))
        col = (90, 200, 255)
        if g["kind"] == "swipe":
            pts = np.array([(round(x * w), round(y * h)) for x, y in g["path"]], np.int32)
            cv2.polylines(img, [pts], False, col, 4, cv2.LINE_AA)
            cv2.arrowedLine(img, tuple(pts[-2]) if len(pts) > 1 else p0, tuple(pts[-1]), col, 4, cv2.LINE_AA,
                            tipLength=0.4)
        cv2.circle(img, p0, 22, col, 4, cv2.LINE_AA)
        if g["kind"] == "long_press":
            cv2.circle(img, p0, 32, col, 2, cv2.LINE_AA)
        label = f"{g['step']} {g['kind'].replace('_', ' ')}"
        cv2.putText(img, label, (12, 34), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 0), 5, cv2.LINE_AA)
        cv2.putText(img, label, (12, 34), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 255, 255), 2, cv2.LINE_AA)
        ok, buf = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, 82])
        if ok:
            (out / f"{g['step']:03d}.jpg").write_bytes(buf.tobytes())


# ---------------------------------------------------------------- lessons on disk
def lessons(root=ROOT):
    """Saved recordings, newest first: [(folder, lesson.json dict)]."""
    out = []
    for d in sorted(Path(root).glob("*/lesson.json"), reverse=True):
        try:
            out.append((d.parent, json.loads(d.read_text(encoding="utf-8"))))
        except (OSError, ValueError):
            continue
    return out


README = """Kingshot Command - Teacher mode lesson

For Claude: this is a recording of a task done by hand on one emulator instance, to be
turned into a new automated job for Kingshot Command (the user's own ADB bots).

lesson.json   what is being taught, the user's notes, instance and screen size
steps.jsonl   one touch per line, in order: kind (tap / long_press / swipe), x, y
              (0..1 of the screen), x2/y2 and path for swipes, duration, and the
              frames seen just before and just after it
steps/        the screen before each touch with the touch drawn on it
frames/       every distinct screen during the recording (540 px wide)
"""


def export(folder, dest_dir=None):
    """One zip of the lesson, for sending. Returns its path."""
    folder = Path(folder)
    dest_dir = Path(dest_dir) if dest_dir else export_dir()
    dest_dir.mkdir(parents=True, exist_ok=True)
    path = dest_dir / f"KingshotLesson_{folder.name}.zip"
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("README.txt", README)
        for f in sorted(folder.rglob("*")):
            if f.is_file():
                z.write(f, f"{folder.name}/{f.relative_to(folder).as_posix()}")
    return path


def export_dir():
    """Documents\\Kingshot lessons (falls back to the app folder)."""
    home = Path.home()
    docs = home / "Documents"
    return (docs if docs.is_dir() else core.ROOT) / "Kingshot lessons"
