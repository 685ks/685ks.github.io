import sys

from kscommand.app import main

sys.exit(main())
