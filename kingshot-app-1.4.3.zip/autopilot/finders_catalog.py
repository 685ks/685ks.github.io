"""Catalogue Finder's Fusion scenes from recordings: every round is learnt into its own
scene (by the title at the top), then each scene's table is rebuilt.

    python -m autopilot.finders_catalog RECORDING_DIR [...]

Instances in the same team film the same round; only the first instance that shows a round
of a scene at a given moment is used (no double counting)."""
import sys
from pathlib import Path

from autopilot import finders as F
from autopilot import finders_build as B
from autopilot import finders_learn as L


def signature(frames):
    """The first full set of names in a round - teammates see the same set (other order)."""
    for f in frames[:12]:
        names = [n for n in F.names(f) if n]
        if len(names) >= 5:
            return frozenset(names)
    return None


def main(dirs):
    per_scene, seen_rounds = {}, set()
    for d in dirs:
        done_file = Path(d) / "catalogued.txt"  # chunks already learnt (re-runs skip them)
        done = set(done_file.read_text().split()) if done_file.exists() else set()
        for v in sorted(Path(d).rglob("*.mp4")):
            tag = f"{v.parent.name}/{v.name}"
            if tag in done:
                continue
            for i, r in enumerate(L.rounds(v)):
                names = [F.scene_id(r[k]) for k in (len(r) // 4, len(r) // 2, 3 * len(r) // 4)]
                scene = max(set(names), key=names.count)
                if scene == "unknown":
                    print(f"{v.parent.name}/{v.name} round {i}: scene name unreadable - skipped", flush=True)
                    continue
                sig = signature(r)
                if sig and (scene, sig) in seen_rounds:
                    print(f"{v.parent.name}/{v.name} round {i}: same round as a teammate's - skipped", flush=True)
                    continue
                seen_rounds.add((scene, sig))
                got = F.learn(r, log=lambda m: None, scene=scene, save_crops=False)
                B.add_sightings(scene, got)
                B.add_round(scene)
                per_scene.setdefault(scene, 0)
                per_scene[scene] += 1
                print(f"{v.parent.name}/{v.name} round {i}: {scene}, {len(r)} frames, {len(got)} items seen",
                      flush=True)
            with open(done_file, "a") as fh:
                fh.write(tag + "\n")
    print()
    for scene, n in sorted(per_scene.items()):
        table, rep = B.build(scene)
        print(f"== {scene}: {n} round(s) this time, table now {len(table)} items")
        print("   " + "\n   ".join(rep))


if __name__ == "__main__":
    main(sys.argv[1:])
