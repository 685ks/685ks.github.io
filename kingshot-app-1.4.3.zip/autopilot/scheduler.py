"""When to run whom: random intervals, quiet hours, one character at a time."""
import random
from datetime import datetime


def _minutes(hhmm):
    h, m = hhmm.split(":")
    return int(h) * 60 + int(m)


def in_quiet(now_local, start, end):
    """True when local time falls in [start, end); the window may wrap past midnight."""
    s, e = _minutes(start), _minutes(end)
    if s == e:
        return False
    t = now_local.hour * 60 + now_local.minute
    return s <= t < e if s < e else (t >= s or t < e)


def next_run(now, schedule, rng=random):
    """Timestamp of the next session: a random point in [min, max] hours from now."""
    return now + rng.uniform(schedule.interval_min_h, schedule.interval_max_h) * 3600


def in_window(now_local, start, end):
    """Inside a character's active hours (local time); equal start and end = always."""
    if _minutes(start) == _minutes(end):
        return True
    return in_quiet(now_local, start, end)


def pick_due(settings, state, now, now_local=None, skip_instances=()):
    """The enabled character that has waited longest past its next-run time, or None.
    Characters outside their active hours, or on a busy instance, wait."""
    now_local = now_local or datetime.now()
    due = [c for c in settings.characters
           if c.enabled and any(j.enabled for j in c.jobs.values())
           and c.instance not in skip_instances
           and state.next_run(c.key) <= now
           and in_window(now_local, getattr(c, "active_start", "00:00"), getattr(c, "active_end", "00:00"))]
    if not due:
        return None
    if settings.schedule.order == "List order":
        return due[0]
    return min(due, key=lambda c: state.next_run(c.key))


def quiet_now(settings, now_local=None):
    sch = settings.schedule
    return in_quiet(now_local or datetime.now(), sch.quiet_start, sch.quiet_end)
