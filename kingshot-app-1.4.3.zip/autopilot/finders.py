"""Finder's Fortune - Finder's Fusion (team mode), recorded 2026-10-11 on Primary
(autopilot/recording_finders, tests/fixtures/finders).

A round: a scene ("Today's Challenges: Dock" - a new scene each day), 26 hidden items, 6 names
at a time in two rows under the scene, 60 s, a teammate finding items too.

User (2026-10-11): team mode only; a wrong tap costs time - only tap items the bot is sure of;
never use the hint.

Learning: when a name leaves the list, the item that vanished from the scene at that moment
is that name - its picture is saved per scene in finders_items/<scene>/<name>.png with its
position. Playing: for each listed name the bot knows, find its picture in the scene, tap it.
"""
import json
import re
from pathlib import Path

import cv2
from intel_adb.vision import imread as _imread
import numpy as np

from intel_adb import timer

DB_DIR = Path(__file__).parent / "finders_items"
SCENE = (45, 100, 455, 735)  # x0, y0, x1, y1 of the scene (below the 2X-7X combo bar)
NAME_SLOTS = [(97, 864), (270, 864), (443, 864), (97, 920), (270, 920), (443, 920)]
NAME_BOX = (150, 40)  # w, h of a name button
TITLE_BOX = (60, 12, 240, 34)  # scene name at the top ("Dock")
CROP = 30  # half-size of a saved item picture
MATCH = 0.82


def _ocr(img, box, psm=7):
    if not timer.available():
        return ""
    x, y, w, h = box
    crop = img[max(0, y):y + h, max(0, x):x + w]
    g = cv2.cvtColor(cv2.resize(crop, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC), cv2.COLOR_BGR2GRAY)
    _, b = cv2.threshold(g, 200, 255, cv2.THRESH_BINARY_INV)  # white text on blue buttons
    try:
        return " ".join(timer.pytesseract.image_to_string(b, config=f"--psm {psm}").split())
    except Exception:
        return ""


def names_one(crop):
    """Name on one button crop, or ''."""
    h, w = crop.shape[:2]
    t = re.sub(r"[^A-Za-z ]", "", _ocr(crop, (0, 0, w, h))).strip()
    if len(t) == 1:
        return t.upper()  # one-letter items exist ("Z")
    return t if len(t) >= 3 else ""


SOLO_SLOTS = [(97, 877), (270, 877), (443, 877)]  # solo stages: one row of 3


def is_solo(img):
    """Solo stage (one row of names, found ones fade) vs Fusion (two rows that refill):
    between the rows Fusion has its second-row button, solo the light background."""
    return int(img[905, 270][0]) > 225


def faded(img, x, y):
    """A solo name button that has been found: struck through and lighter."""
    w, h = NAME_BOX
    import numpy as np
    pill = img[y - 15:y + 15, x - 65:x + 65].reshape(-1, 3)
    return float(np.median(pill[:, 2])) > 85  # red channel: active ~75, faded ~99


def slots(img):
    return SOLO_SLOTS if is_solo(img) else NAME_SLOTS


def names(img):
    """The (up to 6) item names under the scene, in slot order ('' for an empty slot)."""
    w, h = NAME_BOX
    solo = is_solo(img)
    return ["" if solo and faded(img, x, y) else names_one(img[y - h // 2:y + h // 2, x - w // 2:x + w // 2])
            for x, y in (SOLO_SLOTS if solo else NAME_SLOTS)]


def scene_name(img):
    """Scene title at the top ("Dock", "Inn"). White text: a strict cut, with a margin
    around it, reads short titles too."""
    if not timer.available():
        return "unknown"
    x, y, w, h = TITLE_BOX
    g = cv2.cvtColor(cv2.resize(img[y:y + h, x:x + w], None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC),
                     cv2.COLOR_BGR2GRAY)
    for th in (230, 200):
        _, b = cv2.threshold(g, th, 255, cv2.THRESH_BINARY_INV)
        b = cv2.copyMakeBorder(b, 20, 20, 20, 20, cv2.BORDER_CONSTANT, value=255)
        try:
            t = timer.pytesseract.image_to_string(b, config="--psm 7")
        except Exception:
            t = ""
        m = re.search(r"Stage\s*(\d+)\s*-", t)
        if m:  # solo stages: one chapter = one map, so all "Stage 2-x" share "Chapter 2"
            return f"Chapter {m.group(1)}"
        t = re.sub(r"[^A-Za-z ]", "", t).strip()
        if len(t) >= 3:
            return t
    return "unknown"


MAPS_DIR = Path(__file__).parent / "finders_maps"
FP_SAME = 0.85  # fingerprint similarity: same map in other rounds ~1.00, other maps <= 0.5


def fingerprint(img):
    """Tiny blurred greyscale of the scene background (items are too small to matter)."""
    g = cv2.cvtColor(img[115:730, 55:485], cv2.COLOR_BGR2GRAY)
    g = cv2.GaussianBlur(cv2.resize(g, (22, 32), interpolation=cv2.INTER_AREA), (3, 3), 0)
    g = g.astype(np.float32).ravel()
    return (g - g.mean()) / (g.std() + 1e-6)


def _maps_index():
    p = MAPS_DIR / "maps.json"
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}


_map_lock = __import__("threading").Lock()


def scene_id(img):
    """Which map this is. Chapter numbers differ per instance (user, 2026-10-12), so maps are
    recognised by their picture: a known map's name ("Dock", "Inn", "Map 3"), or a new map is
    registered (with a thumbnail). Fusion titles name a map the first time it is seen."""
    fp = fingerprint(img)
    with _map_lock:
        idx = _maps_index()
        best, score = None, -1.0
        for name, v in idx.items():
            s = float(fp @ np.array(v["fp"], np.float32)) / len(fp)
            if s > score:
                best, score = name, s
        if best is not None and score >= FP_SAME:
            return best
        title = scene_name(img)
        name = title if title != "unknown" and not title.startswith("Chapter") else \
            f"Map {sum(1 for n in idx if n.startswith('Map ')) + 1}"
        idx[name] = {"fp": [round(float(v), 3) for v in fp]}
        MAPS_DIR.mkdir(exist_ok=True)
        (MAPS_DIR / "maps.json").write_text(json.dumps(idx), encoding="utf-8")
        cv2.imwrite(str(MAPS_DIR / f"{_key(name)}_thumb.jpg"), img[55:795, 45:495])
        return name


def _key(name):
    return re.sub(r"[^a-z0-9]", "", name.lower())


# ---- learning ----------------------------------------------------------------
def vanished(before, after, unstable=None):
    """Centre of the biggest compact patch of the scene that changed between two frames
    (an item that was found), ignoring always-moving areas (`unstable` mask). Or None."""
    x0, y0, x1, y1 = SCENE
    a = cv2.GaussianBlur(before[y0:y1, x0:x1], (5, 5), 0)
    b = cv2.GaussianBlur(after[y0:y1, x0:x1], (5, 5), 0)
    m = (cv2.absdiff(a, b).max(axis=2) > 45).astype(np.uint8)
    if unstable is not None:
        m[unstable[y0:y1, x0:x1] > 0] = 0
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    n, _, st, cen = cv2.connectedComponentsWithStats(m)
    best = None
    for k in range(1, n):
        w, h, area = st[k][2], st[k][3], st[k][4]
        if 120 <= area <= 5000 and w < 120 and h < 120 and area > 0.2 * w * h:
            if best is None or area > best[2]:
                best = (x0 + int(cen[k][0]), y0 + int(cen[k][1]), area)
    return best[:2] if best else None


def unstable_mask(frames):
    """Pixels that keep changing (water, birds, the multiplier bar) over a round."""
    acc = None
    for a, b in zip(frames, frames[1:]):
        d = (cv2.absdiff(cv2.GaussianBlur(a, (5, 5), 0), cv2.GaussianBlur(b, (5, 5), 0)).max(axis=2) > 45)
        acc = d.astype(np.int32) if acc is None else acc + d
    if acc is None:
        return None
    m = (acc > max(2, len(frames) * 0.15)).astype(np.uint8)
    return cv2.dilate(m, np.ones((9, 9), np.uint8))


def learn(frames, log=print, read=None, scene=None, save_crops=True):
    """Watch a round (list of BGR frames ~0.25 s apart). Whenever exactly one name leaves
    the list, save the patch that vanished from the scene under that name. Returns
    {name: (x, y)} learnt."""
    if len(frames) < 3:
        return {}
    unstable = unstable_mask(frames)
    scene = scene or scene_name(frames[len(frames) // 2])
    learnt = {}
    read = read or [names(f) for f in frames]
    for i in range(2, len(frames) - 1):
        # gone: on the list in the two frames before, missing in this one and the next
        # (one misread frame isn't enough; garbage reads never appear twice in a row)
        gone = [n for n in read[i - 1] if n and n in read[i - 2]
                and n not in read[i] and n not in read[i + 1]]
        if not any(read[i]):  # the stage's last item: the whole scene changes - unreliable
            continue
        if len(gone) == 1:
            before = frames[max(0, i - 3)]
            pos = vanished(before, frames[i], unstable)
            if pos:
                if save_crops:
                    save(scene, gone[0], before, pos)
                learnt[gone[0]] = pos
                log(f"finders: learnt {gone[0]} at {pos} ({scene})")
    return learnt


def save(scene, name, img, pos):
    d = DB_DIR / _key(scene)
    d.mkdir(parents=True, exist_ok=True)
    x, y = pos
    cv2.imwrite(str(d / f"{_key(name)}.png"), img[y - CROP:y + CROP, x - CROP:x + CROP])
    idx = d / "index.json"
    data = json.loads(idx.read_text(encoding="utf-8")) if idx.exists() else {}
    data[_key(name)] = {"name": name, "x": x, "y": y}
    idx.write_text(json.dumps(data, indent=1), encoding="utf-8")


def known(scene):
    idx = DB_DIR / _key(scene) / "index.json"
    return json.loads(idx.read_text(encoding="utf-8")) if idx.exists() else {}


# ---- playing -----------------------------------------------------------------
def locate(img, scene, name):
    """Where the known item `name` is in this frame of `scene`, or None (unknown item, or
    its picture isn't there - e.g. already found)."""
    info = known(scene).get(_key(name))
    if not info:
        return None
    tpl = _imread(str(DB_DIR / _key(scene) / f"{_key(name)}.png"))
    if tpl is None:
        return None
    x, y = info["x"], info["y"]
    r = 60  # items sit in the same place: search only around the learnt spot
    x0, y0 = max(0, x - CROP - r), max(0, y - CROP - r)
    win = img[y0:y + CROP + r, x0:x + CROP + r]
    if win.shape[0] < tpl.shape[0] or win.shape[1] < tpl.shape[1]:
        return None
    res = cv2.matchTemplate(win, tpl, cv2.TM_CCOEFF_NORMED)
    _, score, _, loc = cv2.minMaxLoc(res)
    if score < MATCH:
        return None
    return x0 + loc[0] + tpl.shape[1] // 2, y0 + loc[1] + tpl.shape[0] // 2
