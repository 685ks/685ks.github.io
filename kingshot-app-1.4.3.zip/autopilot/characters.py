"""Switch the logged-in character: avatar -> Governor Profile -> Settings -> Characters ->
row -> Login Confirm, then wait for the game to reload.

Rows on the Characters list are found by their "Town Center Level" label; the name is read
from the line above it and the kingdom from the nearest "Kingdom #N" header above."""
import difflib
import re
import time
from dataclasses import dataclass
from pathlib import Path

import cv2

from intel_adb import timer

TEMPLATE_DIR = Path(__file__).parent / "templates"

AVATAR = (35, 32)
SETTINGS_BUTTON = (470, 915)  # on Governor Profile
CHARACTERS_BUTTON = (166, 252)  # on Settings
LOGIN_CONFIRM = (384, 602)
LIST_SWIPE = ((270, 700), (270, 380))  # drag up to scroll the list down
NAME_BOX = (-4, -31, 290, 28)  # name line relative to the label's top-left
POWER_BOX = (20, 24, 150, 26)  # power line under "Town Center Level", relative to its top-left
POWER_MATCH = 0.10  # a renamed character: same kingdom, power within 10% of the last seen
HEADER_BOX = (34, -13, 110, 26)  # the "#685" part, relative to the "Kingdom" word centre
ROW_TAP_X = 250  # tap the name area, never the right edge (delete button lives there)


@dataclass
class Row:
    name: str  # without alliance tag
    tag: str
    kingdom: int | None
    y: int  # tap here
    power: int = 0


def _ocr(crop, psm=7, whitelist=None):
    if not timer.available() or crop.size == 0:
        return ""
    g = cv2.cvtColor(cv2.resize(crop, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC), cv2.COLOR_BGR2GRAY)
    cfg = f"--psm {psm}" + (f" -c tessedit_char_whitelist={whitelist}" if whitelist else "")
    try:
        return timer.pytesseract.image_to_string(g, config=cfg).strip()
    except Exception:
        return ""


def split_tag(text):
    """'[CAT]Grandfel' -> ('CAT', 'Grandfel'); OCR often reads ']' as 'l' or '|'."""
    text = text.strip().strip("|").strip()
    m = re.match(r"^\[?([A-Za-z0-9]{2,4})[\]|lI1)](.+)$", text)
    if m and text.startswith("["):
        return m.group(1), m.group(2).strip()
    return "", text


MATCH = 0.85  # name_score needed to count as the same character


def _squash(s):
    # long repeated letters (Reeeeee) are hard to count: squash runs of 3+ to 2
    return re.sub(r"(.)\1{2,}", r"\1\1", s.lower().replace(" ", ""))


def name_score(read, wanted):
    """0..1 similarity of an OCR'd row name to a wanted name. Badges after the name add
    junk words, so the best leading run of words is compared."""
    words = read.split()
    b = _squash(wanted)
    if not words or not b:
        return 0.0
    best = 0.0
    for k in range(1, len(words) + 1):
        a = _squash(" ".join(words[:k]))
        best = max(best, 1.0 if a == b else difflib.SequenceMatcher(None, a, b).ratio())
    return best


def same_name(a, b):
    return name_score(a, b) >= MATCH


def _crop(img, x, y, box):
    dx, dy, w, h = box
    return img[max(0, y + dy):y + dy + h, max(0, x + dx):x + dx + w]


def read_rows(img, vision, carry=None):
    """Character rows visible on the Characters list, top to bottom. Rows above the first
    visible header belong to `carry`, the kingdom of the last row on the previous screen."""
    headers = []
    for (x, y) in vision.find_all(img, "kingdom_word", 0.7, gray=True):
        m = re.search(r"#\s*(\d+)", _ocr(_crop(img, x, y, HEADER_BOX)))
        if m:
            headers.append((y, int(m.group(1))))
    rows = []
    t = vision.template("tc_label")
    th, tw = t.shape[:2]
    for (cx, cy) in vision.find_all(img, "tc_label", 0.75, gray=True):
        x, y = cx - tw // 2, cy - th // 2
        tag, name = split_tag(_ocr(_crop(img, x, y, NAME_BOX)))
        digits = re.sub(r"\D", "", _ocr(_crop(img, x, y, POWER_BOX), whitelist="0123456789,"))
        above = [k for hy, k in headers if hy < y]
        rows.append(Row(name, tag, above[-1] if above else carry, y - 20, int(digits) if digits else 0))
    return rows


class Switcher:
    def __init__(self, device, vision, sleep=time.sleep, log=print, read=read_rows):
        self.d, self.v, self.sleep, self.log, self.read = device, vision, sleep, log, read

    def wait_for(self, name, timeout=8.0):
        end = time.monotonic() + timeout
        while time.monotonic() < end:
            img = self.d.screencap()
            if self.v.has(img, name):
                return img
            self.sleep(0.5)
        return None

    def open_list(self):
        self.d.tap(*AVATAR)
        if self.wait_for("profile_title") is None:
            return None
        self.d.tap(*SETTINGS_BUTTON)
        if self.wait_for("settings_title") is None:
            return None
        self.d.tap(*CHARACTERS_BUTTON)
        return self.wait_for("characters_title")

    def find_row(self, img, name, kingdom, scrolls=4, tag="", power=0):
        """Best-matching row for the character (name, then tag as tie-break), scrolling down
        the list until one is found. Only rows of the right kingdom count. A character that
        was renamed is recognised by its power (closest within 10% of the last seen) once
        the whole list has been read without a name match."""
        carry = None
        seen = []
        for i in range(scrolls + 1):
            rows = self.read(img, self.v, carry)
            seen += [(r, img) for r in rows]
            scored = [(name_score(r.name, name) + (0.05 if tag and r.tag == tag else 0), r)
                      for r in rows if kingdom is None or r.kingdom == kingdom]
            scored = [(s, r) for s, r in scored if s >= MATCH]
            if scored:
                return max(scored, key=lambda sr: sr[0])[1], img
            if rows:
                carry = rows[-1].kingdom
            if i < scrolls:
                (x1, y1), (x2, y2) = LIST_SWIPE
                self.d.swipe(x1, y1, x2, y2)
                self.sleep(0.8)
                img = self.d.screencap()
        if power:
            near = [r for r, _ in seen if r.power and (kingdom is None or r.kingdom == kingdom)
                    and abs(r.power - power) <= power * POWER_MATCH]
            if near:
                best = min(near, key=lambda r: abs(r.power - power))
                self.log(f"switch: {name} not on the list - {best.name} has the same power "
                         f"({best.power:,}), taking it as renamed")
                return self._row_on_screen(best, kingdom, scrolls), self.d.screencap()
        return None, img

    def _row_on_screen(self, wanted, kingdom, scrolls):
        """Scroll back to the top and find `wanted` (by name) so its y is on screen."""
        (x1, y1), (x2, y2) = LIST_SWIPE
        for _ in range(scrolls):
            self.d.swipe(x2, y2, x1, y1)
            self.sleep(0.5)
        carry = None
        for i in range(scrolls + 1):
            img = self.d.screencap()
            rows = self.read(img, self.v, carry)
            for r in rows:
                if r.name == wanted.name and r.kingdom == kingdom:
                    return r
            if rows:
                carry = rows[-1].kingdom
            self.d.swipe(x1, y1, x2, y2)
            self.sleep(0.8)
        return None

    def list_all(self, scrolls=8):
        """Every character on the Characters list as Rows (name, tag, kingdom), without
        logging in to any of them. Leaves the list with Back."""
        img = self.open_list()
        if img is None:
            self.log("list: couldn't open the Characters list")
            return []
        found, carry, same = [], None, 0
        for i in range(scrolls + 1):
            rows = self.read(img, self.v, carry)
            new = [r for r in rows if r.name and not any(
                same_name(r.name, f.name) and r.kingdom == f.kingdom for f in found)]
            found += new
            same = same + 1 if not new else 0
            if rows:
                carry = rows[-1].kingdom
            if same >= 2 or i == scrolls:  # two screens with nothing new: end of the list
                break
            (x1, y1), (x2, y2) = LIST_SWIPE
            self.d.swipe(x1, y1, x2, y2)
            self.sleep(0.8)
            img = self.d.screencap()
        for _ in range(3):  # Characters -> Settings -> Profile -> home
            self.d.back()
            self.sleep(0.8)
        return found

    def switch(self, name, kingdom=None, current=None, tag="", power=0):
        """Log in as `name` (in `kingdom`). Returns True when that character is now active.
        self.matched is the list row that was used (its name/power may be newer)."""
        self.matched = None
        if current is not None and same_name(current, name):
            return True
        img = self.open_list()
        if img is None:
            self.log("switch: couldn't open the Characters list")
            return False
        row, img = self.find_row(img, name, kingdom, tag=tag, power=power)
        if not row:
            self.log(f"switch: {name} not found on the Characters list")
            return False
        self.matched = row
        self.d.tap(ROW_TAP_X, row.y)
        login = self.wait_for("login_title", timeout=4)
        if login is None:  # tapping the active character opens nothing: already logged in
            self.log(f"switch: {name} is already active")
            self.d.back()
            return True
        self.d.tap(*LOGIN_CONFIRM)
        self.log(f"switch: logging in as {name} (#{kingdom})")
        self.sleep(3)
        return self.settle()

    def settle(self, timeout=120, clock=time.monotonic):
        """After a login: wait out the loading screen, then press Back until the city or the
        world map shows. Back closes offer popups; at home it opens "Quit game?", which is
        cancelled (never confirmed)."""
        end = clock() + timeout
        while clock() < end:
            img = self.d.screencap()
            if self.v.has(img, "quit_game"):
                pos = self.v.find(img, "cancel_button")
                if pos:
                    self.d.tap(*pos)
                else:
                    self.d.back()  # Back also dismisses the dialog
                self.sleep(1)
                continue
            if self.v.has(img, "world_button") or self.v.has(img, "world_map_marker"):
                return True
            if self.v.has(img, "loading_logo"):
                self.sleep(2)
                continue
            self.d.back()
            self.sleep(1.5)
        self.log("switch: game didn't settle after login")
        return False
