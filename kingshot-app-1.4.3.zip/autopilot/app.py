"""Kingshot Autopilot - settings, schedule and live status for the daily-jobs bot.

    pythonw -m autopilot.app      (the Desktop shortcut runs this)
"""
import os
import threading
from pathlib import Path
import time
from datetime import datetime

import flet as ft

from autopilot import config, engine, scheduler, state

SEED = ft.Colors.AMBER
OPTIONS = {
    ("intel", "formation"): ["Equalize"] + [f"Preset {i}" for i in range(1, 9)],
    ("intel", "bounties"): ["Never", "Only if likely to prevail", "Always"],
    ("hunt", "formation"): ["Equalize"] + [f"Preset {i}" for i in range(1, 9)],
    ("hunt", "level"): ["Highest"] + [str(i) for i in range(1, 31)],
    ("train", "mode"): ["Keep busy", "Finish by", "Off"],
    ("research", "tree"): ["Growth", "Economy", "Battle", "Any"],
    ("gather", "resource"): ["Any", "Bread", "Wood", "Stone", "Iron"],
    ("gather", "level"): ["Highest", "1", "2", "3", "4", "5", "6", "7", "8"],
    ("terrors", "level"): ["Auto", "1", "2", "3", "4", "5", "6", "7", "8"],
    ("terrors", "preset"): ["Equalize"] + [str(i) for i in range(1, 9)],
}
RANGES = {  # numeric params: (min, max, divisions)
    ("gather", "marches"): (1, 6, 5),
    ("hunt", "max_attacks"): (1, 50, 49),
    ("intel", "march_slots"): (0, 7, 7),  # 0 = learn it from "march queue full"
    ("gather", "recall_before"): (0, 30, 30),
    ("gather", "bear_minutes"): (10, 120, 22),
    ("gather", "battle_minutes"): (10, 180, 34),
    ("terrors", "per_day"): (0, 250, 50),  # steps of 5
    ("terrors", "at_once"): (1, 6, 5),
    ("blizzard", "matches_per_slot"): (1, 4, 3),
    ("alliance", "donations"): (0, 25, 25),
}
PARAM_LABELS = {
    "alliance_gifts": "Alliance chests & gifts", "daily": "VIP daily bundle", "mail": "Mail (Read & Claim All)", "meat": "Free Gourmet Feast meat", "at_once": "Rallies at once", "level": "Hunt up to level",
    "finish_by": "Finish by (UTC)", "hold_until": "Don't collect before (UTC)",
    "per_day": "Per day",
    "attack_grey": "Attack grey (finished) pins", "bounties": "Rebel bounties", "march_slots": "March slots (0 = learn)",
    "use_meat": "Use meat when out of stamina (never buys)",
    "recommended_first": "Recommended tech first", "fallback_any": "Any tree when blocked",
    "all_barracks": "All barracks", "spread": "Spread across the day",
    "quests": "Daily & growth quests", "signin": "Sign-in & Earn (free side)",
    "free_chests": "Free chests in Deals & Top-up", "pass_rewards": "Free pass rewards",
    "bank": "Bank: collect & re-deposit (not ready yet)",
    "panel": "Online rewards & Fountain of Life", "recruit": "Free hero recruits", "conquest": "Conquest idle income (hero EXP)", "story": "Story stages when stronger", "trial": "Mystic Trial (until first loss)", "help": "Help All",
    "roulette": "Hero Roulette (free chips, spin them)",
    "start_utc": "Start at (UTC, before the 00:00 reset)", "buy_extra": "Buy the 5 extra challenges (diamonds)",
    "max_gems": "Max diamonds per day for extra challenges",
    "teleport": "Teleport into an ice pool first", "matches_per_slot": "Matches per time slot",
    "avoid_events": "Avoid alliance events (Task List)", "recall_before": "Recall this many min before",
    "bear_minutes": "Bear Hunt lasts (min)", "battle_minutes": "Battles last (min)", "rebel": "Rebel Assault (Quick Challenge)", "heal": "Heal wounded (resources)",
    "ask_help": "Ask the alliance for help", "promote_when_off": "Promote where training is off",
}
JOB_ICONS = {
    "claim": ft.Icons.REDEEM, "rewards": ft.Icons.CARD_GIFTCARD, "train": ft.Icons.SHIELD, "research": ft.Icons.SCIENCE,
    "gather": ft.Icons.AGRICULTURE, "intel": ft.Icons.EXPLORE, "terrors": ft.Icons.LOCAL_FIRE_DEPARTMENT,
    "alliance": ft.Icons.GROUPS, "city": ft.Icons.LOCATION_CITY, "build": ft.Icons.CONSTRUCTION, "arena": ft.Icons.SPORTS_MMA, "blizzard": ft.Icons.AC_UNIT,
}


def label(name):
    return PARAM_LABELS.get(name, name.replace("_", " ").capitalize())


def main(page: ft.Page):
    settings = config.load()
    st = state.State()
    eng = engine.Engine(settings, st)

    page.title = "Kingshot Autopilot"
    page.theme = ft.Theme(color_scheme_seed=SEED)
    page.dark_theme = ft.Theme(color_scheme_seed=SEED)
    page.theme_mode = ft.ThemeMode.DARK if settings.theme == "Dark" else ft.ThemeMode.LIGHT
    page.window.width, page.window.height = 1100, 760
    page.window.min_width, page.window.min_height = 860, 560
    page.padding = 0
    page.window.icon = str(Path(__file__).parent / "icon.ico")

    # Flet's redraw is not thread-safe: the engine log, the dashboard ticker and clicks all
    # redraw from different threads. Every redraw (page.update / control.update) and every
    # background change to the controls goes through this one lock.
    ui_lock = threading.RLock()
    _patch = page.session.patch_control

    def _locked_patch(*a, **k):
        with ui_lock:
            return _patch(*a, **k)
    page.session.patch_control = _locked_patch

    def save():
        config.save(settings)

    # ---------------------------------------------------------------- log
    log_view = ft.ListView(expand=True, spacing=2, auto_scroll=True)

    def add_log(text):
        stamp = datetime.now().strftime("%H:%M:%S")
        with ui_lock:
            log_view.controls.append(ft.Text(f"{stamp}  {text}", size=12, font_family="Consolas", selectable=True))
            if len(log_view.controls) > 2000:
                del log_view.controls[:500]
            try:
                page.update()
            except Exception:
                pass

    eng.on_log = add_log

    # ---------------------------------------------------------------- dashboard
    dash_grid = ft.ResponsiveRow(spacing=16, run_spacing=16)
    run_btn = ft.FilledButton("Start autopilot", icon=ft.Icons.PLAY_ARROW)
    status_chip = ft.Chip(label=ft.Text("Stopped"), leading=ft.Icon(ft.Icons.PAUSE_CIRCLE))

    def fmt_next(ts):
        if not ts:
            return "due now"
        d = ts - time.time()
        if d <= 0:
            return "due now"
        h, m = int(d // 3600), int(d % 3600 // 60)
        return f"in {h}h {m:02d}m" if h else f"in {m}m"

    def character_card(ch):
        jobs_on = [j for j in config.JOBS if ch.jobs[j].enabled]
        chips = []
        for j in jobs_on:
            n = st.count(ch.key, j)
            text = config.JOB_LABELS[j]
            if j == "terrors":
                text += f"  {n}/{ch.jobs[j].params['per_day']}"
            elif n:
                text += f"  {n}"
            chips.append(ft.Container(
                padding=ft.Padding(10, 5, 12, 5), border_radius=20,
                bgcolor=ft.Colors.SECONDARY_CONTAINER,
                content=ft.Row([ft.Icon(JOB_ICONS[j], size=15, color=ft.Colors.ON_SECONDARY_CONTAINER),
                                ft.Text(text, size=12, color=ft.Colors.ON_SECONDARY_CONTAINER)],
                               spacing=5, tight=True)))
        busy = ch.key in eng.running_keys
        return ft.Container(
            col={"sm": 12, "md": 6, "xl": 4},
            content=ft.Card(
                elevation=3,
                content=ft.Container(
                    padding=16,
                    content=ft.Column([
                        ft.Row([
                            ft.Icon(ft.Icons.PERSON, color=ft.Colors.PRIMARY),
                            ft.Column([ft.Text(ch.label.rsplit(" #", 1)[0], size=18, weight=ft.FontWeight.BOLD),
                                       ft.Text(ch.instance + (f"  ·  Kingdom #{ch.kingdom}" if ch.kingdom is not None else ""),
                                               size=12, color=ft.Colors.ON_SURFACE_VARIANT)],
                                      spacing=0, expand=True),
                            ft.ProgressRing(width=18, height=18) if busy else
                            ft.Icon(ft.Icons.CHECK_CIRCLE if ch.enabled else ft.Icons.DO_NOT_DISTURB_ON,
                                    color=ft.Colors.GREEN if ch.enabled else ft.Colors.OUTLINE),
                        ]),
                        ft.Row(chips, wrap=True, spacing=6) if chips else
                        ft.Text("No jobs switched on", italic=True, color=ft.Colors.ON_SURFACE_VARIANT),
                        ft.Row([
                            ft.Icon(ft.Icons.SCHEDULE, size=16, color=ft.Colors.ON_SURFACE_VARIANT),
                            ft.Text("Running now" if busy else f"Next run {fmt_next(st.next_run(ch.key))}",
                                    size=12, expand=True),
                            ft.TextButton("Run now", icon=ft.Icons.BOLT,
                                          on_click=lambda e, c=ch: eng.run_now(c.key),
                                          disabled=not ch.enabled),
                        ]),
                        ft.Text(st.last(ch.key) or "", size=11, color=ft.Colors.ON_SURFACE_VARIANT),
                    ], spacing=10),
                ),
            ),
        )

    def refresh_dashboard():
        dash_grid.controls = [character_card(c) for c in settings.characters] or [
            ft.Container(col=12, padding=40, content=ft.Column([
                ft.Icon(ft.Icons.GROUP_ADD, size=48, color=ft.Colors.PRIMARY),
                ft.Text("No characters yet", size=18, weight=ft.FontWeight.BOLD),
                ft.Text("Add your characters on the Characters page, then switch on the jobs you want."),
            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER))]
        running = eng.running
        run_btn.text = "Stop autopilot" if running else "Start autopilot"
        run_btn.icon = ft.Icons.STOP if running else ft.Icons.PLAY_ARROW
        quiet = scheduler.quiet_now(settings)
        status_chip.label = ft.Text("Quiet hours" if running and quiet else
                                    (f"Running {eng.current}" if eng.current else
                                     ("Waiting for next run" if running else "Stopped")))
        status_chip.leading = ft.Icon(ft.Icons.NIGHTLIGHT if running and quiet else
                                      ft.Icons.PLAY_CIRCLE if running else ft.Icons.PAUSE_CIRCLE)

    def toggle_run(e):
        if eng.running:
            eng.stop()
        else:
            eng.start()
        refresh_dashboard()
        page.update()

    run_btn.on_click = toggle_run

    dashboard = ft.Column([
        ft.Row([ft.Text("Dashboard", size=26, weight=ft.FontWeight.BOLD, expand=True), status_chip, run_btn]),
        ft.Text("Each character runs on its own random schedule; one character at a time.",
                color=ft.Colors.ON_SURFACE_VARIANT),
        ft.Container(content=dash_grid, expand=True),
    ], spacing=12, expand=True, scroll=ft.ScrollMode.AUTO)

    # ---------------------------------------------------------------- characters
    char_list = ft.ListView(spacing=4, expand=True)
    editor = ft.Column(expand=True, scroll=ft.ScrollMode.AUTO, spacing=10)
    selected = {"key": settings.characters[0].key if settings.characters else None}

    def find(key):
        return next((c for c in settings.characters if c.key == key), None)

    def param_control(chars, job, name, value):
        chars = chars if isinstance(chars, list) else [chars]

        def set_(v):
            for c in chars:  # a folder's change goes to every character in it
                c.jobs[job].params[name] = v
            save()

        if isinstance(value, bool):
            return ft.Switch(label=label(name), value=value, on_change=lambda e: set_(e.control.value))
        if (job, name) in OPTIONS:
            return ft.Dropdown(label=label(name), value=str(value), width=220,
                               options=[ft.DropdownOption(key=o, text=o) for o in OPTIONS[(job, name)]],
                               on_select=lambda e: set_(e.control.value))
        if isinstance(value, int) and (job, name) in RANGES:
            lo, hi, div = RANGES[(job, name)]
            val_text = ft.Text(str(value), width=32, weight=ft.FontWeight.BOLD)

            def changed(e):
                v = int(e.control.value)
                val_text.value = str(v)
                set_(v)
                val_text.update()
            return ft.Row([ft.Text(label(name), width=150),
                           ft.Slider(min=lo, max=hi, divisions=div, value=value, expand=True,
                                     label="{value}", on_change=changed), val_text])
        return ft.TextField(label=label(name), value=str(value), width=320,
                            hint_text="e.g. 2026-10-08 00:05" if name in ("finish_by", "hold_until") else None,
                            on_change=lambda e: set_(e.control.value))

    def job_tile(chars, job):
        chars = chars if isinstance(chars, list) else [chars]
        ch = chars[0]
        j = ch.jobs[job]
        ready = job in engine.AVAILABLE_JOBS
        mixed = len({c.jobs[job].enabled for c in chars}) > 1
        sw = ft.Switch(value=j.enabled and not mixed)

        def toggled(e):
            for c in chars:
                c.jobs[job].enabled = e.control.value
            save()
        sw.on_change = toggled
        return ft.Card(content=ft.ExpansionTile(
            leading=ft.Icon(JOB_ICONS[job], color=ft.Colors.PRIMARY),
            title=ft.Text(config.JOB_LABELS[job], weight=ft.FontWeight.W_600),
            subtitle=ft.Text(("" if ready else "Not built yet - needs the screens recorded")
                             or ("Mixed in this folder - switching sets it for all" if mixed else ""),
                             size=11, color=ft.Colors.TERTIARY),
            trailing=sw,
            controls=[ft.Container(padding=ft.Padding(16, 0, 16, 16), content=ft.Column(
                [param_control(chars, job, k, v) for k, v in j.params.items()], spacing=8,
                horizontal_alignment=ft.CrossAxisAlignment.START))],
        ))

    def folder_members(name):
        return [c for c in settings.characters if c.folder == name]

    def show_folder_editor(name):
        members = folder_members(name)
        name_tf2 = ft.TextField(label="Folder name", value=name, width=220, dense=True)

        def rename(e):
            new = (name_tf2.value or "").strip()
            if not new or new == name or new in settings.folders:
                return
            settings.folders[settings.folders.index(name)] = new
            for c in members:
                c.folder = new
            selected["folder"] = new
            save()
            redraw_characters()

        def remove(e):  # characters stay, just leave the folder
            for c in members:
                c.folder = ""
            settings.folders.remove(name)
            selected["folder"] = None
            save()
            redraw_characters()

        def all_enabled(e):
            for c in members:
                c.enabled = e.control.value
            save()

        head = ft.Row([
            ft.Icon(ft.Icons.FOLDER, size=32, color=ft.Colors.PRIMARY),
            ft.Column([ft.Text(name, size=24, weight=ft.FontWeight.BOLD),
                       ft.Text(f"{len(members)} character(s) - changes here apply to all of them",
                               color=ft.Colors.ON_SURFACE_VARIANT)], spacing=0, expand=True),
            ft.Switch(label="All enabled", value=bool(members) and all(c.enabled for c in members),
                      on_change=all_enabled),
            ft.IconButton(ft.Icons.FOLDER_OFF_OUTLINED, tooltip="Delete folder (keeps the characters)",
                          on_click=remove),
        ])
        rename_row = ft.Row([name_tf2, ft.TextButton("Rename", icon=ft.Icons.EDIT, on_click=rename)])
        if not members:
            editor.controls = [head, rename_row, ft.Text(
                "Empty folder. Open a character and pick this folder in its Folder box.",
                color=ft.Colors.ON_SURFACE_VARIANT)]
            return
        editor.controls = [
            head, rename_row,
            ft.Row([ft.Icon(ft.Icons.ACCESS_TIME, color=ft.Colors.PRIMARY),
                    ft.Text("Active hours (local)", weight=ft.FontWeight.W_600),
                    hours_field(members, "active_start", "From"), hours_field(members, "active_end", "Until"),
                    ft.Text("same = any time", size=11, color=ft.Colors.ON_SURFACE_VARIANT)]),
            *[job_tile(members, j) for j in config.JOBS],
        ]

    def folder_dropdown(ch):
        def changed(e):
            ch.folder = "" if e.control.value == "(none)" else e.control.value
            save()
            redraw_characters()
        return ft.Dropdown(label="Folder", value=ch.folder or "(none)", width=200, dense=True,
                           options=[ft.DropdownOption(key=o, text=o) for o in ["(none)", *settings.folders]],
                           on_select=changed)

    def show_editor():
        if selected.get("folder"):
            show_folder_editor(selected["folder"])
            return
        ch = find(selected["key"])
        if not ch:
            editor.controls = [ft.Text("Add or pick a character on the left.", color=ft.Colors.ON_SURFACE_VARIANT)]
            return

        def toggle_char(e):
            ch.enabled = e.control.value
            save()

        def delete(e):
            settings.characters.remove(ch)
            selected["key"] = settings.characters[0].key if settings.characters else None
            save()
            redraw_characters()

        editor.controls = [
            ft.Row([
                ft.Column([ft.Text(ch.label.rsplit(" #", 1)[0], size=24, weight=ft.FontWeight.BOLD),
                           ft.Text(f"on {ch.instance}" + (f"  ·  Kingdom #{ch.kingdom}" if ch.kingdom is not None else ""),
                                   color=ft.Colors.ON_SURFACE_VARIANT)], spacing=0, expand=True),
                ft.Switch(label="Enabled", value=ch.enabled, on_change=toggle_char),
                ft.IconButton(ft.Icons.DELETE_OUTLINE, tooltip="Remove character", on_click=delete),
            ]),
            folder_dropdown(ch),
            ft.Row([ft.Icon(ft.Icons.ACCESS_TIME, color=ft.Colors.PRIMARY),
                    ft.Text("Active hours (local)", weight=ft.FontWeight.W_600),
                    hours_field(ch, "active_start", "From"), hours_field(ch, "active_end", "Until"),
                    ft.Text("same = any time", size=11, color=ft.Colors.ON_SURFACE_VARIANT)]),
            *[job_tile(ch, j) for j in config.JOBS],
        ]

    def hours_field(chars, attr, title):
        chars = chars if isinstance(chars, list) else [chars]
        ch = chars[0]

        def changed(e):
            v = e.control.value.strip()
            try:
                scheduler._minutes(v)
                for c in chars:
                    setattr(c, attr, v)
                e.control.error = None
                save()
            except Exception:
                e.control.error = "HH:MM"
            e.control.update()
        return ft.TextField(label=title, value=getattr(ch, attr), width=110, dense=True, on_change=changed)

    def pick_char(k):
        selected["key"], selected["folder"] = k, None
        redraw_characters()

    def pick_folder(name):
        selected["folder"] = name
        redraw_characters()

    def redraw_characters():
        for c in settings.characters:  # a folder deleted elsewhere: drop the stale name
            if c.folder and c.folder not in settings.folders:
                settings.folders.append(c.folder)
        items = []
        for name in [*settings.folders, ""]:
            chars = [c for c in settings.characters if c.folder == name]
            if name:
                items.append(ft.ListTile(
                    leading=ft.Icon(ft.Icons.FOLDER, color=ft.Colors.PRIMARY), dense=True,
                    title=ft.Text(name, weight=ft.FontWeight.BOLD),
                    subtitle=ft.Text(f"{len(chars)} character(s)", size=11),
                    selected=selected.get("folder") == name,
                    on_click=lambda e, n=name: pick_folder(n)))
            elif chars and settings.folders:
                items.append(ft.Container(padding=ft.Padding(12, 10, 0, 2), content=ft.Text(
                    "NOT IN A FOLDER", size=11, weight=ft.FontWeight.BOLD, color=ft.Colors.PRIMARY)))
            for c in chars:
                items.append(ft.ListTile(
                    leading=ft.Icon(ft.Icons.PERSON),
                    content_padding=ft.Padding(36 if name else 16, 0, 16, 0),
                    title=ft.Text(c.label.rsplit(" #", 1)[0]),
                    subtitle=ft.Text(f"{c.instance}  ·  " + (f"#{c.kingdom}  ·  " if c.kingdom is not None else "")
                                     + f"{sum(j.enabled for j in c.jobs.values())} jobs on", size=11),
                    selected=not selected.get("folder") and c.key == selected["key"],
                    on_click=lambda e, k=c.key: pick_char(k),
                ))
        char_list.controls = items
        show_editor()
        page.update()

    inst_dd = ft.Dropdown(label="Instance", width=230, options=[])
    name_tf = ft.TextField(label="Character name", width=230)

    def load_instances():
        def work():
            names = []
            try:
                from intel_adb.adb import discover, parse_conf, CONF_PATH
                names = [n for n, _ in parse_conf(CONF_PATH.read_text(errors="ignore"))]
            except Exception:
                pass
            with ui_lock:
                inst_dd.options = [ft.DropdownOption(key=n, text=n) for n in names]
                page.update()
        threading.Thread(target=work, daemon=True).start()

    def add_character(e):
        inst, name = inst_dd.value, (name_tf.value or "").strip()
        if not inst or not name:
            page.show_dialog(ft.SnackBar(ft.Text("Pick an instance and type the character name")))
            return
        if find(f"{inst}/{name}"):
            page.show_dialog(ft.SnackBar(ft.Text("That character is already in the list")))
            return
        settings.characters.append(config.Character(instance=inst, name=name))
        selected["key"] = f"{inst}/{name}"
        name_tf.value = ""
        save()
        redraw_characters()

    find_status = ft.Text("", size=12, color=ft.Colors.ON_SURFACE_VARIANT)
    new_folder_tf = ft.TextField(label="New folder", width=180, dense=True)

    def add_folder(e):
        name = (new_folder_tf.value or "").strip()
        if not name or name in settings.folders:
            return
        settings.folders.append(name)
        new_folder_tf.value = ""
        selected["folder"] = name
        save()
        redraw_characters()

    def find_characters(e):
        """Read the in-game Characters list of every running instance and add new ones."""
        if eng.running:
            page.show_dialog(ft.SnackBar(ft.Text("Stop the Autopilot first - this taps the game")))
            return
        e.control.disabled = True
        find_status.value = "Looking for running instances..."
        page.update()

        def work():
            added, msg = 0, ""
            try:
                from autopilot.characters import TEMPLATE_DIR, Switcher
                from intel_adb.adb import discover
                from intel_adb.vision import Vision
                devices = discover()
                if not devices:
                    msg = "No running instance with Kingshot open"
                for dev in devices:
                    with ui_lock:
                        find_status.value = f"Reading characters on {dev.name}..."
                        page.update()
                    dev.screencap()  # sets the tap scale
                    rows = Switcher(dev, Vision(TEMPLATE_DIR), log=add_log).list_all()
                    from autopilot.characters import same_name
                    for r in rows:
                        known = next((c for c in settings.characters if c.instance == dev.name
                                      and same_name(r.name, c.name)
                                      and c.kingdom in (None, r.kingdom)), None)
                        if known:  # already listed (maybe added by hand): fill in kingdom/tag
                            if known.kingdom is None and r.kingdom is not None:
                                known.kingdom = r.kingdom
                            known.tag = r.tag or known.tag
                            known.power = r.power or known.power
                            continue
                        settings.characters.append(config.Character(
                            instance=dev.name, name=r.name, kingdom=r.kingdom, tag=r.tag, power=r.power))
                        added += 1
                    add_log(f"{dev.name}: {len(rows)} characters on the list")
                msg = msg or f"Added {added} new character(s)"
            except Exception as ex:
                msg = f"Failed: {ex!r}"
            with ui_lock:
                save()
                find_status.value = msg
                e.control.disabled = False
                redraw_characters()
        threading.Thread(target=work, daemon=True).start()

    characters = ft.Row([
        ft.Container(width=280, content=ft.Column([
            ft.Text("Characters", size=26, weight=ft.FontWeight.BOLD),
            ft.Card(content=ft.Container(padding=12, content=ft.Column([
                inst_dd, name_tf,
                ft.FilledTonalButton("Add character", icon=ft.Icons.ADD, on_click=add_character),
                ft.Row([new_folder_tf, ft.IconButton(ft.Icons.CREATE_NEW_FOLDER, tooltip="New folder",
                                                     on_click=add_folder)], spacing=4),
                ft.Divider(height=8),
                ft.FilledButton("Find characters", icon=ft.Icons.PERSON_SEARCH, on_click=find_characters,
                                tooltip="Reads the Characters list in every running instance (no switching)"),
                find_status,
            ], spacing=8))),
            char_list,
        ], expand=True)),
        ft.VerticalDivider(width=1),
        ft.Container(content=editor, expand=True, padding=ft.Padding(16, 0, 0, 0)),
    ], expand=True)

    # ---------------------------------------------------------------- schedule
    sch = settings.schedule

    def num_row(title, attr, lo, hi, div, unit, fmt="{:.1f}"):
        val = ft.Text(fmt.format(getattr(sch, attr)) + unit, width=70, weight=ft.FontWeight.BOLD)

        def changed(e):
            setattr(sch, attr, round(float(e.control.value), 2))
            val.value = fmt.format(getattr(sch, attr)) + unit
            save()
            val.update()
        return ft.Row([ft.Text(title, width=220),
                       ft.Slider(min=lo, max=hi, divisions=div, value=getattr(sch, attr),
                                 expand=True, on_change=changed), val])

    def range_row(title, a, b, lo, hi, div, unit):
        val = ft.Text(f"{getattr(sch, a):g}-{getattr(sch, b):g}{unit}", width=90, weight=ft.FontWeight.BOLD)

        def changed(e):
            setattr(sch, a, round(float(e.control.start_value), 2))
            setattr(sch, b, round(float(e.control.end_value), 2))
            val.value = f"{getattr(sch, a):g}-{getattr(sch, b):g}{unit}"
            save()
            val.update()
        return ft.Row([ft.Text(title, width=220),
                       ft.RangeSlider(min=lo, max=hi, divisions=div, start_value=getattr(sch, a),
                                      end_value=getattr(sch, b), expand=True, on_change=changed), val])

    def time_field(title, attr):
        def changed(e):
            v = e.control.value.strip()
            try:
                scheduler._minutes(v)
                setattr(sch, attr, v)
                e.control.error = None
                save()
            except Exception:
                e.control.error = "HH:MM"
            e.control.update()
        return ft.TextField(label=title, value=getattr(sch, attr), width=140, on_change=changed)

    def card(title, icon, controls):
        return ft.Card(content=ft.Container(padding=20, content=ft.Column([
            ft.Row([ft.Icon(icon, color=ft.Colors.PRIMARY), ft.Text(title, size=18, weight=ft.FontWeight.BOLD)]),
            *controls], spacing=12)))

    def order_changed(e):
        sch.order = e.control.value
        save()

    schedule_page = ft.Column([
        ft.Text("Schedule", size=26, weight=ft.FontWeight.BOLD),
        card("Run interval", ft.Icons.TIMER, [
            range_row("Time between runs (per character)", "interval_min_h", "interval_max_h", 0.5, 12, 23, " h"),
            num_row("Max session length", "max_session_min", 5, 120, 23, " min", "{:.0f}"),
            ft.Dropdown(label="Character order", value=sch.order, width=240,
                        options=[ft.DropdownOption(key=o, text=o) for o in ("Round robin", "List order")],
                        on_select=order_changed),
        ]),
        card("Quiet hours", ft.Icons.NIGHTLIGHT, [
            ft.Text("No runs start in this window (local time). Same start and end = off.",
                    color=ft.Colors.ON_SURFACE_VARIANT),
            ft.Row([time_field("From", "quiet_start"), time_field("Until", "quiet_end")]),
        ]),
        card("Human-like pacing", ft.Icons.TOUCH_APP, [
            range_row("Random pause between taps", "tap_pause_min", "tap_pause_max", 0.1, 4, 39, " s"),
        ]),
    ], spacing=16, scroll=ft.ScrollMode.AUTO, expand=True)

    # ---------------------------------------------------------------- safety
    saf = settings.safety

    def saf_switch(title, attr, help_):
        def changed(e):
            setattr(saf, attr, e.control.value)
            save()
        return ft.ListTile(title=ft.Text(title), subtitle=ft.Text(help_, size=12),
                           trailing=ft.Switch(value=getattr(saf, attr), on_change=changed))

    def unknown_changed(e):
        saf.stop_after_unknown = int(e.control.value)
        unknown_val.value = str(saf.stop_after_unknown)
        save()
        unknown_val.update()

    unknown_val = ft.Text(str(saf.stop_after_unknown), weight=ft.FontWeight.BOLD, width=30)

    def theme_changed(e):
        settings.theme = e.control.value
        page.theme_mode = ft.ThemeMode.DARK if settings.theme == "Dark" else ft.ThemeMode.LIGHT
        save()
        page.update()

    safety_page = ft.Column([
        ft.Text("Safety", size=26, weight=ft.FontWeight.BOLD),
        card("Spending", ft.Icons.SAVINGS, [
            saf_switch("Never spend money or diamonds", "never_spend",
                       "Offers, top-ups and diamond prompts are closed, never confirmed"),
        ]),
        card("When something looks wrong", ft.Icons.REPORT, [
            ft.Row([ft.Text("Skip a character after this many unknown screens", expand=True),
                    ft.Slider(min=2, max=15, divisions=13, value=saf.stop_after_unknown, width=260,
                              on_change=unknown_changed), unknown_val]),
            saf_switch("Save a screenshot when stuck", "screenshot_on_stuck",
                       "Saved to autopilot/debug so you can see what it saw"),
        ]),
        card("Appearance", ft.Icons.PALETTE, [
            ft.Dropdown(label="Theme", value=settings.theme, width=200,
                        options=[ft.DropdownOption(key=t, text=t) for t in ("Dark", "Light")],
                        on_select=theme_changed),
        ]),
    ], spacing=16, scroll=ft.ScrollMode.AUTO, expand=True)

    log_page = ft.Column([
        ft.Row([ft.Text("Log", size=26, weight=ft.FontWeight.BOLD, expand=True),
                ft.TextButton("Clear", icon=ft.Icons.CLEAR_ALL,
                              on_click=lambda e: (log_view.controls.clear(), page.update()))]),
        ft.Card(expand=True, content=ft.Container(padding=12, content=log_view)),
    ], expand=True)

    # ---------------------------------------------------------------- statistics
    stats_days = {"n": 7}
    stats_table = ft.Column(scroll=ft.ScrollMode.AUTO, expand=True)

    def refresh_stats():
        days = stats_days["n"]
        rows = []
        for ch in settings.characters:
            hist = st.history(ch.key)
            recent = sorted(hist)[-days:]
            totals = {}
            for d in recent:
                for job, n in hist[d].items():
                    totals[job] = totals.get(job, 0) + n
            today = hist.get(max(hist), {}) if hist else {}
            cells = [ft.DataCell(ft.Text(ch.label, weight=ft.FontWeight.W_600))]
            for j in config.JOBS:
                t, a = today.get(j, 0), totals.get(j, 0)
                cells.append(ft.DataCell(ft.Text(f"{t} / {a}" if a else "–",
                                                 color=None if a else ft.Colors.ON_SURFACE_VARIANT)))
            rows.append(ft.DataRow(cells=cells))
        stats_table.controls = [ft.DataTable(
            columns=[ft.DataColumn(ft.Text("Character"))]
            + [ft.DataColumn(ft.Text(config.JOB_LABELS[j], size=12), numeric=True) for j in config.JOBS],
            rows=rows, column_spacing=18)] if rows else [
            ft.Text("No characters yet.", color=ft.Colors.ON_SURFACE_VARIANT)]

    def stats_range(e):
        stats_days["n"] = int(e.control.value)
        refresh_stats()
        page.update()

    stats_page = ft.Column([
        ft.Row([ft.Text("Statistics", size=26, weight=ft.FontWeight.BOLD, expand=True),
                ft.Dropdown(label="Period", value="7", width=150,
                            options=[ft.DropdownOption(key=k, text=t) for k, t in
                                     (("1", "Today"), ("7", "7 days"), ("30", "30 days"))],
                            on_select=stats_range)]),
        ft.Text("Each cell: today / total over the period (rewards claimed, troops trained, fights, ...).",
                color=ft.Colors.ON_SURFACE_VARIANT),
        ft.Card(expand=True, content=ft.Container(padding=12, content=stats_table)),
    ], expand=True)

    # ---------------------------------------------------------------- shell
    pages = [dashboard, characters, schedule_page, safety_page, stats_page, log_page]
    body = ft.Container(content=pages[0], expand=True, padding=24, alignment=ft.Alignment(-1, -1))

    def nav_changed(e):
        i = e.control.selected_index
        if i == 0:
            refresh_dashboard()
        if i == 1:
            load_instances()
            redraw_characters()
        if pages[i] is stats_page:
            refresh_stats()
        body.content = pages[i]
        page.update()

    rail = ft.NavigationRail(
        selected_index=0, on_change=nav_changed, min_width=90, group_alignment=-0.9,
        leading=ft.Container(padding=ft.Padding(0, 16, 0, 16), content=ft.Column([
            ft.Image(src=str(Path(__file__).parent / "icon.png"), width=44, height=44),
            ft.Text("Autopilot", size=11, weight=ft.FontWeight.BOLD)],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=2)),
        destinations=[
            ft.NavigationRailDestination(icon=ft.Icons.DASHBOARD_OUTLINED, selected_icon=ft.Icons.DASHBOARD,
                                         label="Dashboard"),
            ft.NavigationRailDestination(icon=ft.Icons.PEOPLE_OUTLINE, selected_icon=ft.Icons.PEOPLE,
                                         label="Characters"),
            ft.NavigationRailDestination(icon=ft.Icons.SCHEDULE_OUTLINED, selected_icon=ft.Icons.SCHEDULE,
                                         label="Schedule"),
            ft.NavigationRailDestination(icon=ft.Icons.SHIELD_OUTLINED, selected_icon=ft.Icons.SHIELD,
                                         label="Safety"),
            ft.NavigationRailDestination(icon=ft.Icons.INSIGHTS_OUTLINED, selected_icon=ft.Icons.INSIGHTS,
                                         label="Statistics"),
            ft.NavigationRailDestination(icon=ft.Icons.RECEIPT_LONG_OUTLINED, selected_icon=ft.Icons.RECEIPT_LONG,
                                         label="Log"),
        ],
    )
    page.add(ft.Row([rail, ft.VerticalDivider(width=1), body], expand=True))
    refresh_dashboard()
    page.update()

    def ticker():  # keep the dashboard's countdowns and status fresh
        while True:
            time.sleep(15)
            if body.content is dashboard:
                with ui_lock:
                    refresh_dashboard()
                    try:
                        page.update()
                    except Exception:
                        return
    threading.Thread(target=ticker, daemon=True).start()
    def engine_changed():
        if body.content is dashboard:
            with ui_lock:
                refresh_dashboard()
                page.update()
    eng.on_change = engine_changed

    if os.environ.get("AUTOPILOT_STRESS"):  # test hook: hammer the UI from several threads
        def spam(n):
            for i in range(400):
                add_log(f"stress {n} {i}")
                engine_changed()
        for n in range(3):
            threading.Thread(target=spam, args=(n,), daemon=True).start()
    # Closing the window must end everything: stop the scheduler, save, and exit the process
    # (without this the Python side keeps running - and botting - with no window).
    def window_event(e):
        if e.type == ft.WindowEventType.CLOSE:
            eng.stop()
            try:
                st.save()
                config.save(settings)
            finally:
                # end the whole tree: this process and the flet.exe window it started
                import subprocess
                subprocess.Popen(["taskkill", "/PID", str(os.getpid()), "/T", "/F"],
                                 creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                time.sleep(2)
                os._exit(0)
    page.window.prevent_close = True
    page.window.on_event = window_event
    page.update()


def _log_errors():
    """The shortcut starts the app without a console: send any crash to autopilot/error.log."""
    import logging
    import sys
    logging.basicConfig(filename=Path(__file__).parent / "error.log", level=logging.ERROR,
                        format="%(asctime)s %(message)s")
    sys.excepthook = lambda *exc: logging.error("uncaught", exc_info=exc)
    threading.excepthook = lambda a: logging.error("thread %s", a.thread, exc_info=(a.exc_type, a.exc_value, a.exc_traceback))


if __name__ == "__main__":
    _log_errors()
    ft.run(main)
