"""Rewards job: daily / growth quests, Sign-in & Earn, the free "Claimable" chests in the Deals
and Top-up Center tabs, and free pass rewards. Recorded 2026-10-08 on Primary
(autopilot/recording_quests, spec docs/superpowers/specs/2026-10-08-rewards-design.md).

Safety: only allow-listed things are tapped - green Claim / Claim All, the glowing free sign-in
item, a chest labelled "Claimable", "Tap anywhere to exit". Never a red dot on its own, never
orange Continue / Unlock / CHF, Purchase Level, Go, Cancel Deposit. If a purchase window shows
up anyway it is closed with its X and the tab is left alone."""
import re
import time
from pathlib import Path

import cv2

from intel_adb import timer

QUEST_SCROLL = (33, 784)  # map / city, bottom-left
DEALS_ICON = (498, 182)
TOPUP_ICON = (462, 20)
QUEST_DAILY_TAB = (357, 850)
QUEST_GROWTH_TAB = (183, 850)
TAP_TO_EXIT = (270, 886)
TAB_Y = 105
TAB_XS = (100, 250, 400)
TAB_SWIPE = (430, 112, 80, 112)  # slow; starts left of the red "!" bubble at the bar's end
TAB_REWIND = (100, 112, 450, 112)
MAX_TAB_PAGES = 15
FREE_COLUMN = (30, 390, 155, 555)  # x, y, w, h of the Sign-in page's Free column
CLAIMABLE_AREA = (390, 130, 150, 160)  # top-right corner of a Deals / Top-up tab
CHEST_ABOVE_LABEL = 36  # px from the "Claimable" label up to its chest
BUTTON_COLUMN_X = 380  # pass / quest Claim buttons sit right of this
DEBUG_DIR = Path(__file__).parent / "debug"


def glowing_free_item(img):
    """Centre of the glowing (pale-yellow framed) item in the Sign-in Free column, or None."""
    x0, y0, w, h = FREE_COLUMN
    hsv = cv2.cvtColor(img[y0:y0 + h, x0:x0 + w], cv2.COLOR_BGR2HSV)
    m = cv2.inRange(hsv, (18, 45, 225), (36, 140, 255))
    n, _, st, _ = cv2.connectedComponentsWithStats(m)
    for k in range(1, n):
        x, y, bw, bh, _ = st[k]
        if 55 < bw < 100 and 55 < bh < 100:
            return x0 + int(x + bw / 2), y0 + int(y + bh / 2)
    return None


def claimable_label(vision, img):
    """Centre of the "Claimable" label in the tab's top-right corner, or None. The label sits
    on a different background in every tab, so it is read (loosely: OCR mixes up C/G, m/n)."""
    pos = vision.find(img, "claimable", 0.8)
    if pos or not timer.available():
        return pos
    x0, y0, w, h = CLAIMABLE_AREA
    g = cv2.cvtColor(cv2.resize(img[y0:y0 + h, x0:x0 + w], None, fx=3, fy=3,
                                interpolation=cv2.INTER_CUBIC), cv2.COLOR_BGR2GRAY)
    _, b = cv2.threshold(g, 200, 255, cv2.THRESH_BINARY_INV)
    try:
        d = timer.pytesseract.image_to_data(b, config="--psm 11",
                                            output_type=timer.pytesseract.Output.DICT)
    except Exception:
        return None
    for i, word in enumerate(d["text"]):
        if re.search(r"[CG]la[il1|][mn]", word):
            return (x0 + (d["left"][i] + d["width"][i] // 2) // 3,
                    y0 + (d["top"][i] + d["height"][i] // 2) // 3)
    return None


def is_green(img, pos, half=(40, 14)):
    """The button at `pos` is green (an active Claim), not grey (locked) or orange (paid)."""
    x, y = pos
    hsv = cv2.cvtColor(img[max(0, y - half[1]):y + half[1], max(0, x - half[0]):x + half[0]],
                       cv2.COLOR_BGR2HSV)
    green = cv2.inRange(hsv, (35, 80, 80), (90, 255, 255))
    return green.mean() / 255 > 0.35  # green Claim ~0.5-0.7, grey (locked) 0.0


def green_claim(vision, img, name):
    """Position of an active (green) Claim button right of the reward columns, or None."""
    for pos in vision.find_all(img, name, 0.8):
        if pos[0] >= BUTTON_COLUMN_X and is_green(img, pos):
            return pos
    return None


def purchase_window(vision, img):
    """A paid offer popped up over the page: a price button and a close X, and the page's own
    title (Deals / Top-up Center) is hidden behind the blur. Returns the X position or None."""
    if vision.has(img, "deals_title") or vision.has(img, "topup_title"):
        return None
    if not (vision.has(img, "chf") or vision.has(img, "cancel_deposit")):
        return None
    return vision.find(img, "popup_x")


class Rewards:
    def __init__(self, ctx):
        self.c = ctx
        self.v = ctx.v
        self.claims = 0
        self.params = {}
        self.record = False  # save every tab page to debug/ (live testing)

    # ---- helpers ---------------------------------------------------------
    def debug(self, tag, img):
        try:
            DEBUG_DIR.mkdir(exist_ok=True)
            cv2.imwrite(str(DEBUG_DIR / f"{time.strftime('%m%d_%H%M%S')}_{tag}.png"), img)
        except Exception:
            pass

    def settle(self):
        """After a tap: close the reward overlay, close a purchase window. Returns the
        screenshot, or None when a purchase window had to be closed."""
        for _ in range(3):
            self.c.sleep(1.0)
            img = self.c.shot()
            x = purchase_window(self.v, img)
            if x:
                self.c.log("rewards: a purchase window opened - closed it, nothing bought")
                self.debug("purchase_window", img)
                self.c.d.tap(*x, jitter=1)
                self.c.sleep(1.0)
                return None
            if self.v.has(img, "tap_to_exit"):
                self.c.d.tap(*TAP_TO_EXIT, jitter=4)
                continue
            return img
        return self.c.shot()

    def tap_claim(self, pos):
        self.c.d.tap(*pos, jitter=2)
        self.claims += 1
        return self.settle()

    # ---- quests ----------------------------------------------------------
    def quests(self):
        if not self.c.home():
            return
        img = self.c.shot()
        self.c.d.tap(*(self.v.find(img, "quest_scroll") or QUEST_SCROLL), jitter=2)
        img = self.c.wait_for("quest_title_daily", timeout=4) or self.c.shot()
        if not self.v.has(img, "quest_title_daily"):
            if not self.v.has(img, "quest_title_growth"):
                self.c.log("rewards: quest window didn't open")
                self.c.home()
                return
            self.c.d.tap(*QUEST_DAILY_TAB)
            img = self.c.wait_for("quest_title_daily", timeout=3)
        if img is not None:
            pos = self.v.find(img, "quest_claim_all")
            if pos and is_green(img, pos):
                self.tap_claim(pos)
                self.c.log("rewards: daily quests claimed")
        self.c.d.tap(*QUEST_GROWTH_TAB)
        img = self.c.wait_for("quest_title_growth", timeout=3)
        for _ in range(15):
            if img is None or not self.v.has(img, "quest_title_growth"):
                break
            pos = green_claim(self.v, img, "quest_claim")
            if not pos:
                break
            img = self.tap_claim(pos)
            self.c.log("rewards: growth mission claimed")
        self.c.home()

    # ---- Deals / Top-up tabs ---------------------------------------------
    def handle_tab(self, img):
        """Everything free on one Deals / Top-up tab page."""
        on = lambda k: self.params.get(k, True)
        pos = claimable_label(self.v, img) if on("free_chests") else None
        if pos:
            img = self.tap_claim((pos[0], pos[1] - CHEST_ABOVE_LABEL))
            self.c.log("rewards: free chest claimed")
            if img is None:
                return
        if on("signin") and self.v.has(img, "signin_banner"):
            pos = glowing_free_item(img)
            if pos:
                img = self.tap_claim(pos)
                self.c.log("rewards: sign-in reward claimed")
                if img is None:
                    return
        for _ in range(10 if on("pass_rewards") else 0):  # pass rewards: green Claim beside the free column
            pos = green_claim(self.v, img, "pass_claim")
            if not pos:
                break
            before = img
            img = self.tap_claim(pos)
            if img is not None and cv2.absdiff(before, img).mean() < 1:
                self.claims -= 1
                self.c.log("rewards: Claim did nothing - leaving this tab")
                return
            self.c.log("rewards: pass reward claimed")
            if img is None:
                return

    def walk_tabs(self, open_at, title):
        """Open a tabbed window (Deals / Top-up Center) and handle every tab once."""
        if not self.c.home():
            return
        self.c.d.tap(*open_at, jitter=2)
        if self.c.wait_for(title, timeout=5) is None:
            self.c.log(f"rewards: {title} didn't open")
            self.c.home()
            return
        for _ in range(MAX_TAB_PAGES):  # back to the first tab
            if not self.swipe_tabs(TAB_REWIND):
                break
        for page in range(MAX_TAB_PAGES):
            for x in TAB_XS:
                self.c.d.tap(x, TAB_Y, jitter=3)
                img = self.settle()
                if img is None:
                    continue
                if not (self.v.has(img, title) or self.v.has(img, "back_arrow")):
                    self.c.log(f"rewards: left {title} unexpectedly - stopping this window")
                    self.debug("left_window", img)
                    self.c.home()
                    return
                if self.record:
                    self.debug(f"{title}_{page}_{x}", img)
                self.handle_tab(img)
            if not self.swipe_tabs(TAB_SWIPE):
                break  # the tab bar didn't move: last tabs done
        self.c.home()

    def swipe_tabs(self, swipe):
        """Slow swipe along the tab bar. False when the bar didn't move (at its end). A swipe
        right after a tab change can be swallowed by its animation, so a still bar gets a
        second try before it counts as the end."""
        for _ in range(2):
            before = self.c.shot()
            self.c.d.swipe(*swipe, 800)
            self.c.sleep(1.0)
            if cv2.absdiff(before[70:140], self.c.shot()[70:140]).mean() >= 2:
                return True
        return False

    def run(self, params):
        self.params = params
        if params.get("quests", True):
            self.quests()
        if params.get("free_chests", True) or params.get("signin", True) \
                or params.get("pass_rewards", True):
            self.walk_tabs(DEALS_ICON, "deals_title")
        if params.get("free_chests", True):
            self.walk_tabs(TOPUP_ICON, "topup_title")
        if params.get("bank", False):
            self.c.log("rewards: bank collect/deposit isn't recorded yet - skipped")
        return self.claims


def rewards(ctx, params):
    return Rewards(ctx).run(params)
