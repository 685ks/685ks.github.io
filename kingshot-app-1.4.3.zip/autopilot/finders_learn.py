"""Learn Finder's Fusion items from filmed rounds.

    python -m autopilot.finders_learn VIDEO_DIR [...]

Frames are sampled 4x a second; a round is a run of frames that show the name buttons
under a scene. Each round goes through finders.learn()."""
import sys
from pathlib import Path

import cv2
from intel_adb.vision import imread as _imread
import numpy as np

from autopilot import finders
from journey_adb import chests

FPS = 4


_CLOCK = None


def in_round(img):
    """The blue name buttons AND the round timer's clock (bottom left) are on screen - the
    Finder's Fortune menu also has blue buttons down there, but no timer."""
    global _CLOCK
    hsv = cv2.cvtColor(img[845:940, 20:520], cv2.COLOR_BGR2HSV)
    blue = cv2.inRange(hsv, (100, 90, 150), (120, 255, 255)).mean() / 255
    if blue <= 0.35:
        return False
    if _CLOCK is None:
        _CLOCK = _imread(str(Path(__file__).parent / "templates" / "ff_clock.png"))
    win = img[780:860, 0:140]
    return float(cv2.matchTemplate(win, _CLOCK, cv2.TM_CCOEFF_NORMED).max()) >= 0.75


def rounds(path):
    cap = cv2.VideoCapture(str(path))
    fps = cap.get(cv2.CAP_PROP_FPS) or 30
    step = max(1, round(fps / FPS))
    cur, k, gap = [], 0, 0
    while True:
        ok, f = cap.read()
        if not ok:
            break
        k += 1
        if k % step:
            continue
        h, w = f.shape[:2]
        crop = None
        if w >= 1080 and f[:, w // 2:].mean() < 8:  # low-res instance: game drawn top-left
            crop = (w // 2, h // 2)
        f = chests.fit_frame(f, crop)
        if in_round(f):
            cur.append(f)
            gap = 0
        else:
            gap += 1
            if gap > 2 * FPS and len(cur) > 5 * FPS:
                yield cur
                cur = []
            elif gap > 2 * FPS:
                cur = []
    if len(cur) > 5 * FPS:
        yield cur


def main(dirs):
    total = {}
    for d in dirs:
        for v in sorted(Path(d).rglob("*.mp4")):
            for i, r in enumerate(rounds(v)):
                got = finders.learn(r, log=lambda m: None)
                print(f"{v.parent.name}/{v.name} round {i}: {len(r)} frames, learnt {len(got)}", flush=True)
                for n, p in got.items():
                    total.setdefault(n, []).append(p)
    import json
    Path("autopilot/finders_maps/observed.json").write_text(json.dumps(total, indent=1), encoding="utf-8")
    print(f"\n{len(total)} different items:")
    for n, ps in sorted(total.items()):
        xs, ys = [p[0] for p in ps], [p[1] for p in ps]
        print(f"  {n:20s} x{len(ps)}  at ~({int(np.median(xs))},{int(np.median(ys))})"
              f"  spread {max(xs) - min(xs)}x{max(ys) - min(ys)}")


if __name__ == "__main__":
    main(sys.argv[1:])
