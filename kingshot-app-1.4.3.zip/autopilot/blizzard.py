"""Blizzard Brawl (event), recorded and played live 2026-10-08 on Primary
(tests/fixtures/blizzard). User's wish: only gather the Blizzard Crate barrels, after
teleporting into an ice-blue pool, and use the airdrop items (an event mission).

Join: Events -> Blizzard Brawl tab -> Cross-Gen Battle -> matchmaking -> "Match Found" with a
Ready button that must be tapped within ~25 s (matches re-form when someone doesn't ready).
Open 4 slots a day (02-04, 09-11, 14-16, 19-21 UTC).

In the match: minimap pools -> tap a tile -> Teleport (Advanced Teleporter, free here) ->
Confirm. Then: tap barrel -> Blizzard Crate popup -> Gather -> Deploy (pre-filled).
Barrels already being gathered show Scout/Attack instead of Gather - never tapped.
"""
import time

from autopilot.jobs import _ocr

MINIMAP_POOLS = [(410, 122), (478, 122), (445, 162), (410, 162)]  # ice-blue pools on the minimap
TILE = (270, 470)
PREVIEW_SPOTS = [(200, 420), (300, 420), (200, 330), (330, 330), (150, 480), (380, 480), (270, 250)]
TELEPORT = (163, 689)
TELEPORT_FREE = (282, 502)
TELEPORT_CONFIRM = (270, 591)
DEPLOY = (412, 911)
BARREL_REGION = (0, 95, 540, 590)  # map between the top bar and the airdrop items
UI_BOXES = [(0, 140, 190, 320), (350, 60, 540, 225)]  # marching list, minimap (x0, y0, x1, y1)


def on_map(p):
    return not any(x0 <= p[0] <= x1 and y0 <= p[1] <= y1 for x0, y0, x1, y1 in UI_BOXES)
ITEMS = [(156, 775), (232, 775), (308, 775), (384, 775)]
ITEM_USE = (270, 0)  # set from the popup's teal Use button
MATCH_LENGTH = 11 * 60


def free_marches(img):
    """(used, total) from "Marching 5/6", or None when the list is collapsed / unreadable."""
    import re
    m = re.search(r"(\d)\s*/\s*(\d)", _ocr(img, (90, 150, 100, 22), "0123456789/"))
    return (int(m.group(1)), int(m.group(2))) if m else None


EVENTS_NAV = (497, 120)
TAB_SWIPE = (430, 112, 80, 112)
TAB_REWIND = (100, 112, 450, 112)
SLOTS_UTC = [(2, 4), (9, 11), (14, 16), (19, 21)]
REWARDS_BUTTON = (484, 225)


def in_slot(now_utc_hour_float):
    return any(a <= now_utc_hour_float < b for a, b in SLOTS_UTC)


def open_event(ctx):
    """Events -> the Blizzard Brawl tab. True when its page is showing."""
    if not ctx.home():
        return False
    ctx.d.tap(*EVENTS_NAV)
    ctx.sleep(2)
    for swipe in [None] + [TAB_REWIND] * 3 + [TAB_SWIPE] * 6:
        if swipe:
            ctx.d.swipe(*swipe, 800)
            ctx.sleep(1)
        img = ctx.shot()
        if ctx.v.has(img, "bz_title"):
            return True
        for pos in ctx.v.find_all(img, "bz_tab_icon", 0.8, region=(0, 60, 540, 90)):
            ctx.d.tap(*pos)
            ctx.sleep(1.5)
            if ctx.v.has(ctx.shot(), "bz_title"):
                return True
    return False


def join(ctx, timeout=6 * 60):
    """Cross-Gen Battle; tap Ready whenever a match forms; re-queue when matchmaking drops.
    True once on the battlefield."""
    img = ctx.shot()
    if not ctx.tap_t(img, "bz_cross"):
        return False
    end = time.monotonic() + timeout
    idle = 0
    while time.monotonic() < end:
        ctx.sleep(1)
        img = ctx.shot()
        if ctx.v.has(img, "bz_ready", 0.85):
            ctx.d.tap(270, 836, jitter=2)
            ctx.sleep(1.5)
            continue
        if ctx.v.has(img, "bz_battle_map", 0.75):
            return True
        if ctx.v.has(img, "bz_title"):  # back on the page: matching stopped
            idle += 1
            if idle >= 3:
                ctx.tap_t(img, "bz_cross")
                idle = 0
        else:
            idle = 0
    return False


def teleport(ctx):
    """Move the town into an ice-blue pool (minimap). True when it moved."""
    for pool in MINIMAP_POOLS:
        ctx.d.tap(*pool)
        ctx.sleep(1.5)
        for tile in (TILE, (200, 420), (340, 420), (270, 360)):
            ctx.d.tap(*tile)
            ctx.sleep(1.2)
            img = ctx.shot()
            if not ctx.tap_t(img, "bz_teleport"):
                ctx.d.tap(270, 120)
                ctx.sleep(0.6)
                continue
            img = ctx.wait_for("bz_tp_free", timeout=3)
            # "Unable to place" (button grey): in teleport mode a tap moves the town preview,
            # so try other spots in the pool until it can be placed
            for spot in PREVIEW_SPOTS if img is None else []:
                ctx.d.tap(*spot)
                ctx.sleep(1.2)
                img = ctx.shot()
                if ctx.v.has(img, "bz_tp_free"):
                    break
                img = None
            if img is None or not ctx.tap_t(img, "bz_tp_free"):
                ctx.d.back()
                ctx.sleep(1)
                continue
            img = ctx.wait_for("bz_tp_confirm", timeout=3)
            if img is not None:
                ctx.tap_t(img, "bz_tp_confirm")
                ctx.sleep(2)
                ctx.log("blizzard: teleported into an ice pool")
                return True
    return False


def claim_rewards(ctx):
    from autopilot.rewards import green_claim
    img = ctx.shot()
    if not ctx.v.has(img, "bz_title"):
        return 0
    ctx.d.tap(*REWARDS_BUTTON)
    ctx.sleep(1.5)
    n = 0
    for _ in range(10):
        img = ctx.shot()
        pos = green_claim(ctx.v, img, "pass_claim")
        if not pos:
            break
        ctx.d.tap(*pos)
        n += 1
        ctx.sleep(1.5)
        if ctx.v.has(ctx.shot(), "tap_to_exit"):
            ctx.d.tap(270, 900)
            ctx.sleep(1)
    ctx.d.back()
    ctx.sleep(1)
    return n


def blizzard(ctx, params, now_utc=None):
    """One match in the current time slot (if open), gathering the whole time; then rewards."""
    import datetime as dt
    now = now_utc or dt.datetime.now(dt.timezone.utc)
    if not in_slot(now.hour + now.minute / 60):
        return 0
    if not (open_event(ctx) or open_event(ctx)):
        ctx.log("blizzard: event page not found (event over?)")
        ctx.home()
        return 0
    claim_rewards(ctx)
    ctx.log("blizzard: matchmaking")
    if not join(ctx):
        ctx.log("blizzard: no match")
        ctx.home()
        return 0
    if params.get("teleport", True):
        ctx.sleep(2)
        teleport(ctx)
    sent = gather_loop(ctx)
    ctx.log(f"blizzard: match over, {sent} gatherers sent")
    for _ in range(5):
        img = ctx.shot()
        if ctx.v.has(img, "bz_title"):
            break
        if ctx.at_home(img):
            open_event(ctx)
            break
        ctx.d.tap(270, 900)
        ctx.sleep(2)
    claim_rewards(ctx)
    ctx.home()
    return sent


def _near(a, b, d=25):
    return abs(a[0] - b[0]) <= d and abs(a[1] - b[1]) <= d


MATCH_TIMER = (215, 52, 120, 24)  # "00:06:19" under the points
ITEM_PHASE = 100  # s before the end: stop gathering, use every airdrop item (user)
MINIMAP = (360, 75, 170, 120)  # x, y, w, h


def time_left(img):
    """Seconds left in the match from the top timer, or None."""
    from intel_adb import timer
    return timer.parse_hms(_ocr(img, MATCH_TIMER, "0123456789:"))


def enemy_buildings(img):
    """Red (enemy-held) buildings on the minimap, as screen positions to tap."""
    import cv2
    x0, y0, w, h = MINIMAP
    hsv = cv2.cvtColor(img[y0:y0 + h, x0:x0 + w], cv2.COLOR_BGR2HSV)
    m = cv2.inRange(hsv, (0, 140, 120), (8, 255, 255)) | cv2.inRange(hsv, (172, 140, 120), (180, 255, 255))
    n, _, st, cen = cv2.connectedComponentsWithStats(m)
    spots = [(x0 + int(cen[k][0]), y0 + int(cen[k][1]), int(st[k][4])) for k in range(1, n) if st[k][4] > 25]
    return [(x, y) for x, y, _ in sorted(spots, key=lambda s: s[2])]  # small camps before the big castle


def bomb(ctx, max_bombs=6):
    """Fire Rocket Bombs at enemy buildings via the building card's rocket shortcut."""
    fired = 0
    for spot in enemy_buildings(ctx.shot()):
        for _ in range(max_bombs - fired):
            ctx.d.tap(*spot)
            ctx.sleep(1.5)
            ctx.d.tap(250, 370)  # the building lands in the middle of the screen
            ctx.sleep(1.2)
            img = ctx.shot()
            if not ctx.tap_t(img, "bz_rocket_icon", 0.8):
                ctx.d.tap(450, 650)  # close; no rockets left or not a target
                ctx.sleep(0.6)
                break
            img = ctx.wait_for("bz_use", timeout=2)
            if img is None or not ctx.tap_t(img, "bz_use", 0.8):
                break
            fired += 1
            ctx.log(f"blizzard: rocket bomb {fired} fired")
            ctx.sleep(1.5)
        if fired >= max_bombs:
            break
    return fired


def use_items(ctx):
    """End of the round: rockets at enemy buildings, then every other airdrop item that
    offers a plain Use (never anything with a price)."""
    n = bomb(ctx)
    for pos in ITEMS[1:]:
        for _ in range(3):
            ctx.d.tap(*pos)
            ctx.sleep(1.0)
            img = ctx.shot()
            if ctx.v.has(img, "gem_button_icon") or not ctx.tap_t(img, "bz_use", 0.8):
                ctx.d.tap(450, 650)
                ctx.sleep(0.5)
                break
            n += 1
            ctx.log("blizzard: airdrop item used")
            ctx.sleep(1.2)
    return n


def gather_loop(ctx, seconds=MATCH_LENGTH, rest=4.0, items=True):
    """Keep sending gatherers until the match ends. Barrels that didn't take a gatherer are
    skipped for a minute (someone else is on them)."""
    end = time.monotonic() + seconds
    sent = 0
    tried = {}  # barrel pos -> time tried
    items_used = not items
    while time.monotonic() < end:
        try:
            if not items_used:
                left = time_left(ctx.shot())
                if left is not None and left <= ITEM_PHASE:
                    items_used = True
                    ctx.log(f"blizzard: {left}s left - using the airdrop items")
                    use_items(ctx)
                    continue
            done = _gather_step(ctx, tried)
        except Exception as e:  # a hung screenshot etc.: one bad frame mustn't end the match
            ctx.log(f"blizzard: step failed ({type(e).__name__}) - carrying on")
            ctx.sleep(rest)
            continue
        if done == "over":
            break
        if done == "sent":
            sent += 1
            ctx.log(f"blizzard: gatherer {sent} sent")
            continue
        ctx.sleep(rest)
    return sent


def _gather_step(ctx, tried):
    """One look at the map: 'over' (results screen), 'sent', or 'none'."""
    img = ctx.shot()
    if not ctx.v.has(img, "bz_battle_map", 0.75):
        if ctx.v.has(img, "tap_to_exit") or ctx.v.has(img, "rewards_banner") \
                or ctx.v.has(img, "bz_title"):
            return "over"  # results screen / back on the event page
        ctx.d.tap(270, 120)  # stray popup
        ctx.sleep(1)
        return "none"
    now = time.monotonic()
    recent = [p for p, t in tried.items() if now - t < 60]
    if gather_one(ctx, recent):
        tried.clear()
        return "sent"
    last = getattr(gather_one, "last", None)
    if last:  # a barrel that didn't take a gatherer: skip it for a minute
        tried[last] = now
    return "none"


def gather_one(ctx, tried):
    """Tap the nearest untried barrel; Gather + Deploy if nobody has it. True when sent."""
    img = ctx.shot()
    city = (270, 440)
    gather_one.last = None
    barrels = [b for b in ctx.v.find_all(img, "bz_barrel", 0.75, region=BARREL_REGION)
               if on_map(b) and not any(_near(b, t) for t in tried)]
    if not barrels:
        return False
    b = min(barrels, key=lambda p: (p[0] - city[0]) ** 2 + (p[1] - city[1]) ** 2)
    gather_one.last = b
    if isinstance(tried, list):
        tried.append(b)
    ctx.d.tap(*b)
    ctx.sleep(1.0)
    img = ctx.shot()
    where = crate_coords(ctx.v, img)
    now = time.monotonic()
    for k in [k for k, t in SENT.items() if now - t > SENT_FOR]:
        del SENT[k]
    # our march may still be on its way: the crate then still says "Gatherer: None"
    if where in SENT or not ctx.v.has(img, "bz_crate_title", 0.75) \
            or not ctx.tap_t(img, "bz_gather", 0.8):
        ctx.d.tap(270, 120)  # close the popup
        ctx.sleep(0.6)
        return False
    img = ctx.wait_for("bz_deploy", timeout=3)
    if img is None:
        return False
    ctx.d.tap(*DEPLOY)
    ctx.sleep(1.0)
    if where:
        SENT[where] = time.monotonic()
    return True


SENT = {}  # (x, y) map coordinates of crates we sent a march to -> when
SENT_FOR = 120  # s: march there + 30 s gathering; after that the crate is gone


def crate_coords(vision, img):
    """(x, y) map coordinates from the crate popup ("X:31 Y:64"), or None."""
    import re
    title = vision.find(img, "bz_crate_title", 0.75)
    if not title:
        return None
    nums = re.findall(r"\d+", _ocr(img, (title[0] - 150, title[1] - 42, 110, 24), "XY:0123456789 "))
    return (int(nums[0]), int(nums[1])) if len(nums) == 2 else None
