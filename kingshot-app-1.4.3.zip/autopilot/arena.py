"""Arena of Glory, recorded 2026-10-08 on Primary (tests/fixtures/city/arena_*).

Way in (no direct button): Shop -> Arena tab -> tap the Arena Token at the top -> Get More ->
Go. Then Challenge -> Challenge List -> crossed swords on a row -> Squad Settings -> Fight.

User rules (2026-10-08):
- play 2 minutes before the daily reset (the engine runs this job at 23:58 UTC)
- only green targets (power in green = beatable; red = too strong)
- slot 1 gives the most points, then slot 2 ... so the highest green slot is picked
- NEVER a player from our own alliance: a row is only attacked when its tag reads cleanly and
  differs from ours (or it's an untagged Guardsman bot); when our own tag can't be read, no fights.
"""
import re

import cv2

from intel_adb import timer

SHOP_NAV = (315, 925)
SHOP_ARENA_TAB = (380, 935)
ARENA_TOKEN = (470, 30)
GETMORE_GO = (434, 302)
CHALLENGE = (270, 910)
FIGHT = (397, 900)
LIST_CLOSE = (500, 144)
RESULT_EXIT = (270, 800)  # dark area below the result card ("Tap anywhere to exit")
OWN_NAME = (185, 780, 160, 26)  # "[GoD]Ainz" in the arena page's own row
SWORDS_REGION = (430, 220, 90, 490)


def _ocr_name(img, box):
    if not timer.available():
        return ""
    x, y, w, h = box
    g = cv2.cvtColor(cv2.resize(img[y:y + h, x:x + w], None, fx=3, fy=3,
                                interpolation=cv2.INTER_CUBIC), cv2.COLOR_BGR2GRAY)
    _, b = cv2.threshold(g, 110, 255, cv2.THRESH_BINARY)
    try:
        return timer.pytesseract.image_to_string(b, config="--psm 7").strip()
    except Exception:
        return ""


def tag_of(name):
    """'[SVP]Actuarialbiz' -> 'SVP'; "'TNH lord" -> 'TNH'; None when no clean tag."""
    m = re.match(r"^\W{0,2}([A-Za-z0-9]{2,4})[\]|)}\s]", name)
    return m.group(1).upper() if m else None


def own_tag(img):
    """Our tag from "[GoD]Ainz" on the arena page. OCR often reads the brackets as I/l
    ("IGoDIAInZ"), so a 3-letter tag between bracket look-alikes is accepted too."""
    name = _ocr_name(img, OWN_NAME)
    m = re.match(r"^[\[(|Il1]([A-Za-z0-9]{3})[\])|Il1]", name)
    return m.group(1).upper() if m else tag_of(name)


def power_colour(img, swords_y):
    """'green' / 'red' / None for the power number of the row whose swords are at y."""
    # player rows have the power level with the swords, bot rows (no server line) ~20 px lower
    hsv = cv2.cvtColor(img[swords_y - 12:swords_y + 32, 135:210], cv2.COLOR_BGR2HSV)
    green = cv2.inRange(hsv, (40, 120, 120), (85, 255, 255)).mean() / 255
    red = (cv2.inRange(hsv, (0, 120, 120), (8, 255, 255))
           | cv2.inRange(hsv, (172, 120, 120), (180, 255, 255))).mean() / 255
    if green > 0.04 and green > red * 3:
        return "green"
    if red > 0.04:
        return "red"
    return None


def pick_target(vision, img, mine):
    """Swords position of the highest green, non-alliance row, or None."""
    if not mine:
        return None
    rows = sorted(vision.find_all(img, "arena_swords", 0.85, region=SWORDS_REGION), key=lambda p: p[1])
    for x, y in rows:
        if power_colour(img, y) != "green":
            continue
        name = _ocr_name(img, (112, y - 38, 218, 22))
        if "guardsman" in name.lower():
            return x, y
        tag = tag_of(name)
        if tag is None or tag == mine.upper() or mine.upper() in name.upper():
            continue
        return x, y
    return None


def open_arena(ctx):
    if not ctx.home():
        return False
    ctx.d.tap(*SHOP_NAV)
    ctx.sleep(2)
    ctx.d.tap(*SHOP_ARENA_TAB)
    ctx.sleep(1.5)
    ctx.d.tap(*ARENA_TOKEN)
    img = ctx.wait_for("getmore_title", timeout=4)
    if img is None:
        return False
    ctx.d.tap(*GETMORE_GO)
    return ctx.wait_for("arena_title", timeout=6) is not None


BUY_PLUS = (350, 726)  # "+" next to "Daily challenges: N" in the Challenge List
COUNT_PLUS = (358, 543)  # "+" of the amount slider in the purchase popup
BUY_BUTTON = (270, 639)
BUY_CLOSE = (490, 292)
PRICE_BOX = (250, 624, 80, 30)


def read_price(img, vision=None):
    """Diamonds on the buy button, read right of the diamond icon (its width varies)."""
    from autopilot.jobs import _ocr
    box = PRICE_BOX
    if vision is not None:
        icon = vision.find(img, "gem_button_icon")
        if not icon:
            return None
        box = (icon[0] + 15, PRICE_BOX[1], 100, PRICE_BOX[3])
    digits = re.sub(r"\D", "", _ocr(img, box, "0123456789,"))
    return int(digits) if digits else None


def buy_attempts(ctx, max_gems):
    """In the Challenge List: buy today's extra attempts (all 5, user 2026-10-08) with diamonds
    when the total shown is at most `max_gems`. Returns the price paid (0 if nothing bought)."""
    ctx.d.tap(*BUY_PLUS)
    img = ctx.wait_for("attempts_title", timeout=3)
    if img is None:
        return 0
    for _ in range(5):
        ctx.d.tap(*COUNT_PLUS)
        ctx.sleep(0.4)
    img = ctx.shot()
    price = read_price(img, ctx.v)
    if not ctx.v.has(img, "gem_button_icon") or not price or price > max_gems:
        ctx.log(f"arena: extra attempts cost {price} - over the {max_gems} limit or unreadable, not bought")
        ctx.d.tap(*BUY_CLOSE)
        ctx.sleep(1)
        return 0
    ctx.d.tap(*BUY_BUTTON)
    ctx.sleep(1.5)
    ctx.log(f"arena: bought extra attempts for {price} diamonds")
    if ctx.v.has(ctx.shot(), "attempts_title"):  # popup stays when nothing is left to buy
        ctx.d.tap(*BUY_CLOSE)
        ctx.sleep(1)
    return price


def arena(ctx, tag_hint="", max_fights=12, buy=True, max_gems=2100):
    """Use today's challenges. Returns the number of fights."""
    if not open_arena(ctx):
        ctx.log("arena: couldn't open the Arena")
        ctx.home()
        return 0
    mine = own_tag(ctx.shot()) or (tag_hint or None)
    if not mine:
        ctx.log("arena: can't read our alliance tag - not fighting (never hit own alliance)")
        ctx.home()
        return 0
    fights, bought = 0, not buy
    for _ in range(max_fights):
        img = ctx.shot()
        if not ctx.tap_t(img, "arena_challenge"):
            break
        img = ctx.wait_for("challenge_list_title", timeout=4)
        if img is None:
            break
        if not bought:  # once per run, before the first fight
            bought = True
            buy_attempts(ctx, max_gems)
            img = ctx.wait_for("challenge_list_title", timeout=3) or ctx.shot()
        target = pick_target(ctx.v, img, mine)
        if not target:
            ctx.log("arena: no green target outside our alliance")
            ctx.d.tap(*LIST_CLOSE)
            break
        ctx.d.tap(*target)
        img = ctx.wait_for("fight_button", timeout=5)
        if img is None:
            ctx.log("arena: no challenges left")
            break
        ctx.tap_t(img, "fight_button")
        fights += 1
        for _ in range(40):
            ctx.sleep(2)
            img = ctx.shot()
            if ctx.v.has(img, "arena_title") or ctx.v.has(img, "challenge_list_title"):
                break
            if ctx.v.has(img, "victory_arena") or ctx.v.has(img, "tap_to_exit"):
                ctx.d.tap(*RESULT_EXIT)
        if ctx.v.has(ctx.shot(), "challenge_list_title"):
            ctx.d.tap(*LIST_CLOSE)
            ctx.sleep(1)
        ctx.log(f"arena: fight {fights} done")
    ctx.home()
    return fights

