"""City chores, recorded 2026-10-08 on Primary (autopilot/recording_quests, fixtures in
tests/fixtures/city): alliance Help All, Rebel Assault quick challenge, hospital heal (+ ask the
alliance for help).

Safety: Heal (resources) only - never Finish (diamonds); never the paid "View" card on the
Help screen; Quick Challenge only (no manual Battle)."""
from pathlib import Path

ALLIANCE_NAV = (400, 925)
TOWN_BUTTON = (487, 925)  # bottom-right on the world map
CLAIM_REWARDS = (270, 685)
# slow drags (x1, y1, x2, y2) from the castle-centred city view: first towards the hospital
# (down-right of the castle), then a small spiral around it
CITY_SCAN = [(450, 700, 100, 200), (150, 450, 400, 450), (270, 300, 270, 600),
             (400, 450, 150, 450), (400, 450, 150, 450), (270, 600, 270, 300),
             (270, 600, 270, 300), (150, 450, 400, 450), (150, 450, 400, 450)]


def help_all(ctx):
    """Alliance -> Help -> Help All. Returns 1 when it helped, else 0."""
    if not ctx.home():
        return 0
    ctx.d.tap(*ALLIANCE_NAV)
    img = ctx.wait_for("help_tile", timeout=5)
    if img is None or not ctx.tap_t(img, "help_tile"):
        ctx.log("help: alliance menu didn't open")
        ctx.home()
        return 0
    ctx.sleep(1.5)
    img = ctx.shot()
    done = 0
    if ctx.tap_t(img, "help_all"):
        done = 1
        ctx.log("help: Help All")
        ctx.sleep(1)
    else:
        ctx.log("help: nobody to help")
    ctx.home()
    return done


def to_city(ctx):
    """Into the city view (from the world map if needed). True when there."""
    if not ctx.home():
        return False
    img = ctx.shot()
    if ctx.v.has(img, "world_button"):  # already in the city
        return True
    ctx.d.tap(*TOWN_BUTTON)
    return ctx.wait_for("world_button", timeout=6) is not None


def rebel(ctx):
    """Rebel Assault bubble (city, top-left) -> Quick Challenge -> Claim Rewards."""
    if not to_city(ctx):
        return 0
    img = ctx.shot()
    if not ctx.tap_t(img, "rebel_bubble"):
        return 0
    img = ctx.wait_for("rebel_title", timeout=4)
    if img is None or not ctx.tap_t(img, "quick_challenge"):
        ctx.log("rebel: no Quick Challenge")
        ctx.home()
        return 0
    img = ctx.wait_for("claim_rewards", timeout=8)
    if img is None:
        ctx.log("rebel: no victory screen")
        ctx.home()
        return 0
    ctx.tap_t(img, "claim_rewards")
    ctx.sleep(1.5)
    ctx.log("rebel: assault beaten, rewards claimed")
    ctx.home()
    return 1


def find_in_city(ctx, names):
    """Look for any of the bubbles `names` while panning around the city. Returns
    (name, position) or None. Starts from the castle-centred view (World -> Town)."""
    if not to_city(ctx):
        return None
    ctx.d.tap(*TOWN_BUTTON)  # World ...
    ctx.sleep(2)
    ctx.d.tap(*TOWN_BUTTON)  # ... and back to Town recentres on the castle
    if ctx.wait_for("world_button", timeout=6) is None:
        return None
    for drag in [None] + CITY_SCAN:
        if drag:
            ctx.d.swipe(*drag, 900)
            ctx.sleep(1.0)
        img = ctx.shot()
        for name in names:
            pos = ctx.v.find(img, name)
            if pos:
                return name, pos
    return None


def heal(ctx, ask_help=True):
    """Hospital: Heal the wounded with resources, then ask the alliance for help."""
    found = find_in_city(ctx, ["heal_bubble", "heal_help"])
    if not found:
        ctx.log("heal: nobody wounded (no hospital bubble)")
        ctx.home()
        return 0
    name, pos = found
    healed = 0
    if name == "heal_bubble":
        ctx.d.tap(*pos)
        img = ctx.wait_for("heal_title", timeout=5)
        if img is None or not ctx.tap_t(img, "heal_button"):
            ctx.log("heal: heal screen didn't open")
            ctx.home()
            return 0
        healed = 1
        ctx.log("heal: healing started")
        ctx.sleep(2)
        img = ctx.shot()
        pos = ctx.v.find(img, "heal_help")
    if ask_help and pos and ctx.v.find(ctx.shot(), "heal_help"):
        ctx.d.tap(*pos)
        ctx.log("heal: asked the alliance for help")
        ctx.sleep(1)
    ctx.home()
    return healed


# ---- queue panel (left edge, Town tab): green check rows ---------------------
PANEL_TAB = (10, 410)
PANEL_TOWN = (87, 202)
PANEL_CHECKS = (260, 220, 80, 430)  # x, y, w, h where the rows' buttons sit
PANEL_UP = (170, 260, 170, 620)
PANEL_DOWN = (170, 600, 170, 250)
COLLECT_ROWS = ("online rewards", "fountain of life")  # troop rows: left to the Train job
# after a check is tapped the game shows a bouncing hand pointing at what to tap
HANDS = {"hand_down": (-34, 58), "hand_left": (-51, -64)}  # template centre -> target
HAND_THRESHOLD = 0.75


def row_title(img, check_y):
    import cv2
    from intel_adb import timer
    if not timer.available():
        return ""
    c = img[check_y - 24:check_y - 2, 60:280]
    g = cv2.cvtColor(cv2.resize(c, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC), cv2.COLOR_BGR2GRAY)
    _, b = cv2.threshold(g, 170, 255, cv2.THRESH_BINARY_INV)
    try:
        return timer.pytesseract.image_to_string(b, config="--psm 7").strip().lower()
    except Exception:
        return ""


def pointed_target(vision, img):
    """Where the tutorial hand points, or None."""
    for name, (dx, dy) in HANDS.items():
        pos = vision.find(img, name, HAND_THRESHOLD)
        if pos:
            return pos[0] + dx, pos[1] + dy
    return None


def open_panel(ctx):
    if not ctx.home():
        return False
    if not ctx.v.has(ctx.shot(), "panel_town_tab"):  # its tab toggles: tap only when closed
        ctx.d.tap(*PANEL_TAB)
        ctx.sleep(1.2)
    ctx.d.tap(*PANEL_TOWN)
    ctx.sleep(1.5)
    if not ctx.v.has(ctx.shot(), "panel_town_tab"):
        return False
    for _ in range(3):
        if not scroll_panel(ctx, PANEL_UP):
            return False
    return True


def scroll_panel(ctx, drag):
    """Drag the panel list. False (and back home) if the drag opened something instead."""
    ctx.d.swipe(*drag, 900)
    img = None
    for _ in range(3):  # the list keeps gliding for a moment after the drag
        ctx.sleep(0.7)
        img = ctx.shot()
        if ctx.v.has(img, "panel_town_tab"):
            return True
    if not ctx.at_home(img):
        ctx.log("panel: a scroll opened a screen - backing out")
        ctx.home()
    return False


def collect_panel(ctx, rows=COLLECT_ROWS):
    """Tap the green check of each allowed row (Online Rewards, Fountain of Life), then the
    thing the game's hand points at. Returns the number collected."""
    done, tried = 0, set()
    for _ in range(len(rows) + 1):
        if not open_panel(ctx):
            break
        hit = None
        for page in range(4):
            img = ctx.shot()
            for pos in ctx.v.find_all(img, "panel_check", 0.85, region=PANEL_CHECKS):
                title = row_title(img, pos[1])
                if any(r in title for r in rows) and title not in tried:
                    hit = title, pos
                    break
            if hit or not scroll_panel(ctx, PANEL_DOWN):
                break
        if not hit:
            break
        title, pos = hit
        tried.add(title)
        ctx.d.tap(*pos)
        target = None
        for _ in range(5):
            ctx.sleep(0.8)
            target = pointed_target(ctx.v, ctx.shot())
            if target:
                break
        if not target:
            ctx.log(f"panel: {title} - nothing pointed at")
            continue
        ctx.d.tap(*target, jitter=2)
        ctx.sleep(2)
        ctx.log(f"panel: collected {title}")
        done += 1
        img = ctx.shot()
        if not (ctx.at_home(img) or ctx.v.has(img, "back_arrow")):
            ctx.d.tap(270, 900)  # reward overlay ("Next Chest Ready In ...")
            ctx.sleep(1)
    ctx.home()
    return done


def panel_row(ctx, title, pages=4):
    """Open the panel and return the button position of the row called `title`, or None."""
    if not open_panel(ctx):
        return None
    for _ in range(pages):
        img = ctx.shot()
        for pos in ctx.v.find_all(img, "panel_arrow", 0.8, region=PANEL_CHECKS):
            if row_title(img, pos[1]) == title:
                return pos
        if not scroll_panel(ctx, PANEL_DOWN):
            return None
    return None


RESULT_EXIT = (270, 120)  # "Tap anywhere to exit" - away from the paid "Recruit x1 (key)"


def recruit(ctx, max_free=10):
    """Free hero recruits (green "Recruit x1 Free"); never the orange key/diamond buttons."""
    from autopilot.rewards import is_green
    pos = panel_row(ctx, "advanced")
    if not pos:
        ctx.home()
        return 0
    ctx.d.tap(*pos)
    if ctx.wait_for("recruit_title", timeout=5) is None:
        ctx.log("recruit: recruitment screen didn't open")
        ctx.home()
        return 0
    n = 0
    for _ in range(max_free):
        img = ctx.shot()
        free = [p for p in ctx.v.find_all(img, "recruit_x1", 0.7) if is_green(img, (p[0], p[1] + 12))]
        if not free:
            break
        ctx.d.tap(free[0][0], free[0][1] + 12)
        n += 1
        if ctx.wait_for("rewards_banner", timeout=6) is not None:
            ctx.d.tap(*RESULT_EXIT)
        ctx.wait_for("recruit_title", timeout=4)
    ctx.log(f"recruit: {n} free recruit(s)")
    ctx.home()
    return n


# ---- Conquest (story chapters + idle income) ---------------------------------
CONQUEST_NAV = (47, 925)
IDLE_CHEST = (462, 690)
IDLE_CLAIM = (270, 692)
OUR_POWER = (96, 92, 124, 24)
ENEMY_POWER = (340, 92, 120, 24)


def read_power(img, box):
    import re
    from autopilot.jobs import _ocr
    digits = re.sub(r"\D", "", _ocr(img, box, "0123456789,"))
    return int(digits) if digits else None


def conquest(ctx, fight=True, margin=1.0, max_fights=5):
    """Claim the idle income (hero EXP, gold, gear); then fight story stages while our squad
    power is at least `margin` x the enemy's (Quick Deploy + Fight)."""
    from autopilot.rewards import is_green
    if not ctx.home():
        return 0
    ctx.d.tap(*CONQUEST_NAV)
    img = ctx.wait_for("conquest_title", timeout=5)
    if img is None:
        ctx.log("conquest: screen didn't open")
        ctx.home()
        return 0
    n = 0
    if is_green(img, (IDLE_CHEST[0], IDLE_CHEST[1])):
        ctx.d.tap(*IDLE_CHEST)
        img = ctx.wait_for("idle_title", timeout=4)
        if img is not None and is_green(img, IDLE_CLAIM):
            ctx.d.tap(*IDLE_CLAIM)
            ctx.sleep(1.5)
            ctx.d.tap(*RESULT_EXIT)
            ctx.log("conquest: idle income claimed")
            n += 1
        ctx.wait_for("conquest_title", timeout=4)
    for _ in range(max_fights if fight else 0):
        img = ctx.shot()
        if not ctx.tap_t(img, "conquer_button"):
            break
        img = ctx.wait_for("squad_title", timeout=5)
        if img is None:
            break
        ours, theirs = read_power(img, OUR_POWER), read_power(img, ENEMY_POWER)
        if not ours or not theirs or ours < theirs * margin:
            ctx.log(f"conquest: next stage too strong ({ours} vs {theirs}) - stopping")
            break
        ctx.tap_t(img, "quick_deploy")
        ctx.sleep(1)
        ctx.tap_t(ctx.shot(), "fight_button")
        ctx.log(f"conquest: fighting ({ours} vs {theirs})")
        for _ in range(60):  # battle plays out; results then "Tap anywhere to exit"
            ctx.sleep(2)
            img = ctx.shot()
            if ctx.v.has(img, "conquest_title"):
                break
            if ctx.v.has(img, "tap_to_exit") or ctx.v.has(img, "rewards_banner"):
                ctx.d.tap(*RESULT_EXIT)
        n += 1
    ctx.home()
    return n


# ---- Mystic Trial ------------------------------------------------------------
TRIALS = {"Crystal Cave": (110, 300), "Knowledge Nexus": (430, 320),
          "Forest of Life": (88, 520), "Molten Fort": (440, 510)}
TRIAL_CHALLENGE = (270, 911)
TRIAL_DEPLOY = (412, 911)


def _at(pos, x, y, tol=25):
    return pos is not None and abs(pos[0] - x) <= tol and abs(pos[1] - y) <= tol


TRIAL_STATE = Path(__file__).parent / "trial_state.json"


def _lost_today(who):
    """Trials this character already lost today (UTC), from trial_state.json."""
    import datetime as dt
    import json
    day = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d")
    try:
        data = json.loads(TRIAL_STATE.read_text(encoding="utf-8"))
    except Exception:
        data = {}
    if data.get("day") != day:
        data = {"day": day}
    return data, data.setdefault(who, [])


def _save_trials(data):
    import json
    try:
        TRIAL_STATE.write_text(json.dumps(data), encoding="utf-8")
    except Exception:
        pass


def mystic_trial(ctx, max_battles=10, who="default"):
    """Each trial open today: Challenge -> Deploy (pre-filled troops) until the first loss
    (a retry at the same power only burns an attempt). Returns the number of wins."""
    pos = panel_row(ctx, "forest of life") or panel_row(ctx, "crystal cave")
    if not pos:
        ctx.home()
        return 0
    ctx.d.tap(*pos)
    if ctx.wait_for("mystic_title", timeout=6) is None:
        ctx.log("trial: Mystic Trial didn't open")
        ctx.home()
        return 0
    wins = 0
    data, lost_today = _lost_today(who)
    for name, where in TRIALS.items():
        if name in lost_today:
            continue
        ctx.d.tap(*where)
        ctx.sleep(2.5)
        img = ctx.shot()
        if not _at(ctx.v.find(img, "trial_challenge"), *TRIAL_CHALLENGE):
            if not ctx.v.has(img, "mystic_title"):
                ctx.d.back()  # closed today ("Opens in ...") or another popup
                ctx.sleep(1)
            continue
        for _ in range(max_battles):
            img = ctx.shot()
            if not _at(ctx.v.find(img, "trial_challenge"), *TRIAL_CHALLENGE):
                break
            ctx.d.tap(*TRIAL_CHALLENGE)
            img = ctx.wait_for("trial_deploy", timeout=5)
            if img is None or not _at(ctx.v.find(img, "trial_deploy"), *TRIAL_DEPLOY):
                ctx.log(f"trial: {name} - no attempts left")
                break
            ctx.d.tap(*TRIAL_DEPLOY)
            lost = False
            for _ in range(60):  # wins chain into the next stage by themselves
                ctx.sleep(2)
                img = ctx.shot()
                if ctx.v.has(img, "trial_failed"):
                    lost = True
                    break
                if ctx.v.has(img, "trial_victory"):
                    wins += 1
                    ctx.log(f"trial: {name} - stage won")
                    ctx.sleep(5)  # auto-challenge of the next stage
                    continue
                if _at(ctx.v.find(img, "trial_challenge"), *TRIAL_CHALLENGE):
                    break  # back on the stage screen
            if lost:
                ctx.log(f"trial: {name} - lost, done for today")
                lost_today.append(name)
                _save_trials(data)
                ctx.d.back()
                ctx.sleep(1.5)
                break
        while not ctx.v.has(ctx.shot(), "mystic_title"):  # back to the island map
            if ctx.at_home(ctx.shot()):
                break
            ctx.d.back()
            ctx.sleep(1.2)
        if not ctx.v.has(ctx.shot(), "mystic_title"):
            break
    ctx.home()
    return wins


# ---- Hero Roulette (event) ---------------------------------------------------
EVENTS_NAV = (497, 120)
CHIP_BOX = (300, 16, 40, 28)  # chips owned, top bar (the "+" right of it is left out)
CHIP_CHEST = (58, 770)  # Lucky Chip Pack (free pack + paid ones)
CHIP_FREE = (384, 262)
SPIN1 = (147, 880)
PROGRESS_CHEST = (68, 278)  # spin-count chest (0/5)


def open_event_tab(ctx, tab, title):
    """Events -> the tab whose icon template is `tab`. True when `title` shows."""
    if not ctx.home():
        return False
    ctx.d.tap(*EVENTS_NAV)
    ctx.sleep(2)
    for swipe in [None] + [(100, 112, 450, 112)] * 3 + [(430, 112, 80, 112)] * 6:
        if swipe:
            ctx.d.swipe(*swipe, 800)
            ctx.sleep(1)
        img = ctx.shot()
        if ctx.v.has(img, title):
            return True
        for pos in ctx.v.find_all(img, tab, 0.8, region=(0, 60, 540, 90)):
            ctx.d.tap(*pos)
            ctx.sleep(1.5)
            if ctx.v.has(ctx.shot(), title):
                return True
    return False


def chips(img):
    import re
    from autopilot.jobs import _ocr
    m = re.search(r"\d+", _ocr(img, CHIP_BOX, "0123456789"))
    return int(m.group()) if m else None


def roulette(ctx, max_spins=50):
    """Hero Roulette: claim the free Lucky Chip Pack, then spin once per chip owned (chips
    only - never the CHF packs, never diamonds), and open the spin-count chest."""
    from autopilot.rewards import is_green
    if not open_event_tab(ctx, "roulette_tab", "roulette_title"):
        ctx.home()
        return 0
    ctx.d.tap(*CHIP_CHEST)
    ctx.sleep(1.5)
    img = ctx.shot()
    n = 0
    pos = ctx.v.find(img, "chip_free")
    if pos and is_green(img, pos):
        ctx.d.tap(*pos)
        ctx.sleep(1.5)
        ctx.d.tap(270, 886)  # "Tap anywhere to exit"
        ctx.sleep(1)
        ctx.log("roulette: free chip pack claimed")
        n += 1
    ctx.d.back()
    if ctx.wait_for("roulette_title", timeout=4) is None:
        ctx.home()
        return n
    spins = 0
    for _ in range(max_spins):
        img = ctx.shot()
        have = chips(img)
        if not have or not ctx.v.has(img, "spin1"):
            break  # no chips: Spin would offer chips for diamonds
        ctx.d.tap(*SPIN1)
        spins += 1
        for _ in range(10):  # spin animation, then the dark rewards card replaces the page
            ctx.sleep(1)
            if not ctx.v.has(ctx.shot(), "roulette_title"):
                break
        ctx.sleep(0.8)
        ctx.d.tap(270, 886)  # "Tap anywhere to exit"
        if ctx.wait_for("roulette_title", timeout=4) is None:
            break
    if spins:
        ctx.d.tap(*PROGRESS_CHEST)  # claims when a milestone is reached, else shows info
        ctx.sleep(1.5)
        if not ctx.v.has(ctx.shot(), "roulette_title"):
            ctx.d.tap(270, 886)
            ctx.sleep(1)
        ctx.log(f"roulette: {spins} spin(s)")
    ctx.home()
    return n + spins


def city(ctx, params):
    n = 0
    if params.get("panel", True):
        n += collect_panel(ctx)
    if params.get("recruit", True):
        n += recruit(ctx)
    if params.get("roulette", True):
        n += roulette(ctx)
    if params.get("trial", True):
        n += mystic_trial(ctx, who=params.get("_who", "default"))
    if params.get("conquest", True):
        n += conquest(ctx, fight=params.get("story", True))
    if params.get("rebel", True):
        n += rebel(ctx)
    if params.get("heal", True):
        n += heal(ctx, ask_help=params.get("ask_help", True))
    return n
