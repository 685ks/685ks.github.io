"""Runs the schedule in a background thread: one character session at a time."""
import math
import queue
import random
import threading
import time

from autopilot import scheduler

class Cancelled(BaseException):
    """Raised inside a running job when Stop is pressed. A BaseException, so the jobs' own
    `except Exception` error handling can't swallow it."""


ARENA_HOLD = 15 * 60  # s before the arena start when no new session starts
RETRY_OFFLINE = 15 * 60  # s before retrying a character whose instance isn't running
TERROR_CHUNKS = 3  # with "spread", a session does about a third of what's left today


def _intel(dev, ch, params, log):
    from intel_adb import intel_flow
    from intel_adb.vision import Vision
    form = str(params.get("formation", "Equalize"))
    preset = int(form.split()[-1]) if form.startswith("Preset") else None
    res = intel_flow.run(dev, Vision(intel_flow.TEMPLATE_DIR), preset=preset,
                         sleep=getattr(dev, "isleep", time.sleep),
                         bounties=params.get("bounties", "Only if likely to prevail"),
                         attack_grey=bool(params.get("attack_grey", True)),
                         max_marches=int(params.get("march_slots", 0) or 0) or None)
    log(f"intel: {res.reason} {res.done}")
    return sum(v for k, v in res.done.items() if k not in ("skipped",))


def _terrors(dev, ch, params, log, todo):
    from intel_adb.vision import Vision
    from terror_adb import terror
    return terror.Terror(dev, Vision(terror.TEMPLATE_DIR), preset=terror.parse_preset(params["preset"]),
                         use_meat=bool(params.get("use_meat", False)),
                         at_once=int(params.get("at_once", 1)),
                         sleep=getattr(dev, "isleep", time.sleep)).run(todo)


def _ctx(dev, log):
    from autopilot import jobs
    from intel_adb.vision import Vision
    return jobs.Ctx(dev, Vision(jobs.TEMPLATE_DIR), log=log, sleep=getattr(dev, "isleep", time.sleep))


def utc_ts(text):
    """'2026-10-08 00:05' (UTC) -> epoch seconds; blank/invalid -> None."""
    from datetime import datetime, timezone
    try:
        return datetime.strptime(text.strip(), "%Y-%m-%d %H:%M").replace(tzinfo=timezone.utc).timestamp()
    except (ValueError, AttributeError):
        return None


def _claim(dev, ch, params, log):
    from autopilot import growth, jobs
    ctx = _ctx(dev, log)
    n = jobs.claim(ctx, params)
    if params.get("meat", True):
        n += growth.meat(ctx, params)
    return n


def _hunt(dev, ch, params, log):
    from autopilot import growth
    p = dict(params)
    p["formation"] = str(p.get("formation", "Equalize")).replace("Preset ", "")
    return growth.hunt(_ctx(dev, log), p)


def _research(dev, ch, params, log):
    from autopilot import growth
    return growth.research(_ctx(dev, log), params)


def _rewards(dev, ch, params, log):
    from autopilot import rewards
    return rewards.rewards(_ctx(dev, log), params)


def _alliance(dev, ch, params, log):
    from autopilot import city, jobs
    ctx = _ctx(dev, log)
    helped = city.help_all(ctx) if params.get("help", True) else 0
    return helped + jobs.alliance(ctx, params)


def _build(dev, ch, params, log):
    from autopilot import building
    return building.upgrade(_ctx(dev, log), ask_help=params.get("ask_help", True))


def _arena(dev, ch, params, log):
    from autopilot import arena
    return arena.arena(_ctx(dev, log), tag_hint=ch.tag, buy=bool(params.get("buy_extra", True)),
                       max_gems=int(params.get("max_gems", 2100)))


EVENTS = {}  # character key -> [(start epoch, name)] from its last Task List read


def _gather(dev, ch, params, log):
    from autopilot import gathering
    found = []
    n = gathering.gather(dev, params, log=log, sleep=getattr(dev, "isleep", time.sleep), events_out=found)
    if params.get("avoid_events", True):
        EVENTS[ch.key] = found
    return n


def _recall(dev, ch, params, log):
    """Timed: recall this character's gatherers just before an event."""
    from gather_adb import gather as G
    from intel_adb.vision import Vision
    g = G.Gather(dev, Vision(G.TEMPLATE_DIR), sleep=getattr(dev, "isleep", time.sleep))
    n = g.recall_all()
    g.to_map()
    log(f"recalled {n} gatherer(s) before the event")
    return n


def _blizzard(dev, ch, params, log):
    from autopilot import blizzard
    return blizzard.blizzard(_ctx(dev, log), params)


def _city(dev, ch, params, log):
    from autopilot import city
    return city.city(_ctx(dev, log), params)


def _train(dev, ch, params, log):
    from autopilot import jobs
    p = dict(params)
    if p.get("mode") == "Finish by":
        p["finish_by"] = utc_ts(p.get("finish_by", ""))
        if not p["finish_by"]:
            log("train: 'Finish by' needs a time like 2026-10-08 00:05 (UTC) - skipped")
            return 0
    p["hold_until"] = utc_ts(p.get("hold_until", "")) or 0
    return jobs.train(_ctx(dev, log), p)


DEFAULT_RUNNERS = {"intel": _intel, "terrors": _terrors, "claim": _claim, "rewards": _rewards, "city": _city, "build": _build, "arena": _arena, "blizzard": _blizzard, "gather": _gather,
                   "alliance": _alliance, "train": _train,
                   "hunt": _hunt, "research": _research}
AVAILABLE_JOBS = set(DEFAULT_RUNNERS)
DEFAULT_RUNNERS_EXTRA = {"_recall": _recall}  # timed helpers that aren't jobs of their own


def _switch(dev, ch):
    from autopilot.characters import TEMPLATE_DIR, Switcher
    from intel_adb.vision import Vision
    sw = Switcher(dev, Vision(TEMPLATE_DIR), log=dev.log)
    ok = sw.switch(ch.name, ch.kingdom, tag=ch.tag, power=ch.power)
    learn(ch, getattr(sw, "matched", None), dev.log)
    return ok


def learn(ch, row, log=print):
    """Remember what the Characters list showed for this character: its power (to spot a
    rename next time) and, when it was recognised by power, its new name and tag."""
    from autopilot.characters import same_name
    if row is None:
        return False
    changed = False
    if row.power and row.power != ch.power:
        ch.power, changed = row.power, True
    if row.name and not same_name(row.name, ch.name):
        log(f"character renamed: {ch.name} -> {row.name}")
        ch.name, changed = row.name, True
    if row.tag and row.tag != ch.tag:
        ch.tag, changed = row.tag, True
    return changed


def _connect(instance):
    from intel_adb.adb import discover
    devs = discover(only=instance)
    return devs[0] if devs else None


class Engine:
    def __init__(self, settings, st, connect=_connect, runners=None, now=time.time):
        self.settings, self.state = settings, st
        self.connect = connect
        self.runners = dict(DEFAULT_RUNNERS if runners is None else runners)
        self.now = now
        self.sleep = time.sleep
        self.switch = _switch
        self.active = {}  # instance -> key of the character this app last logged in
        self.on_log = print
        self.on_change = lambda: None
        self.running = False
        self.running_keys = set()  # characters with a session running now
        self._stop = threading.Event()
        self._manual = queue.Queue()
        self._thread = None
        self._workers = {}  # instance -> session thread

    def log(self, msg):
        try:
            self.on_log(msg)
        except Exception:
            pass

    def _changed(self):
        try:
            self.on_change()
        except Exception:
            pass

    # ---- one session -----------------------------------------------------
    def run_session(self, ch):
        st, sch = self.state, self.settings.schedule
        self.running_keys.add(ch.key)
        self._changed()
        self.log(f"▶ {ch.key}")
        dev = None
        try:
            dev = self.connect(ch.instance)
        except Exception as e:
            self.log(f"  can't connect: {e!r}")
        if not dev:
            self.log(f"  {ch.instance} is not running Kingshot - retry in {RETRY_OFFLINE // 60} min")
            st.set_next_run(ch.key, self.now() + RETRY_OFFLINE)
            self._finish(ch, "instance not running")
            return
        dev.log = lambda m, k=ch.key: self.log(f"  {m}")
        self._guard(dev, sch)
        try:
            self._session_body(ch, dev, st, sch)
        except Cancelled:
            self.log("  stopped")
            self._finish(ch, "stopped")

    def _guard(self, dev, sch):
        """Every screenshot/tap/key first checks Stop (so a running job ends within a step);
        taps also get a human-like random pause."""
        def checked(fn, pause=False):
            def wrapper(*a, **k):
                if self._stop.is_set():
                    raise Cancelled()
                if pause:
                    self.sleep(random.uniform(sch.tap_pause_min, sch.tap_pause_max))
                    if self._stop.is_set():
                        raise Cancelled()
                return fn(*a, **k)
            return wrapper
        for name in ("screencap", "tap", "back", "swipe", "type_text"):
            if hasattr(dev, name):
                setattr(dev, name, checked(getattr(dev, name), pause=name == "tap"))

        def isleep(seconds):  # a wait that ends the moment Stop is pressed
            if self._stop.wait(max(0.0, seconds)):
                raise Cancelled()
        dev.isleep = isleep

    def _session_body(self, ch, dev, st, sch):
        if ch.kingdom is not None and self.active.get(ch.instance) != ch.key:
            ok = False
            try:
                ok = self.switch(dev, ch)
                self._save_settings()  # keeps a learnt power / new name
            except Exception as e:
                self.log(f"  switch failed: {e!r}")
            if not ok:
                self.active.pop(ch.instance, None)
                self.log(f"  couldn't switch to {ch.label} - retry in {RETRY_OFFLINE // 60} min")
                st.set_next_run(ch.key, self.now() + RETRY_OFFLINE)
                self._finish(ch, "couldn't switch character")
                return
            self.active[ch.instance] = ch.key
        deadline = self.now() + sch.max_session_min * 60
        done = []
        for job_name, job in ch.jobs.items():
            if not job.enabled:
                continue
            if self._stop.is_set() or self.now() > deadline:
                self.log("  session time used up" if not self._stop.is_set() else "  stopped")
                break
            if job_name in ("arena", "blizzard"):
                continue  # timed: runs on its own just before the daily reset
            runner = self.runners.get(job_name)
            if not runner:
                self.log(f"  {job_name}: not built yet - skipped")
                continue
            try:
                if job_name == "terrors":
                    left = int(job.params["per_day"]) - st.count(ch.key, "terrors")
                    if left <= 0:
                        continue
                    todo = math.ceil(left / TERROR_CHUNKS) if job.params.get("spread") else left
                    n = runner(dev, ch, job.params, self.log, todo)
                else:
                    n = runner(dev, ch, job.params, self.log)
                st.add(ch.key, job_name, int(n or 0))
                done.append(f"{job_name} {n or 0}")
            except Exception as e:
                self.log(f"  {job_name} failed: {e!r}")
            st.save()
        st.set_next_run(ch.key, scheduler.next_run(self.now(), sch))
        self._finish(ch, ", ".join(done) or "nothing to do")

    def _save_settings(self):
        """Persist what a switch learnt (power, a new name after a rename)."""
        try:
            from autopilot import config
            config.save(self.settings)
        except Exception:
            pass

    def _finish(self, ch, summary):
        self.state.set_last(ch.key, f"Last run {time.strftime('%H:%M')}: {summary}")
        self.state.save()
        self.running_keys.discard(ch.key)
        self.log(f"■ {ch.key}: {summary}")
        self._changed()

    # ---- timed arena (user: play just before the daily reset) --------------
    def arena_plan(self):
        """{instance: character} for tonight's arena: the logged-in character when it has
        Arena on, otherwise the first character on that instance with Arena on."""
        plan = {}
        for ch in self.settings.characters:
            job = ch.jobs.get("arena")
            if not (ch.enabled and job and job.enabled):
                continue
            if ch.instance not in plan or self.active.get(ch.instance) == ch.key:
                plan[ch.instance] = ch
        return plan

    def arena_start(self):
        """Second of the UTC day the arena starts (first arena-enabled character's setting)."""
        for ch in self.settings.characters:
            job = ch.jobs.get("arena")
            if ch.enabled and job and job.enabled:
                h, m = map(int, str(job.params.get("start_utc", "23:56")).split(":"))
                early = int(self.state.data.get("_arena", {}).get("early_s", 0))
                return (h * 3600 + m * 60 - early) % 86400
        return None

    def arena_window(self, now=None):
        """'run' in the start minute(s), 'hold' in the 15 min before (no new sessions)."""
        start = self.arena_start()
        if start is None:
            return None
        t = (now if now is not None else self.now()) % 86400
        if start <= t < start + 120:
            return "run"
        hold = max(ARENA_HOLD, self.settings.schedule.max_session_min * 60 + 60)
        if start - hold <= t < start:  # a session started now could still run at the start
            return "hold"
        return None

    def run_arena(self):
        day = time.strftime("%Y-%m-%d", time.gmtime(self.now()))
        meta = self.state.data.setdefault("_arena", {})
        if meta.get("day") == day:
            return
        meta["day"] = day
        self.state.save()
        plan = self.arena_plan()
        self.log("Arena: " + (", ".join(c.label for c in plan.values()) or "nobody"))
        threads = [threading.Thread(target=self._arena_one, args=(ch,), daemon=True)
                   for ch in plan.values()]
        for th in threads:
            th.start()
        for th in threads:
            th.join()
        # too slow (ended after the reset or in its last 30 s): start a minute earlier from now on
        end = self.now() % 86400
        if end < 3600 or end > 86400 - 30:
            meta["early_s"] = int(meta.get("early_s", 0)) + 60
            self.log(f"Arena ended too close to the reset - starting {meta['early_s'] // 60} min "
                     "earlier from now on")
        self.state.save()

    def _arena_one(self, ch):
        try:
            dev = self.connect(ch.instance)
            if not dev:
                self.log(f"  arena: {ch.instance} not running")
                return
            dev.log = lambda m: self.log(f"  [{ch.instance}] {m}")
            self._guard(dev, self.settings.schedule)
            if ch.kingdom is not None and self.active.get(ch.instance) != ch.key:
                if not self.switch(dev, ch):
                    self.log(f"  arena: couldn't switch to {ch.label}")
                    return
                self.active[ch.instance] = ch.key
            n = self.runners["arena"](dev, ch, ch.jobs["arena"].params, dev.log)
            self.state.add(ch.key, "arena", int(n or 0))
            self.state.save()
        except Cancelled:
            pass
        except Exception as e:
            self.log(f"  arena failed on {ch.instance}: {e!r}")

    # ---- timed recall of gatherers before alliance events (Task List) ----------
    def recalls_due(self, now=None):
        """[(character, event start)] whose gatherers must come home now: within
        `recall_before` minutes of an event start, once per event."""
        t = now if now is not None else self.now()
        done = self.state.data.setdefault("_recalled", {})
        out = []
        for ch in self.settings.characters:
            job = ch.jobs.get("gather")
            if not (ch.enabled and job and job.enabled and job.params.get("avoid_events", True)):
                continue
            lead = int(job.params.get("recall_before", 5)) * 60
            for start, _name in EVENTS.get(ch.key, []):
                if start - lead <= t < start and done.get(ch.key) != start:
                    out.append((ch, start))
                    break
        return out

    def run_recall(self, ch, start):
        self.state.data.setdefault("_recalled", {})[ch.key] = start
        self.state.save()
        self.log(f"Recalling gatherers of {ch.label} before the event")
        self._timed_one(ch, "_recall")

    # ---- timed Blizzard Brawl (event slots 02/09/14/19 UTC) -------------------
    def blizzard_due(self, now=None):
        """The slot key ('2026-10-08 09') when a Blizzard slot is open and not yet played."""
        from autopilot import blizzard
        t = now if now is not None else self.now()
        hour = (t % 86400) / 3600
        if not blizzard.in_slot(hour):
            return None
        start = next(a for a, b in blizzard.SLOTS_UTC if a <= hour < b)
        if hour > start + 2 - 0.25:  # under 15 min left: a match wouldn't finish
            return None
        key = time.strftime("%Y-%m-%d ", time.gmtime(t)) + f"{start:02d}"
        if not any(c.enabled and c.jobs.get("blizzard") and c.jobs["blizzard"].enabled
                   for c in self.settings.characters):
            return None
        meta = self.state.data.setdefault("_blizzard", {})
        return None if meta.get("slot") == key else key

    def run_blizzard(self, key):
        meta = self.state.data.setdefault("_blizzard", {})
        meta["slot"] = key
        self.state.save()
        plan = {}
        for ch in self.settings.characters:
            job = ch.jobs.get("blizzard")
            if ch.enabled and job and job.enabled:
                if ch.instance not in plan or self.active.get(ch.instance) == ch.key:
                    plan[ch.instance] = ch
        self.log("Blizzard Brawl: " + ", ".join(c.label for c in plan.values()))
        threads = [threading.Thread(target=self._timed_one, args=(ch, "blizzard"), daemon=True)
                   for ch in plan.values()]
        for th in threads:
            th.start()
        for th in threads:
            th.join()

    def _timed_one(self, ch, job_name):
        try:
            dev = self.connect(ch.instance)
            if not dev:
                self.log(f"  {job_name}: {ch.instance} not running")
                return
            dev.log = lambda m: self.log(f"  [{ch.instance}] {m}")
            self._guard(dev, self.settings.schedule)
            if ch.kingdom is not None and self.active.get(ch.instance) != ch.key:
                if not self.switch(dev, ch):
                    self.log(f"  {job_name}: couldn't switch to {ch.label}")
                    return
                self.active[ch.instance] = ch.key
            n = 0
            params = ch.jobs[job_name].params if job_name in ch.jobs else ch.jobs["gather"].params
            runner = self.runners.get(job_name) or DEFAULT_RUNNERS_EXTRA[job_name]
            for _ in range(int(params.get("matches_per_slot", 1))):
                got = runner(dev, ch, params, dev.log)
                n += int(got or 0)
                if not got:
                    break
            self.state.add(ch.key, job_name, n)
            self.state.save()
        except Cancelled:
            pass
        except Exception as e:
            self.log(f"  {job_name} failed on {ch.instance}: {e!r}")

    # ---- background loop -------------------------------------------------
    @property
    def current(self):
        """Running characters as text (dashboard), or None."""
        return ", ".join(sorted(self.running_keys)) or None

    def busy_instances(self):
        """Instances with a session running right now (finished workers are dropped)."""
        for inst, th in list(self._workers.items()):
            if not th.is_alive():
                del self._workers[inst]
        return set(self._workers)

    def _start_session(self, ch):
        th = threading.Thread(target=self.run_session, args=(ch,), daemon=True)
        self._workers[ch.instance] = th
        th.start()

    def _loop(self):
        """One session per instance at a time, all instances in parallel. Timed jobs (arena,
        Blizzard Brawl) wait until every instance is free; a recall waits for its own."""
        while not self._stop.is_set():
            busy = self.busy_instances()
            window = self.arena_window()
            if not busy:
                if window == "run":
                    self.run_arena()
                bz = self.blizzard_due() if window is None else None
                if bz:
                    self.run_blizzard(bz)
            for ch, start in self.recalls_due():
                if ch.instance not in busy:
                    self.run_recall(ch, start)
            started = False
            waiting = []
            while True:  # manual "Run now" requests first
                try:
                    key = self._manual.get_nowait()
                except queue.Empty:
                    break
                ch = next((c for c in self.settings.characters if c.key == key), None)
                if ch is None:
                    continue
                if ch.instance in self.busy_instances():
                    waiting.append(key)  # that instance is busy: keep it for later
                else:
                    self._start_session(ch)
                    started = True
            for key in waiting:
                self._manual.put(key)
            if window != "hold" and self.settings.schedule.enabled \
                    and not scheduler.quiet_now(self.settings):
                while True:
                    ch = scheduler.pick_due(self.settings, self.state, self.now(),
                                            skip_instances=self.busy_instances())
                    if not ch:
                        break
                    self._start_session(ch)
                    started = True
            self._stop.wait(2 if started else 5)
        for th in list(self._workers.values()):
            th.join(timeout=30)
        self.running = False
        self._changed()

    def start(self):
        if self.running:
            return
        self._stop.clear()
        self.running = True
        self.log("Autopilot started")
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        if self.running:
            self.log("Autopilot stopping (finishes the current step)")
        self._stop.set()
        self.running = False

    def run_now(self, key):
        self._manual.put(key)
        if not self.running:
            self.start()
