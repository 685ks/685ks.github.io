"""Run Autopilot jobs once on the given instances, all at the same time (Kingshot Bots'
"Start Daily" button).

    python -m autopilot.run_jobs --only "685 #5 Ainz Ooal Gown" --jobs hunt,research,heal
        [--formation-for NAME=5] [--hunt-level Highest] [--hunt-attacks 10]

Jobs: mail, meat, conquest, troops (collect + train), heal, research, hunt.
"""
import argparse
import threading
import time

from intel_adb import adb
from intel_adb.vision import Vision

ORDER = ["mail", "meat", "conquest", "troops", "heal", "research", "hunt"]
STAGGER = 3  # s between instances starting


def run_one(dev, jobs_wanted, opts, log=None):
    from autopilot import city, growth, jobs
    log = log or dev.log
    ctx = jobs.Ctx(dev, Vision(jobs.TEMPLATE_DIR), log=log)
    done = {}
    for job in [j for j in ORDER if j in jobs_wanted]:
        try:
            if job == "mail":
                n = jobs.claim(ctx, {"mail": True, "alliance_gifts": False, "daily": False})
            elif job == "meat":
                n = growth.meat(ctx, {})
            elif job == "conquest":
                n = city.conquest(ctx, fight=False)
            elif job == "troops":
                n = jobs.train(ctx, {"mode": "Keep busy"})
            elif job == "heal":
                n = city.heal(ctx, ask_help=True)
            elif job == "research":
                n = growth.research(ctx, {"tree": "Growth", "fallback_any": True})
            elif job == "hunt":
                n = growth.hunt(ctx, {"level": opts.get("hunt_level", "Highest"),
                                      "max_attacks": opts.get("hunt_attacks", 10),
                                      "formation": opts.get("formation", "Equalize")})
            else:
                continue
            done[job] = n
        except Exception as e:  # one job failing must not stop the rest
            log(f"{job}: error - {e!r}")
            ctx.home()
    log("done: " + ", ".join(f"{k} {v}" for k, v in done.items()))
    return done


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--only", action="append")
    ap.add_argument("--jobs", default=",".join(ORDER))
    ap.add_argument("--formation-for", action="append", default=[], help="NAME=N (hunting formation)")
    ap.add_argument("--hunt-level", default="Highest")
    ap.add_argument("--hunt-attacks", type=int, default=10)
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args(argv)
    wanted = {j.strip() for j in a.jobs.split(",") if j.strip()}
    forms = dict(x.split("=", 1) for x in a.formation_for if "=" in x)
    devices = adb.discover(only=a.only, dry_run=a.dry_run)
    if not devices:
        print("No instance with Kingshot open.")
        return
    print(f"Daily jobs ({', '.join(j for j in ORDER if j in wanted)}) on: "
          + ", ".join(d.name for d in devices), flush=True)
    threads = []
    for d in devices:
        opts = {"formation": forms.get(d.name, "Equalize"), "hunt_level": a.hunt_level,
                "hunt_attacks": a.hunt_attacks}
        t = threading.Thread(target=run_one, args=(d, wanted, opts))
        t.start()
        threads.append(t)
        time.sleep(STAGGER)
    for t in threads:
        t.join()


if __name__ == "__main__":
    main()
