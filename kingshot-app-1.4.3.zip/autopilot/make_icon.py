"""Draws the Kingshot Autopilot icon (autopilot/icon.ico + icon.png): an amber crown on a
dark shield, circled by an 'autopilot' loop arrow."""
import math
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter

S = 1024
OUT = Path(__file__).parent


def lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(len(a)))


def main():
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))

    # background: rounded square with a diagonal night-blue gradient
    bg = Image.new("RGBA", (S, S))
    px = bg.load()
    top, bottom = (40, 48, 92), (12, 14, 30)
    for y in range(S):
        for x in range(S):
            px[x, y] = lerp(top, bottom, min(1, (x * 0.35 + y) / (S * 1.2))) + (255,)
    mask = Image.new("L", (S, S), 0)
    ImageDraw.Draw(mask).rounded_rectangle((24, 24, S - 24, S - 24), radius=220, fill=255)
    img.paste(bg, (0, 0), mask)

    # loop arrow (autopilot): thick amber arc with an arrow head, soft glow
    glow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    g = ImageDraw.Draw(glow)
    box = (150, 150, S - 150, S - 150)
    amber, amber_dark = (255, 196, 64), (230, 140, 20)
    g.arc(box, start=-60, end=230, fill=amber + (255,), width=58)
    cx = cy = S / 2
    r = (S - 300) / 2
    a = math.radians(-60)  # arrow tip at the arc's start, pointing clockwise
    tip = (cx + r * math.cos(a), cy + r * math.sin(a))
    tangent = a - math.pi / 2  # counter-clockwise direction
    head = [
        (tip[0] + 95 * math.cos(tangent + math.pi), tip[1] + 95 * math.sin(tangent + math.pi)),
        (tip[0] + 70 * math.cos(a), tip[1] + 70 * math.sin(a)),
        (tip[0] - 70 * math.cos(a), tip[1] - 70 * math.sin(a)),
    ]
    g.polygon(head, fill=amber + (255,))
    blurred = glow.filter(ImageFilter.GaussianBlur(28))
    img.alpha_composite(blurred)
    img.alpha_composite(glow)

    # shield
    d = ImageDraw.Draw(img)
    sx, sy, sw, sh = S / 2, 290, 360, 470
    shield = [(sx - sw / 2, sy), (sx + sw / 2, sy), (sx + sw / 2, sy + sh * 0.58),
              (sx, sy + sh), (sx - sw / 2, sy + sh * 0.58)]
    d.polygon(shield, fill=(26, 32, 66, 255), outline=amber + (255,), width=16)

    # crown on the shield
    cy0, cw = 395, 230
    base_y = cy0 + 160
    crown = [(sx - cw / 2, base_y), (sx - cw / 2, cy0 + 30), (sx - cw / 4, cy0 + 90),
             (sx, cy0), (sx + cw / 4, cy0 + 90), (sx + cw / 2, cy0 + 30), (sx + cw / 2, base_y)]
    d.polygon(crown, fill=amber + (255,))
    d.rectangle((sx - cw / 2, base_y, sx + cw / 2, base_y + 38), fill=amber_dark + (255,))
    for px_, py_ in [(sx - cw / 2, cy0 + 22), (sx, cy0 - 10), (sx + cw / 2, cy0 + 22)]:
        d.ellipse((px_ - 20, py_ - 20, px_ + 20, py_ + 20), fill=(255, 236, 160, 255))
    d.ellipse((sx - 22, base_y - 70, sx + 22, base_y - 26), fill=(200, 60, 70, 255))  # ruby

    img.save(OUT / "icon.png")
    img.save(OUT / "icon.ico", sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
    print(OUT / "icon.ico")


if __name__ == "__main__":
    main()
