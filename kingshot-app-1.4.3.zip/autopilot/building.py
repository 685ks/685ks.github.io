"""Building upgrades: follow the game's own suggestion (bottom-left bar "Upgrade X to Lv. N"),
recorded 2026-10-08 on Primary (tests/fixtures/city/bld_*).

Flow: city -> tap the suggestion bar -> the building's menu opens with a hand on Upgrade ->
upgrade window -> teal Upgrade (resources) when every requirement is ticked -> tap the
handshake bubble to ask the alliance for help.

Safety: never speed-ups (user, 2026-10-08) - when the builder is busy the hand points at
Speedups instead, so the menu must show "Upgrade" before anything is tapped; never Finish
(diamonds); no tap when a requirement is missing (that path leads to buy-resource offers)."""
import cv2

from autopilot import city

SUGGEST_BAR = (180, 788)
UPGRADE_HEX_ABOVE_LABEL = 38  # px from the "Upgrade" label up to its hexagon button
REQ_TICKS = (330, 455, 60, 220)  # x, y, w, h: the requirements' tick column
MENU_AREA = (0, 120, 540, 600)  # building menus; excludes the suggestion bar (its text says "Upgrade")


def requirements_met(img):
    """No red cross in the requirements' tick column (and at least one green tick)."""
    x, y, w, h = REQ_TICKS
    hsv = cv2.cvtColor(img[y:y + h, x:x + w], cv2.COLOR_BGR2HSV)
    green = cv2.inRange(hsv, (40, 100, 100), (85, 255, 255)).mean() / 255
    red = (cv2.inRange(hsv, (0, 150, 120), (8, 255, 255))
           | cv2.inRange(hsv, (172, 150, 120), (180, 255, 255))).mean() / 255
    return green > 0.01 and red < 0.003


def upgrade(ctx, ask_help=True):
    """Start the suggested building upgrade. Returns 1 when one was started."""
    if not city.to_city(ctx):
        return 0
    img = ctx.shot()
    pos = ctx.v.find(img, "suggest_bar")
    if not pos:
        ctx.log("build: no suggestion bar")
        return 0
    ctx.d.tap(*SUGGEST_BAR)
    label = None
    for _ in range(8):  # the menu pops up with an animation
        ctx.sleep(0.6)
        img = ctx.shot()
        if ctx.v.find_all(img, "speedups_label", 0.8, region=MENU_AREA):
            ctx.log("build: builder busy")
            ctx.home()
            return 0
        hits = ctx.v.find_all(img, "upgrade_label", 0.8, region=MENU_AREA)
        if hits:
            label = hits[0]
            break
    if not label:
        ctx.log("build: suggestion isn't an upgrade - skipped")
        ctx.home()
        return 0
    ctx.d.tap(label[0], label[1] - UPGRADE_HEX_ABOVE_LABEL)
    img = ctx.wait_for("requirements", timeout=4)
    if img is None:
        ctx.log("build: upgrade window didn't open")
        ctx.home()
        return 0
    if not requirements_met(img):
        ctx.log("build: requirements not met (resources or another building) - waiting")
        ctx.home()
        return 0
    if not ctx.tap_t(img, "upgrade_win_button"):
        ctx.home()
        return 0
    ctx.sleep(2)
    img = ctx.shot()
    if ctx.v.has(img, "requirements"):  # still open: the game refused
        ctx.log("build: upgrade refused")
        ctx.home()
        return 0
    ctx.log("build: upgrade started")
    if ask_help:
        pos = ctx.v.find(img, "heal_help")  # the same handshake bubble
        if pos:
            ctx.d.tap(*pos)
            ctx.sleep(1)
            ctx.log("build: asked the alliance for help")
    ctx.home()
    return 1
