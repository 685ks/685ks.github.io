"""Per-character progress for the current game day (resets at 00:00 UTC) and next-run times."""
import json
import threading
from datetime import datetime, timezone
from pathlib import Path

STATE_PATH = Path(__file__).parent / "state.json"
HISTORY_DAYS = 30


def game_day(now=None):
    now = now or datetime.now(timezone.utc)
    return now.astimezone(timezone.utc).strftime("%Y-%m-%d")


class State:
    def __init__(self, path=STATE_PATH):
        self.path = Path(path)
        self.data = json.loads(self.path.read_text(encoding="utf-8")) if self.path.exists() else {}
        self.lock = threading.RLock()  # the engine writes while the dashboard reads

    def _ch(self, key):
        return self.data.setdefault(key, {"day": None, "counts": {}, "next_run": 0, "last": ""})

    def _today(self, key, now):
        ch = self._ch(key)
        day = game_day(now)
        if ch["day"] != day:
            if ch["day"] and ch["counts"]:  # keep finished days for the Statistics page
                hist = ch.setdefault("history", {})
                hist[ch["day"]] = ch["counts"]
                for old in sorted(hist)[:-HISTORY_DAYS]:
                    del hist[old]
            ch["day"], ch["counts"] = day, {}
        return ch

    def history(self, key, now=None):
        """{day: {job: count}} for the kept days plus today."""
        with self.lock:
            ch = self._today(key, now)
            out = dict(ch.get("history", {}))
            out[ch["day"]] = dict(ch["counts"])
            return out

    def count(self, key, job, now=None):
        with self.lock:
            return self._today(key, now)["counts"].get(job, 0)

    def add(self, key, job, n=1, now=None):
        with self.lock:
            ch = self._today(key, now)
            ch["counts"][job] = ch["counts"].get(job, 0) + n

    def next_run(self, key):
        with self.lock:
            return self._ch(key)["next_run"]

    def set_next_run(self, key, ts):
        with self.lock:
            self._ch(key)["next_run"] = ts

    def set_last(self, key, text):
        with self.lock:
            self._ch(key)["last"] = text

    def last(self, key):
        with self.lock:
            return self._ch(key)["last"]

    def save(self):
        with self.lock:  # sessions on several instances save at the same time
            text = json.dumps(self.data, indent=2)
            tmp = self.path.with_suffix(".tmp")
            tmp.write_text(text, encoding="utf-8")
            tmp.replace(self.path)
