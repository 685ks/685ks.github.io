"""Finder's Fusion player: taps the listed items from a per-scene position table
(autopilot/finders_maps/<scene>.json - the user's map + learnt spots).

Two bots in one team see the SAME names but in a different order (seen 2026-10-11), so the
work is split by where the item is in the scene: "top" takes items in the upper half,
"bottom" the lower half ("all" = everything). Both read all 6 names.

A wrong tap costs time, so each listed item is tapped once; if its name is still there
after a moment the spot is wrong - it isn't tapped again (logged for fixing the table).

    python -m autopilot.finders_play --only "685 #4 - R5 Kirigaya" --only Primary
"""
import argparse
import difflib
import hashlib
import json
import threading
import time
from pathlib import Path

from autopilot import finders as F
from autopilot.finders_learn import in_round

MAPS = Path(__file__).parent / "finders_maps"
SPLIT_Y = 400  # scene line between the "top" and "bottom" bot's items
CHECK_AFTER = 1.5  # s: a tapped name still listed after this = wrong spot


def load_table(scene):
    p = MAPS / f"{F._key(scene)}.json"
    if not p.exists():
        return {}
    return {F._key(n): tuple(v) for n, v in json.loads(p.read_text(encoding="utf-8")).items()}


def lookup(table, name):
    k = F._key(name)
    if k in table:
        return table[k]
    if len(k) < 4:
        return None  # short names must match exactly
    close = difflib.get_close_matches(k, list(table), n=1, cutoff=0.82)  # OCR slips
    return table[close[0]] if close else None


def mine(pos, rows):
    if rows == "top":
        return pos[1] < SPLIT_Y
    if rows == "bottom":
        return pos[1] >= SPLIT_Y
    return True


class SlotReader:
    """OCR of name buttons, cached by the button's pixels (only changed slots are read)."""

    def __init__(self):
        self.cache = {}

    def read(self, img):
        w, h = F.NAME_BOX
        out = []
        solo = F.is_solo(img)
        for x, y in (F.SOLO_SLOTS if solo else F.NAME_SLOTS):
            if solo and F.faded(img, x, y):  # solo: found names stay, struck through
                out.append("")
                continue
            crop = img[y - h // 2:y + h // 2, x - w // 2:x + w // 2]
            key = hashlib.md5(crop[::2, ::2].tobytes()).hexdigest()
            if key not in self.cache:
                self.cache[key] = F.names_one(crop)
            out.append(self.cache[key])
        return out


LEARN_EVERY = 0.25  # s between frames kept for learning


def learn_from_round(scene, kept, log=print):
    """Run the learner on a played round (in the background) and update the scene's table."""
    import cv2
    import numpy as np
    from autopilot import finders_build
    if not scene or len(kept) < 12:
        return
    frames = [cv2.imdecode(np.frombuffer(j, np.uint8), cv2.IMREAD_COLOR) for j, _ in kept]
    read = [r for _, r in kept]
    try:
        got = F.learn(frames, log=lambda m: None, read=read, scene=scene, save_crops=False)
        if got:
            table, _ = finders_build.add_sightings(scene, got)
            log(f"finders: learnt {len(got)} spots in {scene} - table now has {len(table)} items")
    except Exception as e:
        log(f"finders: learning failed: {e!r}")


def play_round(dev, rows="all", log=print, clock=time.monotonic, max_s=75, learn=True):
    """Play one round from its first frame until it ends. Returns the number of taps.
    Frames are kept (compressed) and learnt from afterwards, so new scenes fill in."""
    import cv2
    reader = SlotReader()
    table, scene = {}, None
    tapped = {}  # name -> time
    unknown, wrong, retried = set(), set(), set()
    kept, last_kept = [], -9.0
    n = 0
    end = clock() + max_s
    out_of_round = 0
    while clock() < end:
        img = dev.screencap()
        if not in_round(img):
            out_of_round += 1
            if out_of_round >= 3:
                break
            continue
        out_of_round = 0
        if scene is None:
            scene = F.scene_id(img)  # by picture: chapter numbers differ per instance
            table = load_table(scene)
            if table:
                log(f"finders: {scene}, {len(table)} items known, my half: {rows}")
            else:
                log(f"finders: '{scene}' is new - learning it this round (no taps)")
        now = clock()
        names_now = reader.read(img)
        if learn and hasattr(img, "shape") and now - last_kept >= LEARN_EVERY:
            ok, jpg = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, 90])
            if ok:
                kept.append((jpg.tobytes(), names_now))
                last_kept = now
        listed = [x for x in names_now if x]
        retry = []
        for name, t in list(tapped.items()):
            if name in listed and now - t > CHECK_AFTER and name not in wrong:
                if name not in retried:  # taps during a score animation get ignored: once more
                    retried.add(name)
                    retry.append(name)
                    tapped[name] = now
                    continue
                wrong.add(name)
                log(f"finders: '{name}' didn't go - its spot in the table is wrong")
        batch = [p for p in (lookup(table, r) for r in retry) if p]
        for name in listed:
            if name in tapped:
                continue
            pos = lookup(table, name)
            if pos is None:
                if table and name not in unknown:
                    unknown.add(name)
                    log(f"finders: '{name}' isn't in the table - left to the others")
                continue
            if not mine(pos, rows):
                continue
            batch.append(pos)
            tapped[name] = now
        if batch:
            dev.taps(batch)
            n += len(batch)
    log(f"finders: round over, {n} taps" + (f", wrong spots: {sorted(wrong)}" if wrong else ""))
    if learn and kept:
        threading.Thread(target=learn_from_round, args=(scene, kept, log), daemon=True).start()
    return n


def wait_and_play(dev, rows, rounds=20, log=print, stop=None):
    played = 0
    while played < rounds and not (stop and stop.is_set()):
        img = dev.screencap()
        if in_round(img):
            play_round(dev, rows, log=log, learn=rows in ("top", "all"))  # one learner per team
            played += 1
        else:
            time.sleep(0.3)
    return played


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", action="append")
    ap.add_argument("--rows", default="", help="comma list per instance, e.g. top,bottom")
    ap.add_argument("--rounds", type=int, default=20)
    a = ap.parse_args()
    from intel_adb import adb
    devs = adb.discover(only=a.only)
    if a.only:  # keep the order given on the command line
        devs.sort(key=lambda d: [o.lower() for o in a.only].index(d.name.lower()))
    rows = [r.strip() for r in a.rows.split(",") if r.strip()] or \
        (["all"] if len(devs) == 1 else ["top", "bottom"] + ["all"] * (len(devs) - 2))
    threads = []
    for d, r in zip(devs, rows):
        d.screencap()
        print(f"{d.name}: {r} half of the scene", flush=True)
        t = threading.Thread(target=wait_and_play, args=(d, r, a.rounds, d.log), daemon=True)
        t.start()
        threads.append(t)
    for t in threads:
        t.join()


if __name__ == "__main__":
    main()
