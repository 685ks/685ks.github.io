"""Growth jobs recorded 2026-10-15 on 685 #5 Ainz Ooal Gown (autopilot/recording_features):
beast hunting, academy research and the free Gourmet Feast meat.

Safety: only allow-listed buttons - Search, the orange Attack (stamina), Deploy, the teal
Research (never the orange diamond Finish), the green Gourmet Feast Claim (never Use, never
Buy & Use, never Go). "Go" on a beast popup ("defeat a lower level first") is never tapped:
the level goes down instead."""
import re

from intel_adb import popups
from intel_adb.intel_flow import PRESET_X, PRESET_Y
from autopilot.city import panel_row, pointed_target, to_city
from autopilot.jobs import _ocr

WORLD_BUTTON = (487, 925)
LEVEL_DOWN = (52, 790)
LEVEL_UP = (365, 790)
BEAST_LEVELS = 30  # taps of "+" to reach the top of the slider
AVATAR = (33, 33)
STAMINA_PLUS = (176, 834)  # "+" on the Governor Profile's stamina bar
GETMORE_CLOSE = (501, 108)
RESEARCH_POPUP_CLOSE = (478, 220)
HOOK_ROW_Y = 300  # unused guard: Gourmet Claim must sit in the first item row (y ~ 300)
BUBBLE_HSV = ((5, 60, 60), (25, 200, 120))  # research level bubbles ("2/3", "MAX")
TREE_UP = (270, 750, 270, 300)  # drag that shows later (lower) research nodes


# ---- shared ---------------------------------------------------------------------
def to_map(ctx):
    """Onto the world map (where the magnifier search is). True when there."""
    if not ctx.home():
        return False
    img = ctx.shot()
    if ctx.v.has(img, "map_magnify"):
        return True
    if ctx.v.has(img, "world_button"):
        ctx.d.tap(*WORLD_BUTTON)
        return ctx.wait_for("map_magnify", timeout=6) is not None
    return False


def _formation(ctx, preset):
    if preset in PRESET_X:
        ctx.d.tap(PRESET_X[preset], PRESET_Y)
        ctx.sleep(0.6)
    else:
        ctx.tap_t(ctx.shot(), "equalize_button")


# ---- beast hunting ------------------------------------------------------------------
def hunt(ctx, params):
    """Search beasts and attack while stamina lasts. params: level ("Highest" or 1..30),
    max_attacks, formation (preset number or "Equalize"), use_meat (False = stop when the
    stamina runs out). Returns the number of attacks sent."""
    level = params.get("level", "Highest")
    max_attacks = int(params.get("max_attacks", 10))
    preset = params.get("formation", "Equalize")
    preset = int(preset) if str(preset).isdigit() else None
    sent, lowered = 0, 0
    top = level in ("Highest", "", None)
    while sent < max_attacks:
        if not to_map(ctx):
            ctx.log("hunt: couldn't reach the world map")
            break
        ctx.tap_t(ctx.shot(), "map_magnify")
        img = ctx.wait_for("map_search", timeout=5)
        if img is None or not ctx.tap_t(img, "hunt_cat_beasts", 0.85):
            ctx.log("hunt: no Beasts search")
            break
        ctx.sleep(0.8)
        beaten = max_opponent(ctx.shot())
        cap = BEAST_LEVELS if top else int(level)
        want = min(cap, beaten + 1) if beaten else (1 if top else cap)
        want = max(1, want - lowered)
        ctx.log(f"hunt: beaten up to Lv.{beaten or '?'} - hunting Lv.{want} (limit {'none' if top else cap})")
        taps = [LEVEL_DOWN] * BEAST_LEVELS + [LEVEL_UP] * (want - 1)
        for pos in taps:
            ctx.d.tap(*pos, jitter=1)
            ctx.sleep(0.12)
        ctx.tap_t(ctx.shot(), "map_search")
        img = ctx.wait_for("hunt_title_beast", timeout=6)
        if img is None:
            ctx.log("hunt: no beast found")
            break
        if not ctx.v.has(img, "hunt_attack", 0.85):  # "defeat a Lv.N beast first" -> Go
            lowered += 1
            if lowered > BEAST_LEVELS:
                break
            ctx.d.back()
            ctx.sleep(1)
            continue
        ctx.tap_t(img, "hunt_attack", 0.85)
        img = ctx.wait_for("hunt_deploy", timeout=5)
        if img is None:
            shot = ctx.shot()
            if ctx.v.has(shot, "getmore_title"):  # out of stamina
                ctx.log("hunt: out of stamina")
                if params.get("use_meat") and meat(ctx, {}, from_getmore=True):
                    continue
                ctx.d.tap(*GETMORE_CLOSE)
                ctx.sleep(1)
                break
            ctx.log("hunt: no Deploy screen (all marches out?)")
            break
        _formation(ctx, preset)
        ctx.tap_t(ctx.shot(), "hunt_deploy")
        ctx.sleep(1.2)
        after = ctx.shot()
        if popups.handle_confirm(ctx.d, ctx.v, after):
            ctx.sleep(1)
            after = ctx.shot()
        if ctx.v.has(after, "hunt_deploy"):
            ctx.log("hunt: the game refused the march (no free march?)")
            ctx.home()
            break
        sent += 1
        ctx.log(f"hunt: beast attack {sent}/{max_attacks}")
    ctx.home()
    return sent


def max_opponent(img):
    """N from "Max opponent: Lv.N Beasts" under the level slider, or None."""
    text = _ocr(img, (150, 846, 240, 24), "MaxopentLvBsN.0123456789: ")
    got = re.search(r"Lv\.?\s*(\d{1,2})", text)
    return int(got.group(1)) if got else None


# ---- academy research --------------------------------------------------------------
def tree_nodes(img):
    """[(x, y, done, total)] of the research nodes on screen (from their level bubbles),
    top to bottom. MAX nodes are left out."""
    import cv2
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    m = cv2.inRange(hsv, *BUBBLE_HSV)
    m[:120] = 0
    n, _, st, _ = cv2.connectedComponentsWithStats(m)
    out = []
    for k in range(1, n):
        x, y, w, h, a = st[k]
        if not (35 <= w <= 60 and 15 <= h <= 25 and 300 <= a <= 1000):
            continue
        if y < 150:
            continue  # node cut off under the tabs
        text = _ocr(img, (int(x), int(y), int(w), int(h)), "0123456789/MAX")
        if "M" in text or "X" in text or not re.search(r"\d", text):
            continue  # MAX (or not a level bubble)
        got = re.search(r"(\d)\s*/\s*(\d)", text)  # "1/3" often reads as just "3"
        done, total = (int(got.group(1)), int(got.group(2))) if got else (None, None)
        if got and done >= total:
            continue
        out.append((int(x + w / 2), int(y - 40), done, total))
    return sorted(out, key=lambda n: n[1])


def research(ctx, params):
    """Start a research when the Academy is idle (via the queue panel's Tech Research row),
    then ask the alliance for help. params: tree ("Growth" / "Economy" / "Battle"),
    fallback_any. Returns 1 when a research was started."""
    pos = panel_row(ctx, "tech research")  # row titles are read lower-case
    if pos is None:
        ctx.log("research: no Tech Research row (busy, or the panel didn't open)")
        ctx.home()
        return 0
    ctx.d.tap(*pos)
    ctx.sleep(1.5)
    target = None
    for _ in range(5):
        img = ctx.shot()
        if ctx.v.has(img, "research_title"):
            break
        target = pointed_target(ctx.v, img)
        if target:
            ctx.d.tap(*target)
        elif ctx.tap_t(img, "academy_research", 0.85):
            pass
        ctx.sleep(1.5)
    if not ctx.v.has(ctx.shot(), "research_title"):
        ctx.log("research: the Tech Research screen didn't open")
        ctx.home()
        return 0
    tabs = {"Growth": (100, 88), "Economy": (270, 88), "Battle": (440, 88)}
    order = [params.get("tree", "Growth")] if params.get("tree", "Growth") in tabs else []
    if params.get("fallback_any", True) or not order:  # "Any" = every tree
        order += [t for t in tabs if t not in order]
    for tab in order:
        ctx.d.tap(*tabs.get(tab, tabs["Growth"]))
        ctx.sleep(1.2)
        for page in range(3):
            img = ctx.shot()
            if ctx.v.has(img, "research_help") or ctx.v.has(img, "speedups_label"):
                ctx.log("research: already researching")
                ctx.home()
                return 0
            for x, y, done, total in tree_nodes(img):
                ctx.d.tap(x, y)
                pop = ctx.wait_for("research_popup_btn", timeout=3)
                if pop is None:
                    continue
                ctx.tap_t(pop, "research_popup_btn")  # teal Research - never the diamond Finish
                ctx.sleep(1.5)
                img2 = ctx.shot()
                if ctx.v.has(img2, "research_help") or not ctx.v.has(img2, "research_popup_btn"):
                    ctx.log(f"research: started ({tab}, node at {x},{y} level {done}/{total})")
                    img2 = ctx.wait_for("research_help", timeout=3)
                    if img2 is not None and params.get("ask_help", True):
                        ctx.tap_t(img2, "research_help")
                        ctx.log("research: asked the alliance for help")
                    ctx.home()
                    return 1
                ctx.d.tap(*RESEARCH_POPUP_CLOSE)  # not enough resources: next node
                ctx.sleep(0.8)
            ctx.d.swipe(*TREE_UP, 600)
            ctx.sleep(1)
    ctx.log("research: nothing could be started")
    ctx.home()
    return 0


# ---- free meat -----------------------------------------------------------------
def meat(ctx, params, from_getmore=False):
    """Claim the free Gourmet Feast stamina (avatar -> stamina + -> Get More -> Claim).
    Returns 1 when claimed."""
    if not from_getmore:
        if not ctx.home():
            return 0
        ctx.d.tap(*AVATAR)
        img = ctx.wait_for("profile_title", timeout=5)
        if img is None:
            ctx.log("meat: governor profile didn't open")
            ctx.home()
            return 0
        ctx.d.tap(*STAMINA_PLUS)  # fixed spot (the template's background differs per account)
    img = ctx.wait_for("getmore_title", timeout=5)
    got = 0
    if img is not None:
        feast = ctx.v.find(img, "gourmet_feast", 0.85)
        claim = ctx.v.find(img, "gourmet_claim", 0.85)
        if feast and claim and abs(claim[1] - feast[1]) < 45:  # the Claim on the Feast's own row
            ctx.d.tap(*claim)
            ctx.sleep(1.5)
            got = 1
            ctx.log("meat: Gourmet Feast claimed")
        else:
            ctx.log("meat: Gourmet Feast not ready")
        ctx.d.tap(*GETMORE_CLOSE)
        ctx.sleep(1)
    if not from_getmore:
        ctx.home()
    return got
