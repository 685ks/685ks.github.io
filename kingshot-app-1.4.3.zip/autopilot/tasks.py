"""The in-game Task List (tap the UTC clock at the top of the city / map): alliance events
with their UTC start times, e.g. "Battle - Lv. 3 Scholar's Tower  UTC 12:25",
"Bear Hunt - Trap 1  UTC 14:30". Recorded 2026-10-08 on 685 #6 (tests/fixtures/tasklist*.png).

Rows sit under date headers ("2026/10/07", "Today", "2026/10/09"); the right side is a start
time, "Ended", or an arrow (running now)."""
import datetime as dt
import re
import time
from dataclasses import dataclass

import cv2

from intel_adb import timer

CLOCK = (180, 20)  # the UTC clock at the top
CLOSE = (512, 268)
LIST = (20, 330, 500, 630)  # x, y, w, h of the list area
SCROLL = (270, 850, 270, 450)


@dataclass(frozen=True)
class Task:
    day: str  # "2026-10-08"
    name: str  # "Bear Hunt - Trap 1", "Battle Lv. 3 Scholar's Tower"
    start: str  # "14:30", "" when running / ended
    status: str  # "upcoming" | "open" (arrow) | "ended"

    def start_utc(self):
        if not self.start:
            return None
        return dt.datetime.strptime(f"{self.day} {self.start}", "%Y-%m-%d %H:%M").replace(
            tzinfo=dt.timezone.utc)


def _words(img):
    if not timer.available():
        return []
    x0, y0, w, h = LIST
    g = cv2.resize(cv2.cvtColor(img[y0:y0 + h, x0:x0 + w], cv2.COLOR_BGR2GRAY), None, fx=2, fy=2,
                   interpolation=cv2.INTER_CUBIC)
    try:
        d = timer.pytesseract.image_to_data(g, config="--psm 11", output_type=timer.pytesseract.Output.DICT)
    except Exception:
        return []
    return [(t.strip(), x0 + (d["left"][k] + d["width"][k] // 2) // 2, y0 + (d["top"][k] + d["height"][k] // 2) // 2)
            for k, t in enumerate(d["text"]) if t.strip()]


def _row_name(img, y):
    """Event name from the row's left text block around y."""
    crop = img[max(0, y - 48):y + 22, 118:400]
    g = cv2.resize(cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY), None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
    try:
        text = timer.pytesseract.image_to_string(g, config="--psm 6")
    except Exception:
        return ""
    text = " ".join(text.split())
    if "bear" in text.lower():
        m = re.search(r"Bear\s*Hunt[^A-Za-z0-9]*Trap\s*(\d)", text, re.I)
        return f"Bear Hunt - Trap {m.group(1)}" if m else "Bear Hunt"
    m = re.search(r"Lv\.?\s*(\d+)\s+(.+)", text)
    return f"Battle Lv. {m.group(1)} {m.group(2).strip()}" if m else "Battle"


HEADER_COLOURS = ((139, 175, 198), (99, 157, 211))  # date bars (BGR): plain, "Today"


def _headers(img, today):
    """(y, 'YYYY-MM-DD') of the date bars on screen, found by their colour at both ends."""
    x0, y0, w, h = LIST
    out = []
    y = y0
    while y < y0 + h:
        hit = None
        for c in HEADER_COLOURS:
            if all(abs(int(a) - b) < 12 for a, b in zip(img[y, 60], c)) and \
                    all(abs(int(a) - b) < 12 for a, b in zip(img[y, 480], c)):
                hit = c
        if not hit:
            y += 2
            continue
        crop = img[y:y + 36, 140:400]  # y is the bar's top edge
        g = cv2.cvtColor(cv2.resize(crop, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC), cv2.COLOR_BGR2GRAY)
        _, b = cv2.threshold(g, 200, 255, cv2.THRESH_BINARY_INV)
        try:
            text = timer.pytesseract.image_to_string(b, config="--psm 7").strip()
        except Exception:
            text = ""
        m = re.search(r"(\d{4})\D?(\d{2})\D?(\d{2})", text)
        if m:
            out.append((y + 18, f"{m.group(1)}-{m.group(2)}-{m.group(3)}"))
        elif "oday" in text.lower() or hit == HEADER_COLOURS[1]:
            out.append((y + 18, today.isoformat()))
        y += 46  # past this bar
    return out


def read_screen(vision, img, today, carry_day=None):
    """Tasks visible on one screen of the list. `today` is a date; returns (tasks, last day)."""
    words = _words(img)
    headers = _headers(img, today)

    def day_at(y):
        above = [d for hy, d in headers if hy < y]
        return above[-1] if above else carry_day

    anchors = []
    for t, x, y in words:
        if x > 400 and re.fullmatch(r"\d{1,2}:\d{2}", t):
            anchors.append((y, t.zfill(5), "upcoming"))
        elif x > 400 and t.lower().startswith("ended"):
            anchors.append((y, "", "ended"))
    for x, y in vision.find_all(img, "task_arrow", 0.8, region=(400, 330, 140, 630)):
        anchors.append((y, "", "open"))  # arrow: "go there" - also on past days, not a time
    tasks = []
    for y, start, status in sorted(anchors):
        day = day_at(y)
        if day is None:
            continue
        tasks.append(Task(day, _row_name(img, y), start, status))
    return tasks, (headers[-1][1] if headers else carry_day)


def read_task_list(ctx, now=None, screens=6):
    """Open the Task List, read every row, close it. Returns a list of Tasks."""
    now = now or dt.datetime.now(dt.timezone.utc)
    if not ctx.home():
        return []
    ctx.d.tap(*CLOCK)
    img = ctx.wait_for("tasklist_title", timeout=4)
    if img is None:
        ctx.log("tasks: Task List didn't open")
        return []
    seen, carry, last = [], None, None
    for _ in range(screens):
        found, carry = read_screen(ctx.v, img, now.date(), carry)
        for t in found:
            if t not in seen:
                seen.append(t)
        ctx.d.swipe(*SCROLL, 900)
        ctx.sleep(1.0)
        img = ctx.shot()
        small = cv2.resize(img[330:960], (54, 63))
        if last is not None and cv2.absdiff(small, last).mean() < 2:
            break  # list didn't move: end
        last = small
    ctx.d.tap(*CLOSE)
    ctx.sleep(0.8)
    return seen


DEFAULT_MINUTES = {"Bear Hunt": 30, "Battle": 60}


def conflict(tasks, now, lead_min=5, minutes=None):
    """The task that blocks gathering now (starting within `lead_min` minutes, or still
    inside its duration), else None."""
    minutes = minutes or DEFAULT_MINUTES
    for t in tasks:
        start = t.start_utc()
        if start is None:
            continue
        dur = minutes.get("Bear Hunt" if t.name.startswith("Bear") else "Battle", 60)
        if start - dt.timedelta(minutes=lead_min) <= now < start + dt.timedelta(minutes=dur):
            return t
    return None
