"""Build finders_maps/<scene>.json from learnt sightings (observed_<scene>.json).

Per item: the biggest group of sightings within 25 px of each other (2+ sightings) wins.
For the Dock (first scene, 2026-10-11) the user's map fills the gaps.
Spots where a red X (wrong tap) was seen are dropped.

    python -m autopilot.finders_build [scene]
"""
import json
import sys
import threading
from pathlib import Path

MAPS = Path(__file__).parent / "finders_maps"
NEAR = 25
_lock = threading.Lock()

# Dock: circle centres from the user's map screenshot (900x2000), mapped with a fitted transform
MAP_IMG = {'dock': {'Kite': (183, 330), 'Hot Air Balloon': (472, 355), 'Z': (588, 405), 'Window': (673, 405),
           'Lighthouse': (425, 515), 'Sailboat': (193, 548), 'Whale': (310, 605), 'Pulley Crane': (497, 605),
           'Diner Sign': (672, 580), 'Paw Mark': (838, 662), 'Patio Umbrella': (318, 750),
           'Trident': (765, 772), 'Pouch': (820, 812), 'Basket': (505, 865), 'Chair': (395, 815),
           'Beach Ball': (135, 855), 'Sea Turtle': (252, 910), 'Cat': (425, 968), 'Oar': (688, 945),
           'Jar': (850, 930), 'Banner': (82, 1022), 'Potatoes': (235, 1142), 'Fish': (333, 1150),
           'Ship Wheel': (487, 1068), 'Fishing Net': (115, 1190), 'Propeller': (367, 1245),
           'Leaf': (450, 1240), 'Telescope': (588, 1225), 'Meat': (672, 1430), 'Gloves': (740, 1595)}}
AX = (4.88855414e-01, -9.76429127e-03, 4.54486871e+01)
AY = (-8.95943479e-03, 4.91057782e-01, -3.82463311e+01)
EXTRA = {'dock': {'Octopus': (360, 475)}}  # seen on a live screen
FIXED = {'dock': {'Gloves': [432, 740]},
         'cafes': {  # checked by eye on a real frame + the Day 3 guide (2026-10-13)
             'Arrow Sign': [150, 303], 'Target': [153, 361], 'Chandelier': [253, 328],
             'Yarn Ball': [103, 590], 'Diary': [66, 653], 'Pocket Watch': [290, 603],
             'Quill': [294, 666], 'Key': [181, 760], 'Music Note': [381, 656], 'Ring': [228, 612],
             'Fork': [381, 734], 'Cheese': [381, 428], 'Lollipop': [409, 463], 'Cake': [206, 695],
             'Corn': [312, 466], 'Apple': [440, 679], 'Hot Air Balloon': [384, 190],
             'Headwear': [180, 205], 'N': [182, 256], 'Picture Frame': [78, 366], 'Broom': [197, 353],
             'Flour': [260, 449], 'Scarf': [255, 530], 'Car': [359, 553], 'Envelope': [361, 601], 'Crown': [431, 619]},
         'inn': {'Axe': [275, 727], 'Clothes Hanger': [228, 335], 'Gramophone': [346, 458]}}  # by eye  # checked by eye (the learner mixed it up with Basket)
BAD = {'dock': {'Seahorse': [(367, 326)], 'Beach Ball': [(103, 380)], 'Meat': [(360, 658)]}}


def key(scene):
    import re
    return re.sub(r"[^a-z0-9]", "", scene.lower())


def from_map(p):
    x, y = p
    return [round(AX[0] * x + AX[1] * y + AX[2]), round(AY[0] * x + AY[1] * y + AY[2])]


def cluster(points):
    best = []
    for p in points:
        group = [q for q in points if abs(q[0] - p[0]) <= NEAR and abs(q[1] - p[1]) <= NEAR]
        if len(group) > len(best):
            best = group
    if len(best) < 2:
        return None, len(best)
    return [round(sum(q[0] for q in best) / len(best)), round(sum(q[1] for q in best) / len(best))], len(best)


def observed_path(scene):
    return MAPS / f"observed_{key(scene)}.json"


def add_sightings(scene, learnt):
    """Append {name: (x, y)} from one round, then rebuild that scene's table."""
    with _lock:
        MAPS.mkdir(exist_ok=True)
        p = observed_path(scene)
        data = json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
        for n, pos in learnt.items():
            data.setdefault(n, []).append(list(pos))
        p.write_text(json.dumps(data, indent=1), encoding="utf-8")
        return build(scene)


def add_round(scene):
    """Count a learnt round for this scene (finders_maps/rounds.json)."""
    with _lock:
        p = MAPS / "rounds.json"
        data = json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
        data[key(scene)] = data.get(key(scene), 0) + 1
        p.write_text(json.dumps(data, indent=1), encoding="utf-8")


def rounds_seen(scene):
    p = MAPS / "rounds.json"
    return json.loads(p.read_text(encoding="utf-8")).get(key(scene), 0) if p.exists() else 0


def build(scene="Dock"):
    k = key(scene)
    p = observed_path(scene)
    seen = json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
    maps, extra, fixed, bad = MAP_IMG.get(k, {}), EXTRA.get(k, {}), FIXED.get(k, {}), BAD.get(k, {})
    lp = MAPS / f"{k}_labels.json"  # spots from a labelled screenshot, in game coordinates
    labels = json.loads(lp.read_text(encoding="utf-8")) if lp.exists() else {}
    out, report = {}, []
    single = rounds_seen(scene) == 1  # only one round so far: trust single sightings
    for n in sorted(set(seen) | set(maps) | set(extra) | set(labels) | set(fixed)):
        pos, cnt = cluster(seen.get(n, []))
        src = f"seen x{cnt}"
        if pos is None and single and len(seen.get(n, [])) == 1:
            pos, src = list(seen[n][0]), "seen once (1 round so far)"
        if n in labels:
            lab = labels[n]
            near = [q for q in seen.get(n, []) if abs(q[0] - lab[0]) <= 35 and abs(q[1] - lab[1]) <= 35]
            if pos is None or abs(pos[0] - lab[0]) > 35 or abs(pos[1] - lab[1]) > 35:
                # a sighting that agrees with the label is more precise; else trust the label
                pos = ([round(sum(q[0] for q in near) / len(near)), round(sum(q[1] for q in near) / len(near))]
                       if near else list(lab))
                src = f"label+seen x{len(near)}" if near else "label"
        if n in fixed:
            pos, src = list(fixed[n]), "fixed"
        if pos is None:
            pos = from_map(maps[n]) if n in maps else (list(extra[n]) if n in extra else None)
            src = "map" if n in maps else "screen"
        if pos is None:
            continue
        if any(abs(pos[0] - b[0]) <= 8 and abs(pos[1] - b[1]) <= 8 for b in bad.get(n, [])):
            report.append(f"{n}: dropped (wrong tap seen there)")
            continue
        out[n] = pos
        report.append(f"{n}: {pos} ({src})")
    MAPS.mkdir(exist_ok=True)
    (MAPS / f"{k}.json").write_text(json.dumps(out, indent=1), encoding="utf-8")
    return out, report


if __name__ == "__main__":
    out, rep = build(sys.argv[1] if len(sys.argv) > 1 else "Dock")
    print("\n".join(rep))
    print(len(out), "items")
