"""Autopilot "Gather resources" job: keep `marches` gathering marches out, using the
gather bot (gather_adb) that runs the nightly gather reset.

Resource "Any" spreads the marches over Bread, Wood, Stone and Iron, starting with the type
that has the fewest gatherers out."""
import re
import time

KINDS = ("Bread", "Wood", "Stone", "Iron")


def plan(resource, have_by_kind, missing):
    """Which resource each new march gathers."""
    if resource in KINDS:
        return [resource] * missing
    counts = {k: have_by_kind.get(k, 0) for k in KINDS}
    out = []
    for _ in range(missing):
        k = min(KINDS, key=lambda k: (counts[k], KINDS.index(k)))
        out.append(k)
        counts[k] += 1
    return out


def gathering_kinds(g, img):
    """{kind: n} of the gathering marches on the Marching panel (by their row icon)."""
    """Counts gathering marches and ones still on their way to a tile (those rows show the
    target's coordinates instead of "Gathering" but already carry the resource icon)."""
    import cv2
    from gather_adb.gather import row_label, row_ys
    out = {}
    for y in row_ys(img):
        label = row_label(img, y).lower()
        if not label or "return" in label or "rally" in label:
            continue
        if not ("gather" in label or re.search(r"x.?\d+", label)):
            continue
        win = img[max(0, y - 24):y + 24, 4:50]
        scores = {k: float(cv2.matchTemplate(win, g.v.template(f"res_{k.lower()}"),
                                             cv2.TM_CCOEFF_NORMED).max()) for k in KINDS}
        best = max(scores, key=scores.get)
        if scores[best] >= 0.8:
            out[best] = out.get(best, 0) + 1
    return out


def minutes(params):
    return {"Bear Hunt": int(params.get("bear_minutes", 30)),
            "Battle": int(params.get("battle_minutes", 60))}


def upcoming(task_list, now, params):
    """[(start epoch, name)] of today's/tomorrow's timed events still to come or running."""
    import datetime as dt
    out = []
    for t in task_list:
        start = t.start_utc()
        if start is None:
            continue
        dur = minutes(params)["Bear Hunt" if t.name.startswith("Bear") else "Battle"]
        if start + dt.timedelta(minutes=dur) > now:
            out.append((start.timestamp(), t.name))
    return sorted(out)


def gather(dev, params, log=print, sleep=time.sleep, events_out=None, now=None):
    """Top up gatherers. With "Avoid events" on, reads the Task List first: no gatherers are
    sent from `recall_before` minutes before an event until it ends (they are recalled
    instead). `events_out` (a list) receives the upcoming events for the engine's timed recall."""
    import datetime as dt
    from autopilot import jobs, tasks
    from gather_adb import gather as G
    from intel_adb.vision import Vision
    g = G.Gather(dev, Vision(G.TEMPLATE_DIR), sleep=sleep)
    now = now or dt.datetime.now(dt.timezone.utc)
    if params.get("avoid_events", True):
        ctx = jobs.Ctx(dev, Vision(jobs.TEMPLATE_DIR), sleep=sleep, log=log)
        task_list = tasks.read_task_list(ctx, now)
        if events_out is not None:
            events_out[:] = upcoming(task_list, now, params)
        busy = tasks.conflict(task_list, now, int(params.get("recall_before", 5)), minutes(params))
        if busy:
            log(f"gather: {busy.name} at {busy.start} UTC - recalling, no new gatherers")
            g.recall_all()
            g.to_map()
            return 0
    if not g.to_map():
        log("gather: couldn't reach the world map")
        return 0
    have = gathering_kinds(g, g.shot())
    want = int(params.get("marches", 2))
    missing = want - sum(have.values())
    if missing <= 0:
        log(f"gather: {sum(have.values())} gatherers already out")
        return 0
    level = params.get("level", "Highest")
    sent = 0
    for kind in plan(params.get("resource", "Any"), have, missing):
        result = "failed"
        for _ in range(2):
            result = g.send_one(kind, level=level)
            if result == "sent":
                break
            g.to_map()
        if result == "sent":
            sent += 1
        elif result == "refused":
            log("gather: no free march")
            break
    g.to_map()
    log(f"gather: sent {sent} gatherer(s)")
    return sent
