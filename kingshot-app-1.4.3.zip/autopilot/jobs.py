"""Autopilot jobs built from the 2026-10-07 recording: claim rewards, alliance research,
train troops. Every job starts and ends in the city or on the world map ("home").

Safety: only known buttons are tapped (green Claim / teal Contribute / Train ...); diamond
buttons (Finish, Contribute with diamonds), "Go" (gift-pack purchase) and Top-up offers are
never touched. Back is used to leave screens; "Quit game?" is always cancelled."""
import math
import re
import time
from pathlib import Path

import cv2

from intel_adb import timer

TEMPLATE_DIR = Path(__file__).parent / "templates"

# home-screen buttons (city and world map share the bottom bar)
ALLIANCE_NAV = (400, 925)
MAIL_ICON = (497, 786)
VIP_BADGE = (480, 58)
MAIL_TABS = {"Wars": (65, 90), "Alliance": (168, 90), "System": (268, 90), "Reports": (370, 90)}
CHEST_TABS = {"Loot Chest": (145, 300), "Alliance Gift": (397, 300)}
VIP_DAILY_CHEST = (465, 200)  # consecutive-login VIP XP chest (red dot when ready)

TRAIN_TABS = {"Infantry": (100, 940), "Cavalry": (270, 940), "Archer": (440, 940)}
TROOPS = ("Infantry", "Cavalry", "Archer")
AMOUNT_FIELD = (405, 734)
TRAIN_COUNT_BOX = (352, 718, 104, 32)  # x, y, w, h of the amount field
TRAIN_TIME_BOX = (330, 832, 150, 26)  # "12:39:47" under "Train"
STATUS_BOX = (-65, 12, 130, 24)  # panel row status text, relative to the troop label centre
ACTION_DX = 135  # panel row action button (x 303), right of the troop label centre (x 168)
ATTEMPTS_BOX = (300, 706, 190, 26)  # "Attempts: 25/25" over the teal Contribute


class Ctx:
    """What a job needs: the device, a Vision on our templates, sleep, log."""

    def __init__(self, device, vision, sleep=time.sleep, log=print, clock=time.time):
        self.d, self.v, self.sleep, self.log, self.clock = device, vision, sleep, log, clock

    def shot(self):
        return self.d.screencap()

    def tap_t(self, img, name, threshold=None):
        pos = self.v.find(img, name, threshold)
        if pos:
            self.d.tap(*pos)
        return pos is not None

    def wait_for(self, name, timeout=6.0):
        for _ in range(int(timeout / 0.5) + 1):
            img = self.shot()
            if self.v.has(img, name):
                return img
            self.sleep(0.5)
        return None

    def at_home(self, img):
        return self.v.has(img, "world_button") or self.v.has(img, "world_map_marker")

    def home(self, tries=8):
        """Back out to the city / world map. True when there."""
        for _ in range(tries):
            img = self.shot()
            if self.v.has(img, "quit_game"):
                self.tap_t(img, "cancel_button") or self.d.back()
                self.sleep(1)
                continue
            if self.at_home(img):
                return True
            self.d.back()
            self.sleep(1.2)
        return False

    def claim_until_gone(self, title, buttons, max_taps=30):
        """On a screen with `title`: tap any of `buttons` until none is left. A reward overlay
        that hides the title is closed with Back. Returns the number of claims."""
        n = 0
        for _ in range(max_taps):
            img = self.shot()
            if not self.v.has(img, title):
                self.d.back()  # reward overlay ("Tap anywhere to exit")
                self.sleep(1)
                if not self.v.has(self.shot(), title):
                    return n  # left the screen altogether
                continue
            if not any(self.tap_t(img, b) for b in buttons):
                return n
            n += 1
            self.sleep(1.2)
        return n


def _ocr(img, box, whitelist):
    if not timer.available():
        return ""
    x, y, w, h = box
    crop = img[max(0, y):y + h, max(0, x):x + w]
    if crop.size == 0:
        return ""
    g = cv2.cvtColor(cv2.resize(crop, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC), cv2.COLOR_BGR2GRAY)
    try:
        return timer.pytesseract.image_to_string(
            g, config=f"--psm 7 -c tessedit_char_whitelist={whitelist}").strip()
    except Exception:
        return ""


# ---- claim rewards ----------------------------------------------------------
def claim(ctx, params):
    """Mail, alliance chests and gifts, VIP daily. Returns the number of claims."""
    total = 0
    if not ctx.home():
        ctx.log("claim: couldn't get to the city / map")
        return 0
    if params.get("mail", True):
        ctx.d.tap(*MAIL_ICON)
        if ctx.wait_for("mail_title") is not None:
            for tab, pos in MAIL_TABS.items():
                ctx.d.tap(*pos)
                ctx.sleep(1)
                got = ctx.claim_until_gone("mail_title", ["read_claim_all"], max_taps=3)
                total += got
            ctx.log("claim: mail done")
        ctx.home()
    if params.get("alliance_gifts", True):
        ctx.d.tap(*ALLIANCE_NAV)
        img = ctx.wait_for("alliance_title")
        if img is not None and ctx.tap_t(img, "chests_button") and ctx.wait_for("chests_title") is not None:
            for tab, pos in CHEST_TABS.items():
                ctx.d.tap(*pos)
                ctx.sleep(1)
                total += ctx.claim_until_gone("chests_title", ["claim_all", "claim"])
            ctx.log("claim: alliance chests done")
        ctx.home()
    if params.get("daily", True):
        ctx.d.tap(*VIP_BADGE)
        img = ctx.wait_for("vip_title")
        if img is not None:
            total += ctx.claim_until_gone("vip_title", ["vip_claim"], max_taps=2)
            ctx.log("claim: VIP daily done")
        ctx.home()
    return total


# ---- alliance research ------------------------------------------------------
def attempts_left(img):
    """Resource contributions left ("Attempts: 25/25"), or None if unreadable."""
    m = re.search(r"(\d+)\s*/\s*\d+", _ocr(img, ATTEMPTS_BOX, "0123456789/"))
    return int(m.group(1)) if m else None



def alliance(ctx, params):
    """Contribute to the recommended alliance tech with resources (never diamonds)."""
    want = int(params.get("donations", 20))
    if want <= 0 or not ctx.home():
        return 0
    ctx.d.tap(*ALLIANCE_NAV)
    img = ctx.wait_for("alliance_title")
    if img is None or not ctx.tap_t(img, "tech_button"):
        ctx.log("alliance: couldn't open Tech")
        ctx.home()
        return 0
    img = ctx.wait_for("tech_title")
    thumb = ctx.v.find(img, "thumbs_up", 0.8) if img is not None else None
    if not thumb:
        ctx.log("alliance: no recommended tech shown")
        ctx.home()
        return 0
    ctx.d.tap(thumb[0] + 33, thumb[1] + 40)  # the tech under the thumbs-up
    done = 0
    for _ in range(want):
        img = ctx.wait_for("contribute_teal", timeout=3)
        if img is None:
            break
        if attempts_left(img) == 0:
            break
        ctx.tap_t(img, "contribute_teal", 0.9)  # colour match: teal (resources), not orange
        done += 1
        ctx.sleep(0.6)
    ctx.log(f"alliance: contributed {done}x")
    ctx.home()
    return done


# ---- train troops -----------------------------------------------------------
def batch_size(per_troop_s, now, target, max_count):
    """Troops to train so the batch completes at `target` (epoch s). 0 when too late."""
    if per_troop_s <= 0 or target <= now:
        return 0
    return max(0, min(max_count, int((target - now) // per_troop_s)))


def parse_duration(text):
    """'12:39:47' -> 45587, '1d 23:30:00' -> 171000; None if unreadable."""
    m = re.search(r"(\d+)\s*d", text)
    days = int(m.group(1)) if m else 0
    rest = text[m.end():] if m else text
    hms = timer.parse_hms(rest.strip())
    return None if hms is None else days * 86400 + hms


def read_train(img):
    """(count, seconds) shown on the train screen, or (None, None)."""
    m = re.search(r"\d+", _ocr(img, TRAIN_COUNT_BOX, "0123456789").replace(",", ""))
    secs = parse_duration(_ocr(img, TRAIN_TIME_BOX, "0123456789:d "))
    return (int(m.group()) if m else None), secs


def train(ctx, params, now=None):
    """Train each enabled troop type. Modes: 'Keep busy' (max batch) or 'Finish by'
    (batch sized to complete at params['finish_by'], epoch seconds). Finished troops are
    not collected before params['hold_until'] (epoch seconds, optional)."""
    now = ctx.clock() if now is None else now
    mode = params.get("mode", "Keep busy")
    if mode == "Off" or not ctx.home():
        return 0
    trained = 0
    for troop in TROOPS:
        if not params.get(troop.lower(), True):
            if params.get("promote_when_off", False):
                trained += promote(ctx, troop)
            continue
        img = ctx.shot()
        if not ctx.v.has(img, "panel_town_tab"):
            ctx.tap_t(img, "panel_tab")
            img = ctx.wait_for("panel_town_tab", timeout=3)
            if img is None:
                ctx.log("train: couldn't open the queue panel")
                break
        label = ctx.v.find(img, f"label_{troop.lower()}")
        if not label:
            ctx.log(f"train: {troop} row not found")
            continue
        status = _ocr(img, (label[0] + STATUS_BOX[0], label[1] + STATUS_BOX[1], STATUS_BOX[2], STATUS_BOX[3]),
                      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789: ").lower()
        if "complet" in status and now < float(params.get("hold_until") or 0):
            ctx.log(f"train: {troop} finished - holding until the set time")
            continue
        if re.search(r"\d+:\d+", status):
            ctx.log(f"train: {troop} still training ({status})")
            continue
        ctx.d.tap(label[0] + ACTION_DX, label[1] + 10)  # collects finished troops, opens the building
        ctx.sleep(1.5)
        img = open_pointed(ctx, "train_menu")
        if img is None or not ctx.tap_t(img, "train_menu"):
            ctx.log(f"train: {troop} building menu didn't open")
            ctx.home()
            continue
        img = ctx.wait_for("train_button", timeout=4)
        if img is None:
            ctx.log(f"train: {troop} train screen didn't open (busy?)")
            ctx.home()
            continue
        count, secs = read_train(img)
        if not count or not secs:
            ctx.log(f"train: {troop} couldn't read amount/time")
            ctx.home()
            continue
        if mode == "Finish by":
            n = batch_size(secs / count, now, float(params.get("finish_by") or 0), count)
            if n <= 0:
                ctx.log(f"train: {troop} - too late to finish by the target")
                ctx.home()
                continue
            if n != count:
                ctx.d.tap(*AMOUNT_FIELD)
                ctx.sleep(0.6)
                ctx.d.type_text(str(n))
                ctx.sleep(0.6)
                ctx.d.back()  # close the keyboard
                ctx.sleep(0.8)
                img = ctx.shot()
                count, secs = read_train(img)
                if count != n:
                    ctx.log(f"train: {troop} amount didn't take ({count} != {n}) - skipped")
                    ctx.home()
                    continue
        if not ctx.tap_t(img, "train_button"):
            ctx.home()
            continue
        trained += count
        ctx.log(f"train: {troop} x{count} ({secs}s)")
        ctx.home()
    return trained


def open_pointed(ctx, want, tries=5):
    """After a queue-panel arrow the game scrolls to the building and a hand points at it
    (seen live 2026-10-15: the bot waited for a menu that only opens once the building is
    tapped). Tap where the hand points until `want` shows. Returns the screenshot or None."""
    from autopilot.city import pointed_target
    for _ in range(tries):
        img = ctx.shot()
        if ctx.v.has(img, want):
            return img
        target = pointed_target(ctx.v, img)
        if target:
            ctx.d.tap(*target)
        ctx.sleep(1.2)
    img = ctx.shot()
    return img if ctx.v.has(img, want) else None


# ---- promote troops ---------------------------------------------------------
TIER_FROM_ARROW = (27, 43)  # from a tier's green up-arrow to its portrait centre


def promote(ctx, troop):
    """Promote the promotable tier (green up-arrow) of `troop` in its idle barracks.
    Only used for barracks whose training is off (training comes first). Never Finish."""
    if not ctx.home():
        return 0
    img = ctx.shot()
    if not ctx.v.has(img, "panel_town_tab"):
        ctx.tap_t(img, "panel_tab")
        img = ctx.wait_for("panel_town_tab", timeout=3)
        if img is None:
            return 0
    label = ctx.v.find(img, f"label_{troop.lower()}")
    if not label:
        return 0
    status = _ocr(img, (label[0] + STATUS_BOX[0], label[1] + STATUS_BOX[1], STATUS_BOX[2], STATUS_BOX[3]),
                  "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789: ").lower()
    if re.search(r"\d+:\d+", status):
        ctx.log(f"promote: {troop} barracks busy ({status})")
        return 0
    ctx.d.tap(label[0] + ACTION_DX, label[1] + 10)  # collects finished troops, opens the building
    ctx.sleep(1.5)
    img = ctx.wait_for("train_menu", timeout=4)
    if img is None or not ctx.tap_t(img, "train_menu"):
        ctx.home()
        return 0
    img = ctx.wait_for("train_button", timeout=4)
    arrow = ctx.v.find(img, "tier_up", 0.75) if img is not None else None
    if not arrow:
        ctx.log(f"promote: {troop} - nothing to promote")
        ctx.home()
        return 0
    ctx.d.tap(arrow[0] + TIER_FROM_ARROW[0], arrow[1] + TIER_FROM_ARROW[1])
    img = ctx.wait_for("promote_arrow", timeout=3)
    if img is None or not ctx.tap_t(img, "promote_arrow"):
        ctx.home()
        return 0
    img = ctx.wait_for("promote_title", timeout=3)
    if img is None or not ctx.tap_t(img, "promotion_button"):
        ctx.log(f"promote: {troop} promotion window didn't open")
        ctx.home()
        return 0
    ctx.sleep(1.5)
    ctx.log(f"promote: {troop} promotion started")
    ctx.home()
    return 1
