"""Exploration helper (recording screens to learn new jobs). Saves every shot it takes.

    python -m autopilot.explore NAME tap X Y | back | swipe X1 Y1 X2 Y2 | wait S ...
"""
import sys
import time
from pathlib import Path

import cv2

from intel_adb.adb import discover

OUT = Path(__file__).parent / "recording_quests"


def main(argv):
    OUT.mkdir(exist_ok=True)
    tag, a = argv[0], argv[1:]
    d = discover(only="Primary")[0]
    d.screencap()  # sets the tap scale (Primary is 1080x1920)
    i = 0
    while i < len(a):
        op = a[i]
        if op == "tap":
            d.tap(int(a[i + 1]), int(a[i + 2]), jitter=0); i += 3; time.sleep(1.5)
        elif op == "back":
            d.back(); i += 1; time.sleep(1.2)
        elif op == "swipe":
            d.swipe(*map(int, a[i + 1:i + 5]), 500); i += 5; time.sleep(1.2)
        elif op == "wait":
            time.sleep(float(a[i + 1])); i += 2
        else:
            raise SystemExit(f"unknown op {op}")
    path = OUT / f"{time.strftime('%H%M%S')}_{tag}.png"
    cv2.imwrite(str(path), d.screencap())
    print(path)


if __name__ == "__main__":
    main(sys.argv[1:])
