"""Film running instances in 3-minute chunks (with tap dots) until stopped.

    python -m autopilot.record_video OUT_DIR [--only NAME ...]

Each chunk is pulled to OUT_DIR/<instance>/NNN.mp4 as soon as it ends. To stop cleanly
(keeping the chunk being filmed), create OUT_DIR/STOP - the Kingshot Bots app does that."""
import argparse
import os
import subprocess
import threading
import time
from pathlib import Path

from intel_adb import adb
from journey_adb import chests

CHUNK = 180


def _run(dev, *args):
    return subprocess.run([adb.ADB_PATH, "-s", dev.serial, *args], capture_output=True,
                          creationflags=adb.NO_WINDOW)


def film(dev, out, stop):
    out.mkdir(parents=True, exist_ok=True)
    plan, _ = chests.record_plan(dev._adb("shell", "wm", "size").decode(errors="ignore"))
    _run(dev, "shell", "settings", "put", "system", "show_touches", "1")
    n = len(list(out.glob("*.mp4")))
    lost = 0
    while not stop.is_set():
        remote = f"/sdcard/rec_{os.getpid()}_{n:03d}.mp4"  # unique: two recorders at once collided
        _run(dev, "shell", "screenrecord", *plan, "--time-limit", str(CHUNK), remote)  # blocks
        got = _run(dev, "pull", remote, str(out / f"{n:03d}.mp4")).returncode == 0
        _run(dev, "shell", "rm", remote)
        if not got:  # emulator closed / disconnected: don't spin through empty "chunks"
            lost += 1
            if lost >= 3:
                print(f"[{dev.name}] can't record (emulator gone?) - stopped filming it", flush=True)
                return
            time.sleep(5)
            continue
        lost = 0
        print(f"[{dev.name}] chunk {n} saved", flush=True)
        n += 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("out")
    ap.add_argument("--only", action="append")
    a = ap.parse_args()
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    devs = adb.discover(only=a.only)
    print("filming:", ", ".join(d.name for d in devs) or "nothing", flush=True)
    stop = threading.Event()
    threads = []
    for d in devs:
        safe = d.name.replace("#", "").replace(" ", "_")
        t = threading.Thread(target=film, args=(d, out / safe, stop), daemon=True)
        t.start()
        threads.append(t)
    while not (out / "STOP").exists():
        time.sleep(1)
    stop.set()
    for d in devs:  # end the chunks being filmed now; they are pulled before exiting
        _run(d, "shell", "pkill", "-INT", "-f", f"rec_{os.getpid()}_")  # only our own recording
    for t in threads:
        t.join(timeout=60)
    for d in devs:  # tap dots off again: bots that read the screen would see them
        _run(d, "shell", "settings", "put", "system", "show_touches", "0")
    print(f"recording saved to {out}", flush=True)


if __name__ == "__main__":
    main()
