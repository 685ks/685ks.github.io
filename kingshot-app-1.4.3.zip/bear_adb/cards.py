"""Read rally cards on the War list. Every card's numbers sit at fixed offsets from its + button."""
import re
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass

import cv2

from intel_adb import timer

# offsets from the + button centre (540x960 screen)
TIME_BOX = (-52, -142, 82, 24)    # "Rallying: 00:00:50" -> the time part
TROOPS_BOX = (-268, -66, 182, 24)  # "544,731/1,600,231"

_POOL = ThreadPoolExecutor(max_workers=2)
JOIN_TROOPS = 110_000
MIN_SECONDS = 10


@dataclass
class Card:
    plus: tuple  # (x, y) of the + button
    seconds: int | None  # until the rally leaves
    troops: int | None
    capacity: int | None

    @property
    def space(self):
        if self.troops is None or self.capacity is None:
            return None
        return self.capacity - self.troops


def _crop(img, plus, box):
    dx, dy, w, h = box
    x, y = plus[0] + dx, plus[1] + dy
    return img[max(0, y):y + h, max(0, x):x + w]


def _ocr(crop, whitelist):
    if not timer.available() or crop.size == 0:
        return ""
    gray = cv2.cvtColor(cv2.resize(crop, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC),
                        cv2.COLOR_BGR2GRAY)
    try:
        return timer.pytesseract.image_to_string(
            gray, config=f"--psm 7 -c tessedit_char_whitelist={whitelist}")
    except Exception:
        return ""


def parse_troops(text):
    """'544,731/1,600,231' -> (544731, 1600231); None if unreadable."""
    m = re.search(r"([\d,.]+)\s*/\s*([\d,.]+)", text)
    if not m:
        return None
    a, b = (int(re.sub(r"[^\d]", "", g) or 0) for g in m.groups())
    if not b or a > b:
        return None
    return a, b


def read_card(img, plus):
    # both reads at once: each one is a separate Tesseract run
    t = _POOL.submit(_ocr, _crop(img, plus, TIME_BOX), "0123456789:")
    troops = parse_troops(_ocr(_crop(img, plus, TROOPS_BOX), "0123456789,/"))
    seconds = timer.parse_hms(t.result())
    return Card(plus, seconds, *(troops or (None, None)))


def skip_reason(card):
    """None when we should join; otherwise why not. Unreadable numbers don't block a join:
    a slow join costs more than an occasional over-full rally."""
    if card.seconds is not None and card.seconds < MIN_SECONDS:
        return f"starts in {card.seconds}s"
    if card.space is not None and card.space < JOIN_TROOPS:
        return f"only {card.space:,} space"
    return None
