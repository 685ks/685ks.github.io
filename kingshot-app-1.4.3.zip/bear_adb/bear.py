"""Bear event: keep the 6 joiner marches busy joining rallies, and start our own rally with
the Special march once every joiner is out.

    python -m bear_adb.bear [--only Primary] [--dry-run]
"""
import argparse
import re
import time
from pathlib import Path

import cv2

from intel_adb import adb, popups, timer
from intel_adb.intel_flow import PRESET_X, PRESET_Y
from intel_adb.vision import Vision
from bear_adb import cards

TEMPLATE_DIR = Path(__file__).parent / "templates"
DEBUG_DIR = Path(__file__).parent / "debug"

JOINERS = 6
JOIN_FORMATIONS = (8,)  # default: right-most formation, 110k troops, no heroes
PRESET_OWN = (40, 92)
WAR_ICON = (492, 412)  # red War button on the map (fixed)
DEPLOY = (412, 911)  # Deploy on the formation screen (fixed)
LABEL_MIN = 0.7  # "Special"/"Ends in" over a busy map score ~0.76; nothing else reaches 0.7
SPECIAL_ROW_MIN = 0.1  # teal share under "Special": ~0.2+ with a march out, ~0 without
LEAD_HERO_MIN = 0.7  # lead hero's face in formation slot 1: ~1.0 when there, ~0.3 otherwise
HERO_RETRY = 10  # s before checking again whether the heroes are home
FULL_BACKOFF = 10  # s to wait after the game says every march is out
MAX_BEAR = 30 * 60
ENDS_EVERY = 20  # s between reads of the bear's "Ends in" timer  # left-most "My" formation, with heroes
BEAR_FROM_ENDS_IN = (30, -80)  # bear sprite relative to its "Ends in:" label
MIN_OWN_RALLY_LEFT = 5 * 60  # can't start rallies in the last 5 minutes
OWN_RALLY_RETRY = 30  # s between attempts while the Special march is busy
BEAR_FIND_TRIES = 3  # screenshots to find the bear's timer before giving up for now
OWN_RALLY_GAP = 5 * 60  # s after starting our rally before trying another
BEAR_TARGET_MIN = 0.75
GREEN_PLUS_SAT = 120  # joined rallies show a grey + (saturation ~50); open ones ~190
SCREEN_WAIT = 3.0  # s to wait for an expected screen
POLL = 0.3
MARCHING_ABSENT = 0.65  # "Marching" label score below this = panel hidden (no march out)
# "Ends in" templates and their size relative to ends_in.png; the map zoom changes label size
ENDS_TEMPLATES = (("ends_in", 1.0), ("ends_in_zoom", 1.1))  # zoom: cut from Falkor 2026-10-11
ENDS_SCALES = (1.0, 0.95, 1.05, 0.9, 1.1, 1.15, 0.85, 1.2)
ENDS_MIN = 0.68  # label on screen scores 0.70-1.0 (colour or white-text match); elsewhere <= 0.61


def parse_formations(text):
    """"1-6" / "1,3,5" / "8" -> [formation numbers 1-8], in order. Bad input -> default."""
    out = []
    for part in str(text or "").replace(" ", "").split(","):
        a, _, b = part.partition("-")
        if a.isdigit() and (not b or b.isdigit()):
            lo, hi = int(a), int(b or a)
            out += [n for n in range(lo, hi + 1) if 1 <= n <= 8 and n not in out]
    return out or list(JOIN_FORMATIONS)


def bear_card(vision, img, plus):
    """The card's target picture (left of the + button) is the Raging Bear. Stray terror or
    other rallies on the War list score ~0.5; bear cards ~1.0."""
    x, y = plus
    region = img[max(0, y - 90):y + 60, 20:200]
    return float(vision._match(region, vision.template("bear_target")).max()) >= BEAR_TARGET_MIN


def special_busy(vision, img):
    """The Special (7th) march is out: a row with a teal eye/return button sits under the
    "Special" label of the Marching panel. No row = it's home. No label = can't tell (a banner
    or effect over the panel - seen live, it started a rally attempt while Special was out),
    so count it as busy."""
    pos = vision.find(img, "special_label", LABEL_MIN)
    if pos is None:
        return True
    x, y = pos
    hsv = cv2.cvtColor(img[y + 18:y + 62, x + 75:x + 125], cv2.COLOR_BGR2HSV)
    return cv2.inRange(hsv, (80, 100, 150), (100, 255, 255)).mean() / 255 >= SPECIAL_ROW_MIN


def lead_hero_home(vision, img):
    """Your lead hero (always in your own-rally formation) is in formation slot 1."""
    region = img[200:440, 40:220]
    return float(vision._match(region, vision.template("lead_hero")).max()) >= LEAD_HERO_MIN


def hero_count(img):
    """Heroes in the formation on the Deploy screen: each has an orange "-" button top-right."""
    hsv = cv2.cvtColor(img[215:260], cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, (0, 170, 200), (14, 255, 255))
    n, _, stats, _ = cv2.connectedComponentsWithStats(mask)
    return sum(1 for k in range(1, n) if 15 <= stats[k][2] <= 40 and 15 <= stats[k][3] <= 40)


# ---- OCR readers (real implementations; tests pass fakes) ----------------
def _ocr(crop, whitelist):
    if not timer.available() or crop.size == 0:
        return ""
    gray = cv2.cvtColor(cv2.resize(crop, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC),
                        cv2.COLOR_BGR2GRAY)
    try:
        return timer.pytesseract.image_to_string(
            gray, config=f"--psm 7 -c tessedit_char_whitelist={whitelist}")
    except Exception:
        return ""


def _ocr_white_text(crop, whitelist):
    """White text over a busy map: keep only near-white pixels as black-on-white, read as
    one word. Much steadier than plain greyscale, especially below 540x960."""
    if not timer.available() or crop.size == 0:
        return ""
    big = cv2.resize(crop, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
    hsv = cv2.cvtColor(big, cv2.COLOR_BGR2HSV)
    white = (hsv[..., 1] < 70) & (hsv[..., 2] > 170)
    img = cv2.copyMakeBorder(255 - white.astype("uint8") * 255, 8, 8, 8, 8,
                             cv2.BORDER_CONSTANT, value=255)
    try:
        return timer.pytesseract.image_to_string(
            img, config=f"--psm 8 -c tessedit_char_whitelist={whitelist}")
    except Exception:
        return ""


def _hms(text):
    """Seconds from the last "hh:mm:ss" in OCR text. The crop can catch the colon of "in:",
    read as an extra digit ("200:13:49"): only two digits per part count."""
    found = re.findall(r"(\d{2}):(\d{2}):(\d{2})", text or "")
    if found:
        h, m, sec = map(int, found[-1])
        return h * 3600 + m * 60 + sec if m < 60 and sec < 60 else None
    return timer.parse_hms(text)


def _white(img):
    """Near-white pixels (map label text) as a 0/255 mask."""
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    return (((hsv[..., 1] < 70) & (hsv[..., 2] > 170)) * 255).astype("uint8")


def make_readers(vision):
    def read_count(img):
        """Busy joiner marches from 'Marching N/6', or None if the panel isn't readable.
        With no march out the game hides the panel: clearly absent (~0.58) = 0 busy."""
        res = vision._match(img, vision.template("marching_label"))
        score = float(res.max()) if res is not None else 0.0
        if score < MARCHING_ABSENT:
            return 0
        if score < vision.threshold:
            return None  # partly covered: don't guess
        _, _, _, loc = cv2.minMaxLoc(res)
        th, tw = vision.template("marching_label").shape[:2]
        x, y = loc[0] + tw // 2, loc[1] + th // 2
        crop = img[y - 11:y + 11, x + 82:x + 125]
        hit = (re.search(r"(\d)\s*/\s*(\d)", _ocr_white_text(crop, "0123456789/"))
               or re.search(r"(\d)\s*/\s*(\d)", _ocr(crop, "0123456789/")))
        return int(hit.group(1)) if hit else None

    def read_ends(img):
        """(seconds left, label position) from 'Ends in: 00:23:06', or (None, None)."""
        # map labels grow and shrink with the map zoom, and the map behind the white text
        # changes all the time: try both templates at a few sizes, in colour and as white text
        best = (0.0, None, 1.0)
        img_white = _white(img)
        for name, size in ENDS_TEMPLATES:
            base = vision.template(name)
            for s in ENDS_SCALES:
                tpl = base if s == 1.0 else cv2.resize(base, None, fx=s, fy=s, interpolation=cv2.INTER_CUBIC)
                if tpl.shape[0] > img.shape[0] or tpl.shape[1] > img.shape[1]:
                    continue
                for a, b in ((img, tpl), (img_white, _white(tpl))):
                    _, val, _, loc = cv2.minMaxLoc(cv2.matchTemplate(a, b, cv2.TM_CCOEFF_NORMED))
                    if val > best[0]:
                        best = (val, (loc[0] + tpl.shape[1] // 2, loc[1] + tpl.shape[0] // 2), s * size)
                if best[0] >= 0.9:
                    break
            if best[0] >= 0.9:
                break
        if best[0] < ENDS_MIN:
            return None, None
        e, s = best[1], best[2]
        x, y = e
        crop = img[y - round(9 * s):y + round(9 * s), x + round(18 * s):x + round(82 * s)]
        secs = _hms(_ocr_white_text(crop, "0123456789:"))
        if secs is None:
            secs = _hms(_ocr(crop, "0123456789:"))
        return secs, e

    return read_count, read_ends, cards.read_card


class Bear:
    def __init__(self, device, vision, sleep=time.sleep, clock=time.monotonic, readers=None,
                 bear_fn=bear_card, lead_fn=None, special_fn=None, formations=JOIN_FORMATIONS):
        self.d, self.v, self.sleep, self.clock = device, vision, sleep, clock
        self.formations = list(formations) or list(JOIN_FORMATIONS)  # joins rotate through these
        self.read_count, self.read_ends, self.read_card = readers or make_readers(vision)
        self.ends_at = None  # clock time the bear ends (from the last "Ends in" read)
        self.bear_pos = None
        self.next_own_try = 0
        self.joined = 0
        self.own = 0
        self.dry = getattr(device, "dry_run", False)
        self.bear_fn = bear_fn
        self.lead_fn = lead_fn or lead_hero_home
        self.special_fn = special_fn or special_busy
        self.next_ends_read = 0
        self.full_until = 0
        self.list_img = None  # War list screenshot when a Deploy left us on it
        self.bad_ends = 0  # the game said "march queue full": don't try again before this

    # ---- helpers -------------------------------------------------------
    def shot(self):
        return self.d.screencap()

    def tap(self, x, y):
        self.d.tap(x, y, jitter=2)

    def tap_t(self, img, name):
        pos = self.v.find(img, name)
        if pos:
            self.tap(*pos)
        return pos is not None

    def wait_for(self, names, timeout=SCREEN_WAIT):
        """Screenshot until one of `names` shows; returns (name, img) or (None, img)."""
        end = self.clock() + timeout
        while True:
            img = self.shot()
            for n in names:
                if self.v.has(img, n):
                    return n, img
            if self.clock() >= end:
                return None, img
            self.sleep(POLL)

    def back(self):
        self.d.back()
        self.sleep(POLL)
        img = self.shot()
        if self.v.has(img, "quit_game"):  # never quit the game
            self.tap_t(img, "cancel_button")

    def seconds_left(self):
        return None if self.ends_at is None else self.ends_at - self.clock()

    def is_bear(self, img, plus):
        return self.bear_fn(self.v, img, plus)

    def green_pluses(self, img):
        pts = self.v.find_all(img, "green_plus", 0.8)
        return [p for p in pts if self.v.saturation(img, p, r=12) >= GREEN_PLUS_SAT]

    # ---- actions -------------------------------------------------------
    def pick_card(self, img):
        """Top-most qualifying rally card on the War list, or None."""
        for p in self.green_pluses(img):
            if not self.is_bear(img, p):
                self.d.log(f"skip rally at y={p[1]}: not the bear")
                continue
            card = self.read_card(img, p)
            why = cards.skip_reason(card)
            if why:
                self.d.log(f"skip rally at y={p[1]}: {why}")
                continue
            return card
        return None

    def join_one(self):
        """Join the top qualifying rally. Returns True if a march went out.
        After a Deploy the game drops us back on the War list: the next join starts from
        there (self.list_img) instead of going via the map."""
        img, self.list_img = self.list_img, None
        if img is not None:  # make sure the game is really still on the War list
            img = self.shot()
            if not self.v.has(img, "war_title"):
                img = None
        if img is None:
            self.tap(*WAR_ICON)  # fixed position: no screenshot needed first
            name, img = self.wait_for(["war_title"])
            if not name:
                return False
        card = self.pick_card(img)
        if not card:
            self.d.log("no rally to join")
            self.back()
            return False
        self.tap(*card.plus)
        name, img = self.wait_for(["bear_deploy", "march_full", "no_soldiers"])
        if name != "bear_deploy":
            self.d.log(f"can't join: {name or 'no Deploy screen'}")
            if name is None and not isinstance(img, str):  # unknown screen: keep it to look at
                try:
                    DEBUG_DIR.mkdir(parents=True, exist_ok=True)
                    cv2.imwrite(str(DEBUG_DIR / f"cant_join_{time.strftime('%H%M%S')}.png"), img)
                except Exception:
                    pass
            # the counter said a slot was free but the game disagrees: trust the game
            self.full_until = self.clock() + FULL_BACKOFF
            self.back()
            self.back()
            return False
        form = self.formations[self.joined % len(self.formations)]  # round robin
        self.tap(PRESET_X[form], PRESET_Y)
        self.sleep(0.15)
        self.tap(*DEPLOY)
        self.joined += 1
        left = f"{card.seconds}s" if card.seconds is not None else "?"
        self.d.log(f"joined rally with formation {form} (leaves in {left}, space {card.space or '?'})"
                   f" - total {self.joined}")
        name, img = self.wait_for(["war_title", "war_icon", "confirm_title"], timeout=SCREEN_WAIT)
        if name == "confirm_title":  # "not enough Archer" warning
            popups.handle_confirm(self.d, self.v, img)
            name, img = self.wait_for(["war_title", "war_icon"], timeout=SCREEN_WAIT)
        if name == "war_title":
            self.list_img = img
        return True

    def leave_list(self):
        if self.list_img is not None:
            self.list_img = None
            self.back()

    def start_own_rally(self):
        self.next_own_try = self.clock() + OWN_RALLY_RETRY
        pos = None
        for _ in range(BEAR_FIND_TRIES):  # where the bear is *now*: the camera may have moved
            img = self.shot()
            if self.special_fn(self.v, img):  # double-check on a fresh screenshot
                return False
            _, pos = self.read_ends(img)
            if pos:
                break
            self.sleep(POLL)
        if not pos:
            self.d.log(f"own rally: bear not on screen - retrying in {HERO_RETRY}s")
            self.next_own_try = self.clock() + HERO_RETRY
            return False
        self.bear_pos = pos
        bx, by = pos[0] + BEAR_FROM_ENDS_IN[0], pos[1] + BEAR_FROM_ENDS_IN[1]
        self.tap(bx, by)
        steps = [("rally_button", None), ("hold_rally", None), ("bear_deploy", PRESET_OWN)]
        for name, preset in steps:
            got, img = self.wait_for([name, "march_full"])
            if got != name:
                self.d.log(f"own rally: no {name} ({got or 'nothing'})")
                if got == "march_full":
                    self.tap_t(img, "close_button")
                else:
                    self.back()
                return False
            if preset:
                self.tap(*preset)
                self.sleep(POLL)
                img = self.shot()
                if not self.lead_fn(self.v, img):  # still marching home from the last rally
                    self.d.log(f"own rally: lead hero not home yet - retrying in {HERO_RETRY}s")
                    self.back()
                    self.back()
                    self.next_own_try = self.clock() + HERO_RETRY
                    return False
            self.tap_t(img, name)
        self.sleep(POLL)
        popups.handle_confirm(self.d, self.v, self.shot())  # "not enough Archer" warning
        self.own += 1
        self.next_own_try = self.clock() + OWN_RALLY_GAP
        self.d.log(f"started own rally - total {self.own}")
        self.wait_for(["war_icon"], timeout=SCREEN_WAIT)
        return True

    # ---- main loop -----------------------------------------------------
    def observe(self, img):
        if self.clock() >= self.next_ends_read:  # the timer only needs an occasional read
            secs, pos = self.read_ends(img)
            if secs is not None and not self.plausible_ends(secs):
                secs = None
            if secs is not None:
                self.ends_at = self.clock() + secs
                self.bear_pos = pos
                self.next_ends_read = self.clock() + ENDS_EVERY
        return self.read_count(img)

    def plausible_ends(self, secs):
        """Reject misreads (seen live: 36868, 72868, 1200972 with ~900 s left). The bear lasts
        30 min; a good read agrees with the last one within a minute. Three disagreeing but
        in-range reads in a row win, so one bad first read can't stick."""
        if not 0 <= secs <= MAX_BEAR:
            return False
        if self.ends_at is None or abs(self.clock() + secs - self.ends_at) <= 60:
            self.bad_ends = 0
            return True
        self.bad_ends += 1
        if self.bad_ends >= 3:
            self.bad_ends = 0
            return True
        return False

    def dry_report(self, img):
        if self.v.has(img, "war_title"):
            for p in self.green_pluses(img):
                card = self.read_card(img, p)
                why = cards.skip_reason(card)
                self.d.log(f"(dry) rally y={p[1]} leaves {card.seconds}s space {card.space}: "
                           f"{'skip - ' + why if why else 'JOIN'}")
        else:
            busy = self.observe(img)
            left = self.seconds_left()
            self.d.log(f"(dry) marching {busy}/{JOINERS}, bear left "
                       f"{int(left) if left is not None else '?'}s")

    def run(self, max_minutes=40):
        stop = self.clock() + max_minutes * 60
        while self.clock() < stop:
            img = self.shot()
            if self.dry:
                self.dry_report(img)
                self.sleep(2)
                continue
            if self.v.has(img, "quit_game"):
                self.tap_t(img, "cancel_button")
                continue
            if not self.v.has(img, "war_icon"):  # not on the map (leftover window)
                self.back()
                continue
            busy = self.observe(img)
            left = self.seconds_left()
            if left is not None and left <= 0:
                self.d.log("bear is over")
                break
            if busy is None:  # Marching panel unreadable (collapsed/covered): don't guess
                self.sleep(0.5)
                continue
            if busy < JOINERS and self.clock() >= self.full_until:
                if self.join_one():
                    # more slots free: straight back into the War list, no map re-read
                    while busy + 1 < JOINERS and self.clock() >= self.full_until and self.join_one():
                        busy += 1
                    self.leave_list()
                    continue
                self.sleep(1)  # nothing joinable right now
                continue
            if (left is not None and left > MIN_OWN_RALLY_LEFT
                    and self.clock() >= self.next_own_try
                    and not self.special_fn(self.v, img)):  # Special march still out
                self.start_own_rally()
                continue
            self.sleep(0.5)
        self.d.log(f"finished: joined {self.joined}, own rallies {self.own}")
        return self.joined, self.own


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--only", default="Primary", help="BlueStacks instance (default Primary)")
    ap.add_argument("--dry-run", action="store_true", help="read and log decisions, never tap")
    ap.add_argument("--minutes", type=float, default=40)
    ap.add_argument("--formations", default="8",
                    help="joiner formations, used in turn: e.g. 1-6, 1,3,5 or 8 (default)")
    args = ap.parse_args(argv)
    adb.ADB_GAP = 0  # one instance: no need to space out ADB commands
    devices = adb.discover(only=args.only, dry_run=args.dry_run)
    if not devices:
        print(f"Kingshot is not open on {args.only!r}.")
        return
    forms = parse_formations(args.formations)
    print(f"Bear bot on {devices[0].name}, joining with formation(s) {', '.join(map(str, forms))}"
          f"{' (dry run)' if args.dry_run else ''}", flush=True)
    Bear(devices[0], Vision(TEMPLATE_DIR), formations=forms).run(args.minutes)


if __name__ == "__main__":
    main()
