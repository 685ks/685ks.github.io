"""Read-only recorder: saves a screenshot from each Kingshot instance whenever its screen
changes. Never taps. Used to learn the Bear event flow before automating it.

    python -m bear_adb.record [--minutes 90] [--interval 1.5]
"""
import argparse
import threading
import time
from pathlib import Path

import cv2
import numpy as np

from intel_adb.adb import discover

OUT = Path(__file__).parent / "recording"
CHANGE = 4.0  # mean grey-level difference (0-255) on a small thumbnail that counts as "changed"


def thumb(img):
    return cv2.cvtColor(cv2.resize(img, (90, 160)), cv2.COLOR_BGR2GRAY).astype(np.int16)


def record(dev, until, interval, stop, out=OUT):
    folder = Path(out) / dev.name.replace("#", "").replace(" ", "_")
    folder.mkdir(parents=True, exist_ok=True)
    last, saved = None, 0
    while time.time() < until and not stop.is_set():
        t0 = time.time()
        try:
            img = dev.screencap()
        except Exception as e:
            dev.log(f"screencap failed: {e!r}")
            time.sleep(interval)
            continue
        th = thumb(img)
        if last is None or np.abs(th - last).mean() > CHANGE:
            name = time.strftime("%H%M%S") + f"_{int(t0 * 10) % 10}.jpg"
            cv2.imwrite(str(folder / name), img, [cv2.IMWRITE_JPEG_QUALITY, 85])
            saved += 1
            last = th
            if saved % 25 == 0:
                dev.log(f"{saved} frames")
        time.sleep(max(0.0, interval - (time.time() - t0)))
    dev.log(f"stopped, {saved} frames in {folder}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--minutes", type=float, default=90)
    ap.add_argument("--interval", type=float, default=1.5)
    ap.add_argument("--out", default=str(OUT), help="folder for the recording")
    ap.add_argument("--only", action="append", help="instance name(s) to record")
    args = ap.parse_args()
    devices = discover(only=args.only)
    print(f"Recording {len(devices)} instance(s): {', '.join(d.name for d in devices)}", flush=True)
    until = time.time() + args.minutes * 60
    stop = threading.Event()
    threads = [threading.Thread(target=record, args=(d, until, args.interval, stop, args.out)) for d in devices]
    for t in threads:
        t.start()
    try:
        for t in threads:
            t.join()
    except KeyboardInterrupt:
        stop.set()


if __name__ == "__main__":
    main()
