"""Which terrors our own accounts are rallying right now, shared by every bot process (Kingshot
Bots and Autopilot can run terrors at the same time): a small JSON file of
{"x:y": expiry epoch}. A terror whose coordinates are claimed is skipped before Rally."""
import json
import re
import threading
import time
from pathlib import Path

import cv2

CLAIMS = Path(__file__).parent / "claims.json"
CLAIM_SECONDS = 8 * 60  # hold 3 min + march + fight
_lock = threading.Lock()


def read_coords(img, ocr):
    """(x, y) from "X:729 Y:921" in the target popup's upper half, or None. `ocr(img) -> text`."""
    if not hasattr(img, "shape"):
        return None
    h = img.shape[0]
    text = ocr(img[int(h * 0.1):int(h * 0.55)])
    m = re.search(r"X\s*[:;.]?\s*(\d{2,4})\D{1,4}Y\s*[:;.]?\s*(\d{2,4})", text or "")
    return (int(m.group(1)), int(m.group(2))) if m else None


def default_ocr(crop):
    from intel_adb import timer
    if not timer.available():
        return ""
    g = cv2.cvtColor(cv2.resize(crop, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC), cv2.COLOR_BGR2GRAY)
    try:
        return timer.pytesseract.image_to_string(g, config="--psm 11")
    except Exception:
        return ""


def _load(path):
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return {}
    now = time.time()
    return {k: v for k, v in data.items() if v > now}


def claimed(xy, path=CLAIMS):
    with _lock:
        return f"{xy[0]}:{xy[1]}" in _load(path)


def claim(xy, path=CLAIMS, seconds=CLAIM_SECONDS):
    """Claim (x, y) for us. False if someone else (another of our bots) already has it."""
    key = f"{xy[0]}:{xy[1]}"
    with _lock:
        data = _load(path)
        if key in data:
            return False
        data[key] = time.time() + seconds
        tmp = Path(path).with_suffix(".tmp")
        tmp.write_text(json.dumps(data), encoding="utf-8")
        tmp.replace(path)
        return True


def release(xy, path=CLAIMS):
    key = f"{xy[0]}:{xy[1]}"
    with _lock:
        data = _load(path)
        if data.pop(key, None) is not None:
            Path(path).write_text(json.dumps(data), encoding="utf-8")
