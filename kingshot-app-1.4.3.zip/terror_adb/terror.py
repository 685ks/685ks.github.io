"""Auto terrors: search the terror, hold a rally with a formation preset, deploy, wait for the
march to come home, repeat N times. Runs on every ticked instance in parallel.

    python -m terror_adb.terror --rallies 5 [--only "Primary"] [--preset 6] [--dry-run]
"""
import argparse
import time

import cv2
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from terror_adb import claims
from intel_adb import one_troop
from intel_adb import adb, popups, timer
from intel_adb.vision import Vision
from bear_adb.bear import make_readers as _bear_readers

TEMPLATE_DIR = Path(__file__).parent / "templates"

PRESET_X = {1: 40, 2: 95, 3: 151, 4: 207, 5: 265, 6: 321, 7: 377, 8: 433}  # formation flags
PRESET_Y = 92
DEFAULT_PRESET = 6  # "Ter"
EQUALIZE = "Eq"  # formation choice: tap Equalize instead of a preset flag
HOLD_SECONDS = 180  # "Hold a rally": 3 min is preselected
HOME_MARGIN = 15  # s for the battle and lag on top of hold + 2x march
UNKNOWN_MARCH = 60  # s assumed when the march timer can't be read
EXTRA_WAIT = 120  # s to keep waiting for the march to show as home
AUTO_JOIN = 60  # s before alliance auto-joiners set off
ROW_FIRST_SEEN = 30  # s to find the rally row after deploying before falling back
ROW_POLL = 10  # s between checks of the Marching panel
ROW_MAX_WAIT = 20 * 60
MARCH_PANEL = (0, 160, 70, 320)  # x, y, w, h of the Marching list's icon column
SCREEN_WAIT = 4.0
POLL = 0.4
MAX_FAILS = 12  # failures in a row before giving up (user: false stops - don't give up quickly)
RETRY_WAITS = (5, 10, 20, 30, 60)  # s between retries, growing
DEBUG_DIR = Path(__file__).parent / "debug"


RESOURCE_ICONS = ("res_iron", "res_stone", "res_wood", "res_bread")
SAME_TARGET_CONFIRM = (384, 591)  # teal Confirm on "Other troops are marching toward the same target"
SAME_TARGET_CANCEL = (157, 591)  # orange Cancel on that popup - the one we tap
TAKEN_WAIT = 30  # s before searching again when the terror found already has a rally
TAKEN_MAX = 16  # tries (~8 min: covers the other rally's 3-min hold, march and fight)
QUEUE_CLOSE = (481, 254)  # X on the "March Queue" popup
GET_MORE_CLOSE = (501, 108)  # X on the "Get More" (Governor Stamina) popup
MAX_MEAT_USES = 10  # per rally: 10 stamina each, a terror costs 20


def rally_out(vision, img):
    """Our rally's row (crossed-swords icon) is in the Marching panel."""
    return rally_count(vision, img) > 0


def rally_count(vision, img):
    """Rally rows (crossed-swords icon) in the Marching panel. Gathering icons are also
    white-on-teal (the stone one scored 0.82 as a rally), so a row only counts when it looks
    more like the swords than like any resource icon."""
    hits = vision.find_all(img, "rally_row", 0.75, region=MARCH_PANEL)
    if not hasattr(img, "shape"):  # fake screens in tests: no pixels to compare
        return len(hits)
    n = 0
    for (cx, cy) in hits:
        win = img[max(0, cy - 22):cy + 22, max(0, cx - 22):cx + 22]
        score = lambda name: float(cv2.matchTemplate(win, vision.template(name),
                                                     cv2.TM_CCOEFF_NORMED).max())
        rally = score("rally_row")
        if rally >= 0.8 and rally > max(score(r) for r in RESOURCE_ICONS) + 0.03:
            n += 1
    return n


def make_readers(vision):
    count, _, _ = _bear_readers(vision)
    return count, timer.read_march_time


class Terror:
    def __init__(self, device, vision, sleep=time.sleep, clock=time.monotonic,
                 read_count=None, read_time=None, preset=DEFAULT_PRESET, use_meat=False,
                 read_coords=None, at_once=1, read_marching=None, one_troop=False):
        self.d, self.v, self.sleep, self.clock = device, vision, sleep, clock
        rc, rt = make_readers(vision) if read_count is None or read_time is None else (None, None)
        self.read_count = read_count or rc
        self.read_time = read_time or rt
        self.preset = preset
        self.at_once = max(1, int(at_once))  # rallies kept out at the same time
        self.one_troop = one_troop  # lead the rally with a single infantry (instant return)
        if read_marching is None:
            from intel_adb.intel_flow import read_marching as _rm
            read_marching = lambda img: _rm(self.v, img) if hasattr(img, "shape") else None
        self.read_marching = read_marching  # img -> (busy, total) from "Marching N/M", or None
        self.recent = []  # send times: a new row takes a moment to show in the panel
        self.read_coords = read_coords or (lambda img: claims.read_coords(img, claims.default_ocr))
        self.target = None
        self.use_meat = use_meat  # use stamina items (meat) when the game says out of stamina
        self.march = self.before = None  # last rally's march time / Marching count before it
        self.sent_at = 0.0  # clock time the last rally was deployed

    def shot(self):
        return self.d.screencap()

    def tap_t(self, img, name):
        pos = self.v.find(img, name)
        if pos:
            self.d.tap(*pos)
        return pos is not None

    def wait_for(self, name, timeout=SCREEN_WAIT):
        end = self.clock() + timeout
        while True:
            img = self.shot()
            if self.v.has(img, name):
                return img
            if self.clock() >= end:
                return None
            self.sleep(POLL)

    def save_debug(self, tag):
        try:
            img = self.shot()
            if hasattr(img, "shape"):
                DEBUG_DIR.mkdir(parents=True, exist_ok=True)
                cv2.imwrite(str(DEBUG_DIR / f"{self.d.name}_{tag}_{time.strftime('%H%M%S')}.png"), img)
        except Exception:
            pass

    def back(self):
        self.d.back()
        self.sleep(POLL)
        img = self.shot()
        if self.v.has(img, "quit_game"):  # never quit the game
            self.tap_t(img, "cancel_button")

    def to_map(self):
        for _ in range(4):
            if self.v.has(self.shot(), "magnify"):
                return True
            self.back()
        return False

    def rally_once(self):
        """One rally. Returns 'sent', 'refused' (no stamina/troops) or 'failed'."""
        if not self.to_map():
            return "failed"
        if self.at_once == 1 and rally_out(self.v, self.shot()):  # e.g. one started by hand
            self.d.log("a rally is already out - waiting for it to come home first")
            self.watch_row()
        img = self.shot()
        if self.marches_full(img):  # every march is out: nothing can go until one returns
            return "busy"
        before = self.read_count(img)
        self.target = None
        steps = ("magnify", "terror_tab", "search_button", "rally_button", "hold_rally")
        for i, name in enumerate(steps):
            img = self.wait_for(name)
            if img is None and i > 0:  # lag: the last tap may not have registered - tap it again
                prev = self.shot()
                if self.tap_t(prev, steps[i - 1]):
                    img = self.wait_for(name, timeout=SCREEN_WAIT * 2)
            if name == "rally_button" and img is not None:
                # 1) our own accounts: skip a terror another of our bots is already rallying
                xy = self.read_coords(img)
                if xy and not claims.claim(xy):
                    self.d.log(f"terror at X:{xy[0]} Y:{xy[1]} is already being rallied by one of our accounts")
                    self.back()
                    return "taken"
                self.target = xy
            if img is None and self.v.has(self.shot(), "march_queue_title"):
                # "March Queue": no free march (offers Research / VIP / Buy - never tapped)
                self.d.tap(*QUEUE_CLOSE, jitter=1)
                self.sleep(POLL)
                self.release_target()
                self.to_map()
                return "busy"
            if img is None or not self.tap_t(img, name):
                self.d.log(f"no {name} on screen")
                self.save_debug(f"no_{name}")
                self.release_target()
                return "failed"
        img = self.wait_for("deploy_text")
        if img is None:
            self.d.log("no Deploy screen")
            return "failed"
        if self.one_troop:  # 1 infantry: it gets injured and the march is home at once
            if not one_troop.set_one_troop(self.d, self.shot, self.sleep, self.d.log):
                self.back()
                self.release_target()
                return "failed"
        elif self.preset in PRESET_X:
            self.d.tap(PRESET_X[self.preset], PRESET_Y, jitter=0)
        elif not self.tap_t(img, "equalize_button"):  # EQUALIZE: split the troops evenly
            self.d.log("no Equalize button - deploying as it is")
        self.sleep(POLL)
        img = self.shot()
        march = self.read_time(img)
        result = self.deploy(img)
        if result != "sent":
            self.release_target()
            return result
        self.march, self.before, self.sent_at = march, before, self.clock()
        return "sent"

    def release_target(self):
        if getattr(self, "target", None):
            claims.release(self.target)
            self.target = None

    def deploy(self, img):
        """Tap Deploy and deal with what follows: the formation warning, "other troops are
        marching toward the same target", and the out-of-stamina popup (meat)."""
        for _ in range(3):
            self.tap_t(img, "deploy_text")
            self.sleep(POLL * 2)
            img = self.shot()
            if popups.handle_confirm(self.d, self.v, img):  # "not enough Archer" warning
                self.sleep(POLL * 2)
                img = self.shot()
            if self.v.has(img, "same_target") and not self.v.has(img, "quit_game"):
                # another rally (often one of our own accounts) is on this terror: never stack
                # a second rally on it (user 2026-10-16) - Cancel and look for another
                self.d.log("this terror already has a rally on it - cancelling")
                self.d.tap(*SAME_TARGET_CANCEL, jitter=2)
                self.sleep(POLL * 2)
                self.back()  # off the Deploy screen
                return "taken"
            if self.v.has(img, "get_more_title"):
                if not self.use_meat:
                    self.d.log("out of stamina (meat option is off) - stopping")
                    self.d.tap(*GET_MORE_CLOSE, jitter=0)
                    return "refused"
                if not self.eat():
                    self.d.log("no meat left - stopping")
                    self.d.tap(*GET_MORE_CLOSE, jitter=0)
                    self.sleep(POLL)
                    self.back()
                    return "refused"
                img = self.wait_for("deploy_text")
                if img is None:
                    return "failed"
                continue  # deploy again with the new stamina
            if self.v.has(img, "deploy_text"):  # game refused (troops)
                self.back()
                return "refused"
            return "sent"
        return "failed"

    def eat(self):
        """On the Get More popup: tap the green Use (meat you own - never Buy & Use with
        diamonds) until Deploy goes through. Returns False when there's no meat to use."""
        used = 0
        while used < MAX_MEAT_USES:
            img = self.shot()
            pos = self.v.find(img, "use_meat", 0.9)
            if not pos or pos[0] < 380:  # only the button in the Use column
                break
            self.d.tap(*pos, jitter=2)
            used += 1
            self.sleep(POLL * 2)
            if used % 2 == 0:  # 20 stamina = one terror: close and try to deploy
                break
        if not used:
            return False
        self.d.log(f"used meat x{used}")
        self.d.tap(*GET_MORE_CLOSE, jitter=0)
        self.sleep(POLL * 2)
        return True

    def wait_home(self):
        """Watch our rally's row in the Marching panel (it leaves only once the auto-joiners
        have arrived, so its timing varies) until it disappears. If the row can't be seen,
        fall back to an estimate: hold + 2x march + margin."""
        seen_until = self.clock() + ROW_FIRST_SEEN
        while self.clock() < seen_until:
            if rally_out(self.v, self.shot()):
                break
            self.sleep(3)
        else:
            return self._wait_estimate()
        # it can't be home before the 1-min auto-join plus our march: don't spend screenshots
        quiet = AUTO_JOIN + (self.march or 0) - (self.clock() - self.sent_at)
        self.d.log(f"rally out (march {self.march or '?'}s) - watching its row from "
                   f"{AUTO_JOIN + (self.march or 0)}s after deploy")
        if quiet > 0:
            self.sleep(quiet)
        self.watch_row()

    def watch_row(self):
        """Wait until the rally row has left the Marching panel."""
        end, gone = self.clock() + ROW_MAX_WAIT, 0
        while self.clock() < end:
            self.sleep(ROW_POLL)
            gone = 0 if rally_out(self.v, self.shot()) else gone + 1
            if gone >= 2:  # two checks in a row: not a passing popup
                self.d.log("rally row gone - march is home")
                return
        self.d.log("rally row still there after the max wait - carrying on")

    def _wait_estimate(self):
        march = self.march or UNKNOWN_MARCH
        expect = HOLD_SECONDS + 2 * march + HOME_MARGIN
        self.d.log(f"rally row not found - using the estimate, back in ~{expect}s")
        self.sleep(expect)
        end = self.clock() + EXTRA_WAIT
        while self.clock() < end:  # confirm on the Marching counter when it's readable
            now = self.read_count(self.shot())
            if now is None or self.before is None or now <= self.before:
                return
            self.sleep(5)

    def marches_full(self, img):
        """The map's "Marching N/M" counter says every march is out (unreadable: not full)."""
        got = self.read_marching(img)
        return bool(got) and got[0] >= got[1]

    def busy(self):
        """Our rallies out now: rows in the Marching panel, or the ones sent in the last
        ROW_FIRST_SEEN s if more (their rows can take a moment to appear)."""
        now = self.clock()
        self.recent = [t for t in self.recent if now - t < ROW_FIRST_SEEN]
        return max(rally_count(self.v, self.shot()), len(self.recent))

    def wait_slot(self):
        """Wait until fewer than at_once rallies are out."""
        end = self.clock() + ROW_MAX_WAIT
        while self.clock() < end:
            n = self.busy()
            if n < self.at_once and not self.marches_full(self.shot()):
                return
            self.sleep(ROW_POLL)
        self.d.log("rallies still out after the max wait - carrying on")

    def run(self, rallies):
        done = fails = taken = 0
        busy_logged = False
        while done < rallies:
            if self.d.dry_run:
                self.d.log("(dry-run) would rally the terror now")
                return 0
            try:
                result = self.rally_once()
            except Exception as e:  # e.g. the emulator froze: count it as a failure and retry
                self.d.log(f"error: {e!r} - retrying")
                self.release_target()
                result = "failed"
            if result == "sent":
                done += 1
                fails = taken = 0
                busy_logged = False
                self.d.log(f"rally {done}/{rallies} sent")
                if done < rallies:
                    if self.at_once == 1:
                        self.wait_home()
                    else:
                        self.recent.append(self.clock())
                        self.wait_slot()
            elif result == "refused":
                self.d.log("Deploy refused (out of stamina or troops) - stopping")
                break
            elif result == "busy":
                if not busy_logged:
                    self.d.log("all marches are out - waiting for one to come home")
                    busy_logged = True
                self.sleep(ROW_POLL)
                continue
            elif result == "taken":
                taken += 1
                if taken >= TAKEN_MAX:
                    self.d.log("every terror found already had a rally - stopping")
                    break
                self.d.log(f"searching again in {TAKEN_WAIT}s")
                self.sleep(TAKEN_WAIT)
                continue
            else:
                fails += 1
                self.back()
                if fails >= MAX_FAILS:
                    self.d.log(f"giving up after {fails} failures in a row")
                    break
                wait = RETRY_WAITS[min(fails - 1, len(RETRY_WAITS) - 1)]
                self.d.log(f"retrying in {wait}s (failure {fails}/{MAX_FAILS})")
                self.to_map()
                self.sleep(wait)
        self.d.log(f"finished: {done} rallies")
        return done


def parse_presets(items):
    """['Primary=3', '685 #7=Eq'] -> {'Primary': 3, '685 #7': 'Eq'}."""
    out = {}
    for item in items or []:
        name, _, num = item.rpartition("=")
        n = parse_preset(num)
        if not name:
            raise ValueError(f"bad --preset-for {item!r} (use NAME=1..8 or NAME=Eq)")
        out[name] = n
    return out


def parse_preset(text):
    """'3' -> 3, 'Eq' / 'Equalize' -> EQUALIZE."""
    t = str(text).strip()
    if t.lower() in ("eq", "equalize"):
        return EQUALIZE
    if t.isdigit() and int(t) in PRESET_X:
        return int(t)
    raise ValueError(f"bad formation {text!r} (use 1..8 or Eq)")


def _run_one(dev, rallies, preset, delay, sleep=time.sleep, use_meat=False, at_once=1, one_troop=False):
    sleep(delay)
    try:
        return dev.name, Terror(dev, Vision(TEMPLATE_DIR), preset=preset,
                                use_meat=use_meat, at_once=at_once, one_troop=one_troop).run(rallies)
    except Exception as e:
        dev.log(f"error: {e!r}")
        return dev.name, 0


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--rallies", type=int, default=5)
    ap.add_argument("--only", action="append", help="instance name; repeat for several")
    ap.add_argument("--preset", type=parse_preset, default=DEFAULT_PRESET,
                    help="formation flag 1-8, or Eq for Equalize (default 6 = 'Ter')")
    ap.add_argument("--preset-for", action="append", metavar="NAME=N",
                    help="formation for one instance, e.g. \"Primary=3\"; repeat per instance")
    ap.add_argument("--stagger", type=float, default=5)
    ap.add_argument("--at-once", type=int, default=1, help="rallies kept out at the same time")
    ap.add_argument("--one-troop", action="store_true",
                    help="lead each rally with 1 infantry: it is injured and the march is home at once")
    ap.add_argument("--at-once-for", action="append", metavar="NAME=N", default=[],
                    help="rallies at once for one instance; repeat per instance")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--use-meat", action="store_true",
                    help="use stamina items (meat) when out of stamina - never buys with diamonds")
    args = ap.parse_args(argv)
    presets = parse_presets(args.preset_for)
    at_once_for = {k: int(v) for k, _, v in (x.rpartition("=") for x in args.at_once_for) if k and v.isdigit()}
    devices = adb.discover(only=args.only, dry_run=args.dry_run)
    if not devices:
        print("No running Kingshot instances found.")
        return []
    print(f"Terrors x{args.rallies} on: "
          + ", ".join(f"{d.name} (formation {presets.get(d.name, args.preset)})" for d in devices), flush=True)
    with ThreadPoolExecutor(max_workers=len(devices)) as pool:
        results = list(pool.map(
            lambda iv: _run_one(iv[1], args.rallies, presets.get(iv[1].name, args.preset),
                                iv[0] * args.stagger, use_meat=args.use_meat,
                                at_once=at_once_for.get(iv[1].name, args.at_once),
                                one_troop=args.one_troop),
            enumerate(devices)))
    for name, n in results:
        print(f"{name}: {n} rallies")
    return results


if __name__ == "__main__":
    main()
