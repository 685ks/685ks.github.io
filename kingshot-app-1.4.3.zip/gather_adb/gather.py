"""Gather reset: at a set UTC time recall every gathering march, wait until they are all home,
then send fresh gatherers (one per resource type plus extras) to the highest-level full tiles.

    python -m gather_adb.gather --only Falkor [--at 00:00] [--plan Bread,Wood,Stone,Iron,Stone]
"""
import argparse
import ctypes
import re
import datetime as dt
import time
from pathlib import Path

import cv2

from intel_adb import adb, popups, timer
from intel_adb.vision import Vision
from terror_adb.terror import Terror

TEMPLATE_DIR = Path(__file__).parent / "templates"
DEBUG_DIR = Path(__file__).parent / "debug"

DEFAULT_PLAN = ("Bread", "Wood", "Stone", "Iron", "Stone")
RECALL_COL = (130, 170, 70, 300)  # x, y, w, h of the Marching panel's button column
CAT_ROW = (450, 690, 60, 690)  # swipe that scrolls the resource tiles to their right end
LEVEL_DOWN = (52, 790)  # "-" next to the level slider
LEVEL_UP = (365, 790)  # "+"
QUEUE_CLOSE = (481, 254)  # X on the "March Queue" popup (its Buy button is never tapped)
TILE_COORDS = (128, 266, 120, 22)  # "X:742 Y:503" on the tile popup
HOME_POLL = 10  # s between checks for returning marches
HOME_MAX = 30 * 60
SEND_RETRY = 20  # s to wait when the game refuses a march (no free slot yet)
SEND_MAX_WAIT = 15 * 60


def _ocr(img, box, invert_threshold=None):
    x, y, w, h = box
    g = cv2.cvtColor(cv2.resize(img[y:y + h, x:x + w], None, fx=3, fy=3,
                                interpolation=cv2.INTER_CUBIC), cv2.COLOR_BGR2GRAY)
    if invert_threshold is not None:
        _, g = cv2.threshold(g, invert_threshold, 255, cv2.THRESH_BINARY_INV)
    try:
        return timer.pytesseract.image_to_string(g, config="--psm 7").strip()
    except Exception:
        return ""


def row_label(img, button_y):
    """'Gathering' / 'Returning' / 'Rallying' ... of the Marching row whose button is at y."""
    return _ocr(img, (44, button_y - 16, 68, 16), invert_threshold=150)


def row_ys(img):
    """Button y of each Marching row (rows are 46 px apart from the first at ~201)."""
    return [201 + 46 * i for i in range(6)]


class Gather(Terror):
    def __init__(self, device, vision, sleep=time.sleep, clock=time.monotonic):
        super().__init__(device, vision, sleep=sleep, clock=clock,
                         read_count=lambda img: None, read_time=lambda img: None)
        self.used = set()  # tile coordinates already sent to this run

    def debug(self, tag, img=None):
        try:
            DEBUG_DIR.mkdir(exist_ok=True)
            cv2.imwrite(str(DEBUG_DIR / f"{self.d.name}_{time.strftime('%H%M%S')}_{tag}.png"),
                        img if img is not None else self.shot())
        except Exception:
            pass

    def gathering_rows(self, img):
        hits = self.v.find_all(img, "recall", 0.8, region=RECALL_COL)
        return [(x, y) for x, y in hits if "gather" in row_label(img, y).lower()]

    def recall_all(self):
        if not self.to_map():
            self.d.log("can't reach the world map")
            return 0
        self.debug("before_recall")
        n = 0
        for _ in range(12):
            img = self.shot()
            rows = self.gathering_rows(img)
            if not rows:
                break
            self.d.tap(*rows[0], jitter=2)
            self.sleep(1.5)
            img = self.shot()
            if not self.v.has(img, "magnify"):  # a confirmation popup: tap its Confirm/Recall
                box = popups._teal_button(img, (0, 250, 540, 550))
                label = popups._label(img, box) if box else ""
                if box and any(w in label for w in ("confirm", "recall", "ok", "yes")) \
                        and not self.v.has(img, "quit_game"):
                    self.d.tap(box[0] + box[2] // 2, box[1] + box[3] // 2, jitter=2)
                    self.sleep(1.5)
                else:
                    self.debug("recall_popup", img)
                    self.back()
            n += 1
            self.d.log(f"recalled gatherer {n}")
        self.debug("after_recall")
        return n

    def returning(self, img):
        return sum("return" in row_label(img, y).lower() for y in row_ys(img))

    def wait_home(self):
        end = self.clock() + HOME_MAX
        clear = 0
        while self.clock() < end:
            self.to_map()
            left = self.returning(self.shot())
            clear = clear + 1 if left == 0 else 0
            if clear >= 2:
                self.d.log("all marches home")
                return True
            self.sleep(HOME_POLL)
        self.d.log("still marches returning after the max wait - sending anyway")
        return False

    def pick_category(self, kind):
        name = f"cat_{kind.lower()}"
        for _ in range(3):
            img = self.shot()
            pos = self.v.find(img, name, 0.85)
            if pos:
                self.d.tap(pos[0], pos[1] - 20, jitter=2)
                self.sleep(0.6)
                return True
            self.d.swipe(*CAT_ROW, 500)
            self.sleep(1)
        return False

    def set_level(self, level):
        """Tile level on the search panel: None/'Highest' = all the way up, else 1..8."""
        if level in (None, "", "Highest"):
            taps = [LEVEL_UP] * 8
        else:
            taps = [LEVEL_DOWN] * 8 + [LEVEL_UP] * (int(level) - 1)
        for pos in taps:
            self.d.tap(*pos, jitter=1)
            self.sleep(0.15)

    def send_one(self, kind, level=None):
        """Returns 'sent', 'refused' (no free march) or 'failed'."""
        if not self.to_map():
            return "failed"
        self.tap_t(self.shot(), "magnify")
        if self.wait_for("search_button") is None or not self.pick_category(kind):
            self.d.log(f"couldn't open the {kind} search")
            return "failed"
        if level is not None:
            self.set_level(level)
        for attempt in range(3):
            self.tap_t(self.shot(), "search_button")
            img = self.wait_for("gather_button", 6)
            if img is None:
                self.d.log(f"no {kind} tile found")
                self.debug("no_tile")
                return "failed"
            where = ":".join(re.findall(r"\d{2,}", _ocr(img, TILE_COORDS)))
            if where and where in self.used and attempt < 2:
                self.d.log(f"{kind} tile {where} already taken - one level lower")
                self.back()
                self.wait_for("search_button")
                self.d.tap(*LEVEL_DOWN, jitter=1)
                self.sleep(0.5)
                continue
            break
        self.tap_t(img, "gather_button")
        img = self.wait_for("deploy_text")
        if img is None:  # every march slot is busy
            shot = self.shot()
            if self.v.has(shot, "march_queue_title"):  # Research / Activate VIP / Buy offer
                self.d.log("march queue full - closing the offer (never Buy)")
                self.d.tap(*QUEUE_CLOSE, jitter=1)
                self.sleep(0.8)
            else:
                self.d.log("no Deploy screen (march queue full?)")
                self.debug("no_deploy", shot)
            self.to_map()
            return "refused"
        result = self.deploy(img)
        if result == "sent":
            self.used.add(where)
            self.d.log(f"{kind} gatherer sent to {where or '?'}")
        elif result == "taken" and where:
            self.used.add(where)
        return result

    def deploy(self, img):
        """Tap Deploy. 'taken' when someone is already heading to the tile (that popup is
        backed out of, never confirmed), 'refused' when the game keeps the Deploy screen."""
        self.tap_t(img, "deploy_text")
        self.sleep(0.8)
        img = self.shot()
        if popups.handle_confirm(self.d, self.v, img):  # formation warning
            self.sleep(0.8)
            img = self.shot()
        if self.v.has(img, "same_target") and not self.v.has(img, "quit_game"):
            self.d.log("someone is already marching to that tile - searching again")
            self.debug("taken", img)
            self.to_map()
            return "taken"
        if self.v.has(img, "deploy_text"):
            self.debug("refused", img)
            self.to_map()
            return "refused"
        return "sent"

    def resend(self, plan):
        sent = 0
        for kind in plan:
            end = self.clock() + SEND_MAX_WAIT
            fails = 0
            while True:
                r = self.send_one(kind)
                if r == "sent":
                    sent += 1
                    break
                if r in ("failed", "taken"):
                    fails += 1
                    self.back()
                    if fails >= 3:
                        self.d.log(f"giving up on {kind}")
                        break
                if self.clock() > end:
                    self.d.log(f"no free march for {kind} - giving up")
                    break
                if r == "refused":
                    self.d.log("no free march yet - waiting")
                    self.sleep(SEND_RETRY)
        self.to_map()
        self.debug("done")
        return sent

    def run(self, plan):
        n = self.recall_all()
        self.d.log(f"{n} gatherers recalled - waiting for them to get home")
        if n:
            self.sleep(5)
            self.wait_home()
        sent = self.resend(plan)
        self.d.log(f"finished: {sent}/{len(plan)} gatherers sent")
        return sent


def seconds_until(hhmm, now=None):
    """Seconds until the next HH:MM UTC (plus 30 s so the reset has happened)."""
    now = now or dt.datetime.now(dt.timezone.utc)
    h, m = map(int, hhmm.split(":"))
    target = now.replace(hour=h, minute=m, second=30, microsecond=0)
    if target <= now:
        target += dt.timedelta(days=1)
    return (target - now).total_seconds()


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--only", action="append", required=True)
    ap.add_argument("--at", help="UTC time HH:MM to start (omit to start now)")
    ap.add_argument("--plan", default=",".join(DEFAULT_PLAN))
    args = ap.parse_args(argv)
    plan = [p.strip().capitalize() for p in args.plan.split(",") if p.strip()]
    try:  # keep Windows awake (and the emulators running) until this exits
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000000 | 0x00000001)
    except Exception:
        pass
    if args.at:
        wait = seconds_until(args.at)
        print(f"waiting {wait / 3600:.2f} h until {args.at} UTC", flush=True)
        time.sleep(wait)
    devices = adb.discover(only=args.only)
    if not devices:
        print("No running Kingshot instances found.", flush=True)
        return
    for d in devices:
        try:
            Gather(d, Vision(TEMPLATE_DIR)).run(plan)
        except Exception as e:
            d.log(f"error: {e!r}")


if __name__ == "__main__":
    main()
