# Kingshot Python — code export

All Python code from the Kingshot bots (ADB + OpenCV automation of BlueStacks / MuMu / Google
Play emulator instances), exported 2026-10-19 for reuse in another project.

- **`FUNCTIONS.md`** — index of every module, class, method and function: signature + first
  docstring line (85 modules, 466 functions, 47 classes / 344 methods, ~18k lines).
- **`functions.json`** — the same index, machine-readable (with line numbers).
- The packages below, with the image templates and data they load at run time.
- `tests/` — 526 tests (pytest), all passing in this folder as exported.
- `legacy_scripts/` — the older standalone root scripts (pyautogui era), for reference only.

## Layout

| Package | What it is | Run |
|---|---|---|
| `intel_adb/` | **Shared core**, used by every bot — see below. Also the Intel bot and the **Kingshot Bots** Tkinter GUI. | `python -m intel_adb.gui` |
| `bear_adb/` | Bear hunt: own rally + joins with formation round robin | `python -m bear_adb.bear` |
| `terror_adb/` | Terror rallies: formations / Equalize, rallies at once, coordinate claims, 1-troop | `python -m terror_adb.terror` |
| `caravan_adb/` | Caravans: collect, refresh to gold (diamond-capped), escort | `python -m caravan_adb.caravan` |
| `cesares_adb/` | Cesares boss (chat cards, 1 infantry) and Cesares Raider (Fury levels) | `python -m cesares_adb.boss` / `.raider` |
| `fishing_adb/` | Fishing tournament: vision, steering, prediction, fish catalogue, helper overlay | `python -m fishing_adb.helper` |
| `gather_adb/`, `journey_adb/`, `pouch_adb/` | Gathering, Journey event, Red pouch | `python -m <pkg>.<module>` |
| `autopilot/` | **Kingshot Autopilot** Flet app: daily jobs engine, growth (hunt / research / meat), city, rewards, characters | `python -m autopilot.app` |
| `giftcode/` | Gift code redeemer | `python -m giftcode.app` |

Every bot takes `--only NAME` (repeatable) and `--dry-run`; `--help` lists the rest.

## The reusable core (`intel_adb`)

| Module | Use it for |
|---|---|
| `adb` | `discover()` finds running instances with Kingshot open → `Device`s. `Device.screencap()` (normalised to 540 px wide, landscape emulators cropped to the game), `tap(x, y)`, `swipe`, `back`, `log`. |
| `vision` | `Vision(template_dir)`: `find`, `find_all(region=…)`, `has` — OpenCV TM_CCOEFF_NORMED template matching. |
| `timer` | Tesseract set-up (`available()`, `pytesseract`) and march-time OCR. |
| `popups` | Common popups (formation warning confirm, …). |
| `touch` | Raw multi-touch through `/dev/input` (`Touch`), `--release NAME` to lift stuck fingers. |
| `stream` | Fast frames: screenrecord h264 → OpenCV over a local socket. |
| `one_troop` | Deploy screen: Clear All + one Infantry. |
| `intel_flow` | Map helpers, e.g. `read_marching` ("Marching N/M"). |

All coordinates are in the 540×960 portrait frame that `screencap()` returns.

## Setup

1. `pip install -r requirements.txt`
2. Install **Tesseract OCR** to `C:\Program Files\Tesseract-OCR\` (path in `intel_adb/timer.py`).
3. Machine-specific paths — edit them for another PC:
   - `intel_adb/adb.py`: `ADB_PATH` (BlueStacks `HD-Adb.exe`), `CONF_PATH` (`bluestacks.conf`),
     `MUMU_VMS` (MuMu instance configs).
   - `intel_adb/bs_extras.py`: `CONF`.
4. Run from this folder so the packages import each other: `python -m pytest tests -q`.

## Left out on purpose

- Recordings, debug screenshots and capture folders (hundreds of MB of game screens, not code).
- Personal state: `autopilot/settings*.json` and `state.json`, `terror_adb/claims.json`,
  `cesares_adb/raider_state.json`, the GUI's `gui_settings.json`, player-ID lists.
- `.superpowers/` one-off patch scripts and `.venv/`.

## Notes

- `giftcode/app.py` and `legacy_scripts/giftcode.py` contain the gift-code API signing salt
  (`WOS_ENCRYPT_KEY`). Move it to an environment variable before putting this code anywhere public.
- The image templates are crops of Kingshot's own screens: fine for your own use, don't
  publish them.
- Kingshot's terms don't allow automation, so accounts that use these bots risk a ban.
