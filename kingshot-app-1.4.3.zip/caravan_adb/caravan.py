"""Caravans (Events > caravan tab > My Caravan), recorded on 685 #5 Ainz Ooal Gown 2026-10-15.

For each free slot: collect finished caravans' rewards, open a new caravan, refresh it until
it is gold (SSR), then Escort. The user OK'd spending diamonds on caravan refreshes ONLY
(2026-10-15): free, then 100, 200, 300, 400, 500 - "Guaranteed in 6 SSR". Hard limits:
  - at most MAX_PER_CARAVAN diamonds per caravan, MAX_PRICE per refresh,
  - the Confirm dialog must say "Spend [Gems] to roll for Caravan" and show the same price
    the card showed, else it is closed and nothing is spent,
  - the diamond count is read before and after; any surprise stops the bot,
  - unknown rarity / unreadable price = no refresh.

    python -m caravan_adb.caravan [--only NAME ...] [--dry-run]
"""
import argparse
import re
import threading
import time
from pathlib import Path

import cv2

from intel_adb import adb
from intel_adb.vision import Vision
from fishing_adb.tourney import ocr
from bear_adb.bear import _ocr_white_text

TEMPLATE_DIR = Path(__file__).parent / "templates"
DEBUG_DIR = Path(__file__).parent / "debug"

MAX_PER_CARAVAN = 1500  # diamonds: free + 100 + 200 + 300 + 400 + 500
MAX_PRICE = 500
MAX_REFRESHES = 6
SEND = ("epic", "gold")  # user 2026-10-15: "only send purple and above"
SEEN = 0.8
PLUS_SEEN = 0.75  # the "+" pulses
STAGGER = 3  # s between starting instances
OUTSIDE_CARD = (270, 905)  # below the caravan card: closes it without escorting

CARAVAN_TAB = (270, 105)
MY_CARAVAN = (113, 192)
BACK_ARROW = (38, 28)
REFRESH = (456, 313)  # the yellow arrows on the caravan card
ESCORT = (270, 771)
CONFIRM_REFRESH = (270, 590)  # orange "Refresh <price>" in the Spend Gems dialog
DIALOG_CLOSE = (478, 335)  # X of the Spend Gems / Tips dialogs
TIPS_CONFIRM = (383, 591)  # "Other caravans may offer higher-level rewards. Escort anyway?"
TAP_TO_EXIT = (270, 915)

BAR = (130, 330, 160, 355)  # coloured "Time Required" bar: its hue = the rarity
CARD_PRICE = (412, 334, 482, 358)
DIALOG_PRICE = (258, 592, 312, 616)
GEMS = (440, 20, 505, 45)
DEPARTURES = (160, 868, 380, 893)


def rarity(img):
    """'uncommon' / 'rare' / 'epic' / 'gold' from the card's bar colour, or None."""
    x0, y0, x1, y1 = BAR
    hsv = cv2.cvtColor(img[y0:y1, x0:x1], cv2.COLOR_BGR2HSV).reshape(-1, 3)
    h, s = float(sorted(hsv[:, 0])[len(hsv) // 2]), float(sorted(hsv[:, 1])[len(hsv) // 2])
    if s < 60:
        return None
    if 45 <= h <= 85:
        return "uncommon"  # measured 61
    if 95 <= h <= 118:
        return "rare"  # 106-109
    if 122 <= h <= 160:
        return "epic"  # 130-135
    if 8 <= h <= 35 and s >= 100:
        return "gold"
    return None


def price(text):
    """0 for 'Free', the number for '200', None if unreadable."""
    t = (text or "").strip()
    if "Free" in t or "ree" in t:
        return 0
    m = re.search(r"\d+", t)
    return int(m.group()) if m else None


def white_ocr(img, box):
    """White digits on the orange button (plain OCR reads nothing there)."""
    x0, y0, x1, y1 = box
    return _ocr_white_text(img[y0:y1, x0:x1], "0123456789")


def number(text):
    digits = re.sub(r"[^\d]", "", text or "")
    return int(digits) if digits else None


class Caravan:
    def __init__(self, device, vision, sleep=time.sleep, read=ocr, read_white=white_ocr,
                 rarity_fn=rarity):
        self.d, self.v, self.sleep = device, vision, sleep
        self.read, self.read_white, self.rarity = read, read_white, rarity_fn
        self.sent = 0
        self.spent = 0
        self.claimed = 0

    def shot(self):
        return self.d.screencap()

    def seen(self, img, name):
        return self.v.has(img, name, SEEN)

    def gems(self, img):
        return number(self.read(img, GEMS, "0123456789,"))

    def save_debug(self, img, tag):
        try:
            DEBUG_DIR.mkdir(parents=True, exist_ok=True)
            cv2.imwrite(str(DEBUG_DIR / f"{self.d.name}_{tag}_{time.strftime('%H%M%S')}.png"), img)
        except Exception:
            pass

    # ---- getting there -------------------------------------------------
    def on_caravans(self, img):
        """My Caravan screen. Its "My Caravan" label is often under the progress bar or the
        "Departed" banner, so the "Remaining Departures" line at the bottom decides."""
        return self.seen(img, "departures_label") or self.seen(img, "my_caravan")

    def open(self):
        for _ in range(10):
            img = self.shot()
            if self.on_caravans(img):
                return True
            if self.seen(img, "tap_continue"):  # "Last Match: Victory" and similar results
                self.d.tap(*TAP_TO_EXIT)
                self.sleep(1.2)
                continue
            if self.seen(img, "events_title"):
                self.d.tap(*CARAVAN_TAB)
                self.sleep(1.2)
                self.d.tap(*MY_CARAVAN)
                self.sleep(1.2)
                continue
            # the round caravan icon by the map's bottom right (user: "just click on the small
            # caravans icon"); Events is only the fallback
            pos = self.v.find(img, "caravan_icon", SEEN) or self.v.find(img, "events_icon", SEEN)
            if pos:
                self.d.tap(*pos)
                self.sleep(2)
                continue
            self.sleep(1)
        self.save_debug(self.shot(), "no_caravan_screen")
        return False

    def leave(self):
        img = self.shot()
        if self.seen(img, "events_title"):
            self.d.tap(*BACK_ARROW)
            self.sleep(1)

    # ---- one caravan ---------------------------------------------------
    def wait_card(self):
        for _ in range(6):
            self.sleep(0.8)
            img = self.shot()
            if self.seen(img, "escort_button"):
                return img
        return None

    def close_card(self):
        """Leave the caravan without escorting it (user: only purple and above go)."""
        for _ in range(3):
            self.d.tap(*OUTSIDE_CARD)
            self.sleep(1.2)
            if not self.seen(self.shot(), "escort_button"):
                return

    def escort(self):
        self.d.tap(*ESCORT)
        self.sleep(1.2)
        img = self.shot()
        if self.seen(img, "tips_text"):  # "Other caravans may offer higher-level rewards"
            self.d.tap(*TIPS_CONFIRM)
            self.sleep(1.5)
        for _ in range(6):  # the "Departed" banner plays over the screen for a moment
            img = self.shot()
            if self.on_caravans(img) and not self.seen(img, "escort_button"):
                self.sent += 1
                return True
            self.sleep(1)
        self.save_debug(img, "after_escort")
        return False

    def refresh_once(self, card_img, cost, item):
        """One refresh: `cost` diamonds (0 = free), or one refresh item. False = stop."""
        before = self.gems(card_img)
        if before is None:
            self.d.log("caravan: can't read the diamonds - not refreshing")
            return False
        self.d.tap(*REFRESH)
        self.sleep(1.0)
        img = self.shot()
        if self.seen(img, "spend_gems"):
            shown = price(self.read_white(img, DIALOG_PRICE))
            if item or not cost or shown != cost:
                self.d.log(f"caravan: refresh dialog asks {shown} diamonds, card said "
                           f"{'an item' if item else cost} - closing it")
                self.d.tap(*DIALOG_CLOSE)
                self.sleep(1)
                return False
            self.d.tap(*CONFIRM_REFRESH)
            self.sleep(1.5)
        elif cost:
            self.save_debug(img, "no_spend_dialog")
            self.d.log("caravan: no price dialog after a paid refresh - stopping")
            return False
        img = self.wait_card()
        if img is None:
            return False
        after = self.gems(img)
        if after is None or before - after != cost:
            self.d.log(f"caravan: diamonds {before} -> {after}, expected -{cost} - stopping")
            raise RuntimeError("unexpected diamond change")
        self.spent += cost
        return True

    def handle_card(self):
        """Refresh until gold; escort only purple (epic) or gold. Returns False to stop."""
        spent = 0
        for _ in range(MAX_REFRESHES + 1):
            img = self.wait_card()
            if img is None:
                return False
            r = self.rarity(img)
            if r == "gold":
                self.d.log(f"caravan: gold - escort ({spent} diamonds on refreshes)")
                return self.escort()
            text = self.read(img, CARD_PRICE, "Free0123456789/")
            item = "/" in text  # "1/14": refresh items instead of diamonds
            cost = 0 if item else price(text)
            can = (r is not None and cost is not None and cost <= MAX_PRICE
                   and spent + cost <= MAX_PER_CARAVAN and not self.d.dry_run)
            if not can:
                if r in SEND:
                    self.d.log(f"caravan: {r}, can't refresh further ({text.strip() or '?'}) - escort")
                    return self.escort()
                self.save_debug(img, "not_sent")
                self.d.log(f"caravan: {r or 'unknown'} and can't refresh further - not sending it")
                self.close_card()
                return False
            what = "a refresh item" if item else ("free" if cost == 0 else f"{cost} diamonds")
            self.d.log(f"caravan: {r} - refresh ({what})")
            if not self.refresh_once(img, cost, item):
                img = self.shot()
                if self.seen(img, "escort_button") and self.rarity(img) in SEND:
                    return self.escort()
                self.close_card()
                return False
            spent += cost
        self.close_card()
        return False

    # ---- main ----------------------------------------------------------
    def run(self, max_steps=40):
        if not self.open():
            self.d.log("caravan: couldn't open My Caravan")
            return self.sent
        for _ in range(max_steps):
            img = self.shot()
            if self.seen(img, "escort_rewards") or self.seen(img, "tap_continue"):
                self.claimed += self.seen(img, "escort_rewards")
                self.d.tap(*TAP_TO_EXIT)
                self.sleep(1.2)
                continue
            if not self.on_caravans(img):
                self.sleep(1)
                if not self.open():
                    break
                continue
            chest = self.v.find(img, "chest", SEEN)
            if chest:
                self.d.tap(*chest)
                self.sleep(1.5)
                continue
            left = number(self.read(img, DEPARTURES, "0123456789/RemainigDpatus: ").split(":")[-1][:1])
            plus = self.v.find(img, "plus", PLUS_SEEN)
            if not left or not plus:
                self.d.log(f"caravan: departures left {left}, free slot {'yes' if plus else 'no'} - done")
                break
            self.d.tap(*plus)
            self.sleep(1.2)
            if not self.handle_card():
                break
        self.leave()
        self.d.log(f"caravan: finished - sent {self.sent}, rewards collected {self.claimed}, "
                   f"diamonds spent {self.spent}")
        return self.sent


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--only", action="append")
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args(argv)
    devices = adb.discover(only=a.only, dry_run=a.dry_run)
    if not devices:
        print("No instance with Kingshot open.")
        return
    v = Vision(TEMPLATE_DIR)

    def one(d):
        try:
            Caravan(d, v).run()
        except RuntimeError as e:
            d.log(f"caravan: stopped - {e}")
        except Exception as e:  # one instance failing must not stop the others
            d.log(f"caravan: error - {e!r}")
    print(f"Caravans on {len(devices)} instance(s) at once: " + ", ".join(d.name for d in devices), flush=True)
    threads = [threading.Thread(target=one, args=(d,)) for d in devices]
    for t in threads:
        t.start()
        time.sleep(STAGGER)  # not all tapping at the same moment (eases emulator lag)
    for t in threads:
        t.join()


if __name__ == "__main__":
    main()
