"""Lucky Pouch: the first 10 players to open a pouch posted in chat win diamonds.

Watches the map for the little pouch bubble next to the chat strip, opens chat, finds the
newest pouch that can still be opened (a card with a countdown clock - claimed/finished
cards have none), opens it, and goes back to watching. Stops at the daily limit.

    python -m pouch_adb.pouch [--only Primary] [--dry-run]
"""
import argparse
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import cv2

from intel_adb import adb
from intel_adb.vision import Vision

TEMPLATE_DIR = Path(__file__).parent / "templates"

TAB = {"World": (100, 88), "Alliance": (270, 88)}
OTHER = {"World": "Alliance", "Alliance": "World"}
OPEN_BUTTON = (270, 762)
POPUP_CLOSE = (453, 130)
RESULT_CLOSE = (463, 166)
CHAT_CLOSE = (512, 30)
CHAT_STRIP = (250, 848)  # the chat lines on the map: tapping the bubble itself does nothing
CARD_FROM_CLOCK = (255, -45)  # pouch bag on the card, relative to its clock icon
TICK = 1.0  # s between map checks while waiting for a pouch


def card_tap(clock_pos):
    return clock_pos[0] + CARD_FROM_CLOCK[0], clock_pos[1] + CARD_FROM_CLOCK[1]


def open_cards(vision, img):
    """Clock icons of pouch cards that can still be opened, top to bottom (newest last)."""
    return sorted(vision.find_all(img, "card_clock", 0.8), key=lambda p: p[1])


def open_lit(img):
    """The popup's Open button is teal (claimable), not grey (limit reached / pouch gone)."""
    x, y = OPEN_BUTTON
    hsv = cv2.cvtColor(img[y - 15:y + 15, x - 80:x + 80], cv2.COLOR_BGR2HSV)
    teal = cv2.inRange(hsv, (80, 120, 150), (100, 255, 255))
    return teal.mean() / 255 > 0.4


class Pouch:
    def __init__(self, device, vision, sleep=time.sleep, clock=time.monotonic, open_lit_fn=open_lit):
        self.d, self.v, self.sleep, self.clock = device, vision, sleep, clock
        self.open_lit = open_lit_fn
        self.tab = "World"  # chat opens on World
        self.tried_other = False
        self.stats = {"claimed": 0, "missed": 0, "limit": False}
        self.dry_logged = set()

    def tap(self, p):
        self.d.tap(*p, jitter=2)

    def dry(self, msg):
        if msg not in self.dry_logged:
            self.d.log(f"(dry-run) {msg}")
            self.dry_logged.add(msg)

    def step(self, img):
        """Handle one screenshot; returns 'busy' when it acted, 'done' at the daily limit."""
        if self.v.has(img, "quit_game"):
            self.tap(self.v.find(img, "cancel_button") or (156, 591))
            return "busy"
        if self.v.has(img, "pouch_title"):
            if self.v.has(img, "limit_text") or self.stats["limit"]:
                self.d.log("Daily Lucky Pouch limit reached - stopping")
                self.stats["limit"] = True
                if not self.d.dry_run:
                    self.tap(POPUP_CLOSE)
                return "done"
            if self.d.dry_run:
                self.dry(f"pouch popup, Open {'lit' if self.open_lit(img) else 'grey'}")
                return "idle"
            if self.open_lit(img):
                self.tap(OPEN_BUTTON)
                self.sleep(1.5)
                self.tap(RESULT_CLOSE)
                self.stats["claimed"] += 1
                self.d.log(f"pouch opened - {self.stats['claimed']} today")
            else:
                self.tap(POPUP_CLOSE)
                self.stats["missed"] += 1
                self.d.log("pouch already gone")
            return "busy"
        if self.v.has(img, "chat_title"):
            cards = open_cards(self.v, img)
            if cards:
                if self.d.dry_run:
                    self.dry(f"{len(cards)} open pouch(es) in {self.tab} chat")
                    return "idle"
                self.tap(card_tap(cards[-1]))  # newest = lowest on screen
                self.tried_other = False
                return "busy"
            if self.d.dry_run:
                self.dry(f"chat open, no open pouch in {self.tab}")
                return "idle"
            if not self.tried_other:  # pouch may be in the other tab (alliance members)
                self.tab = OTHER[self.tab]
                self.tried_other = True
                self.tap(TAB[self.tab])
                return "busy"
            self.tried_other = False
            self.tap(CHAT_CLOSE)  # nothing to open: back to watching
            return "busy"
        if self.v.has(img, "pouch_bubble"):
            if self.d.dry_run:
                self.dry("pouch bubble on the map")
                return "idle"
            self.d.log("pouch posted - opening chat")
            self.tab = "World"
            self.tried_other = False
            self.tap(CHAT_STRIP)
            return "busy"
        return "idle"

    def run(self, max_minutes=12 * 60):
        end = self.clock() + max_minutes * 60
        while self.clock() < end:
            result = self.step(self.d.screencap())
            if result == "done":
                break
            self.sleep(0.5 if result == "busy" else TICK)
        self.d.log(f"finished: {self.stats}")
        return self.stats


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--only", action="append")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--minutes", type=float, default=12 * 60)
    args = ap.parse_args(argv)
    devices = adb.discover(only=args.only, dry_run=args.dry_run)
    if not devices:
        print("No running Kingshot instances found.")
        return
    print(f"Watching for pouches on: {', '.join(d.name for d in devices)}", flush=True)

    def one(d):
        try:
            return Pouch(d, Vision(TEMPLATE_DIR)).run(args.minutes)
        except Exception as e:
            d.log(f"error: {e!r}")

    with ThreadPoolExecutor(max_workers=len(devices)) as pool:
        list(pool.map(one, devices))


if __name__ == "__main__":
    main()
