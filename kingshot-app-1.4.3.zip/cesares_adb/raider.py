"""Cesares Fury - the Cesares Raider (recorded on Primary 2026-10-18). Levels 1-25, one at a
time: Events -> Cesares Fury (Private) -> Scout (15 stamina) -> the raider's popup:

* normal level: Attack -> formation flag -> Diana in the formation (her skill: Deploy costs 8
  stamina instead of 10) -> Deploy. A win moves the event to the next level.
* help level: Request Help (1 Cesares Accord) -> Confirm. Allies kill it - the bot waits.

Help levels, in the user's order: bosses 15, 20, 25 first, then 24, 23 (the 5 accords you
start with), then 22, 21, 19, 18, 17 (the 5 you can earn).

Stamina (user, 2026-10-18): about 668 a day (1 per 5 min = 288, two claims of 160, pet 60).
The 10 daily terrors take 200, so the Raider spends at most 468 a day, and spreads the levels
left evenly over the event's days left. Never uses meat, never buys: when stamina runs out it
waits and tries again.

    python -m cesares_adb.raider [--only "Primary"] [--preset-for "Primary=5"] [--dry-run]
"""
import argparse
import json
import math
import re
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from pathlib import Path

import cv2
import numpy as np

from intel_adb import adb, popups, timer
from intel_adb.vision import Vision

TEMPLATE_DIR = Path(__file__).parent / "templates"
TERROR_TEMPLATES = Path(__file__).parent.parent / "terror_adb" / "templates"
STATE_FILE = Path(__file__).parent / "raider_state.json"
DEBUG_DIR = Path(__file__).parent / "debug"

LAST_LEVEL = 25
HELP_ORDER = (15, 20, 25, 24, 23, 22, 21, 19, 18, 17)  # user's order for Request Help
START_ASSISTS = 5  # accords at the start; up to 5 more can be earned
STAMINA_PER_DAY = 668  # 288 regen + 2x160 claims + 60 pet
TERROR_RESERVE = 200  # 10 daily terrors x 20
SCOUT_COST = 15
ATTACK_COST = 8  # with Diana (10 without)

PRESET_X = {1: 40, 2: 95, 3: 151, 4: 207, 5: 265, 6: 321, 7: 377, 8: 433}  # formation flags
PRESET_Y = 92
HERO_SLOT_1 = (128, 300)  # first hero card on the Deploy screen -> Select Heroes
SELECT_CLOSE = (481, 111)  # X on Select Heroes
HELP_CONFIRM = (384, 590)  # teal Confirm on the "Help requests require Cesares Accord" tips
GET_MORE_CLOSE = (501, 108)  # X on "Get More" (out of stamina) - never buys
QUEUE_CLOSE = (481, 254)  # X on "March Queue"
LEVEL_BOX = (248, 655, 82, 37)  # "Lv. 11" on the event page (x, y, w, h)
LEFT_BOX = (58, 266, 117, 28)  # "1d 08:23:43" left in the event
ACCORD_BOX = (264, 853, 36, 20)  # "8/1" under Request Help

SCREEN_WAIT = 5.0
POLL = 0.4
RESULT_WAIT = 5 * 60  # s to see the level go up after a Deploy
HELP_WAIT = 65 * 60  # s for allies to kill a raider we asked help for (it lasts 1 h)
HELP_POLL = 10 * 60
NO_STAMINA_WAIT = 30 * 60
MAX_FAILS = 8
MAX_LOSSES = 3  # lost fights on one level before leaving it to the user
RETRY_WAITS = (5, 10, 20, 30, 60)


# ---------- reading the screen ----------

def _white_mask(crop, s=60, v=200):
    hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
    return ((hsv[..., 1] < s) & (hsv[..., 2] > v)).astype(np.uint8) * 255


def _ocr(img, config):
    if timer.pytesseract is None or not timer.available():
        return ""
    try:
        return timer.pytesseract.image_to_string(img, config=config)
    except Exception:
        return ""


def _crop(img, box):
    x, y, w, h = box
    return img[y:y + h, x:x + w] if hasattr(img, "shape") else None


def parse_level(text):
    """'Ly. 11' / 'Lv, 12' -> 11 / 12 (OCR reads "Lv" as "Ly")."""
    m = re.search(r"l[vy][.,]?\s*(\d{1,2})", (text or "").lower())
    return int(m.group(1)) if m and 1 <= int(m.group(1)) <= 30 else None


def parse_left(text):
    """'1d 08:23:43' / 'Id 08:23:25' -> seconds left (OCR reads "1" as "I")."""
    t = (text or "").replace("I", "1").replace("l", "1")
    m = re.search(r"(?:(\d+)\s*d)?\s*(\d{1,2}):(\d{2}):(\d{2})", t)
    if not m:
        return None
    d, h, mi, s = (int(g or 0) for g in m.groups())
    return ((d * 24 + h) * 60 + mi) * 60 + s


def parse_accords(text):
    m = re.match(r"\s*(\d{1,2})\s*/", text or "")
    return int(m.group(1)) if m else None


def read_level(img):
    c = _crop(img, LEVEL_BOX)
    if c is None or c.size == 0:
        return None
    return parse_level(_ocr(cv2.resize(255 - _white_mask(c), None, fx=3, fy=3), "--psm 7"))


def read_left(img):
    c = _crop(img, LEFT_BOX)
    if c is None or c.size == 0:
        return None
    return parse_left(_ocr(cv2.resize(255 - _white_mask(c), None, fx=3, fy=3), "--psm 7"))


def read_accords(img):
    """Cesares Accords owned, from "8/1" under Request Help (None if unreadable)."""
    c = _crop(img, ACCORD_BOX)
    if c is None or c.size == 0:
        return None
    b = cv2.copyMakeBorder(cv2.resize(255 - _white_mask(c, 50, 215), None, fx=4, fy=4),
                           20, 20, 20, 20, cv2.BORDER_CONSTANT, value=255)
    return parse_accords(_ocr(b, "--psm 7 -c tessedit_char_whitelist=0123456789/"))


# ---------- planning ----------

def help_levels(total_accords):
    """Levels that get Request Help with this many accords in all (used + owned)."""
    return set(HELP_ORDER[:max(0, total_accords)])


def days_left(seconds_left, now):
    """UTC days the event still touches, today included."""
    if seconds_left is None:
        return 1
    end = now + timedelta(seconds=seconds_left)
    return max(1, (end.date() - now.date()).days + 1)


def levels_for_today(level, seconds_left, now, done_today):
    """How many more levels to do today: what's left spread evenly over the days left."""
    left = LAST_LEVEL - level + 1
    if left <= 0:
        return 0
    per_day = math.ceil((left + done_today) / days_left(seconds_left, now))
    return max(0, per_day - done_today)


def stamina_budget():
    return STAMINA_PER_DAY - TERROR_RESERVE


class State:
    """Per-instance memory in raider_state.json: day counters and accords used."""

    def __init__(self, name, path=STATE_FILE):
        self.name, self.path = name, path

    def _all(self):
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def get(self, today):
        s = self._all().get(self.name, {})
        if s.get("day") != today:
            s.update(day=today, spent=0, levels=0)
        s.setdefault("assists", [])  # levels we used a Cesares Accord on
        s.setdefault("helped_at", {})  # level -> unix time help was asked
        return s

    def save(self, s):
        data = self._all()
        data[self.name] = s
        try:
            self.path.write_text(json.dumps(data, indent=1), encoding="utf-8")
        except Exception:
            pass


# ---------- the bot ----------

class Raider:
    def __init__(self, device, preset=None, sleep=time.sleep, clock=time.monotonic,
                 now=lambda: datetime.now(timezone.utc), state=None, assists=START_ASSISTS):
        self.d, self.sleep, self.clock, self.now = device, sleep, clock, now
        self.v = Vision(TEMPLATE_DIR)
        self.tv = Vision(TERROR_TEMPLATES)
        self.preset = preset
        self.state = state or State(device.name)
        self.assists = assists  # accords in all when the screen can't be read

    def shot(self):
        return self.d.screencap()

    def wait_for(self, name, timeout=SCREEN_WAIT):
        end = self.clock() + timeout
        while True:
            img = self.shot()
            if self.v.has(img, name):
                return img
            if self.clock() >= end:
                return None
            self.sleep(POLL)

    def save_debug(self, tag):
        try:
            img = self.shot()
            if hasattr(img, "shape"):
                DEBUG_DIR.mkdir(parents=True, exist_ok=True)
                cv2.imwrite(str(DEBUG_DIR / f"{self.d.name}_{tag}_{time.strftime('%H%M%S')}.png"), img)
        except Exception:
            pass

    def back(self):
        self.d.back()
        self.sleep(POLL)
        img = self.shot()
        if self.tv.has(img, "quit_game"):  # never quit the game
            pos = self.tv.find(img, "cancel_button")
            if pos:
                self.d.tap(*pos)

    def to_map(self):
        for _ in range(5):
            img = self.shot()
            if self.tv.has(img, "magnify") and not self.v.has(img, "raider_attack"):
                return True
            self.back()
        return False

    def open_event(self):
        """Events -> Cesares Fury tab. The event page's screenshot, or None."""
        img = self.shot()
        if self.v.has(img, "fury_title"):
            return img
        if not self.to_map():
            return None
        pos = self.v.find(self.shot(), "events_icon", 0.7)
        if not pos:
            return None
        self.d.tap(*pos)
        img = self.wait_for("events_title")
        if img is None:
            return None
        tab = self.v.find(img, "fury_tab")
        if not tab:
            self.d.log("no Cesares Fury tab in Events")
            return None
        self.d.tap(*tab)
        return self.wait_for("fury_title")

    def scout(self):
        """Event page -> Scout -> the raider's popup. Popup screenshot, 'stamina' or None."""
        img = self.shot()
        pos = self.v.find(img, "scout_button")
        if not pos:
            return None
        self.d.tap(*pos)
        img = self.wait_for("raider_attack", timeout=SCREEN_WAIT * 2)
        if img is None and self.v.has(self.shot(), "get_more_title"):
            self.d.tap(*GET_MORE_CLOSE, jitter=0)
            return "stamina"
        return img

    def ensure_diana(self):
        """Diana in the formation (Deploy 8 stamina). Swaps her into the first slot if needed."""
        img = self.shot()
        if self.v.find_all(img, "diana_deploy", 0.8, region=(60, 220, 440, 200)):
            return True
        self.d.tap(*HERO_SLOT_1, jitter=2)
        img = self.wait_for("select_heroes")
        if img is None:
            return False
        tile = self.v.find(img, "diana_tile")
        if not tile:
            self.d.log("Diana isn't in the hero list - deploying without her")
            self.d.tap(*SELECT_CLOSE, jitter=0)
            self.sleep(POLL)
            return False
        self.d.tap(*tile)
        self.sleep(POLL * 2)
        self.d.tap(*SELECT_CLOSE, jitter=0)
        self.sleep(POLL * 2)
        return bool(self.v.find_all(self.shot(), "diana_deploy", 0.8, region=(60, 220, 440, 200)))

    def attack(self, popup):
        """Raider popup -> Attack -> flag + Diana -> Deploy. 'sent', 'stamina', 'busy', 'failed'."""
        pos = self.v.find(popup, "raider_attack")
        if not pos:
            return "failed"
        self.d.tap(*pos)
        img = self.wait_for("raider_deploy", timeout=SCREEN_WAIT * 2)
        if img is None:
            if self.v.has(self.shot(), "march_queue_title"):
                self.d.tap(*QUEUE_CLOSE, jitter=1)
                return "busy"
            self.save_debug("no_deploy")
            return "failed"
        if self.preset in PRESET_X:
            self.d.tap(PRESET_X[self.preset], PRESET_Y, jitter=0)
            self.sleep(POLL * 2)
        self.diana = self.ensure_diana()
        for _ in range(3):
            pos = self.v.find(self.shot(), "raider_deploy")
            if not pos:
                return "failed"
            self.d.tap(*pos)
            self.sleep(POLL * 2)
            img = self.shot()
            if popups.handle_confirm(self.d, self.tv, img):  # formation warnings
                self.sleep(POLL * 2)
                img = self.shot()
            if self.v.has(img, "get_more_title"):
                self.d.tap(*GET_MORE_CLOSE, jitter=0)  # never buys / uses meat
                self.sleep(POLL)
                self.back()
                return "stamina"
            if self.v.has(img, "march_queue_title"):
                self.d.tap(*QUEUE_CLOSE, jitter=1)
                return "busy"
            if not self.v.has(img, "raider_deploy"):
                return "sent"
        return "failed"

    def request_help(self, popup):
        """Raider popup -> Request Help -> Confirm on the Cesares Accord tips."""
        pos = self.v.find(popup, "request_help")
        if not pos:
            return "failed"
        self.d.tap(*pos)
        img = self.wait_for("help_tips")
        if img is not None:
            self.d.tap(*HELP_CONFIRM, jitter=2)
            self.sleep(POLL * 2)
        return "helped"

    def level_now(self):
        img = self.open_event()
        return (read_level(img), read_left(img)) if img is not None else (None, None)

    def wait_level_up(self, level, timeout):
        end = self.clock() + timeout
        while self.clock() < end:
            self.sleep(20 if timeout <= RESULT_WAIT else HELP_POLL)
            lv, _ = self.level_now()
            if lv and lv > level:
                return True
        return False

    def sleep_till_tomorrow(self):
        now = self.now()
        tomorrow = (now + timedelta(days=1)).replace(hour=0, minute=5, second=0, microsecond=0)
        secs = (tomorrow - now).total_seconds()
        self.d.log(f"today's Raider share is done - back at 00:05 UTC (in {secs / 3600:.1f} h)")
        self.to_map()
        self.sleep(secs)

    def run(self):
        if self.d.dry_run:
            self.d.log("(dry-run) would do the Cesares Raider levels")
            return 0
        fails = losses = 0
        done = 0
        while True:
            try:
                img = self.open_event()
            except Exception as e:
                self.d.log(f"error: {e!r}")
                img = None
            level = read_level(img) if img is not None else None
            if level is None:
                fails += 1
                if fails >= MAX_FAILS:
                    self.d.log("can't open / read the Cesares Fury event - stopping")
                    break
                self.save_debug("no_event")
                self.sleep(RETRY_WAITS[min(fails - 1, len(RETRY_WAITS) - 1)])
                continue
            if level > LAST_LEVEL:
                self.d.log("all 25 Raider levels done")
                break
            left = read_left(img)
            now = self.now()
            st = self.state.get(now.date().isoformat())
            asked = st["helped_at"].get(str(level))
            if asked and time.time() - asked < HELP_WAIT:
                self.d.log(f"Lv. {level}: help asked - waiting for allies to kill it")
                self.to_map()
                self.sleep(HELP_POLL)
                continue
            if levels_for_today(level, left, now, st["levels"]) <= 0 \
                    or st["spent"] + SCOUT_COST + ATTACK_COST > stamina_budget():
                self.sleep_till_tomorrow()
                continue
            popup = self.scout()
            if popup == "stamina":
                self.d.log(f"out of stamina - waiting {NO_STAMINA_WAIT // 60} min (never uses meat)")
                self.to_map()
                self.sleep(NO_STAMINA_WAIT)
                continue
            if popup is None:
                fails += 1
                if fails >= MAX_FAILS:
                    self.d.log(f"giving up after {fails} failures in a row")
                    break
                self.sleep(RETRY_WAITS[min(fails - 1, len(RETRY_WAITS) - 1)])
                continue
            st["spent"] += SCOUT_COST
            owned = read_accords(popup)
            total = len(st["assists"]) + owned if owned is not None else self.assists
            if level in help_levels(total) and str(level) not in st["helped_at"]:
                self.d.log(f"Lv. {level}: Request Help (Cesares Accord {len(st['assists']) + 1})")
                self.request_help(popup)
                st["assists"].append(level)
                st["helped_at"][str(level)] = time.time()
                self.state.save(st)
                self.to_map()
                if self.wait_level_up(level, HELP_WAIT):
                    st = self.state.get(self.now().date().isoformat())
                    st["levels"] += 1
                    done += 1
                    self.state.save(st)
                    self.d.log(f"Lv. {level} killed by allies")
                continue
            self.d.log(f"Lv. {level}: attacking")
            result = self.attack(popup)
            if result == "sent":
                st["spent"] += ATTACK_COST if getattr(self, "diana", True) else 10
                self.state.save(st)
                fails = 0
                self.to_map()
                if self.wait_level_up(level, RESULT_WAIT):
                    st = self.state.get(self.now().date().isoformat())
                    st["levels"] += 1
                    self.state.save(st)
                    done += 1
                    losses = 0
                    self.d.log(f"Lv. {level} won")
                else:
                    losses += 1
                    self.d.log(f"Lv. {level} not won ({losses}/{MAX_LOSSES})")
                    if losses >= MAX_LOSSES:
                        self.d.log(f"Lv. {level} is too strong - leaving it to you")
                        break
            elif result == "stamina":
                self.state.save(st)
                self.d.log(f"out of stamina - waiting {NO_STAMINA_WAIT // 60} min (never uses meat)")
                self.to_map()
                self.sleep(NO_STAMINA_WAIT)
            else:
                self.state.save(st)
                fails += 1
                if fails >= MAX_FAILS:
                    self.d.log(f"giving up after {fails} failures in a row")
                    break
                wait = RETRY_WAITS[min(fails - 1, len(RETRY_WAITS) - 1)]
                self.d.log(f"{'no free march' if result == 'busy' else 'that did not work'} - "
                           f"retrying in {wait}s")
                self.to_map()
                self.sleep(wait)
        self.to_map()
        self.d.log(f"finished: {done} Raider levels this run")
        return done


def parse_presets(items):
    out = {}
    for item in items or []:
        name, _, num = item.rpartition("=")
        if name and num.strip().isdigit() and int(num) in PRESET_X:
            out[name] = int(num)
    return out


def _run_one(dev, preset, assists, delay, sleep=time.sleep):
    sleep(delay)
    try:
        return dev.name, Raider(dev, preset=preset, assists=assists).run()
    except Exception as e:
        dev.log(f"error: {e!r}")
        return dev.name, 0


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--only", action="append", help="instance name; repeat for several")
    ap.add_argument("--preset", type=int, default=None, help="formation flag 1-8 for every instance")
    ap.add_argument("--preset-for", action="append", metavar="NAME=N", help="formation flag for one instance")
    ap.add_argument("--assists", type=int, default=START_ASSISTS,
                    help="Cesares Accords in all, used when the count can't be read (5, up to 10)")
    ap.add_argument("--stagger", type=float, default=3)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args(argv)
    presets = parse_presets(args.preset_for)
    devices = adb.discover(only=args.only, dry_run=args.dry_run)
    if not devices:
        print("No running Kingshot instances found.")
        return []
    print("Cesares Raider on: " + ", ".join(
        f"{d.name} (flag {presets.get(d.name, args.preset) or 'as is'})" for d in devices), flush=True)
    with ThreadPoolExecutor(max_workers=len(devices)) as pool:
        results = list(pool.map(lambda iv: _run_one(iv[1], presets.get(iv[1].name, args.preset),
                                                    args.assists, iv[0] * args.stagger),
                                enumerate(devices)))
    for name, n in results:
        print(f"{name}: {n} Raider levels")
    return results


if __name__ == "__main__":
    main()
