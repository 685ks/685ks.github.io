"""Cesares boss (recorded on Primary 2026-10-18): the alliance leader posts a pink "Cesares
Captain found!" card in Alliance chat for each of 5 bosses, one after the other:

    Lv. 1 Ravager, 2 Gilded Baron, 3 Plague Cleric, 4 Death Knight, 5 Highlord Cesares

One hit gets the full rewards (damage doesn't count), so each boss gets a single infantry:
tap the card's coordinates -> Attack -> remove the heroes, Clear All, + one Infantry -> Deploy.
Then wait in chat for the next level's card. Done after level 5.

In chat the bot only taps the coordinates on a Cesares card - it never types or sends.

    python -m cesares_adb.boss [--only "Primary"] [--dry-run]
"""
import argparse
import re
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import cv2
import numpy as np

from intel_adb import adb, one_troop, popups, timer
from intel_adb.vision import Vision

TEMPLATE_DIR = Path(__file__).parent / "templates"
TERROR_TEMPLATES = Path(__file__).parent.parent / "terror_adb" / "templates"

BOSSES = {1: "ravager", 2: "gilded baron", 3: "plague cleric", 4: "death knight", 5: "highlord cesares"}
LAST_LEVEL = 5
CARD_BOX = (-7, 20, 232, 70)  # "Cesares Captain found!" title centre -> pink box (dx, dy, w, h)
CHAT_TICKER = (150, 853)  # the chat lines above the bottom bar on the map: opens chat
POPUP_TITLE = (120, 662, 300, 30)  # "Lv. 5 Highlord Cesares" on the boss popup (x, y, w, h)
SAME_TARGET_CONFIRM = (384, 591)  # everyone hits the same boss: go ahead
QUEUE_CLOSE = (481, 254)  # X on "March Queue" (no free march)
GET_MORE_CLOSE = (501, 108)  # X on "Get More" (out of stamina) - never buys
SCREEN_WAIT = 5.0
POLL = 0.4
CHAT_POLL = 15  # s between looks at chat while waiting for the next boss
NEXT_MAX = 60 * 60  # s without a new boss before giving up
MAX_FAILS = 8  # failed attacks on one boss in a row
RETRY_WAITS = (5, 10, 20, 30, 60)
DEBUG_DIR = Path(__file__).parent / "debug"


def level_of(text):
    """Boss level from card / popup text: the boss name first (OCR reads "Lv." as "Ly."),
    then the number after "Lv"."""
    t = (text or "").lower()
    for lv, name in BOSSES.items():
        if name in t or name.split()[-1] in t:
            return lv
    m = re.search(r"l[vy][.,]?\s*([1-5])\b", t)
    return int(m.group(1)) if m else None


def _ocr_white(crop):
    """White text on the pink card -> string."""
    if timer.pytesseract is None or not timer.available():
        return ""
    hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
    m = ((hsv[..., 1] < 60) & (hsv[..., 2] > 200)).astype(np.uint8) * 255
    big = cv2.resize(255 - m, None, fx=3, fy=3)
    try:  # sparse mode reads the short "Lv. 1 Ravager" line; block mode the wrapped ones
        return " ".join(timer.pytesseract.image_to_string(big, config=f"--psm {psm}") for psm in (11, 6))
    except Exception:
        return ""


def _ocr_dark(crop):
    """Dark text on a light popup -> string."""
    if timer.pytesseract is None or not timer.available():
        return ""
    g = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    _, b = cv2.threshold(g, 120, 255, cv2.THRESH_BINARY)
    try:
        return timer.pytesseract.image_to_string(cv2.resize(b, None, fx=3, fy=3), config="--psm 7")
    except Exception:
        return ""


def coords_point(box):
    """Where to tap the light-blue "(X:716 Y:749)" link on a card: the middle of its biggest
    piece (the link can wrap onto two lines). None when there's no link."""
    hsv = cv2.cvtColor(box, cv2.COLOR_BGR2HSV)
    m = ((hsv[..., 0] > 85) & (hsv[..., 0] < 110) & (hsv[..., 1] > 120) & (hsv[..., 2] > 180)).astype(np.uint8)
    m = cv2.dilate(m, np.ones((5, 9), np.uint8))
    n, _, stats, cent = cv2.connectedComponentsWithStats(m)
    if n < 2:
        return None
    i = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    if stats[i, cv2.CC_STAT_AREA] < 150:
        return None
    return int(cent[i][0]), int(cent[i][1])


def find_cards(vision, img, read=_ocr_white):
    """Cesares cards on the chat screen, top to bottom: [(level or None, tap point or None)]."""
    out = []
    for cx, cy in sorted(vision.find_all(img, "captain_found", 0.8), key=lambda p: p[1]):
        dx, dy, w, h = CARD_BOX
        x0, y0 = max(0, cx - 100 + dx), cy + dy
        box = img[y0:y0 + h, x0:x0 + w] if hasattr(img, "shape") else None
        if box is None or box.size == 0:
            out.append((None, None))
            continue
        pt = coords_point(box)
        out.append((level_of(read(box)), (x0 + pt[0], y0 + pt[1]) if pt else None))
    return out


class Boss:
    def __init__(self, device, vision=None, sleep=time.sleep, clock=time.monotonic,
                 read_card=_ocr_white, read_title=_ocr_dark):
        self.d, self.sleep, self.clock = device, sleep, clock
        self.v = vision or Vision(TEMPLATE_DIR)
        self.tv = Vision(TERROR_TEMPLATES)  # map magnifier, popups shared with the terror bot
        self.read_card, self.read_title = read_card, read_title
        self.done = set()  # levels hit in this run

    def shot(self):
        return self.d.screencap()

    def wait_for(self, name, vision=None, timeout=SCREEN_WAIT):
        v = vision or self.v
        end = self.clock() + timeout
        while True:
            img = self.shot()
            if v.has(img, name):
                return img
            if self.clock() >= end:
                return None
            self.sleep(POLL)

    def save_debug(self, tag):
        try:
            img = self.shot()
            if hasattr(img, "shape"):
                DEBUG_DIR.mkdir(parents=True, exist_ok=True)
                cv2.imwrite(str(DEBUG_DIR / f"{self.d.name}_{tag}_{time.strftime('%H%M%S')}.png"), img)
        except Exception:
            pass

    def back(self):
        self.d.back()
        self.sleep(POLL)
        img = self.shot()
        if self.tv.has(img, "quit_game"):  # never quit the game
            pos = self.tv.find(img, "cancel_button")
            if pos:
                self.d.tap(*pos)

    def to_map(self):
        for _ in range(5):
            img = self.shot()
            if self.tv.has(img, "magnify") and not self.v.has(img, "possible_drops"):
                return True
            self.back()
        return False

    def open_chat(self):
        if self.v.has(self.shot(), "chat_title"):
            return True
        if not self.to_map():
            return False
        self.d.tap(*CHAT_TICKER, jitter=2)
        return self.wait_for("chat_title") is not None

    def latest_card(self):
        """(level, tap point) of the newest Cesares card in Alliance chat, or None."""
        if not self.open_chat():
            return None
        cards = find_cards(self.v, self.shot(), self.read_card)
        cards = [c for c in cards if c[0]]
        return cards[-1] if cards else None

    def attack(self, level, point):
        """Card coordinates -> Attack -> 1 infantry -> Deploy. 'sent', 'gone' (no boss of that
        level there any more), 'busy' (no free march), 'refused' or 'failed'."""
        self.d.tap(*point, jitter=1)
        img = self.wait_for("possible_drops")
        if img is None:  # the map moved there but no popup: tap the boss in the middle
            if self.tv.has(self.shot(), "magnify"):
                self.d.tap(270, 450, jitter=2)
                img = self.wait_for("possible_drops")
        if img is None:
            self.save_debug(f"no_popup_lv{level}")
            return "gone"
        title = level_of(self.read_title(self._crop(img, POPUP_TITLE)))
        if title and title != level:
            self.d.log(f"the boss there is level {title}, not {level}")
            return "gone"
        pos = self.v.find(img, "attack_button")
        if not pos:
            return "failed"
        self.d.tap(*pos)
        img = self.wait_for("deploy_button", timeout=SCREEN_WAIT * 2)
        if img is None:
            if self.tv.has(self.shot(), "march_queue_title"):
                self.d.tap(*QUEUE_CLOSE, jitter=1)
                return "busy"
            self.save_debug(f"no_deploy_lv{level}")
            return "failed"
        self.remove_heroes()
        if not one_troop.set_one_troop(self.d, self.shot, self.sleep, self.d.log):
            self.save_debug(f"no_one_troop_lv{level}")
            return "failed"
        return self.deploy()

    def remove_heroes(self):
        """Tap the orange "-" on each hero (right to left, so nothing shifts under the finger)."""
        for _ in range(6):
            hits = self.v.find_all(self.shot(), "hero_minus", 0.8)
            if not hits:
                return
            self.d.tap(*max(hits, key=lambda p: p[0]), jitter=1)
            self.sleep(POLL)

    def deploy(self):
        for _ in range(3):
            img = self.shot()
            pos = self.v.find(img, "deploy_button")
            if not pos:
                return "failed"
            self.d.tap(*pos)
            self.sleep(POLL * 2)
            img = self.shot()
            if popups.handle_confirm(self.d, self.tv, img):  # formation warnings
                self.sleep(POLL * 2)
                img = self.shot()
            if self.tv.has(img, "same_target") and not self.tv.has(img, "quit_game"):
                self.d.tap(*SAME_TARGET_CONFIRM, jitter=2)  # the whole alliance hits this boss
                self.sleep(POLL * 2)
                img = self.shot()
            if self.tv.has(img, "get_more_title"):
                self.d.log("out of stamina - stopping (never buys)")
                self.d.tap(*GET_MORE_CLOSE, jitter=0)
                self.sleep(POLL)
                self.back()
                return "refused"
            if self.tv.has(img, "march_queue_title"):
                self.d.tap(*QUEUE_CLOSE, jitter=1)
                return "busy"
            if not self.v.has(img, "deploy_button"):
                return "sent"
        return "failed"

    @staticmethod
    def _crop(img, box):
        x, y, w, h = box
        return img[y:y + h, x:x + w] if hasattr(img, "shape") else img

    def run(self, last=LAST_LEVEL):
        if self.d.dry_run:
            self.d.log("(dry-run) would hit each Cesares boss with 1 infantry")
            return 0
        fails, waited_since, logged = 0, self.clock(), None
        while max(self.done, default=0) < last:
            try:
                card = self.latest_card()
            except Exception as e:  # e.g. the emulator froze
                self.d.log(f"error: {e!r} - retrying")
                card = None
            level, point = card or (None, None)
            if not level or level in self.done or level < max(self.done, default=0) or not point:
                if self.clock() - waited_since > NEXT_MAX:
                    self.d.log(f"no new boss for {NEXT_MAX // 60} min - stopping")
                    break
                want = max(self.done, default=0) + 1
                if logged != want:
                    self.d.log(f"waiting in chat for the Lv. {want} boss card")
                    logged = want
                self.sleep(CHAT_POLL)
                continue
            self.d.log(f"Lv. {level} {BOSSES[level].title()} - sending 1 infantry")
            try:
                result = self.attack(level, point)
            except Exception as e:
                self.d.log(f"error: {e!r}")
                result = "failed"
            if result == "sent":
                self.done.add(level)
                fails, waited_since = 0, self.clock()
                self.d.log(f"Lv. {level} hit ({len(self.done)}/{last})")
                self.to_map()
            elif result == "gone":
                self.d.log(f"Lv. {level} isn't there any more - waiting for the next one")
                self.done.add(level)
                waited_since = self.clock()
                self.to_map()
            elif result == "refused":
                break
            else:
                fails += 1
                if fails >= MAX_FAILS:
                    self.d.log(f"giving up after {fails} failures in a row")
                    break
                wait = RETRY_WAITS[min(fails - 1, len(RETRY_WAITS) - 1)]
                why = "no free march" if result == "busy" else "it didn't work"
                self.d.log(f"{why} - retrying in {wait}s ({fails}/{MAX_FAILS})")
                self.to_map()
                self.sleep(wait)
        self.to_map()
        self.d.log(f"finished: hit levels {sorted(self.done) or 'none'}")
        return len(self.done)


def _run_one(dev, delay, sleep=time.sleep):
    sleep(delay)
    try:
        return dev.name, Boss(dev).run()
    except Exception as e:
        dev.log(f"error: {e!r}")
        return dev.name, 0


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--only", action="append", help="instance name; repeat for several")
    ap.add_argument("--stagger", type=float, default=3)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args(argv)
    devices = adb.discover(only=args.only, dry_run=args.dry_run)
    if not devices:
        print("No running Kingshot instances found.")
        return []
    print("Cesares boss on: " + ", ".join(d.name for d in devices), flush=True)
    with ThreadPoolExecutor(max_workers=len(devices)) as pool:
        results = list(pool.map(lambda iv: _run_one(iv[1], iv[0] * args.stagger), enumerate(devices)))
    for name, n in results:
        print(f"{name}: {n} bosses")
    return results


if __name__ == "__main__":
    main()
