"""The window's pages. Each takes the Hub (shared services and settings) and listens to its
signals; none of them touches adb directly."""
import html
import time
from datetime import datetime, timedelta, timezone

from PySide6.QtCore import QTimer, Qt, Signal
from PySide6.QtGui import QColor, QIcon, QImage, QPixmap, QTextCursor
from PySide6.QtWidgets import (QAbstractItemView, QComboBox, QDoubleSpinBox, QFileDialog, QFormLayout,
                               QGridLayout, QHBoxLayout, QHeaderView, QLabel, QLineEdit, QListWidget,
                               QListWidgetItem, QProgressBar, QPushButton, QScrollArea, QSpinBox,
                               QTableWidget, QTableWidgetItem, QTextEdit, QVBoxLayout, QWidget)

from intel_adb import commands as C
from kscommand import bots as B
from kscommand import core
from kscommand.ui.theme import C as COL
from kscommand.ui.widgets import (BarChart, Card, HeroButton, PulseDot, Ring, Spinner, StatTile, Toggle,
                                  chip, heading, hline, label, line_icon, monogram, no_emoji)


EYEBROWS = {"Teacher": "Automation", "Command Center": "Overview", "Autopilot": "Automation", "Bots": "Automation",
            "Characters": "Accounts",
            "Gift codes": "Rewards", "Statistics": "Insight", "Feature map": "Insight", "Settings": "System",
            "Logs": "System"}


def dim_last_word(title):
    """Hero-title treatment: the last word of a multi-word title in 500 weight, dimmed."""
    words = html.escape(title).split(" ")
    if len(words) < 2:
        return words[0]
    return (f"{' '.join(words[:-1])} <span style=\"color:{COL['dim']}; font-weight:500\">{words[-1]}</span>")


def scroll_page(title, sub):
    """A page: big title, subtitle, then a scrolling column. Returns (page, column layout)."""
    page = QWidget()
    outer = QVBoxLayout(page)
    outer.setContentsMargins(0, 0, 0, 0)
    sc = QScrollArea()
    sc.setWidgetResizable(True)
    sc.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
    body = QWidget()
    col = QVBoxLayout(body)
    col.setContentsMargins(32, 28, 32, 32)
    col.setSpacing(18)
    head = QVBoxLayout()
    head.setSpacing(4)
    head.addWidget(label(EYEBROWS.get(title, "Kingshot Command"), "eyebrow"))
    head.addWidget(label(dim_last_word(title), "pageTitle"))
    page.sub = label(sub, "pageSub")
    head.addWidget(page.sub)
    col.addLayout(head)
    sc.setWidget(body)
    outer.addWidget(sc)
    return page, col


def to_pixmap(img, radius=12):
    h, w = img.shape[:2]
    qi = QImage(img.data, w, h, img.strides[0], QImage.Format_BGR888).copy()
    pm = QPixmap.fromImage(qi)
    if radius:
        from PySide6.QtGui import QPainter, QPainterPath
        out = QPixmap(pm.size())
        out.fill(Qt.transparent)
        p = QPainter(out)
        p.setRenderHint(QPainter.Antialiasing)
        path = QPainterPath()
        path.addRoundedRect(0, 0, pm.width(), pm.height(), radius, radius)
        p.setClipPath(path)
        p.drawPixmap(0, 0, pm)
        p.end()
        return out
    return pm


def fmt_eta(ts):
    if not ts:
        return "now"
    left = ts - time.time()
    if left <= 0:
        return "due now"
    h, rem = divmod(int(left), 3600)
    return f"in {h} h {rem // 60:02d} min" if h else f"in {rem // 60} min"


# =========================================================================== dashboard
class InstanceCard(Card):
    def __init__(self, hub, name, serial):
        super().__init__(pad=14, spacing=8)
        self.hub, self.name, self.serial = hub, name, serial
        self.setFixedWidth(236)
        self.preview = QLabel()
        self.preview.setFixedSize(206, 300)
        self.preview.setAlignment(Qt.AlignCenter)
        self.preview.setStyleSheet(f"background: {COL['panel']}; border: 1px solid {COL['line2']}; border-radius: 12px;"
                                   f" color: {COL['faint']};")
        self.preview.setText("Waiting for a screenshot…")
        self.lay.addWidget(self.preview, 0, Qt.AlignHCenter)
        row = QHBoxLayout()
        self.dot = PulseDot("online", 10)
        row.addWidget(self.dot)
        n = label(name, "h3")
        n.setToolTip(f"{name}\n{serial}")
        n.setMinimumWidth(1)
        row.addWidget(n, 1)
        self.lay.addLayout(row)
        self.activity = label("Online · Kingshot open", "faint", wrap=True)
        self.activity.setMinimumHeight(30)
        self.lay.addWidget(self.activity)
        btns = QHBoxLayout()
        shot = QPushButton("Save shot")
        shot.setObjectName("ghost")
        shot.clicked.connect(lambda: hub.save_screenshot(name))
        btns.addWidget(shot)
        run = QPushButton("▶ Run now")
        run.setObjectName("ghost")
        run.setToolTip("Start an Autopilot session for this instance's character now")
        run.clicked.connect(lambda: hub.run_instance_now(name))
        btns.addWidget(run)
        self.lay.addLayout(btns)

    def set_frame(self, img):
        if img is None:
            self.dot.set_status("offline")
            self.preview.setText("No picture: instance busy or closed")
            return
        pm = to_pixmap(img)
        self.preview.setPixmap(pm.scaled(self.preview.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
        if self.dot.status == "offline":
            self.dot.set_status("online")

    def set_status(self, status, text=None):
        self.dot.set_status(status)
        if text:
            self.activity.setText(text[:140])


class Dashboard(QWidget):
    def __init__(self, hub):
        super().__init__()
        self.hub = hub
        page, col = scroll_page("Command Center", "")
        self.page_sub = page.sub
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(page)

        # autostart banner
        self.banner = QWidget()
        self.banner.setObjectName("banner")
        bl = QHBoxLayout(self.banner)
        bl.setContentsMargins(16, 12, 16, 12)
        self.banner_text = label("")
        bl.addWidget(self.banner_text, 1)
        now = QPushButton("Start now")
        now.setObjectName("primary")
        now.clicked.connect(hub.autostart_now)
        cancel = QPushButton("Cancel")
        cancel.clicked.connect(hub.autostart_cancel)
        bl.addWidget(now)
        bl.addWidget(cancel)
        self.banner.hide()
        col.addWidget(self.banner)

        # hero
        hero = QWidget()
        hero.setObjectName("hero")
        hl = QHBoxLayout(hero)
        hl.setContentsMargins(28, 24, 28, 24)
        left = QVBoxLayout()
        left.setSpacing(6)
        t = QHBoxLayout()
        self.hero_dot = PulseDot("idle", 14)
        t.addWidget(self.hero_dot)
        t.addWidget(label("Autopilot", "heroTitle"))
        t.addStretch()
        left.addLayout(t)
        self.hero_status = label("Idle", "muted", wrap=True)
        left.addWidget(self.hero_status)
        self.hero_chips = QHBoxLayout()
        left.addLayout(self.hero_chips)
        hl.addLayout(left, 1)
        self.hero_btn = HeroButton("▶  Start Autopilot", hub.settings.accent)
        self.hero_btn.clicked.connect(hub.toggle_autopilot)
        hl.addWidget(self.hero_btn, 0, Qt.AlignVCenter)
        col.addWidget(hero)

        # stats
        grid = QGridLayout()
        grid.setSpacing(14)
        self.t_inst = StatTile("Instances online", 0, glyph="🖥")
        self.t_today = StatTile("Actions today", 0, glyph="⚡")
        self.t_bots = StatTile("Bots running", 0, glyph="🤖")
        self.t_next = StatTile("Next session", 0, glyph="⏱")
        for i, w in enumerate((self.t_inst, self.t_today, self.t_bots, self.t_next)):
            grid.addWidget(w, 0, i)
        col.addLayout(grid)

        # instances
        ih = QHBoxLayout()
        ih.addWidget(heading("Instances"))
        self.spin = Spinner()
        self.spin.hide()
        ih.addWidget(self.spin)
        ih.addStretch()
        self.inst_note = label("", "faint")
        ih.addWidget(self.inst_note)
        boot = QPushButton("Start instances")
        boot.setToolTip("Opens every instance switched to Start in Settings, then Kingshot on it")
        boot.clicked.connect(lambda: hub.start_emulators())
        ih.addWidget(boot)
        ref = QPushButton("Refresh")
        ref.clicked.connect(hub.discover)
        ih.addWidget(ref)
        col.addLayout(ih)
        self.inst_wrap = QWidget()
        self.inst_grid = QGridLayout(self.inst_wrap)
        self.inst_grid.setContentsMargins(0, 0, 0, 0)
        self.inst_grid.setSpacing(14)
        self.inst_grid.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        col.addWidget(self.inst_wrap)
        self.empty = Card(hover=False)
        self.empty.lay.addWidget(heading("No instance with Kingshot open yet"))
        self.empty.lay.addWidget(label(
            "Open Kingshot in BlueStacks, MuMu, LDPlayer, the Google Play Games emulator or on a "
            "phone with USB debugging, then press Refresh. The app finds them on its own.", "muted", wrap=True))
        col.addWidget(self.empty)
        self.cards = {}

        # activity
        act = Card(hover=False)
        act.lay.addWidget(heading("Recent activity"))
        self.feed = QListWidget()
        self.feed.setMinimumHeight(220)
        self.feed.setFocusPolicy(Qt.NoFocus)
        self.feed.setSelectionMode(QAbstractItemView.NoSelection)
        act.lay.addWidget(self.feed)
        col.addWidget(act)
        col.addStretch()

        hub.instances_changed.connect(self.show_instances)
        hub.discovering.connect(lambda on: self.spin.start() if on else self.spin.stop())
        hub.frame.connect(self.on_frame)
        hub.instance_state.connect(self.on_state)
        hub.activity.connect(self.add_activity)
        hub.autopilot_changed.connect(self.refresh)
        hub.autostart_tick.connect(self.on_autostart)
        self.clock = QTimer(self, interval=1000, timeout=self.tick)
        self.clock.start()
        self.tick()
        self.refresh()

    def tick(self):
        now = datetime.now()
        utc = datetime.now(timezone.utc)
        self.page_sub.setText(f"{now:%A %d %B} · {now:%H:%M:%S} local · {utc:%H:%M} UTC · "
                              f"daily reset in {self._reset_in(utc)}")
        self.t_next.value.set_value(self.hub.next_session_text())
        self.t_bots.value.set_value(len(self.hub.procs.running()))

    @staticmethod
    def _reset_in(utc):
        nxt = (utc + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
        h, rem = divmod(int((nxt - utc).total_seconds()), 3600)
        return f"{h} h {rem // 60:02d} min"

    def refresh(self):
        br = self.hub.bridge
        running = br.running
        self.hero_btn.set_active(running, "■  Stop Autopilot" if running else "▶  Start Autopilot")
        self.hero_dot.set_status("running" if running else "idle")
        cur = br.engine.current
        chars = [c for c in br.settings.characters if c.enabled]
        if running and cur:
            self.hero_status.setText(f"Working on {cur}")
        elif running:
            self.hero_status.setText(f"Running · {len(chars)} character(s) · next session {self.hub.next_session_text()}")
        else:
            self.hero_status.setText("One click runs every enabled job on every character, around the clock, "
                                     "with random gaps and quiet hours.")
        while self.hero_chips.count():
            w = self.hero_chips.takeAt(0).widget()
            if w:
                w.deleteLater()
        sch = br.settings.schedule
        for text, kind in ((f"{len(chars)} character(s)", ""),
                           (f"every {sch.interval_min_h:g}–{sch.interval_max_h:g} h", ""),
                           (f"quiet {sch.quiet_start}–{sch.quiet_end}" if sch.quiet_start != sch.quiet_end else "no quiet hours", ""),
                           ("never spends diamonds" if br.settings.safety.never_spend else "may spend", "ok" if br.settings.safety.never_spend else "warn"),
                           ("keep-alive on" if self.hub.settings.keep_alive else "keep-alive off", "ok" if self.hub.settings.keep_alive else "")):
            self.hero_chips.addWidget(chip(text, kind))
        self.hero_chips.addStretch()
        self.t_today.value.set_value(self.hub.actions_today())

    def show_instances(self, insts, err):
        for c in self.cards.values():
            c.deleteLater()
        self.cards = {}
        for i, (name, serial) in enumerate(insts):
            card = InstanceCard(self.hub, name, serial)
            self.cards[name] = card
            self.inst_grid.addWidget(card, i // 4, i % 4)
        self.empty.setVisible(not insts)
        self.t_inst.value.set_value(len(insts))
        self.inst_note.setText(err or (f"found {len(insts)} · {datetime.now():%H:%M}" if insts else ""))

    def on_frame(self, name, img):
        if name in self.cards:
            self.cards[name].set_frame(img)

    def on_state(self, name, status, text):
        if name in self.cards:
            self.cards[name].set_status(status, text)

    def add_activity(self, text, kind):
        colour = {"ok": COL["ok"], "bad": COL["bad"], "warn": COL["warn"]}.get(kind, COL["muted"])
        it = QListWidgetItem(f"{datetime.now():%H:%M:%S}   {no_emoji(text).strip()}")
        it.setForeground(QColor(colour))
        self.feed.insertItem(0, it)
        while self.feed.count() > 60:
            self.feed.takeItem(self.feed.count() - 1)
        if kind in ("ok", "bad"):
            self.t_today.value.set_value(self.hub.actions_today())

    def on_autostart(self, left):
        if left <= 0:
            self.banner.hide()
            return
        self.banner.show()
        self.banner_text.setText(f"Autopilot starts in {left} s on every instance it finds. "
                                 "Cancel to look around first.")


# =========================================================================== autopilot
CHOICES = {
    ("train", "mode"): ["Keep busy", "Finish by"],
    ("research", "tree"): ["Growth", "Economy", "Battle"],
    ("hunt", "level"): ["Highest", *map(str, range(1, 31))],
    ("hunt", "formation"): ["Equalize", *(f"Preset {i}" for i in range(1, 9))],
    ("intel", "formation"): ["Equalize", *(f"Preset {i}" for i in range(1, 9))],
    ("intel", "bounties"): C.BOUNTIES,
    ("gather", "resource"): ["Any", "Bread", "Wood", "Stone", "Iron"],
    ("gather", "level"): ["Highest", *map(str, range(1, 9))],
}
JOB_HELP = {
    "claim": "Mail, alliance chests and gifts, VIP daily, free meat.",
    "rewards": "Daily and growth quests, sign-in, every free chest in Deals and Top-up Center, pass rewards.",
    "train": "Keeps barracks busy, or sizes a batch to finish at a time. Promotes when training is off.",
    "research": "Starts academy research when idle and asks the alliance for help.",
    "hunt": "Hunts beasts while stamina lasts (meat optional).",
    "gather": "Keeps gatherers out; recalls them before Bear Hunt and battles from the Task List.",
    "intel": "Clears intel pins: rebels, bounties, rescues, beasts.",
    "terrors": "Daily Terror rallies, spread over the day.",
    "alliance": "Help All and alliance tech donations (never diamonds).",
    "city": "Online rewards, free recruits, conquest, story, Mystic Trial, roulette chips, rebels, healing.",
    "build": "Starts the game's suggested building upgrade when requirements are met.",
    "arena": "Arena fights just before reset. Buys extra attempts up to the gem cap you set.",
    "blizzard": "Blizzard Brawl slots: gathers crate barrels, teleports into ice pools.",
}


def nice(key):
    return key.replace("_", " ").capitalize()


class AutopilotPage(QWidget):
    def __init__(self, hub):
        super().__init__()
        self.hub = hub
        self.br = hub.bridge
        page, col = scroll_page("Autopilot", "Characters, the jobs each one runs, and when.")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(page)
        self._save_timer = QTimer(self, singleShot=True, interval=500, timeout=self._save)

        row = QHBoxLayout()
        row.setSpacing(16)
        # character list
        left = Card(hover=False)
        left.setFixedWidth(310)
        left.lay.addWidget(heading("Characters"))
        self.list = QListWidget()
        self.list.setMinimumHeight(320)
        self.list.currentRowChanged.connect(self.pick)
        left.lay.addWidget(self.list)
        b = QHBoxLayout()
        add = QPushButton("＋ Add")
        add.clicked.connect(self.add)
        auto = QPushButton("Detect")
        auto.setToolTip("One character per instance with Kingshot open (the logged-in one)")
        auto.clicked.connect(self.detect)
        rem = QPushButton("Remove")
        rem.setObjectName("danger")
        rem.clicked.connect(self.remove)
        b.addWidget(add)
        b.addWidget(auto)
        b.addWidget(rem)
        left.lay.addLayout(b)
        left.lay.addWidget(label("A character with no kingdom runs as whoever is logged in on that "
                                 "instance. Give a kingdom and name to switch characters each session.",
                                 "faint", wrap=True))
        row.addWidget(left, 0, Qt.AlignTop)

        self.editor = QWidget()
        self.ed = QVBoxLayout(self.editor)
        self.ed.setContentsMargins(0, 0, 0, 0)
        self.ed.setSpacing(14)
        row.addWidget(self.editor, 1)
        col.addLayout(row)

        # schedule + safety
        sched = Card(hover=False)
        sched.lay.addWidget(heading("Schedule & safety"))
        g = QGridLayout()
        g.setHorizontalSpacing(18)
        g.setVerticalSpacing(10)
        s, sf = self.br.settings.schedule, self.br.settings.safety
        fields = [
            ("Session every (min h)", self._dspin(s, "interval_min_h", 0.25, 24, 0.25)),
            ("…to (max h)", self._dspin(s, "interval_max_h", 0.25, 48, 0.25)),
            ("Quiet from (local)", self._text(s, "quiet_start")),
            ("Quiet until", self._text(s, "quiet_end")),
            ("Tap pause min (s)", self._dspin(s, "tap_pause_min", 0, 5, 0.1)),
            ("Tap pause max (s)", self._dspin(s, "tap_pause_max", 0, 10, 0.1)),
            ("Max session (min)", self._dspin(s, "max_session_min", 5, 240, 5)),
            ("Order", self._combo(s, "order", ["Round robin", "List order"])),
            ("Never spend diamonds", self._toggle(sf, "never_spend")),
            ("Skip after unknown screens", self._ispin(sf, "stop_after_unknown", 1, 50)),
            ("Screenshot when stuck", self._toggle(sf, "screenshot_on_stuck")),
        ]
        for i, (t, w) in enumerate(fields):
            g.addWidget(label(t, "muted"), i // 2, (i % 2) * 2)
            g.addWidget(w, i // 2, (i % 2) * 2 + 1)
        sched.lay.addLayout(g)
        col.addWidget(sched)
        col.addStretch()

        hub.autopilot_changed.connect(self.reload_list)
        self.reload_list()

    # -- generic editors bound to dataclass attributes
    def _changed(self):
        self._save_timer.start()
        self.hub.autopilot_changed.emit()

    def _save(self):
        self.br.save()

    def _dspin(self, obj, attr, lo, hi, step):
        w = QDoubleSpinBox()
        w.setRange(lo, hi)
        w.setSingleStep(step)
        w.setValue(float(getattr(obj, attr)))
        w.valueChanged.connect(lambda v: (setattr(obj, attr, v), self._changed()))
        return w

    def _ispin(self, obj, attr, lo, hi):
        w = QSpinBox()
        w.setRange(lo, hi)
        w.setValue(int(getattr(obj, attr)))
        w.valueChanged.connect(lambda v: (setattr(obj, attr, v), self._changed()))
        return w

    def _text(self, obj, attr):
        w = QLineEdit(str(getattr(obj, attr)))
        w.setMaximumWidth(120)
        w.textChanged.connect(lambda v: (setattr(obj, attr, v), self._changed()))
        return w

    def _combo(self, obj, attr, items):
        w = QComboBox()
        w.addItems(items)
        w.setCurrentText(str(getattr(obj, attr)))
        w.currentTextChanged.connect(lambda v: (setattr(obj, attr, v), self._changed()))
        return w

    def _toggle(self, obj, attr):
        w = Toggle(bool(getattr(obj, attr)), accent_name=self.hub.settings.accent)
        w.toggled.connect(lambda v: (setattr(obj, attr, v), self._changed()))
        return w

    # -- list
    def reload_list(self):
        cur = self.list.currentRow()
        self.list.blockSignals(True)
        self.list.clear()
        for ch in self.br.settings.characters:
            on = sum(j.enabled for j in ch.jobs.values())
            busy = ch.key in self.br.engine.running_keys
            it = QListWidgetItem(f"{'●' if busy else ('○' if ch.enabled else '–')}  {ch.label}\n     {ch.instance} · {on} job{'s' if on != 1 else ''}")
            it.setForeground(QColor(COL["ok"] if busy else (COL["text"] if ch.enabled else COL["faint"])))
            self.list.addItem(it)
        self.list.blockSignals(False)
        n = self.list.count()
        if n:
            self.list.setCurrentRow(min(max(cur, 0), n - 1))
            if self.ed.count() == 0:
                self.pick(self.list.currentRow())
        else:
            self._clear_editor()
            self.ed.addWidget(label("No characters yet. Press Detect with Kingshot open, or Add.", "muted"))

    def _clear_editor(self):
        while self.ed.count():
            it = self.ed.takeAt(0)
            if it.widget():
                it.widget().deleteLater()

    def pick(self, row):
        chars = self.br.settings.characters
        if not 0 <= row < len(chars):
            return
        ch = chars[row]
        self._clear_editor()
        head = Card(hover=False)
        top = QHBoxLayout()
        top.addWidget(label(ch.label, "h2"))
        top.addStretch()
        run = QPushButton("▶ Run this character now")
        run.setObjectName("primary")
        run.clicked.connect(lambda: (self.br.run_now(ch.key), self.hub.toast(f"Session queued for {ch.label}", "ok")))
        top.addWidget(run)
        head.lay.addLayout(top)
        st = self.br.state
        head.lay.addWidget(label(f"{st.last(ch.key) or 'Not run yet'} · next {fmt_eta(st.next_run(ch.key))}", "faint"))
        form = QGridLayout()
        form.setHorizontalSpacing(14)
        name = QLineEdit(ch.name)
        name.textChanged.connect(lambda v: (setattr(ch, "name", v), self._save_timer.start()))
        inst = QComboBox()
        inst.setEditable(True)
        inst.addItems(sorted({c.instance for c in self.br.settings.characters} | {n for n, _ in self.hub.instances}))
        inst.setCurrentText(ch.instance)
        inst.currentTextChanged.connect(lambda v: (setattr(ch, "instance", v), self._save_timer.start()))
        kd = QSpinBox()
        kd.setRange(0, 99999)
        kd.setSpecialValueText("logged-in (no switch)")
        kd.setValue(ch.kingdom or 0)
        kd.valueChanged.connect(lambda v: (setattr(ch, "kingdom", v or None), self._save_timer.start()))
        en = Toggle(ch.enabled, accent_name=self.hub.settings.accent)
        en.toggled.connect(lambda v: (setattr(ch, "enabled", v), self._changed()))
        a_start, a_end = QLineEdit(ch.active_start), QLineEdit(ch.active_end)
        a_start.textChanged.connect(lambda v: (setattr(ch, "active_start", v), self._save_timer.start()))
        a_end.textChanged.connect(lambda v: (setattr(ch, "active_end", v), self._save_timer.start()))
        for i, (t, w) in enumerate((("Name", name), ("Instance", inst), ("Kingdom", kd), ("Enabled", en),
                                     ("Active from", a_start), ("Active until", a_end))):
            form.addWidget(label(t, "muted"), i // 2, (i % 2) * 2)
            form.addWidget(w, i // 2, (i % 2) * 2 + 1)
        head.lay.addLayout(form)
        self.ed.addWidget(head)

        jobs = Card(hover=False)
        jh = QHBoxLayout()
        jh.addWidget(heading("Jobs"))
        jh.addStretch()
        today = {j: st.count(ch.key, j) for j in self.br.config.JOBS}
        jh.addWidget(label(f"{sum(today.values())} actions today", "faint"))
        jobs.lay.addLayout(jh)
        for j in self.br.config.JOBS:
            jobs.lay.addWidget(self._job_row(ch, j, today.get(j, 0)))
        self.ed.addWidget(jobs)

    def _job_row(self, ch, j, done):
        job = ch.jobs[j]
        box = QWidget()
        v = QVBoxLayout(box)
        v.setContentsMargins(0, 6, 0, 6)
        top = QHBoxLayout()
        top.addWidget(monogram(self.br.config.JOB_LABELS[j], 24), 0, Qt.AlignTop)
        txt = QVBoxLayout()
        txt.setSpacing(0)
        txt.addWidget(label(self.br.config.JOB_LABELS[j], "h2"))
        txt.addWidget(label(JOB_HELP.get(j, ""), "faint", wrap=True))
        top.addLayout(txt, 1)
        if done:
            top.addWidget(chip(f"{done} today", "ok"))
        gear = QPushButton()
        gear.setIcon(QIcon(line_icon("settings", 16)))
        gear.setToolTip("Options")
        gear.setObjectName("ghost")
        gear.setCheckable(True)
        top.addWidget(gear)
        t = Toggle(job.enabled, accent_name=self.hub.settings.accent)
        top.addWidget(t)
        v.addLayout(top)
        params = QWidget()
        pf = QFormLayout(params)
        pf.setContentsMargins(36, 6, 0, 4)
        for k, val in job.params.items():
            pf.addRow(label(nice(k), "muted"), self._param(job, j, k, val))
        params.hide()
        v.addWidget(params)
        gear.toggled.connect(params.setVisible)
        t.toggled.connect(lambda on: (setattr(job, "enabled", on), self._changed()))
        v.addWidget(hline())
        return box

    def _param(self, job, j, k, val):
        def set_(x):
            job.params[k] = x
            self._save_timer.start()
        if isinstance(val, bool):
            w = Toggle(val, accent_name=self.hub.settings.accent)
            w.toggled.connect(set_)
        elif isinstance(val, int):
            w = QSpinBox()
            w.setRange(0, 100000)
            w.setValue(val)
            w.valueChanged.connect(set_)
        elif isinstance(val, float):
            w = QDoubleSpinBox()
            w.setRange(0, 100000)
            w.setValue(val)
            w.valueChanged.connect(set_)
        elif (j, k) in CHOICES:
            w = QComboBox()
            w.addItems(CHOICES[(j, k)])
            if str(val) not in CHOICES[(j, k)]:
                w.addItem(str(val))
            w.setCurrentText(str(val))
            w.currentTextChanged.connect(set_)
        else:
            w = QLineEdit(str(val))
            w.setPlaceholderText("YYYY-MM-DD HH:MM (UTC)" if k in ("finish_by", "hold_until") else "")
            w.textChanged.connect(set_)
        w.setMaximumWidth(260)
        return w

    def add(self):
        inst = self.hub.instances[0][0] if self.hub.instances else "Primary"
        self.br.settings.characters.append(self.br.config.Character(instance=inst, name="New character"))
        self.br.save()
        self.reload_list()
        self.list.setCurrentRow(self.list.count() - 1)

    def detect(self):
        added = self.br.ensure_characters([n for n, _ in self.hub.instances])
        self.hub.toast(f"Added {', '.join(added)}" if added else
                       "Every instance already has a character (or none is open: press Refresh)",
                       "ok" if added else "info")
        self.reload_list()

    def remove(self):
        r = self.list.currentRow()
        chars = self.br.settings.characters
        if 0 <= r < len(chars):
            chars.pop(r)
            self.br.save()
            self.reload_list()


# =========================================================================== characters
class _SortItem(QTableWidgetItem):
    """Sorts by the value in UserRole (numbers sort as numbers, not text)."""

    def __lt__(self, other):
        a, b = self.data(Qt.UserRole), other.data(Qt.UserRole)
        if a is None or b is None:
            return super().__lt__(other)
        return a < b


CAT_COLS = ["PLAYER ID", "NAME", "TAG", "KINGDOM", "LEVEL", "POWER", "INSTANCE", "AUTOPILOT", "SEEN"]


class CharactersPage(QWidget):
    """One click per instance learns every character on it (player ID, kingdom, level, power,
    name); the catalogue lists them all, keyed by player ID so renames update in place."""

    def __init__(self, hub):
        super().__init__()
        from kscommand import catalogue
        self.K = catalogue
        self.hub = hub
        self.rows = {}  # instance -> (status label, bar, button)
        page, col = scroll_page("Characters", "Every character on every instance: player ID, kingdom, Town "
                                              "Center or Truegold level, power and name.")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(page)

        learn = Card(hover=False)
        lh = QHBoxLayout()
        lh.addWidget(heading("Learn characters"), 1)
        self.all_btn = QPushButton("Learn every instance")
        self.all_btn.clicked.connect(self.learn_all)
        lh.addWidget(self.all_btn)
        learn.lay.addLayout(lh)
        learn.lay.addWidget(label("Press Learn on an instance with Kingshot open. The bot opens the Governor Profile "
                                  "to note the player ID, then switches through every character on the Characters "
                                  "list the same way, and logs the first one back in at the end. Allow about a "
                                  "minute per character; Autopilot leaves that instance alone meanwhile.",
                                  "muted", wrap=True))
        self.inst_box = QVBoxLayout()
        self.inst_box.setSpacing(8)
        learn.lay.addLayout(self.inst_box)
        col.addWidget(learn)

        cat = Card(hover=False)
        ch = QHBoxLayout()
        ch.addWidget(heading("Catalogue"), 1)
        self.count = chip("")
        ch.addWidget(self.count)
        cat.lay.addLayout(ch)
        bar = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search name, ID, alliance or kingdom")
        self.search.textChanged.connect(self.fill)
        bar.addWidget(self.search, 1)
        self.only = QComboBox()
        self.only.setMinimumWidth(180)
        self.only.currentIndexChanged.connect(self.fill)
        bar.addWidget(self.only)
        cat.lay.addLayout(bar)
        self.table = QTableWidget(0, len(CAT_COLS))
        self.table.setHorizontalHeaderLabels(CAT_COLS)
        self.table.verticalHeader().hide()
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSortingEnabled(True)
        self.table.setMinimumHeight(420)
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(QHeaderView.ResizeToContents)
        hh.setStretchLastSection(True)
        self.table.sortItems(6)  # by instance until a header is clicked
        cat.lay.addWidget(self.table)
        btns = QHBoxLayout()
        copy = QPushButton("Copy table")
        copy.setToolTip("Copies the rows shown, ready to paste into a spreadsheet")
        copy.clicked.connect(self.copy)
        export = QPushButton("Export CSV…")
        export.clicked.connect(self.export)
        add = QPushButton("Add to Autopilot")
        add.setToolTip("Adds the selected characters (or every one not in Autopilot yet) switched off, "
                       "with the everyday jobs ready")
        add.clicked.connect(self.add_to_autopilot)
        edit = QPushButton("Edit")
        edit.setToolTip("Change the selected character by hand, e.g. type in a player ID the bot missed "
                        "(double-click a row does the same)")
        edit.clicked.connect(self.edit_selected)
        new_btn = QPushButton("Add by hand")
        new_btn.setToolTip("Add a character the bot hasn't learned")
        new_btn.clicked.connect(lambda: self.open_editor(None))
        self.table.doubleClicked.connect(lambda _i: self.edit_selected())
        rm = QPushButton("Remove")
        rm.setObjectName("ghost")
        rm.setToolTip("Forget the selected rows (they come back the next time that instance is learned)")
        rm.clicked.connect(self.remove)
        for b in (edit, new_btn, copy, export, add):
            btns.addWidget(b)
        btns.addStretch()
        btns.addWidget(rm)
        cat.lay.addLayout(btns)
        col.addWidget(cat)

        # hand editor: fills in what the bot missed (or got wrong)
        self.editing = None
        self.ed = Card(hover=False)
        self.ed_title = heading("Edit character")
        self.ed.lay.addWidget(self.ed_title)
        self.ed.lay.addWidget(label("What you type here is kept: the next Learn won't overwrite a player ID, kingdom "
                                    "or instance you set, and still recognises the character. Level, power and "
                                    "alliance change in the game, so the next Learn updates those.",
                                    "faint", wrap=True))
        form = QGridLayout()
        form.setHorizontalSpacing(14)
        self.f = {}
        fields = [("player_id", "Player ID", "e.g. 88538112"), ("name", "Name", "without the alliance tag"),
                  ("tag", "Alliance", "e.g. 586"), ("kingdom", "Kingdom", "e.g. 685"),
                  ("level", "Level", "TC 22 or TG 8"), ("power", "Power", "e.g. 589675969"),
                  ("instance", "Instance", ""), ("aka", "Earlier names", "comma separated")]
        for i, (key, text, hint) in enumerate(fields):
            if key == "instance":
                w = QComboBox()
                w.setEditable(True)
            else:
                w = QLineEdit()
                w.setPlaceholderText(hint)
            self.f[key] = w
            form.addWidget(label(text, "muted"), i // 2, (i % 2) * 2)
            form.addWidget(w, i // 2, (i % 2) * 2 + 1)
        self.ed.lay.addLayout(form)
        self.ed_err = label("", "faint", wrap=True)
        self.ed_err.setStyleSheet(f"color: {COL['bad']};")
        self.ed.lay.addWidget(self.ed_err)
        eb = QHBoxLayout()
        save = QPushButton("Save")
        save.setObjectName("primary")
        save.clicked.connect(self.save_edit)
        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self.close_editor)
        eb.addWidget(save)
        eb.addWidget(cancel)
        eb.addStretch()
        self.ed.lay.addLayout(eb)
        self.ed.hide()
        col.addWidget(self.ed)
        col.addStretch()

        hub.instances_changed.connect(self.set_instances)
        hub.characters_progress.connect(self.on_progress)
        hub.characters_changed.connect(self.reload)
        hub.autopilot_changed.connect(self.fill)
        self.set_instances(hub.instances)
        self.reload()

    # ---- instances
    def set_instances(self, insts, _err=""):
        while self.inst_box.count():
            w = self.inst_box.takeAt(0).widget()
            if w:
                w.setParent(None)
                w.deleteLater()
        self.rows = {}
        if not insts:
            self.inst_box.addWidget(label("No instance with Kingshot open. Open the game, then press Refresh on Home.",
                                          "faint", wrap=True))
            self.all_btn.setEnabled(False)
            return
        self.all_btn.setEnabled(True)
        cat = self.K.load()
        for name, serial in insts:
            box = QWidget()
            row = QHBoxLayout(box)
            row.setContentsMargins(0, 4, 0, 4)
            row.addWidget(monogram(name, 26))
            txt = QVBoxLayout()
            txt.setSpacing(0)
            txt.addWidget(label(name, "h2"))
            known = sum(1 for e in cat if e.instance == name)
            status = label(f"{known} characters in the catalogue" if known else "Not learned yet", "faint")
            txt.addWidget(status)
            row.addLayout(txt, 1)
            bar = QProgressBar()
            bar.setFixedWidth(180)
            bar.setTextVisible(False)
            bar.hide()
            row.addWidget(bar)
            btn = QPushButton("Learn all characters")
            btn.setObjectName("primary")
            btn.clicked.connect(lambda _=False, n=name, s=serial: self.toggle(n, s))
            row.addWidget(btn)
            self.inst_box.addWidget(box)
            self.rows[name] = (status, bar, btn)
            if self.hub.learning(name):
                bar.show()
                btn.setText("Stop")
                btn.setObjectName("")

    def toggle(self, name, serial):
        if self.hub.learning(name):
            self.hub.stop_learning(name)
        elif self.hub.learn_characters(name, serial):
            self._busy(name, True)

    def learn_all(self):
        n = sum(bool(self.hub.learn_characters(name, serial) and (self._busy(name, True) or True))
                for name, serial in self.hub.instances if not self.hub.learning(name))
        if n:
            self.hub.toast(f"Learning characters on {n} instance{'s' if n != 1 else ''}", "info")

    def _busy(self, name, on):
        if name not in self.rows:
            return
        _status, bar, btn = self.rows[name]
        bar.setVisible(on)
        bar.setRange(0, 0) if on else bar.setRange(0, 1)
        btn.setText("Stop" if on else "Learn all characters")
        btn.setObjectName("" if on else "primary")
        btn.style().unpolish(btn)
        btn.style().polish(btn)

    def on_progress(self, name, done, total, text):
        if name not in self.rows:
            return
        status, bar, _btn = self.rows[name]
        if total == 0:  # finished
            self._busy(name, False)
            status.setText(text[:160])
            return
        if bar.isHidden():
            self._busy(name, True)
        if done:
            bar.setRange(0, total)
            bar.setValue(done)
            status.setText(f"{done} of {total}: {text}"[:160])
        else:
            status.setText(text[:160])

    # ---- catalogue
    def reload(self):
        self.entries = self.K.load()
        cur = self.only.currentText()
        self.only.blockSignals(True)
        self.only.clear()
        self.only.addItem("All instances")
        for inst in sorted({e.instance for e in self.entries}):
            self.only.addItem(inst)
        if cur:
            self.only.setCurrentText(cur)
        self.only.blockSignals(False)
        self.fill()

    def shown(self):
        q = self.search.text().strip().lower()
        inst = self.only.currentText() if self.only.currentIndex() > 0 else None
        out = []
        for e in getattr(self, "entries", []):
            if inst and e.instance != inst:
                continue
            hay = " ".join([e.player_id, e.name, e.tag, str(e.kingdom or ""), f"#{e.kingdom}", *e.aka]).lower()
            if q and q not in hay:
                continue
            out.append(e)
        return out

    def fill(self):
        if not hasattr(self, "entries"):
            return
        rows = self.shown()
        settings = self.hub.bridge.settings
        self.table.setSortingEnabled(False)
        self.table.setRowCount(len(rows))
        for r, e in enumerate(rows):
            auto = self.K.in_autopilot(settings, e)
            lvl_key = e.tg + 100 if e.tg else e.tc
            was = f"   (was {', '.join(reversed(e.aka))})" if e.aka else ""
            cells = [(e.player_id or "not read", e.player_id or ""), (e.name + was, e.name.lower()), (e.tag, e.tag.lower()),
                     (f"#{e.kingdom}" if e.kingdom is not None else "", e.kingdom or 0), (e.level, lvl_key),
                     (f"{e.power:,}" if e.power else "", e.power), (e.instance, e.instance), ("Yes" if auto else "", auto),
                     (e.seen[5:], e.seen)]
            for c, (text, key) in enumerate(cells):
                it = _SortItem(text)
                it.setData(Qt.UserRole, key)
                if c == 0:
                    it.setData(Qt.UserRole + 1, id(e))
                    if not e.player_id:
                        it.setForeground(QColor(COL["warn"]))
                if c in (3, 4, 5):
                    it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                if c == 4 and e.tg:
                    it.setForeground(QColor(COL.get("gold", COL["warn"])))
                if c == 7 and auto:
                    it.setForeground(QColor(COL["ok"]))
                if c == 1 and e.aka:
                    it.setToolTip("Earlier names: " + ", ".join(reversed(e.aka)))
                if c == 0 and "player_id" in e.manual:
                    it.setToolTip("Typed in by hand")
                    it.setForeground(QColor(COL["accent"]))
                self.table.setItem(r, c, it)
        self.table.setSortingEnabled(True)
        total = len(self.entries)
        self.count.setText(f"{len(rows)} of {total}" if len(rows) != total else f"{total} characters")

    def selected(self):
        ids = {self.table.item(i.row(), 0).data(Qt.UserRole + 1) for i in self.table.selectionModel().selectedRows()}
        return [e for e in self.entries if id(e) in ids]

    def _current(self):
        r = self.table.currentRow()
        it = self.table.item(r, 0) if r >= 0 else None
        if it is None:
            return None
        return next((e for e in self.entries if id(e) == it.data(Qt.UserRole + 1)), None)

    # ---- hand editor
    def edit_selected(self):
        e = self._current()
        if e is None:
            self.hub.toast("Select a character first", "info")
            return
        self.open_editor(e)

    def open_editor(self, e):
        self.editing = e
        insts = sorted({x.instance for x in self.entries} | {n for n, _ in self.hub.instances})
        box = self.f["instance"]
        box.clear()
        box.addItems(insts)
        if e is None:
            for k, w in self.f.items():
                if k != "instance":
                    w.clear()
            only = self.only.currentText() if self.only.currentIndex() > 0 else (insts[0] if insts else "")
            box.setCurrentText(only)
        else:
            vals = {"player_id": e.player_id, "name": e.name, "tag": e.tag,
                    "kingdom": "" if e.kingdom is None else str(e.kingdom), "level": e.level,
                    "power": str(e.power) if e.power else "", "aka": ", ".join(e.aka)}
            for k, v in vals.items():
                self.f[k].setText(v)
            box.setCurrentText(e.instance)
        self._set_title("Edit " + e.label if e else "Add a character by hand")
        self.ed_err.setText("")
        self.ed.show()
        (self.f["player_id"] if e is not None and not e.player_id else self.f["name"]).setFocus()
        QTimer.singleShot(50, lambda: self.ed.parentWidget() and self._scroll_to_editor())

    def _set_title(self, text):
        for lb in self.ed_title.findChildren(QLabel):
            if lb.text():
                lb.setText(text)

    def _scroll_to_editor(self):
        w = self.ed.parentWidget()
        while w is not None and not isinstance(w, QScrollArea):
            w = w.parentWidget()
        if w is not None:
            w.ensureWidgetVisible(self.ed)

    def close_editor(self):
        self.editing = None
        self.ed.hide()

    def save_edit(self):
        vals = {k: (w.currentText() if isinstance(w, QComboBox) else w.text()) for k, w in self.f.items()}
        entries = self.K.load()  # fresh copy: a Learn may have saved meanwhile
        target = None
        if self.editing is not None:
            old = self.editing
            target = next((x for x in entries if (old.player_id and x.player_id == old.player_id)
                           or (x.instance == old.instance and x.kingdom == old.kingdom and x.name == old.name)), None)
            if target is None:
                self.ed_err.setText("That character was removed meanwhile.")
                return
        try:
            e = self.K.edit(entries, target, **vals)
        except ValueError as err:
            self.ed_err.setText(f"Not saved: {err}.")
            return
        self.K.save(entries)
        br = self.hub.bridge
        if self.K.sync_autopilot(br.settings, entries):
            br.save()
            self.hub.autopilot_changed.emit()
        self.hub.log("Characters", f"edited by hand: {e.label} (ID {e.player_id or '-'})")
        self.hub.toast(f"Saved {e.name}", "ok")
        self.close_editor()
        self.hub.characters_changed.emit()

    def _visible_rows(self):
        out = []
        for r in range(self.table.rowCount()):
            out.append([self.table.item(r, c).text() if self.table.item(r, c) else "" for c in range(len(CAT_COLS))])
        return out

    def copy(self):
        from PySide6.QtWidgets import QApplication
        lines = ["\t".join(c.title() for c in CAT_COLS)] + ["\t".join(r) for r in self._visible_rows()]
        QApplication.clipboard().setText("\n".join(lines))
        self.hub.toast(f"Copied {self.table.rowCount()} rows", "ok")

    def export(self):
        path, _ = QFileDialog.getSaveFileName(self, "Export characters", str(core.ROOT / "characters.csv"),
                                              "CSV (*.csv)")
        if path:
            with open(path, "w", encoding="utf-8-sig", newline="") as f:
                f.write(self.K.to_csv(self.shown()))
            self.hub.toast("Exported", "ok")
            core.reveal(path)

    def add_to_autopilot(self):
        from kscommand.services import SAFE_DEFAULT_JOBS
        br = self.hub.bridge
        pick = self.selected() or self.shown()
        added = []
        for e in pick:
            if self.K.in_autopilot(br.settings, e) or e.kingdom is None:
                continue
            ch = br.config.Character(instance=e.instance, name=e.name, kingdom=e.kingdom, tag=e.tag,
                                     power=e.power, enabled=False)
            for j in SAFE_DEFAULT_JOBS:
                ch.jobs[j].enabled = True
            br.settings.characters.append(ch)
            added.append(e.name)
        if added:
            br.save()
            self.hub.autopilot_changed.emit()
            self.hub.toast(f"Added {len(added)} to Autopilot, switched off: turn them on on the Autopilot page", "ok")
        else:
            self.hub.toast("Those characters are in Autopilot already", "info")

    def remove(self):
        gone = self.selected()
        if not gone:
            self.hub.toast("Select rows to remove first", "info")
            return
        ids = {id(e) for e in gone}
        self.K.save([e for e in self.entries if id(e) not in ids])
        self.reload()


# =========================================================================== bots
class BotCard(Card):
    def __init__(self, page, bot):
        super().__init__(pad=18, spacing=8)
        self.page, self.bot = page, bot
        hub = page.hub
        top = QHBoxLayout()
        top.addWidget(monogram(bot.title, 34), 0, Qt.AlignTop)
        tv = QVBoxLayout()
        tv.setSpacing(0)
        tv.addWidget(label(bot.title, "h2"))
        cats = QHBoxLayout()
        cats.addWidget(chip(bot.category))
        if bot.single:
            cats.addWidget(chip("one instance"))
        cats.addStretch()
        tv.addLayout(cats)
        top.addLayout(tv, 1)
        self.dot = PulseDot("idle", 11)
        top.addWidget(self.dot, 0, Qt.AlignTop)
        self.lay.addLayout(top)
        self.lay.addWidget(label(bot.blurb, "muted", wrap=True))
        saved = hub.settings.bot_options.setdefault(bot.id, {})
        self.opts = B.options_for(bot, saved)
        if bot.options:
            ow = QWidget()
            of = QFormLayout(ow)
            of.setContentsMargins(0, 4, 0, 0)
            for o in bot.options:
                of.addRow(label(o.label, "faint"), self._opt(o, saved))
            ow.hide()
            more = QPushButton("Options")
            more.setObjectName("ghost")
            more.setCheckable(True)
            more.toggled.connect(ow.setVisible)
            self.lay.addWidget(more, 0, Qt.AlignLeft)
            self.lay.addWidget(ow)
        self.last = label("Ready", "faint", wrap=True)
        self.lay.addWidget(self.last)
        self.lay.addStretch()
        b = QHBoxLayout()
        self.go = QPushButton("▶ Start")
        self.go.setObjectName("primary")
        self.go.clicked.connect(self.toggle)
        b.addWidget(self.go)
        self.lay.addLayout(b)
        self.pending = None

    def _opt(self, o, saved):
        def set_(v):
            self.opts[o.key] = v
            saved[o.key] = v
            self.page.hub.save_settings()
        v = self.opts[o.key]
        if o.kind == "bool":
            w = Toggle(bool(v), accent_name=self.page.hub.settings.accent)
            w.toggled.connect(set_)
        elif o.kind == "int":
            w = QSpinBox()
            w.setRange(o.lo, o.hi)
            w.setValue(int(v))
            w.valueChanged.connect(set_)
        elif o.kind == "per_instance":
            w = self._per_instance(o, saved)
        elif o.kind == "choice":
            w = QComboBox()
            w.setEditable(o.key == "formations")
            w.addItems([str(c) for c in o.choices])
            w.setCurrentText(str(v))
            w.currentTextChanged.connect(set_)
        else:
            w = QLineEdit(str(v))
            w.textChanged.connect(set_)
        return w

    def _per_instance(self, o, saved):
        """One picker per instance; rebuilt when instances come and go, keeping saved picks."""
        hub = self.page.hub
        box = QWidget()
        grid = QGridLayout(box)
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setHorizontalSpacing(8)
        grid.setVerticalSpacing(6)
        if o.help:
            box.setToolTip(o.help)

        def pick(name, v):
            m = dict(self.opts.get(o.key) or {})
            m[name] = v
            self.opts[o.key] = saved[o.key] = m
            hub.save_settings()

        def build(*_):
            while grid.count():
                it = grid.takeAt(0)
                if it.widget():
                    it.widget().hide()
                    it.widget().deleteLater()
            names = [n for n, _ in hub.instances] or list((self.opts.get(o.key) or {}))
            if not names:
                grid.addWidget(label("Shows each instance once it is found", "faint"), 0, 0)
                return
            cur = self.opts.get(o.key) or {}
            for i, n in enumerate(names):
                grid.addWidget(label(n, "muted"), i, 0)
                c = QComboBox()
                c.addItems([str(x) for x in o.choices])
                c.setCurrentText(str(cur.get(n, o.default)))
                c.currentTextChanged.connect(lambda v, n=n: pick(n, v))
                grid.addWidget(c, i, 1)
            grid.setColumnStretch(1, 1)

        build()
        hub.instances_changed.connect(build)
        return box

    def running(self):
        return self.bot.id in self.page.hub.procs.running()

    def toggle(self):
        hub = self.page.hub
        if self.pending:
            self.pending.stop()
            self.pending = None
            self.last.setText("Delayed start cancelled")
            self.sync()
            return
        if self.running():
            hub.procs.stop(self.bot.id)
            return
        names = self.page.selected()
        if not names:
            hub.toast("Tick at least one instance first (or press Refresh)", "warn")
            return
        delay = 0
        try:
            delay = C.delay_seconds(self.page.delay.currentText(), datetime.now(timezone.utc))
        except ValueError:
            hub.toast("Start time not understood: use now, in 10 min, in 1 h or after 00:00 UTC", "warn")
            return
        if delay > 0:
            self.pending = QTimer(self, singleShot=True, interval=int(delay * 1000),
                                  timeout=lambda: (setattr(self, "pending", None), self._launch(names)))
            self.pending.start()
            self.last.setText(f"Starts {(datetime.now() + timedelta(seconds=delay)):%H:%M} local")
            self.go.setText("✕ Cancel start")
            self.dot.set_status("starting")
            return
        self._launch(names)

    def _launch(self, names):
        hub = self.page.hub
        all_sel = len(names) == len(hub.instances)
        argv = self.bot.build(names, self.opts, self.page.dry.isChecked(), all_sel)
        if hub.procs.start(self.bot.id, argv, names):
            hub.toast(f"{self.bot.title} started on {', '.join(names[:1] if self.bot.single else names)}", "ok")
        self.sync()

    def sync(self):
        on = self.running()
        if self.pending:
            return
        self.go.setText("■ Stop" if on else "▶ Start")
        self.go.setObjectName("danger" if on else "primary")
        self.go.style().unpolish(self.go)
        self.go.style().polish(self.go)
        self.dot.set_status("running" if on else "idle")

    def on_line(self, text):
        self.last.setText(text[:160])


class BotsPage(QWidget):
    def __init__(self, hub):
        super().__init__()
        self.hub = hub
        page, col = scroll_page("Bots", "Event and combat bots that run on their own, outside the Autopilot schedule.")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(page)
        bar = Card(hover=False)
        r = QHBoxLayout()
        r.addWidget(heading("Run on"))
        self.chips = QHBoxLayout()
        r.addLayout(self.chips)
        r.addStretch()
        r.addWidget(label("Start", "muted"))
        self.delay = QComboBox()
        self.delay.setEditable(True)
        self.delay.addItems(C.DELAY_CHOICES)
        r.addWidget(self.delay)
        r.addWidget(label("Dry run", "muted"))
        self.dry = Toggle(False, accent_name=hub.settings.accent)
        self.dry.setToolTip("Log the taps instead of doing them")
        r.addWidget(self.dry)
        stop = QPushButton("■ Stop all")
        stop.setObjectName("danger")
        stop.clicked.connect(hub.procs.stop_all)
        r.addWidget(stop)
        bar.lay.addLayout(r)
        col.addWidget(bar)
        grid = QGridLayout()
        grid.setSpacing(16)
        self.cards = {}
        for i, bot in enumerate(B.BOTS):
            c = BotCard(self, bot)
            self.cards[bot.id] = c
            grid.addWidget(c, i // 3, i % 3)
        for cidx in range(3):
            grid.setColumnStretch(cidx, 1)
        col.addLayout(grid)
        col.addStretch()
        self.inst_btns = []
        hub.instances_changed.connect(self.set_instances)
        hub.procs.changed.connect(lambda: [c.sync() for c in self.cards.values()])
        hub.procs.line.connect(lambda b, t: self.cards[b].on_line(t) if b in self.cards else None)

    def set_instances(self, insts, _err=""):
        for b in self.inst_btns:
            b.deleteLater()
        self.inst_btns = []
        for name, _ in insts:
            b = QPushButton(name)
            b.setObjectName("instChip")
            b.setCheckable(True)
            b.setChecked(True)
            self.chips.addWidget(b)
            self.inst_btns.append(b)
        if not insts:
            lb = QPushButton("no instance found")
            lb.setObjectName("instChip")
            lb.setEnabled(False)
            self.chips.addWidget(lb)
            self.inst_btns.append(lb)

    def selected(self):
        return [b.text() for b in self.inst_btns if b.isCheckable() and b.isChecked()]


# =========================================================================== gift codes
class GiftPage(QWidget):
    def __init__(self, hub):
        super().__init__()
        self.hub = hub
        page, col = scroll_page("Gift codes", "Redeem a code for every saved player ID in one go, on the official gift code site.")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(page)
        row = QHBoxLayout()
        row.setSpacing(16)
        pl = Card(hover=False)
        pl.lay.addWidget(heading("Players"))
        self.table = QTableWidget(0, 2)
        self.table.setHorizontalHeaderLabels(["PLAYER ID", "NAME"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.verticalHeader().hide()
        self.table.setMinimumHeight(260)
        self.table.itemChanged.connect(self._edited)
        pl.lay.addWidget(self.table)
        add = QHBoxLayout()
        self.pid = QLineEdit()
        self.pid.setPlaceholderText("Player ID (avatar → profile)")
        self.pname = QLineEdit()
        self.pname.setPlaceholderText("Name (optional)")
        ab = QPushButton("＋ Add")
        ab.clicked.connect(self.add)
        rb = QPushButton("Remove")
        rb.setObjectName("danger")
        rb.clicked.connect(self.remove)
        add.addWidget(self.pid)
        add.addWidget(self.pname)
        add.addWidget(ab)
        add.addWidget(rb)
        pl.lay.addLayout(add)
        row.addWidget(pl, 1)

        rd = Card(hover=False)
        rd.lay.addWidget(heading("Redeem"))
        cr = QHBoxLayout()
        self.code = QLineEdit()
        self.code.setPlaceholderText("Gift code, e.g. KINGSHOT2026")
        self.code.returnPressed.connect(self.redeem)
        self.go = QPushButton("Redeem for all")
        self.go.setObjectName("primary")
        self.go.clicked.connect(self.redeem)
        cr.addWidget(self.code, 1)
        cr.addWidget(self.go)
        rd.lay.addLayout(cr)
        self.bar = QProgressBar()
        self.bar.setMaximumHeight(8)
        self.bar.hide()
        rd.lay.addWidget(self.bar)
        self.res = QTableWidget(0, 4)
        self.res.setHorizontalHeaderLabels(["TIME", "CODE", "PLAYER", "RESULT"])
        self.res.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        self.res.verticalHeader().hide()
        self.res.setMinimumHeight(260)
        rd.lay.addWidget(self.res)
        rd.lay.addWidget(label("Players a code already worked for are skipped next time. Telegram: /redeem CODE.", "faint", wrap=True))
        row.addWidget(rd, 1)
        col.addLayout(row)
        col.addStretch()
        self.worker = None
        self.load()

    def load(self):
        self.table.blockSignals(True)
        self.table.setRowCount(0)
        for p in self.hub.settings.player_ids:
            r = self.table.rowCount()
            self.table.insertRow(r)
            self.table.setItem(r, 0, QTableWidgetItem(str(p.get("id", ""))))
            self.table.setItem(r, 1, QTableWidgetItem(p.get("name", "")))
        self.table.blockSignals(False)

    def _edited(self, _item):
        out = []
        for r in range(self.table.rowCount()):
            i, n = self.table.item(r, 0), self.table.item(r, 1)
            if i and i.text().strip():
                out.append({"id": i.text().strip(), "name": n.text().strip() if n else ""})
        self.hub.settings.player_ids = out
        self.hub.save_settings()

    def add(self):
        pid = self.pid.text().strip()
        if not pid.isdigit():
            self.hub.toast("Player IDs are numbers (tap your avatar in game to see it)", "warn")
            return
        self.hub.settings.player_ids.append({"id": pid, "name": self.pname.text().strip()})
        self.hub.save_settings()
        self.pid.clear()
        self.pname.clear()
        self.load()

    def remove(self):
        r = self.table.currentRow()
        if 0 <= r < len(self.hub.settings.player_ids):
            self.hub.settings.player_ids.pop(r)
            self.hub.save_settings()
            self.load()

    def redeem(self, code=None):
        code = (code if isinstance(code, str) else self.code.text()).strip()
        if not code:
            return
        if self.worker and self.worker.isRunning():
            self.hub.toast("Still redeeming the previous code", "warn")
            return
        done = set(self.hub.settings.redeemed.get(code, []))
        players = [p for p in self.hub.settings.player_ids if p["id"] not in done]
        if not players:
            self.hub.toast("No players saved, or this code already worked for all of them", "warn")
            return
        from kscommand.services import Redeemer
        self.worker = Redeemer(code, players, self)
        self.worker.result.connect(self.on_result)
        self.worker.done.connect(self.on_done)
        self.bar.setRange(0, len(players))
        self.bar.setValue(0)
        self.bar.show()
        self.go.setEnabled(False)
        self.worker.start()

    def on_result(self, code, pid, name, msg):
        r = 0
        self.res.insertRow(r)
        good = msg.startswith("Successfully") or msg == "Already redeemed"
        for c, t in enumerate((f"{datetime.now():%H:%M:%S}", code, name or pid, msg)):
            it = QTableWidgetItem(t)
            if c == 3:
                it.setForeground(QColor(COL["ok"] if good else COL["bad"]))
            self.res.setItem(r, c, it)
        if good:
            self.hub.settings.redeemed.setdefault(code, []).append(pid)
            self.hub.save_settings()
        self.bar.setValue(self.bar.value() + 1)
        self.hub.activity.emit(f"Gift code {code} · {name or pid}: {msg}", "ok" if good else "warn")

    def on_done(self, code):
        self.bar.hide()
        self.go.setEnabled(True)
        self.hub.toast(f"Gift code {code} done", "ok")
        self.hub.notify(f"🎁 Gift code {code} redeemed for your players")


# =========================================================================== stats
class StatsPage(QWidget):
    def __init__(self, hub):
        super().__init__()
        self.hub = hub
        page, col = scroll_page("Statistics", "What Autopilot did, per character and day (game days reset at 00:00 UTC).")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(page)
        top = QHBoxLayout()
        top.addWidget(label("Character", "muted"))
        self.who = QComboBox()
        self.who.setMinimumWidth(260)
        self.who.currentIndexChanged.connect(self.draw)
        top.addWidget(self.who)
        top.addStretch()
        col.addLayout(top)
        c1 = Card(hover=False)
        c1.lay.addWidget(heading("Actions per day"))
        self.chart = BarChart(accent_name=hub.settings.accent)
        c1.lay.addWidget(self.chart)
        col.addWidget(c1)
        c2 = Card(hover=False)
        c2.lay.addWidget(heading("By job"))
        self.table = QTableWidget(0, 0)
        self.table.verticalHeader().hide()
        self.table.setMinimumHeight(380)
        c2.lay.addWidget(self.table)
        col.addWidget(c2)
        col.addStretch()
        hub.autopilot_changed.connect(self.reload)
        self.reload()

    def reload(self):
        cur = self.who.currentText()
        self.who.blockSignals(True)
        self.who.clear()
        self.who.addItem("All characters")
        for ch in self.hub.bridge.settings.characters:
            self.who.addItem(ch.key)
        if cur:
            self.who.setCurrentText(cur)
        self.who.blockSignals(False)
        self.draw()

    def draw(self):
        br = self.hub.bridge
        keys = [c.key for c in br.settings.characters]
        if self.who.currentIndex() > 0:
            keys = [self.who.currentText()]
        days = {}
        for k in keys:
            for day, jobs in br.state.history(k).items():
                d = days.setdefault(day, {})
                for j, n in jobs.items():
                    d[j] = d.get(j, 0) + n
        order = sorted(days)[-7:]
        self.chart.set_data([(d[5:], sum(days[d].values())) for d in order])
        jobs = br.config.JOBS
        self.table.setColumnCount(len(order) + 1)
        self.table.setHorizontalHeaderLabels(["JOB", *(d[5:] for d in order)])
        self.table.setRowCount(len(jobs))
        for r, j in enumerate(jobs):
            self.table.setItem(r, 0, QTableWidgetItem(br.config.JOB_LABELS[j]))
            for c, d in enumerate(order, 1):
                n = days[d].get(j, 0)
                it = QTableWidgetItem(str(n) if n else "·")
                it.setTextAlignment(Qt.AlignCenter)
                if n:
                    it.setForeground(QColor(COL["ok"]))
                self.table.setItem(r, c, it)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)


# =========================================================================== feature map
class CoveragePage(QWidget):
    def __init__(self, hub):
        super().__init__()
        self.hub = hub
        self.rows = core.coverage()
        page, col = scroll_page("Feature map", "Every one of the 233 actions on your list, and which part of this app does it.")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(page)
        top = QHBoxLayout()
        top.setSpacing(16)
        rc = Card(hover=False)
        rl = QHBoxLayout()
        self.ring = Ring(150, accent_name=hub.settings.accent)
        rl.addWidget(self.ring)
        legend = QVBoxLayout()
        n = len(self.rows) or 1
        cov = sum(r["status"] == "covered" for r in self.rows)
        part = sum(r["status"] == "partial" for r in self.rows)
        legend.addWidget(heading("Coverage"))
        legend.addWidget(chip(f"{cov} done by a job", "ok"))
        legend.addWidget(chip(f"{part} swept up by a broader job", "warn"))
        legend.addWidget(chip(f"{len(self.rows) - cov - part} not automated yet", "bad"))
        legend.addStretch()
        rl.addLayout(legend)
        rc.lay.addLayout(rl)
        top.addWidget(rc)
        cc = Card(hover=False)
        cc.lay.addWidget(heading("Automated per category"))
        self.chart = BarChart(accent_name=hub.settings.accent)
        cats = {}
        for r in self.rows:
            c = cats.setdefault(r["category"], [0, 0])
            c[1] += 1
            c[0] += r["status"] != "missing"
        self.chart.set_data([(k.split(" ")[0], v[0]) for k, v in cats.items()])
        cc.lay.addWidget(self.chart)
        top.addWidget(cc, 1)
        col.addLayout(top)
        QTimer.singleShot(400, lambda: self.ring.set_share((cov + part) / n, f"{round(100 * (cov + part) / n)}%", "automated"))

        f = QHBoxLayout()
        self.q = QLineEdit()
        self.q.setPlaceholderText("Search actions…")
        self.q.textChanged.connect(self.fill)
        self.st = QComboBox()
        self.st.addItems(["All", "covered", "partial", "missing"])
        self.st.currentTextChanged.connect(self.fill)
        self.cat = QComboBox()
        self.cat.addItems(["All categories", *sorted(cats)])
        self.cat.currentTextChanged.connect(self.fill)
        f.addWidget(self.q, 1)
        f.addWidget(self.st)
        f.addWidget(self.cat)
        col.addLayout(f)
        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["ACTION", "CATEGORY", "STATUS", "DONE BY"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        self.table.verticalHeader().hide()
        self.table.setMinimumHeight(520)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        col.addWidget(self.table)
        self.fill()

    def fill(self):
        q = self.q.text().lower()
        st, cat = self.st.currentText(), self.cat.currentText()
        rows = [r for r in self.rows if (st == "All" or r["status"] == st)
                and (cat == "All categories" or r["category"] == cat)
                and (not q or q in (r["label"] + r["action"] + r.get("feature", "")).lower())]
        self.table.setRowCount(len(rows))
        colours = {"covered": COL["ok"], "partial": COL["warn"], "missing": COL["faint"]}
        for i, r in enumerate(rows):
            a = QTableWidgetItem(r["label"])
            a.setToolTip(f"{r['action']}\n{r.get('note', '')}".strip())
            self.table.setItem(i, 0, a)
            self.table.setItem(i, 1, QTableWidgetItem(r["category"]))
            s = QTableWidgetItem(r["status"])
            s.setForeground(QColor(colours[r["status"]]))
            self.table.setItem(i, 2, s)
            d = QTableWidgetItem(r.get("feature") or "—")
            d.setToolTip(r.get("where", ""))
            self.table.setItem(i, 3, d)


# =========================================================================== logs
# =========================================================================== teacher mode
class TeacherPage(QWidget):
    """Record a task done by hand on one instance, then export it as a lesson zip for Claude."""
    _update = Signal(object)

    def __init__(self, hub):
        super().__init__()
        from kscommand import teacher
        self.T = teacher
        self.hub = hub
        self.rec = None
        self._paused_autopilot = False
        page, col = scroll_page("Teacher", "Show the bot something new: record it once by hand on an instance, "
                                           "then send the lesson to Claude to turn into a job.")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(page)

        # learned skills: Claude's updates made from your lessons
        from kscommand import learned
        self.L = learned
        self._available = None
        up = Card(hover=False)
        uh = QHBoxLayout()
        uh.addWidget(heading("Updates and learned skills"), 1)
        self.up_chip = chip("", "ok")
        self.up_chip.hide()
        uh.addWidget(self.up_chip)
        up.lay.addLayout(uh)
        up.lay.addWidget(label("Press Update to get Claude's latest fixes to the app and the skills made from your "
                               "lessons. Skills work straight away; an app fix restarts the app. Your settings, "
                               "stats and lessons always stay.", "muted", wrap=True))
        self.up_status = label("", "faint", wrap=True)
        up.lay.addWidget(self.up_status)
        ub = QHBoxLayout()
        self.up_btn = QPushButton("Update")
        self.up_btn.setObjectName("primary")
        self.up_btn.clicked.connect(self.update_skills)
        from_file = QPushButton("Install from file…")
        from_file.clicked.connect(self.install_file)
        self.undo_btn = QPushButton("Undo last update")
        self.undo_btn.clicked.connect(hub.roll_back_learned)
        ub.addWidget(self.up_btn)
        ub.addWidget(from_file)
        ub.addStretch()
        ub.addWidget(self.undo_btn)
        up.lay.addLayout(ub)
        self.skill_rows = QVBoxLayout()
        self.skill_rows.setSpacing(8)
        up.lay.addLayout(self.skill_rows)
        col.addWidget(up)
        hub.learned_changed.connect(self.show_skills)
        hub.update_available.connect(self._on_available)

        rec = Card(hover=False)
        rec.lay.addWidget(heading("Record a lesson"))
        rec.lay.addWidget(label("Pick the instance, say what you're teaching, press Record and play the task "
                                "normally. Every tap and swipe is saved with the screen before and after it. "
                                "The recorder only watches; it never taps.", "muted", wrap=True))
        body = QHBoxLayout()
        body.setSpacing(22)
        form = QGridLayout()
        form.setVerticalSpacing(10)
        form.setHorizontalSpacing(14)
        self.inst = QComboBox()
        self.title = QLineEdit()
        self.title.setPlaceholderText("e.g. Daily Pet Adventure, Alliance shop, Hero gear upgrade")
        self.notes = QTextEdit()
        self.notes.setPlaceholderText("Optional notes for Claude: when it should run, what to skip, "
                                      "what counts as done…")
        self.notes.setFixedHeight(84)
        form.addWidget(label("Instance", "fieldLabel"), 0, 0)
        form.addWidget(self.inst, 0, 1)
        form.addWidget(label("Teaching", "fieldLabel"), 1, 0)
        form.addWidget(self.title, 1, 1)
        form.addWidget(label("Notes", "fieldLabel"), 2, 0, Qt.AlignTop)
        form.addWidget(self.notes, 2, 1)
        pr = QHBoxLayout()
        self.pause_ap = Toggle(True, accent_name=hub.settings.accent)
        pr.addWidget(self.pause_ap)
        pr.addWidget(label("Pause Autopilot while recording", "muted"))
        pr.addStretch()
        form.addLayout(pr, 3, 1)
        left = QVBoxLayout()
        left.addLayout(form)
        btns = QHBoxLayout()
        self.rec_btn = HeroButton("●  Start recording", hub.settings.accent)
        self.rec_btn.clicked.connect(self.toggle)
        btns.addWidget(self.rec_btn)
        btns.addStretch()
        left.addLayout(btns)
        stats = QHBoxLayout()
        self.dot = PulseDot("idle", 12)
        stats.addWidget(self.dot)
        self.stat = label("Not recording", "muted")
        stats.addWidget(self.stat, 1)
        left.addLayout(stats)
        self.last = label("", "faint", wrap=True)
        left.addWidget(self.last)
        left.addStretch()
        body.addLayout(left, 1)
        self.preview = QLabel("Live screen appears here")
        self.preview.setFixedSize(180, 320)
        self.preview.setAlignment(Qt.AlignCenter)
        self.preview.setStyleSheet(f"background: {COL['panel']}; border: 1px solid {COL['line2']}; border-radius: 12px;"
                                   f" color: {COL['faint']};")
        body.addWidget(self.preview, 0, Qt.AlignTop)
        rec.lay.addLayout(body)
        col.addWidget(rec)

        ls = Card(hover=False)
        lh = QHBoxLayout()
        lh.addWidget(heading("Lessons"), 1)
        ls.lay.addLayout(lh)
        ls.lay.addWidget(label("Send to Claude packs a lesson into one zip in Documents\\Kingshot lessons, shows it "
                               "in Explorer and copies its path. Drop that file into the Claude thread.",
                               "muted", wrap=True))
        self.list = QListWidget()
        self.list.setMinimumHeight(180)
        ls.lay.addWidget(self.list)
        lb = QHBoxLayout()
        send = QPushButton("Send to Claude")
        send.setObjectName("primary")
        send.clicked.connect(self.send)
        opn = QPushButton("Open folder")
        opn.clicked.connect(self.open_folder)
        rm = QPushButton("Delete")
        rm.setObjectName("danger")
        rm.clicked.connect(self.delete)
        lb.addWidget(send)
        lb.addWidget(opn)
        lb.addStretch()
        lb.addWidget(rm)
        ls.lay.addLayout(lb)
        col.addWidget(ls)
        col.addStretch()

        self._update.connect(self._show)
        self.tick = QTimer(self, interval=1000, timeout=lambda: self.rec and self._show(self.rec))
        hub.instances_changed.connect(lambda *_: self.fill_instances())
        self.fill_instances()
        self.reload()
        self.show_skills()

    # ---- learned skills
    WHEN = {"before_game": "Before Kingshot opens", "session_start": "Before each session", "manual": "Run by hand"}

    def show_skills(self):
        pack = self.L.installed()
        while self.skill_rows.count():
            it = self.skill_rows.takeAt(0)
            w = it.widget()
            if w:
                w.deleteLater()
        ver = pack.get("version", 0)
        app_line = f"App: Kingshot Command {self.hub.version}"
        if ver:
            when = (pack.get("published") or "")[:16].replace("T", " ")
            n = len(pack.get("skills", []))
            self.up_status.setText(f"{app_line}  ·  Skills: update {ver}, {n} skill{'s' * (n != 1)}, published {when}"
                                   + (f"\n{pack['notes']}" if pack.get("notes") else ""))
        else:
            self.up_status.setText(f"{app_line}  ·  No learned skills yet. Send a lesson to Claude, then press Update.")
        self.undo_btn.setEnabled((self.L.PREV / "pack.json").is_file())
        if self._available and self._available["version"] <= ver and not self._app_ready():
            self._available = None
        self._show_available()
        off = set(self.hub.settings.learned_off)
        for s in pack.get("skills", []):
            row = QWidget()
            rl = QHBoxLayout(row)
            rl.setContentsMargins(0, 4, 0, 4)
            rl.setSpacing(12)
            tg = Toggle(s["id"] not in off, accent_name=self.hub.settings.accent)
            tg.toggled.connect(lambda on, sid=s["id"]: self._toggle_skill(sid, on))
            rl.addWidget(tg, 0, Qt.AlignTop)
            text = QVBoxLayout()
            text.setSpacing(2)
            text.addWidget(label(no_emoji(s.get("title", s["id"])), "h2"))
            where = ", ".join(s.get("instances") or []) or "every instance"
            text.addWidget(label(no_emoji(f"{s.get('about', '')}  ({where})".strip()), "faint", wrap=True))
            rl.addLayout(text, 1)
            rl.addWidget(chip(self.WHEN.get(s.get("when"), s.get("when", ""))), 0, Qt.AlignTop)
            run = QPushButton("Run now")
            run.clicked.connect(lambda _=False, sk=s: self.run_skill(sk))
            rl.addWidget(run, 0, Qt.AlignTop)
            self.skill_rows.addWidget(row)

    def _on_available(self, info):
        self._available = info
        self._show_available()

    def _app_ready(self):
        from kscommand import selfupdate
        return selfupdate.newer(self._available, self.hub.version)

    def _show_available(self):
        info = self._available
        self.up_btn.setText("Update")
        parts = []
        if info and info["version"] > self.L.installed().get("version", 0):
            parts.append(f"Skills update {info['version']}")
        app = self._app_ready() if info else None
        if app:
            parts.append(f"App {app['version']}")
        if parts:
            self.up_chip.setText(" + ".join(parts) + " ready")
            self.up_chip.show()
        else:
            self.up_chip.hide()

    def _toggle_skill(self, sid, on):
        off = [x for x in self.hub.settings.learned_off if x != sid]
        if not on:
            off.append(sid)
        self.hub.settings.learned_off = off
        self.hub.save_settings()

    def update_skills(self):
        self.up_btn.setEnabled(False)
        self.up_btn.setText("Updating…")

        def done(res):
            self.up_btn.setEnabled(True)
            if not isinstance(res, Exception):
                self._available = None
            self.show_skills()
        self.hub.apply_learned(done)

    def install_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Learned skills pack", str(core.ROOT), "Skill pack (*.zip)")
        if path:
            self.hub.apply_learned(lambda res: self.show_skills(), path=path)

    def run_skill(self, skill):
        serial, name = self.inst.currentData(), self.inst.currentText()
        if not serial:
            self.hub.toast("Pick an instance in Record a lesson below first", "warn")
            return
        self.hub.toast(f"Running {skill.get('title', skill['id'])} on {name}", "info")
        self.hub.log("Learned", f"{name}: running {skill.get('title', skill['id'])} by hand")

        def work():
            from intel_adb import adb as A
            return self.L.run_skill(skill, A.Device(name, serial), log=lambda t: self.hub.log("Learned", t))

        def done(res):
            if isinstance(res, Exception):
                self.hub.toast(f"{skill.get('title')}: {res}", "bad")
            else:
                self.hub.toast(res[1], "ok" if res[0] else "warn")
        self.hub.in_thread(work, done)

    # ---- instances / lessons
    def fill_instances(self):
        cur = self.inst.currentText()
        self.inst.clear()
        for n, serial in self.hub.instances:
            self.inst.addItem(n, serial)
        if cur:
            self.inst.setCurrentText(cur)
        if not self.hub.instances:
            self.inst.addItem("No instance with Kingshot open", None)

    def reload(self):
        self.list.clear()
        for folder, meta in self.T.lessons():
            it = QListWidgetItem(f"{meta.get('title', folder.name)}    ·  {meta.get('steps', 0)} touches, "
                                 f"{meta.get('frames', 0)} screens, {round(meta.get('seconds', 0))} s  ·  "
                                 f"{meta.get('instance', '')}  ·  {meta.get('started', '')[:16].replace('T', ' ')}")
            it.setData(Qt.UserRole, str(folder))
            self.list.addItem(it)
        if not self.list.count():
            it = QListWidgetItem("No lessons yet")
            it.setFlags(Qt.NoItemFlags)
            self.list.addItem(it)
        else:
            self.list.setCurrentRow(0)

    def _selected(self):
        it = self.list.currentItem()
        return it.data(Qt.UserRole) if it else None

    # ---- recording
    def toggle(self):
        if self.rec:
            self.stop()
        else:
            self.start()

    def start(self):
        serial = self.inst.currentData()
        name = self.inst.currentText()
        if not serial:
            self.hub.toast("Open Kingshot on an instance first (Home → Refresh)", "warn")
            return
        title = self.title.text().strip()
        if not title:
            self.hub.toast("Say what you're teaching first", "warn")
            self.title.setFocus()
            return
        if self.pause_ap.isChecked() and self.hub.bridge.running:
            self.hub.bridge.stop()
            self._paused_autopilot = True
            self.hub.toast("Autopilot paused while you record", "info")
        try:
            self.rec = self.T.Recorder(name, serial, title, self.notes.toPlainText().strip(),
                                       on_update=self._update.emit).start()
        except Exception as e:  # noqa: BLE001
            self.hub.toast(f"Couldn't start recording: {e}", "bad")
            self.rec = None
            return
        self.hub.log("Teacher", f"recording '{title}' on {name}")
        self.rec_btn.set_active(True, "■  Stop recording")
        self.dot.set_status("stopped")
        self.inst.setEnabled(False)
        self.title.setEnabled(False)
        self.tick.start()
        self._show(self.rec)

    def stop(self):
        rec, self.rec = self.rec, None
        self.tick.stop()
        self.rec_btn.setEnabled(False)
        self.stat.setText("Saving…")

        def done(res):
            self.rec_btn.setEnabled(True)
            self.rec_btn.set_active(False, "●  Start recording")
            self.dot.set_status("idle")
            self.inst.setEnabled(True)
            self.title.setEnabled(True)
            if isinstance(res, Exception):
                self.stat.setText(f"Saving failed: {res}")
                return
            self.stat.setText(f"Saved: {len(rec.gestures)} touches, {len(rec.frames)} screens. "
                              "Press Send to Claude below.")
            self.hub.log("Teacher", f"saved {res}")
            self.hub.toast("Lesson saved", "ok")
            self.reload()
            if self._paused_autopilot:
                self._paused_autopilot = False
                self.hub.start_autopilot()
        self.hub.in_thread(rec.stop, done)

    def _show(self, rec):
        if rec is not self.rec:
            return
        m, sec = divmod(int(rec.seconds), 60)
        self.stat.setText(f"Recording {m}:{sec:02d}  ·  {len(rec.gestures)} touches  ·  {len(rec.frames)} screens")
        if rec.gestures:
            g = rec.gestures[-1]
            self.last.setText(f"Last: {g['kind'].replace('_', ' ')} at {round(g['x'] * 540)}, {round(g['y'] * 960)}")
        if rec.error:
            self.last.setText(f"Only screens are recorded: {rec.error}")
        if rec.last_img is not None:
            pm = to_pixmap(rec.last_img, 12)
            self.preview.setPixmap(pm.scaled(self.preview.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))

    # ---- lessons
    def send(self):
        folder = self._selected()
        if not folder:
            self.hub.toast("Record a lesson first", "warn")
            return

        def done(res):
            if isinstance(res, Exception):
                self.hub.toast(f"Couldn't pack the lesson: {res}", "bad")
                return
            from PySide6.QtWidgets import QApplication
            QApplication.clipboard().setText(str(res))
            core.reveal(res)
            self.hub.log("Teacher", f"lesson packed: {res}")
            self.hub.toast("Lesson zip ready and its path copied. Drop it into the Claude thread.", "ok")
        self.hub.in_thread(lambda: self.T.export(folder), done)

    def open_folder(self):
        folder = self._selected()
        if folder:
            core.reveal(folder)

    def delete(self):
        folder = self._selected()
        if not folder:
            return
        import shutil
        shutil.rmtree(folder, ignore_errors=True)
        self.reload()


class LogsPage(QWidget):
    def __init__(self, hub):
        super().__init__()
        self.hub = hub
        lay = QVBoxLayout(self)
        lay.setContentsMargins(32, 28, 32, 28)
        lay.setSpacing(12)
        lay.addWidget(label("System", "eyebrow"))
        lay.addWidget(label("Logs", "pageTitle"))
        bar = QHBoxLayout()
        self.src = QComboBox()
        self.src.addItems(["Everything", "Autopilot", "App", *(b.title for b in B.BOTS)])
        self.src.currentTextChanged.connect(self.redraw)
        self.q = QLineEdit()
        self.q.setPlaceholderText("Filter…")
        self.q.textChanged.connect(self.redraw)
        save = QPushButton("Save")
        save.clicked.connect(self.save)
        clear = QPushButton("Clear")
        clear.clicked.connect(self.clear)
        bar.addWidget(self.src)
        bar.addWidget(self.q, 1)
        bar.addWidget(save)
        bar.addWidget(clear)
        lay.addLayout(bar)
        self.view = QTextEdit()
        self.view.setObjectName("console")
        self.view.setReadOnly(True)
        lay.addWidget(self.view, 1)
        self.lines = []  # (time, source, text)
        hub.log_line.connect(self.add)

    def _fmt(self, t, src, text):
        low = text.lower()
        colour = (COL["bad"] if any(w in low for w in ("error", "failed", "traceback", "exception")) else
                  COL["ok"] if any(w in low for w in ("■", "finished", "done", "claimed", "started")) else
                  COL["warn"] if any(w in low for w in ("retry", "skipped", "warn", "waiting")) else COL["text"])
        return (f'<span style="color:{COL["faint"]}">{t}</span> '
                f'<span style="color:{COL["info"]}">{html.escape(src):<10}</span> '
                f'<span style="color:{colour}">{html.escape(text)}</span>')

    def _match(self, src, text):
        s, q = self.src.currentText(), self.q.text().lower()
        return (s == "Everything" or s == src) and (not q or q in text.lower())

    def add(self, src, text):
        text = no_emoji(text)
        t = datetime.now().strftime("%H:%M:%S")
        self.lines.append((t, src, text))
        if len(self.lines) > 8000:
            self.lines = self.lines[-6000:]
        if self._match(src, text):
            self.view.append(self._fmt(t, src, text))
            self.view.moveCursor(QTextCursor.End)

    def redraw(self):
        self.view.setHtml("<br>".join(self._fmt(*ln) for ln in self.lines[-3000:] if self._match(ln[1], ln[2])))
        self.view.moveCursor(QTextCursor.End)

    def save(self):
        path, _ = QFileDialog.getSaveFileName(self, "Save log", str(core.LOG_DIR / f"log-{datetime.now():%Y%m%d-%H%M}.txt"),
                                              "Text (*.txt)")
        if path:
            with open(path, "w", encoding="utf-8") as f:
                f.writelines(f"{t} {s}: {x}\n" for t, s, x in self.lines)

    def clear(self):
        self.lines = []
        self.view.clear()


# =========================================================================== settings
class SettingsPage(QWidget):
    def __init__(self, hub):
        super().__init__()
        self.hub = hub
        s = hub.settings
        page, col = scroll_page("Settings", "Tools, automation, emulators and your Telegram remote.")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(page)

        tools = Card(hover=False)
        tools.lay.addWidget(heading("Tools"))
        self.adb_row, self.adb_lbl, self.adb_btn = self._tool_row("ADB (talks to the emulators)", "Download ADB",
                                                                  self.get_adb)
        self.ocr_row, self.ocr_lbl, self.ocr_btn = self._tool_row("OCR (reads timers, names, prices)", "Install OCR",
                                                                  self.get_ocr)
        tools.lay.addWidget(self.adb_row)
        tools.lay.addWidget(self.ocr_row)
        self.dl = QProgressBar()
        self.dl.hide()
        tools.lay.addWidget(self.dl)
        col.addWidget(tools)

        auto = Card(hover=False)
        auto.lay.addWidget(heading("Automation"))
        auto.lay.addWidget(self._switch("Start Autopilot when the app opens", "autostart",
                                        "The one-click part: open the app and it gets going after a short countdown."))
        auto.lay.addWidget(self._switch("Keep Kingshot running", "keep_alive",
                                        "While Autopilot runs, relaunch the game when it crashed or was closed."))
        auto.lay.addWidget(self._switch("Start with Windows", "start_with_windows",
                                        "Opens minimised to the tray when you sign in.", self.hub.apply_startup))
        auto.lay.addWidget(self._switch("Close to tray", "minimize_to_tray",
                                        "Closing the window keeps the bot running in the tray."))
        col.addWidget(auto)

        launch = Card(hover=False)
        lh = QHBoxLayout()
        lh.addWidget(heading("Start and close instances"), 1)
        rescan = QPushButton("Rescan")
        rescan.clicked.connect(hub.refresh_emulators)
        add = QPushButton("+ Add shortcut")
        add.setToolTip("Any shortcut, .exe or .bat that opens an emulator (LDPlayer, Kingshot Player, a script…)")
        add.clicked.connect(self.add_shortcut)
        lh.addWidget(rescan)
        lh.addWidget(add)
        launch.lay.addLayout(lh)
        launch.lay.addWidget(label(
            "Start: Autopilot opens the instance (and Kingshot) when one of its sessions is due. Close: once its "
            "sessions are done and the next one is more than 15 minutes away, Autopilot closes it again. "
            "Instances a bot is using are never closed.", "muted", wrap=True))
        self.emu_rows = QVBoxLayout()
        self.emu_rows.setSpacing(2)
        launch.lay.addLayout(self.emu_rows)
        col.addWidget(launch)
        hub.emulators_changed.connect(self.fill_emulators)
        self.fill_emulators()

        emu = Card(hover=False)
        emu.lay.addWidget(heading("Emulators"))
        emu.lay.addWidget(label("Low resolution (540×960) makes screenshots 4× smaller and the bots faster. "
                                "Kingshot looks the same; undo it any time.", "muted", wrap=True))
        r = QHBoxLayout()
        lo = QPushButton("Set low resolution")
        lo.clicked.connect(lambda: hub.set_resolution(True))
        rs = QPushButton("Reset resolution")
        rs.clicked.connect(lambda: hub.set_resolution(False))
        rel = QPushButton("Release stuck touches")
        rel.setToolTip("Lifts a finger a killed bot left on the screen (white dot that won't go)")
        rel.clicked.connect(hub.release_touches)
        r.addWidget(lo)
        r.addWidget(rs)
        r.addWidget(rel)
        r.addStretch()
        emu.lay.addLayout(r)
        col.addWidget(emu)

        tg = Card(hover=False)
        tg.lay.addWidget(heading("Telegram remote"))
        tg.lay.addWidget(label("Make a bot with @BotFather, paste its token, send it /start, then paste the chat id "
                               "it replies with. You get session results and crash alerts, and can send /status, "
                               "/start, /stop, /shot, /run <bot>, /redeem <code>, /launch and /close.", "muted", wrap=True))
        g = QGridLayout()
        self.token = QLineEdit(s.telegram_token)
        self.token.setEchoMode(QLineEdit.Password)
        self.token.setPlaceholderText("123456:ABC-DEF…")
        self.chat = QLineEdit(s.telegram_chat)
        self.chat.setPlaceholderText("Your chat id")
        g.addWidget(label("Bot token", "muted"), 0, 0)
        g.addWidget(self.token, 0, 1)
        g.addWidget(label("Chat id", "muted"), 1, 0)
        g.addWidget(self.chat, 1, 1)
        tg.lay.addLayout(g)
        tr = QHBoxLayout()
        conn = QPushButton("Connect")
        conn.setObjectName("primary")
        conn.clicked.connect(self.connect_tg)
        test = QPushButton("Send test")
        test.clicked.connect(lambda: hub.notify("👋 Kingshot Command is connected."))
        tr.addWidget(conn)
        tr.addWidget(test)
        self.tg_state = label("", "faint")
        tr.addWidget(self.tg_state, 1)
        tg.lay.addLayout(tr)
        tg.lay.addWidget(self._switch("Send session results and alerts", "telegram_events", ""))
        col.addWidget(tg)

        look = Card(hover=False)
        look.lay.addWidget(heading("Appearance"))
        ar = QHBoxLayout()
        ar.addWidget(label("Accent", "muted"))
        ac = QComboBox()
        from kscommand.ui.theme import ACCENTS
        ac.addItems(list(ACCENTS))
        ac.setCurrentText(s.accent)
        ac.currentTextChanged.connect(hub.set_accent)
        ar.addWidget(ac)
        ar.addStretch()
        look.lay.addLayout(ar)
        col.addWidget(look)

        about = Card(hover=False)
        about.lay.addWidget(heading("About"))
        about.lay.addWidget(label(f"{core.APP_NAME} · app folder {core.ROOT}", "faint", wrap=True))
        about.lay.addWidget(label("Kingshot's terms don't allow automation; an account using any bot can be banned. "
                                  "This app only taps the screen you could tap yourself and never logs in for you.",
                                  "faint", wrap=True))
        col.addWidget(about)
        col.addStretch()
        hub.telegram_status.connect(self.tg_state.setText)
        self.refresh_tools()

    def fill_emulators(self):
        while self.emu_rows.count():
            it = self.emu_rows.takeAt(0)
            old = it.widget()
            if old:
                old.hide()
                old.deleteLater()
        targets = self.hub.emulator_targets()
        if not targets:
            self.emu_rows.addWidget(label("No BlueStacks or MuMu instances found on this PC. Add a shortcut for "
                                          "any other emulator.", "faint", wrap=True))
            return
        head = QWidget()
        hh = QHBoxLayout(head)
        hh.setContentsMargins(0, 6, 0, 2)
        hh.addWidget(label("Instance", "fieldLabel"), 1)
        for text, w in (("Start", 60), ("Close", 60), ("", 236)):
            lb = label(text, "fieldLabel")
            lb.setFixedWidth(w)
            hh.addWidget(lb)
        self.emu_rows.addWidget(head)
        self.emu_rows.addWidget(hline())
        for t in targets:
            self.emu_rows.addWidget(self._emu_row(t))

    def _emu_row(self, t):
        from kscommand.emulators import KIND_LABELS
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 6, 0, 6)
        v = QVBoxLayout()
        v.setSpacing(2)
        top = QHBoxLayout()
        top.setSpacing(8)
        top.addWidget(label(t.name, "h3"))
        top.addWidget(chip(KIND_LABELS.get(t.kind, t.kind)))
        top.addStretch()
        v.addLayout(top)
        where = t.ident if t.kind == "shortcut" else t.serial
        if t.kind == "shortcut" and t.proc:
            where += f" · closes {t.proc}"
        v.addWidget(label(where, "faint"))
        h.addLayout(v, 1)
        for attr in ("start", "close"):
            box = QWidget()
            box.setFixedWidth(60)
            bl = QHBoxLayout(box)
            bl.setContentsMargins(0, 0, 0, 0)
            tg = Toggle(getattr(t, attr), accent_name=self.hub.settings.accent)
            tg.toggled.connect(lambda on, a=attr, tt=t: self.hub.set_emulator(tt, **{a: on}))
            bl.addWidget(tg)
            bl.addStretch()
            h.addWidget(box)
        acts = QWidget()
        acts.setFixedWidth(236)
        al = QHBoxLayout(acts)
        al.setContentsMargins(0, 0, 0, 0)
        al.setSpacing(4)
        go = QPushButton("Start")
        go.setToolTip("Start this instance and open Kingshot now")
        go.setObjectName("ghost")
        go.clicked.connect(lambda _=False, n=t.name: self.hub.start_emulators([n]))
        stop = QPushButton("Close")
        stop.setToolTip("Close this instance now")
        stop.setObjectName("ghost")
        stop.clicked.connect(lambda _=False, n=t.name: self.hub._close(n))
        al.addWidget(go)
        al.addWidget(stop)
        if t.kind == "shortcut":
            rm = QPushButton("Remove")
            rm.setObjectName("ghost")
            rm.clicked.connect(lambda _=False, n=t.name: self.hub.remove_emulator(n))
            al.addWidget(rm)
        al.addStretch()
        h.addWidget(acts)
        return w

    def add_shortcut(self):
        from PySide6.QtWidgets import QInputDialog
        path, _ = QFileDialog.getOpenFileName(self, "Shortcut that opens the emulator", "",
                                              "Shortcuts and programs (*.lnk *.exe *.bat *.cmd);;All files (*)")
        if not path:
            return
        known = sorted({n for n, _ in self.hub.instances} | {c.instance for c in self.hub.bridge.settings.characters})
        name, ok = QInputDialog.getItem(
            self, "Which instance is it?",
            "The instance name Autopilot uses for it (the name on the Home page once it runs Kingshot):",
            known or [__import__("pathlib").Path(path).stem], 0, True)
        if ok and name.strip():
            self.hub.add_shortcut(path, name.strip())

    def _tool_row(self, title, btn_text, fn):
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        v = QVBoxLayout()
        v.setSpacing(0)
        v.addWidget(label(title))
        st = label("", "faint")
        v.addWidget(st)
        h.addLayout(v, 1)
        b = QPushButton(btn_text)
        b.clicked.connect(fn)
        h.addWidget(b)
        return w, st, b

    def _switch(self, title, attr, sub, after=None):
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 4, 0, 4)
        v = QVBoxLayout()
        v.setSpacing(0)
        v.addWidget(label(title))
        if sub:
            v.addWidget(label(sub, "faint", wrap=True))
        h.addLayout(v, 1)
        t = Toggle(bool(getattr(self.hub.settings, attr)), accent_name=self.hub.settings.accent)

        def changed(on):
            setattr(self.hub.settings, attr, on)
            self.hub.save_settings()
            if after:
                after(on)
        t.toggled.connect(changed)
        h.addWidget(t)
        return w

    def refresh_tools(self):
        st = core.tool_status()
        self.adb_lbl.setText(f"✓ {st['adb']}" if st["adb"] else "Not found: install BlueStacks/MuMu, or download Google's ADB")
        self.adb_btn.setVisible(not st["adb"])
        self.ocr_lbl.setText(f"✓ {st['ocr']}" if st["ocr"] else
                             "Not installed: bots still run, but timers and names fall back to safe guesses")
        self.ocr_btn.setVisible(not st["ocr"])

    def _download(self, fn, what):
        import threading
        self.dl.setRange(0, 100)
        self.dl.setValue(0)
        self.dl.show()
        prog = self.hub.download_progress

        def work():
            try:
                fn(lambda f: prog.emit(int(f * 100)))
                prog.emit(101)
                self.hub.toast_sig.emit(f"{what} installed", "ok")
            except Exception as e:
                prog.emit(-1)
                self.hub.toast_sig.emit(f"{what} failed: {e}", "bad")
        prog.connect(self._prog)
        threading.Thread(target=work, daemon=True).start()

    def _prog(self, v):
        if v < 0 or v > 100:
            self.dl.hide()
            self.refresh_tools()
        else:
            self.dl.setValue(v)

    def get_adb(self):
        self._download(core.install_adb, "ADB")

    def get_ocr(self):
        self._download(core.install_ocr, "OCR")

    def connect_tg(self):
        self.hub.settings.telegram_token = self.token.text().strip()
        self.hub.settings.telegram_chat = self.chat.text().strip()
        self.hub.save_settings()
        self.hub.start_telegram()
