"""Autopilot settings: every knob with a default, saved as JSON next to the app."""
import copy
import json
import threading
from dataclasses import asdict, dataclass, field
from pathlib import Path

SETTINGS_PATH = Path(__file__).parent / "settings.json"

JOBS = ["claim", "rewards", "train", "research", "hunt", "gather", "intel", "terrors", "alliance", "city", "build", "arena", "blizzard"]

JOB_LABELS = {
    "claim": "Claim rewards",
    "rewards": "Quests & free rewards",
    "train": "Train troops",
    "research": "Academy research",
    "hunt": "Beast hunting",
    "gather": "Gather resources",
    "intel": "Intel missions",
    "terrors": "Terrors",
    "alliance": "Alliance help & research",
    "city": "City chores",
    "build": "Building upgrades",
    "arena": "Arena (before reset)",
    "blizzard": "Blizzard Brawl (gather barrels)",
}

DEFAULT_PARAMS = {
    "claim": {"mail": True, "alliance_gifts": True, "daily": True, "meat": True},
    "rewards": {"quests": True, "signin": True, "free_chests": True, "pass_rewards": True,
                "bank": False},
    "train": {"mode": "Keep busy", "finish_by": "", "hold_until": "",
              "infantry": True, "cavalry": True, "archer": True, "promote_when_off": True},
    "research": {"tree": "Growth", "fallback_any": True, "ask_help": True},
    "hunt": {"level": "Highest", "max_attacks": 10, "formation": "Equalize", "use_meat": False},
    "gather": {"resource": "Any", "level": "Highest", "marches": 2, "avoid_events": True,
               "recall_before": 5, "bear_minutes": 30, "battle_minutes": 60},
    "intel": {"formation": "Equalize", "bounties": "Only if likely to prevail", "attack_grey": True,
              "march_slots": 0},
    "terrors": {"per_day": 10, "preset": 6, "use_meat": False, "spread": True, "at_once": 1},
    "alliance": {"help": True, "donations": 25},
    "build": {"ask_help": True},
    "blizzard": {"teleport": True, "matches_per_slot": 2},
    "arena": {"start_utc": "23:56", "buy_extra": True, "max_gems": 2100},
    "city": {"panel": True, "recruit": True, "conquest": True, "story": True, "trial": True, "roulette": True, "rebel": True, "heal": True, "ask_help": True},
}


@dataclass
class Job:
    enabled: bool = False
    params: dict = field(default_factory=dict)


def _default_jobs():
    return {j: Job(False, copy.deepcopy(DEFAULT_PARAMS[j])) for j in JOBS}


@dataclass
class Character:
    instance: str
    name: str  # in-game name without the alliance tag (the tag can change)
    enabled: bool = True
    jobs: dict = field(default_factory=_default_jobs)
    kingdom: int | None = None
    tag: str = ""  # alliance tag when last seen, display only
    folder: str = ""  # Characters-page folder ("" = none)
    power: int = 0  # last seen on the Characters list: recognises the character after a rename
    active_start: str = "00:00"  # local time window this character may run in;
    active_end: str = "00:00"  # equal start and end = any time
    bots: list = field(default_factory=list)  # Build-a-bot templates (ids) run each session, before the jobs

    @property
    def key(self):
        if self.kingdom is None:
            return f"{self.instance}/{self.name}"
        return f"{self.instance}/{self.kingdom}/{self.name}"

    @property
    def label(self):
        tag = f"[{self.tag}]" if self.tag else ""
        return f"{tag}{self.name}" + (f" #{self.kingdom}" if self.kingdom is not None else "")


@dataclass
class Schedule:
    interval_min_h: float = 2.0
    interval_max_h: float = 4.0
    quiet_start: str = "02:00"  # local time; equal start/end = no quiet hours
    quiet_end: str = "08:00"
    tap_pause_min: float = 0.4  # s, random pause between taps
    tap_pause_max: float = 1.2
    max_session_min: float = 30.0
    order: str = "Round robin"  # or "List order"
    enabled: bool = True


@dataclass
class Safety:
    never_spend: bool = True  # close purchase / top-up / diamond prompts, never confirm them
    stop_after_unknown: int = 5  # consecutive unknown screens before a character is skipped
    screenshot_on_stuck: bool = True


@dataclass
class Settings:
    characters: list = field(default_factory=list)
    folders: list = field(default_factory=list)  # folder names, in display order
    schedule: Schedule = field(default_factory=Schedule)
    safety: Safety = field(default_factory=Safety)
    theme: str = "Dark"


def _merge(default, data):
    """Fill missing keys from `default`, drop unknown ones, keep user values."""
    out = copy.deepcopy(default)
    for k, v in (data or {}).items():
        if k in out:
            out[k] = v
    return out


def _character(d):
    ch = Character(instance=d["instance"], name=d["name"], enabled=d.get("enabled", True),
                   kingdom=d.get("kingdom"), tag=d.get("tag", ""), power=int(d.get("power", 0) or 0), folder=d.get("folder", ""),
                   active_start=d.get("active_start", "00:00"), active_end=d.get("active_end", "00:00"),
                   bots=[str(b) for b in d.get("bots") or []])
    for j in JOBS:
        jd = (d.get("jobs") or {}).get(j, {})
        ch.jobs[j] = Job(bool(jd.get("enabled", False)), _merge(DEFAULT_PARAMS[j], jd.get("params")))
    return ch


def load(path=SETTINGS_PATH):
    path = Path(path)
    if not path.exists():
        return Settings()
    d = json.loads(path.read_text(encoding="utf-8"))
    return Settings(
        characters=[_character(c) for c in d.get("characters", [])],
        folders=list(d.get("folders", [])),
        schedule=Schedule(**_merge(asdict(Schedule()), d.get("schedule"))),
        safety=Safety(**_merge(asdict(Safety()), d.get("safety"))),
        theme=d.get("theme", "Dark"),
    )


_save_lock = threading.Lock()


def save(settings, path=SETTINGS_PATH):
    with _save_lock:  # the app and several sessions may save at once
        path = Path(path)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(asdict(settings), indent=2), encoding="utf-8")
        tmp.replace(path)
