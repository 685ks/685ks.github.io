"""Getting an instance back when adb stops answering in the middle of a bot run.

Seen live 2026-10-21 (Terror rallies on BlueStacks "Falkor"): every adb command to the
instance hung for minutes while Kingshot kept running on screen. The bot used to stop with
0 rallies. recover() instead remakes the adb connection, waits for the instance to answer,
reopens Kingshot if it is no longer in front (after the learned "before game" skills, so the
VPN rule still holds) and lets the bot carry on.
"""
import subprocess
import time

from intel_adb import adb

WAIT = 10 * 60  # s to wait for the instance to answer again before giving up
RETRY = 20  # s between reconnects
OPEN_WAIT = 120  # s for Kingshot to come to the front after opening it
SETTLE = 25  # s for the loading screen once it is in front

# what a hung / lost instance raises from Device methods
ADB_ERRORS = (subprocess.TimeoutExpired, subprocess.SubprocessError, OSError, RuntimeError)


def before_game(name, serial):
    """Run the installed "before_game" learned skills like the app does. False: a required
    one failed (e.g. Proton VPN), so Kingshot must stay closed."""
    try:
        from kscommand import core, learned
    except Exception:  # bots run on their own (no app): nothing learned to run
        return True
    off = core.load().learned_off
    if not learned.has_hook("before_game", name, off):
        return True
    res = learned.run_hook("before_game", name, serial, off, log=print)
    return learned.blocked(res) is None


def recover(dev, wait=WAIT, retry=RETRY, sleep=time.sleep, clock=time.monotonic, before=before_game):
    """True once `dev` answers again with Kingshot in front, False if it stays silent for
    `wait` s or Kingshot can't (or may not) be opened."""
    dev.log("instance stopped answering adb - reconnecting")
    end = clock() + wait
    while True:
        dev.reconnect()
        if dev.alive():
            break
        if clock() >= end:
            dev.log(f"still no answer after {wait // 60} min - is the emulator frozen or closed?")
            return False
        sleep(retry)
    dev.log("adb answers again")
    try:
        if dev.foreground_package() == adb.KINGSHOT_PACKAGE:
            return True
        if not before(dev.name, dev.serial):
            dev.log("not reopening Kingshot: a required learned skill failed")
            return False
        dev.log("Kingshot isn't in front - opening it")
        opened = clock() + OPEN_WAIT
        tries = 0
        while clock() < opened:
            if dev.foreground_package() == adb.KINGSHOT_PACKAGE:
                sleep(SETTLE)
                dev.log("Kingshot is open again - carrying on")
                return True
            if tries % 5 == 0:
                dev._adb("shell", "monkey", "-p", adb.KINGSHOT_PACKAGE, "-c",
                         "android.intent.category.LAUNCHER", "1", timeout=20)
            tries += 1
            sleep(3)
    except ADB_ERRORS as e:
        dev.log(f"lost the instance again while reopening Kingshot: {e!r}")
        return False
    dev.log("Kingshot didn't open")
    return False
