"""Starting and closing emulator instances, so Autopilot can open an instance before its
session and close it again when it's done.

Each instance is a Target: a BlueStacks instance (started with HD-Player --instance, which
also opens Kingshot), a MuMu instance (MuMuManager control -v N launch/shutdown), or a
shortcut the user picked (a .lnk, .exe or .bat; anything that brings an emulator up)."""
import os
import re
import shlex
import subprocess
import threading
import time
from dataclasses import asdict, dataclass, replace
from pathlib import Path

from intel_adb import adb as A

KINGSHOT = "com.run.tower.defense"
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
BOOT_TIMEOUT = 240  # s for the emulator to boot and Kingshot to come to the front
SETTLE = 25  # s after we opened Kingshot ourselves, for its loading screen
MAX_PARALLEL_BOOTS = 2  # booting is the heavy part; more at once slows every instance


@dataclass
class Target:
    name: str  # instance name, as discovery and Autopilot characters use it
    kind: str  # "bluestacks" | "mumu" | "shortcut"
    ident: str = ""  # BlueStacks instance id, MuMu index, or the shortcut's path
    args: str = ""  # shortcut only
    serial: str = ""  # adb serial when known
    proc: str = ""  # shortcut only: process to end when closing (e.g. "qemu-system-x86_64.exe")
    start: bool = False  # start it when a session needs it
    close: bool = False  # close it once its sessions are done

    def to_json(self):
        return asdict(self)


KIND_LABELS = {"bluestacks": "BlueStacks", "mumu": "MuMu", "shortcut": "Shortcut"}


# ---------------------------------------------------------------- detection
def bluestacks_targets(conf_text):
    """BlueStacks instances from bluestacks.conf: [Target] with the instance id and adb port.
    Uses the same stale-entry rule as discovery (adb.parse_conf)."""
    names = dict(re.findall(r'bst\.instance\.([^.]+)\.display_name="([^"]*)"', conf_text))
    ports = {i: int(p) for i, p in re.findall(r'bst\.instance\.([^.]+)\.status\.adb_port="(\d+)"', conf_text)}
    keep = set(A.parse_conf(conf_text))
    out = []
    for i, name in names.items():
        if i in ports and (name, ports[i]) in keep:
            out.append(Target(name=name, kind="bluestacks", ident=i, serial=f"127.0.0.1:{ports[i]}"))
    return out


def bluestacks_player():
    """HD-Player.exe from the registry, else the default install folder."""
    if os.name == "nt":
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\BlueStacks_nxt") as k:
                d = winreg.QueryValueEx(k, "InstallDir")[0]
            if (Path(d) / "HD-Player.exe").exists():
                return str(Path(d) / "HD-Player.exe")
        except OSError:
            pass
    base = Path(os.environ.get("ProgramFiles", r"C:\Program Files"))
    return str(base / "BlueStacks_nxt" / "HD-Player.exe")


def mumu_roots():
    if os.environ.get("KS_MUMU_ROOT"):
        return [Path(os.environ["KS_MUMU_ROOT"])]
    out = []
    for env in ("ProgramFiles", "ProgramFiles(x86)"):
        base = Path(os.environ.get(env, r"C:\Program Files")) / "Netease"
        out += [base / "MuMuPlayer-12.0", base / "MuMuPlayer", base / "MuMu Player 12"]
    return [r for r in out if (r / "vms").is_dir()]


def mumu_manager(root):
    for rel in ("shell/MuMuManager.exe", "nx_main/MuMuManager.exe", "MuMuManager.exe"):
        if (Path(root) / rel).exists():
            return str(Path(root) / rel)
    return str(Path(root) / "shell" / "MuMuManager.exe")


def mumu_targets(root):
    """MuMu instances under <root>/vms (folders like MuMuPlayer-12.0-3, index 3). Named the
    way discovery names them."""
    import json
    out = []
    for vm in sorted(Path(root, "vms").glob("*/configs")):
        idx = vm.parent.name.rsplit("-", 1)[-1]
        if not idx.isdigit():
            continue
        try:
            port = int(json.loads((vm / "vm_config.json").read_text(encoding="utf-8"))
                       ["vm"]["nat"]["port_forward"]["adb"]["host_port"])
        except Exception:
            continue
        try:
            name = json.loads((vm / "extra_config.json").read_text(encoding="utf-8")).get("playerName", "")
        except Exception:
            name = ""
        if not name or name == A.MUMU_DEFAULT_NAME:
            name = f"MuMu {idx}"
        out.append(Target(name=name, kind="mumu", ident=f"{root}|{idx}", serial=f"127.0.0.1:{port}"))
    return out


def detect(conf_text=None, roots=None):
    if conf_text is None:
        try:
            conf_text = A.CONF_PATH.read_text(errors="ignore")
        except OSError:
            conf_text = ""
    found = bluestacks_targets(conf_text)
    for root in (mumu_roots() if roots is None else roots):
        found += mumu_targets(root)
    return found


def merge(saved, detected, known_names=()):
    """Detected instances plus saved shortcuts, with the switches the user set. An instance
    the app has already seen running Kingshot starts with "start" on."""
    out, seen = [], set()
    for t in detected:
        t = replace(t)
        s = saved.get(t.name)
        if s:
            t.start, t.close = bool(s.get("start")), bool(s.get("close"))
        else:
            t.start = t.name in known_names
        out.append(t)
        seen.add(t.name)
    for name, s in saved.items():
        if s.get("kind") == "shortcut" and name not in seen:
            fields = {k: s.get(k, v) for k, v in asdict(Target(name, "shortcut")).items()}
            fields["name"], fields["kind"] = name, "shortcut"
            out.append(Target(**fields))
    return out


def shortcut_process(path, runner=subprocess.run):
    """The program a shortcut starts (its exe name), used to close it again."""
    p = Path(path)
    if p.suffix.lower() == ".exe":
        return p.name
    if p.suffix.lower() == ".lnk" and os.name == "nt":
        ps = f"(New-Object -ComObject WScript.Shell).CreateShortcut('{_ps_quote(path)}').TargetPath"
        try:
            out = runner(["powershell", "-NoProfile", "-Command", ps], capture_output=True, timeout=15,
                         creationflags=NO_WINDOW).stdout.decode(errors="ignore").strip()
            if out.lower().endswith(".exe"):
                return Path(out).name
        except Exception:
            pass
    return ""


def _ps_quote(s):
    return str(s).replace("'", "''")


# ---------------------------------------------------------------- start / close
class Launcher:
    """Brings instances up for Autopilot and closes them afterwards. Thread-safe: sessions
    call ensure() from their own threads."""

    def __init__(self, targets_fn, runner=subprocess.run, popen=subprocess.Popen, sleep=time.sleep,
                 now=time.time, log=print, discover=None):
        self.targets_fn = targets_fn  # -> [Target]
        self.runner, self.popen, self.sleep, self.now = runner, popen, sleep, now
        self.log = log
        self.discover = discover or (lambda name: A.discover(only=name))
        self.before_game = None  # (name, serial) -> False to keep Kingshot closed: learned skills run first
        self.has_before_game = lambda name: False
        self.up_since = {}  # name -> time we started it (or first saw it up)
        self._boots = threading.BoundedSemaphore(MAX_PARALLEL_BOOTS)
        self._locks = {}
        self._lock = threading.Lock()

    def target(self, name):
        return next((t for t in self.targets_fn() if t.name.lower() == name.lower()), None)

    # ---- adb helpers
    def _adb(self, serial, *args, timeout=10):
        return self.runner([A.ADB_PATH, "-s", serial, *args], capture_output=True, timeout=timeout,
                           creationflags=NO_WINDOW)

    def _serials(self, t):
        """adb serials to try. BlueStacks sometimes listens one port above its config."""
        if not t.serial:
            return []
        out = [t.serial]
        if t.kind == "bluestacks" and t.serial.startswith("127.0.0.1:"):
            out.append(f"127.0.0.1:{int(t.serial.rsplit(':', 1)[1]) + 1}")
        return out

    def _booted(self, serial):
        try:
            if serial.startswith("127.0.0.1:"):
                self.runner([A.ADB_PATH, "connect", serial], capture_output=True, timeout=5,
                            creationflags=NO_WINDOW)
            out = self._adb(serial, "shell", "getprop", "sys.boot_completed", timeout=8).stdout or b""
            return out.strip() == b"1"
        except Exception:
            return False

    def _foreground(self, serial):
        try:
            return A.Device("", serial, runner=self.runner).foreground_package()
        except Exception:
            return None

    def _open_game(self, serial):
        try:
            self._adb(serial, "shell", "monkey", "-p", KINGSHOT, "-c", "android.intent.category.LAUNCHER", "1",
                      timeout=20)
        except Exception:
            pass

    def is_up(self, t):
        """Booted, by adb. Targets without a known serial: whatever discovery finds."""
        if t.serial:
            return any(self._booted(s) for s in self._serials(t))
        return bool(self.discover(t.name))

    # ---- start
    def launch(self, t, open_game=True):
        """Start the instance (returns at once; ensure() waits for it)."""
        if t.kind == "bluestacks":
            cmd = [bluestacks_player(), "--instance", t.ident]
            if open_game and not self.has_before_game(t.name):  # else _game_ready opens it after the skills
                cmd += ["--cmd", "launchApp", "--package", KINGSHOT]
            self.popen(cmd, creationflags=NO_WINDOW)
        elif t.kind == "mumu":
            root, idx = t.ident.rsplit("|", 1)
            self.runner([mumu_manager(root), "control", "-v", idx, "launch"], capture_output=True, timeout=60,
                        creationflags=NO_WINDOW)
        elif os.name == "nt":
            os.startfile(t.ident, arguments=t.args) if t.args else os.startfile(t.ident)
        else:
            self.popen([t.ident, *shlex.split(t.args)])
        self.log(f"Starting {KIND_LABELS.get(t.kind, t.kind)} instance {t.name}")

    def ensure(self, name, stop=None, force=False):
        """Make sure `name` is up with Kingshot in front. Starts it when its "start" switch is on
        (or force=True). Returns True when it's ready, False when it isn't (or isn't ours)."""
        t = self.target(name)
        if not t or not (t.start or force):
            return False
        with self._instance_lock(t):  # one start per instance; a second caller just waits for the first
            up = self._up(t, stop, open_game=True)
            if up is None:
                return False
            serial, started = up
            return self._game_ready(t, serial, stop, opened_by_us=started)

    def boot(self, name, stop=None):
        """Start `name` (whatever its switch says) and wait for Android, without opening the game.
        Returns its adb serial, "" when it's up but its serial is unknown, or None."""
        t = self.target(name)
        if not t:
            return None
        with self._instance_lock(t):
            up = self._up(t, stop, open_game=False)
        return None if up is None else (up[0] or "")

    def serial(self, name):
        """adb serial of `name` when it's booted, else None."""
        t = self.target(name)
        return next((s for s in self._serials(t) if self._booted(s)), None) if t else None

    def _instance_lock(self, t):
        with self._lock:
            return self._locks.setdefault(t.name, threading.Lock())

    def _up(self, t, stop, open_game):
        """Boot t unless it's up (call with its instance lock held). (serial, started by us), or
        None when it didn't come up."""
        serial = next((s for s in self._serials(t) if self._booted(s)), None)
        if serial or (not t.serial and self.discover(t.name)):
            self.up_since.setdefault(t.name, self.now())
            return serial, False
        with self._boots:
            if stop is not None and stop.is_set():
                return None
            try:
                self.launch(t, open_game=open_game)
            except Exception as e:
                self.log(f"Couldn't start {t.name}: {e}")
                return None
            self.up_since[t.name] = self.now()
            deadline = self.now() + BOOT_TIMEOUT
            while self.now() < deadline:
                if stop is not None and stop.is_set():
                    return None
                serial = next((s for s in self._serials(t) if self._booted(s)), None)
                if serial or (not t.serial and self.discover(t.name)):
                    break
                self.sleep(3)
            else:
                self.log(f"{t.name} didn't finish starting within {BOOT_TIMEOUT // 60} min")
                return None
        self.log(f"{t.name} is up")
        return serial, True

    def _game_ready(self, t, serial, stop, opened_by_us=False):
        if not serial:  # serial unknown: discovery only finds it with Kingshot open
            return bool(self.discover(t.name))
        if self._foreground(serial) == KINGSHOT:
            return True
        if self.before_game:
            try:
                go = self.before_game(t.name, serial)
            except Exception as e:  # noqa: BLE001
                self.log(f"Learned skills on {t.name} failed: {e}")
                go = True
            if go is False:  # a required skill (e.g. the VPN) failed: don't open the game without it
                self.log(f"Not opening Kingshot on {t.name}: a required learned skill failed")
                return False
        deadline = self.now() + 120
        tries = 0
        while self.now() < deadline:
            if stop is not None and stop.is_set():
                return False
            if self._foreground(serial) == KINGSHOT:
                self.log(f"Kingshot is open on {t.name}")
                if opened_by_us or tries:
                    self.sleep(SETTLE)  # let the loading screen finish
                return True
            if tries % 5 == 0:  # (re)open it every ~15 s; the first tap can land mid-boot
                self._open_game(serial)
            tries += 1
            self.sleep(3)
        self.log(f"Kingshot didn't open on {t.name}")
        return False

    # ---- close
    def close(self, name):
        t = self.target(name)
        if not t:
            return False
        try:
            if t.kind == "bluestacks":
                ports = ",".join(s.rsplit(":", 1)[1] for s in self._serials(t)) or "0"
                ps = (f"$t='{_ps_quote(t.name)}'; $ports=@({ports});"
                      "$p = Get-Process HD-Player -ErrorAction SilentlyContinue | Where-Object {"
                      " $_.MainWindowTitle -eq $t -or (Get-NetTCPConnection -State Listen -OwningProcess $_.Id"
                      " -ErrorAction SilentlyContinue | Where-Object { $ports -contains $_.LocalPort }) };"
                      "foreach ($x in $p) { $null = $x.CloseMainWindow();"
                      " if (-not $x.WaitForExit(15000)) { Stop-Process -Id $x.Id -Force } }")
                self.runner(["powershell", "-NoProfile", "-Command", ps], capture_output=True, timeout=60,
                            creationflags=NO_WINDOW)
            elif t.kind == "mumu":
                root, idx = t.ident.rsplit("|", 1)
                self.runner([mumu_manager(root), "control", "-v", idx, "shutdown"], capture_output=True,
                            timeout=60, creationflags=NO_WINDOW)
            elif t.serial.startswith("emulator-"):  # Android Studio emulator (e.g. Kingshot Player)
                self._adb(t.serial, "emu", "kill", timeout=20)
            elif t.proc:
                self.runner(["taskkill", "/IM", t.proc, "/T"], capture_output=True, timeout=20,
                            creationflags=NO_WINDOW)
                self.sleep(10)
                self.runner(["taskkill", "/IM", t.proc, "/T", "/F"], capture_output=True, timeout=20,
                            creationflags=NO_WINDOW)
            elif t.serial:
                self._adb(t.serial, "shell", "reboot", "-p", timeout=20)
            else:
                self.log(f"Don't know how to close {t.name}: set its process in Settings")
                return False
        except Exception as e:
            self.log(f"Couldn't close {t.name}: {e}")
            return False
        self.up_since.pop(t.name, None)
        self.log(f"Closed {t.name}")
        return True


def due_to_close(t, *, running, busy, bots_using, sessions_done, next_due, up_since, now, idle=60, gap=15 * 60):
    """Whether Autopilot should close instance t now: its switch is on, Autopilot runs, nothing
    is using it, it had a session since it came up, and nothing on it is due for a while."""
    if not (t.close and running) or t.name in busy or t.name in bots_using:
        return False
    done = sessions_done.get(t.name)
    if done is None or done < up_since.get(t.name, 0) or now - done < idle:
        return False
    return next_due is not None and next_due - now > gap
