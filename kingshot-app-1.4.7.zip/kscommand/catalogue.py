"""Character catalogue: every character on an instance's account, with its player ID,
kingdom, Town Center / Truegold level, power and name.

"Learn all characters" walks the game's own switch path for each character in turn:
avatar -> Governor Profile (read ID, name, kingdom) -> Settings -> Characters (read every row's
kingdom, name, level, power) -> tap the next row -> Login Confirm. When every character has
been read, the one that was logged in at the start is logged in again.

Entries are keyed by player ID, so a renamed character updates its old entry (the old name
is kept under "aka") instead of showing up twice. Screen reading only: screenshots + taps."""
import json
import re
import threading
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path

import cv2

from autopilot import characters as CH
from kscommand import core

PATH = core.ROOT / "characters.json"
PROFILE_PANEL = (0.62, 0.94, 180)  # top and bottom (fraction of height), left x of the info panel
POWER_MATCH = CH.POWER_MATCH
# Typed-in values a later Learn never overwrites. Level, power and alliance change in the game,
# so a Learn updates those; a typed name stays until the game shows a genuinely new name.
KEEP_MANUAL = ("player_id", "kingdom", "instance")


# ---------------------------------------------------------------- entries
@dataclass
class Entry:
    player_id: str  # "" until the profile has been read
    name: str
    tag: str = ""
    kingdom: int | None = None
    tc: int = 0  # Town Center level
    tg: int = 0  # Truegold level (0 = not Truegold yet)
    power: int = 0
    instance: str = ""
    seen: str = ""  # local time of the last read, "YYYY-MM-DD HH:MM"
    aka: list = field(default_factory=list)  # earlier names, oldest first
    manual: list = field(default_factory=list)  # fields typed in by hand (see KEEP_MANUAL)

    @property
    def level(self):
        if self.tg:
            return f"TG {self.tg}"
        return f"TC {self.tc}" if self.tc else ""

    @property
    def label(self):
        tag = f"[{self.tag}]" if self.tag else ""
        return f"{tag}{self.name}" + (f" #{self.kingdom}" if self.kingdom is not None else "")


def load(path=None):
    path = Path(path or PATH)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    names = Entry.__dataclass_fields__
    return [Entry(**{k: v for k, v in d.items() if k in names}) for d in data.get("characters", [])]


_lock = threading.Lock()


def save(entries, path=None):
    path = Path(path or PATH)
    with _lock:
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps({"characters": [asdict(e) for e in entries]}, indent=2, ensure_ascii=False),
                       encoding="utf-8")
        tmp.replace(path)


def find(entries, read):
    """The stored entry `read` is: same player ID; failing that (ID not read yet) the same
    instance, kingdom and name, or a current/earlier name; failing that the same instance and
    kingdom with power within 10% (a rename seen before its ID was)."""
    if read.player_id:
        hit = next((e for e in entries if e.player_id == read.player_id), None)
        if hit:
            return hit
    pool = [e for e in entries if e.instance == read.instance and e.kingdom == read.kingdom
            and (not read.player_id or not e.player_id or "player_id" in e.manual)]
    for e in pool:
        if any(CH.same_name(read.name, n) for n in [e.name, *e.aka]):
            return e
    if read.power:
        near = [e for e in pool if e.power and abs(e.power - read.power) <= e.power * POWER_MATCH]
        if len(near) == 1:
            return near[0]
    return None


_LOOKALIKE = str.maketrans({"0": "o", "1": "l", "i": "l", "|": "l", "5": "s", "8": "b"})


def renamed(old, new):
    """True when `new` is really another name, not the same one read slightly differently.
    (The Autopilot matcher is looser on purpose: there a near miss should still find the row.)"""
    import difflib
    a = CH._squash(old).translate(_LOOKALIKE).replace("rn", "m")
    b = CH._squash(new).translate(_LOOKALIKE).replace("rn", "m")
    if a == b:
        return False
    return abs(len(a) - len(b)) > 1 or difflib.SequenceMatcher(None, a, b).ratio() < 0.9


def upsert(entries, read):
    """Merge one read into the catalogue. Returns (entry, what) with what one of
    "new", "renamed" or "updated"; a rename keeps the old name in entry.aka."""
    e = find(entries, read)
    if e is None:
        entries.append(read)
        return read, "new"
    what = "updated"
    if "name" in e.manual and read.name and any(not renamed(n, read.name) for n in [e.name, *e.aka]):
        pass  # the game still shows the name that was corrected by hand: keep the typed one
    elif read.name and e.name and renamed(e.name, read.name):
        if "name" in e.manual:
            e.manual.remove("name")
        if e.name not in e.aka:
            e.aka.append(e.name)
        e.aka = [n for n in e.aka if renamed(n, read.name)]
        e.name, what = read.name, "renamed"
    elif read.name and "name" not in e.manual:
        e.name = read.name  # same name, maybe a cleaner read
    for k in ("player_id", "tag", "tc", "tg", "power", "instance", "seen"):
        v = getattr(read, k)
        if not v or (k in e.manual and k in KEEP_MANUAL):
            continue
        setattr(e, k, v)
        if k in e.manual:
            e.manual.remove(k)
    if read.kingdom is not None and "kingdom" not in e.manual:
        e.kingdom = read.kingdom
    return e, what


def parse_level(text):
    """'TG 8' / 'tg8' -> (30, 8); 'TC 22' / '22' -> (22, 0); '' -> (0, 0). ValueError otherwise."""
    t = text.strip().upper().replace(" ", "")
    if not t:
        return 0, 0
    m = re.fullmatch(r"(TG|TC)?(\d{1,2})", t)
    if not m:
        raise ValueError("level looks like TC 22 or TG 8")
    n = int(m.group(2))
    if m.group(1) == "TG":
        if not 1 <= n <= 20:
            raise ValueError("Truegold levels go from TG 1 up")
        return 30, n
    if not 1 <= n <= 30:
        raise ValueError("Town Center levels go from 1 to 30 (use TG for Truegold)")
    return n, 0


def edit(entries, e, **values):
    """Apply values typed in by hand to entry `e` (or a new entry when e is None, added to
    `entries`). Text values are trimmed; player_id must be digits and not used by another
    character; level is text like "TG 8". Returns the entry. Raises ValueError with a message
    for the person on bad input. Changed fields are remembered in e.manual."""
    clean = {}
    for k, v in values.items():
        if k == "player_id":
            v = re.sub(r"\s", "", str(v or ""))
            if v and not v.isdigit():
                raise ValueError("the player ID is digits only")
            other = next((x for x in entries if v and x.player_id == v and x is not e), None)
            if other:
                raise ValueError(f"{other.name} already has player ID {v}")
        elif k == "level":
            clean["tc"], clean["tg"] = parse_level(str(v or ""))
            continue
        elif k in ("kingdom", "power"):
            v = str(v or "").strip().lstrip("#").replace(",", "").replace(" ", "")
            if v and not v.isdigit():
                raise ValueError(f"{k} is a number")
            v = int(v) if v else (None if k == "kingdom" else 0)
        elif k == "aka":
            v = [n.strip() for n in (v if isinstance(v, list) else str(v or "").split(",")) if n.strip()]
        else:
            v = str(v or "").strip()
        clean[k] = v
    if e is None:
        if not clean.get("name"):
            raise ValueError("give the character a name")
        e = Entry(player_id="", name="")
        entries.append(e)
    if "name" in clean and not clean["name"]:
        raise ValueError("the name can't be empty")
    for k, v in clean.items():
        old = getattr(e, k)
        if old == v:
            continue
        if k == "name" and old and old not in e.aka and old not in clean.get("aka", e.aka):
            e.aka.append(old)  # a Learn still recognises the character by what the game showed
        setattr(e, k, v)
        if k != "aka" and k not in e.manual:
            e.manual.append(k)
    e.aka = [n for n in e.aka if n != e.name]
    return e


# ---------------------------------------------------------------- reading screens
def _ocr_block(img):
    g = cv2.cvtColor(cv2.resize(img, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC), cv2.COLOR_BGR2GRAY)
    out = []
    for psm in (6, 11):
        try:
            out.append(CH.timer.pytesseract.image_to_string(g, config=f"--psm {psm}"))
        except Exception:
            pass
    return "\n".join(out)


def parse_profile(text):
    """{'id', 'kingdom', 'name', 'tag'} from the Governor Profile panel's OCR text."""
    out = {"id": "", "kingdom": None, "name": "", "tag": ""}
    m = re.search(r"\bI[Dd]\s*[:;.]?\s*(\d{5,12})\b", text)
    if m:
        out["id"] = m.group(1)
    for m in re.finditer(r"(\w*)\s*Kingdom\s*[:;.]?\s*#\s*(\d{1,5})", text):
        if m.group(1).lower() != "initial":
            out["kingdom"] = int(m.group(2))
            break
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    for i, ln in enumerate(lines):
        if re.match(r"I[Dd]\s*[:;.]?\s*\d", ln) and i > 0:
            out["tag"], out["name"] = CH.split_tag(clean_name(lines[i - 1]))
            break
    return out


def clean_name(text):
    """Drop OCR'd icons after a name (the edit pencil reads as '[4%' or '(%')."""
    words = text.split()
    while len(words) > 1 and not re.fullmatch(r"[\w\-.'!?~]+", words[-1].lstrip("[").rstrip("]")):
        words.pop()
    while len(words) > 1 and re.search(r"[%()|{}<>=]", words[-1]):
        words.pop()
    return " ".join(words)


def read_profile(img):
    h = img.shape[0]
    top, bottom, left = PROFILE_PANEL
    return parse_profile(_ocr_block(img[int(h * top):int(h * bottom), left:]))


def tidy(list_name, profile_name):
    """The list's OCR sometimes adds a stray letter for a badge after the name ("Grandfell m").
    Trailing short words that the profile doesn't show are dropped."""
    words = list_name.split()
    if not profile_name:
        return list_name
    prof = profile_name.lower()
    while len(words) > 1 and len(words[-1]) <= 2 and words[-1].lower() not in prof.split():
        words.pop()
    return " ".join(words)


def same_character(row, prof):
    """False when the profile clearly belongs to someone else (other kingdom or name)."""
    if not prof:
        return True
    if prof.get("kingdom") is not None and row.kingdom is not None and prof["kingdom"] != row.kingdom:
        return False
    return not prof.get("name") or CH.name_score(prof["name"], row.name) >= CH.MATCH \
        or CH.name_score(row.name, prof["name"]) >= CH.MATCH


# ---------------------------------------------------------------- learning one instance
class Stopped(Exception):
    pass


class Learner:
    """Reads every character on one instance. `stop` is a threading.Event; `progress(done,
    total, text)` is called as it goes. Returns the list of Entries read."""

    def __init__(self, device, vision=None, instance="", log=print, progress=None, stop=None,
                 sleep=None, now=None, read=None, profile=None):
        from intel_adb.vision import Vision
        self.d = device
        self.v = vision or Vision(CH.TEMPLATE_DIR)
        self.instance = instance or getattr(device, "name", "")
        self.log = log
        self.progress = progress or (lambda done, total, text: None)
        self.stop = stop or threading.Event()
        self.sleep = sleep or self.stop.wait  # a wait that ends the moment Stop is pressed
        self.now = now or (lambda: datetime.now().strftime("%Y-%m-%d %H:%M"))
        self.read = read or (lambda img, v, carry=None: CH.read_rows(img, v, carry, details=True))
        self.read_profile = profile or read_profile
        self.sw = CH.Switcher(device, self.v, sleep=self._sleep, log=log, read=read or CH.read_rows)
        self.final_active = None  # Row logged in when learning ended

    def _sleep(self, s):
        self.sleep(s)
        self._check()

    def _check(self):
        if self.stop.is_set():
            raise Stopped()

    # ---- screens
    def open_profile(self):
        self._check()
        self.d.tap(*CH.AVATAR)
        return self.sw.wait_for("profile_title")

    def profile_to_list(self):
        self._check()
        self.d.tap(*CH.SETTINGS_BUTTON)
        if self.sw.wait_for("settings_title") is None:
            return None
        self.d.tap(*CH.CHARACTERS_BUTTON)
        return self.sw.wait_for("characters_title")

    def read_list(self, img, scrolls=8):
        """Every row on the list, top to bottom (scrolls down, then back to the top)."""
        found, carry, same = [], None, 0
        for i in range(scrolls + 1):
            self._check()
            rows = self.read(img, self.v, carry)
            new = [r for r in rows if r.name and not any(
                CH.same_name(r.name, f.name) and r.kingdom == f.kingdom for f in found)]
            for r in rows:  # a row seen again may be the active one read better this time
                for f in found:
                    if r.active and CH.same_name(r.name, f.name) and r.kingdom == f.kingdom:
                        f.active = True
            found += new
            same = same + 1 if not new else 0
            if rows:
                carry = rows[-1].kingdom
            if same >= 2 or i == scrolls:
                break
            (x1, y1), (x2, y2) = CH.LIST_SWIPE
            self.d.swipe(x1, y1, x2, y2)
            self._sleep(0.8)
            img = self.d.screencap()
        (x1, y1), (x2, y2) = CH.LIST_SWIPE
        for _ in range(min(i, scrolls)):  # back to the top for the next find_row
            self.d.swipe(x2, y2, x1, y1)
            self._sleep(0.4)
        return found

    def login(self, row):
        """From the open Characters list: log in as `row`. True once the game has settled."""
        hit, _img = self.sw.find_row(self.d.screencap(), row.name, row.kingdom, tag=row.tag, power=row.power)
        if hit is None:
            self.log(f"characters: {row.name} #{row.kingdom} not found on the list")
            return False
        self.d.tap(CH.ROW_TAP_X, hit.y)
        if self.sw.wait_for("login_title", timeout=4) is None:
            self.d.back()  # it was the active one after all: back out to the city
            return self.sw.settle(timeout=30)
        self._check()
        self.d.tap(*CH.LOGIN_CONFIRM)
        self._sleep(3)
        return self.sw.settle()

    def leave_list(self):
        for _ in range(3):  # Characters -> Settings -> Profile -> home
            self.d.back()
            self._sleep(0.8)

    # ---- the whole walk
    def entry(self, row, prof):
        name = tidy(row.name, prof.get("name", "")) if row else prof.get("name", "")
        return Entry(player_id=prof.get("id", ""), name=name or prof.get("name", ""),
                     tag=(row.tag if row else "") or prof.get("tag", ""),
                     kingdom=row.kingdom if row and row.kingdom is not None else prof.get("kingdom"),
                     tc=row.tc if row else 0, tg=row.tg if row else 0, power=row.power if row else 0,
                     instance=self.instance, seen=self.now())

    def run(self, return_home=True):
        read = []
        img = self.open_profile()
        if img is None:
            raise RuntimeError("the Governor Profile didn't open (is Kingshot on its city or map screen?)")
        prof = self.read_profile(img)
        lst = self.profile_to_list()
        if lst is None:
            raise RuntimeError("couldn't open Settings -> Characters")
        rows = self.read_list(lst)
        if not rows:
            raise RuntimeError("no characters found on the Characters list")
        start = next((r for r in rows if r.active), None)
        if start is None:  # no highlight seen: match the profile's name
            start = next((r for r in rows if prof["name"] and CH.same_name(r.name, prof["name"])
                          and (prof["kingdom"] is None or r.kingdom == prof["kingdom"])), None)
        total = len(rows)
        self.log(f"characters: {total} on {self.instance}" + (f", logged in: {start.name}" if start else ""))
        if start:
            read.append(self.entry(start, prof))
            self.progress(1, total, f"{start.name}: ID {prof['id'] or '?'}")
        todo = [r for r in rows if r is not start]
        current = start
        for row in todo:
            self._check()
            self.progress(len(read), total, f"switching to {row.name} #{row.kingdom}")
            if not self.login(row):
                self.log(f"characters: couldn't log in as {row.name} - kept what the list shows")
                read.append(self.entry(row, {}))
                lst = self._reopen_list()
                if lst is None:
                    break
                continue
            current = row
            img = self.open_profile()
            prof = self.read_profile(img) if img is not None else {}
            if prof.get("id") and any(e.player_id == prof["id"] for e in read):
                self.log(f"characters: still on an earlier character after switching to {row.name} - "
                         f"ID not recorded")
                prof = {}
            elif not same_character(row, prof):
                self.log(f"characters: the profile shows {prof.get('name')} #{prof.get('kingdom')}, "
                         f"not {row.name} #{row.kingdom} - ID not recorded")
                prof = {}
            if not prof.get("id"):
                self.log(f"characters: {row.name}: couldn't read the player ID")
            read.append(self.entry(row, prof))
            self.progress(len(read), total, f"{row.name}: ID {prof.get('id') or '?'}")
            if row is todo[-1]:
                break
            if img is None or self.profile_to_list() is None:
                if self._reopen_list() is None:
                    break
        self.final_active = current
        if return_home and start is not None and current is not start and len(todo):
            self.progress(len(read), total, f"logging {start.name} back in")
            if self._reopen_list() is not None and self.login(start):
                self.final_active = start
            else:
                self.log(f"characters: couldn't log {start.name} back in")
        elif current is start:
            self.leave_list()
        else:
            self.d.back()  # close the profile
        missing = [r for r in rows if not any(CH.same_name(r.name, e.name) and r.kingdom == e.kingdom
                                              for e in read)]
        for r in missing:
            read.append(self.entry(r, {}))
        return read

    def _reopen_list(self):
        self.sw.settle(timeout=30)
        if self.open_profile() is None:
            return None
        return self.profile_to_list()


def learn(device, instance="", path=None, log=print, progress=None, stop=None, **kw):
    """Learn one instance and merge it into the catalogue file. Returns (entries read,
    {"new": [...], "renamed": [(old, new)], "updated": [...]}, final active Row)."""
    lr = Learner(device, instance=instance, log=log, progress=progress, stop=stop, **kw)
    read = lr.run()
    with _lock:
        entries = load(path)
    changes = {"new": [], "renamed": [], "updated": []}
    for r in read:
        old = find(entries, r)
        old_name = old.name if old else ""
        e, what = upsert(entries, r)
        if what == "renamed":
            changes["renamed"].append((old_name, e.name))
            log(f"characters: renamed {old_name} -> {e.name} (ID {e.player_id or '?'})")
        else:
            changes[what].append(e.name)
    save(entries, path)
    return read, changes, lr.final_active


# ---------------------------------------------------------------- Autopilot link
def sync_autopilot(settings, entries, active=None):
    """Bring Autopilot's characters up to date with the catalogue: renames (matched by
    instance + kingdom + a current or earlier name), alliance tag and power. The placeholder
    "Logged-in character" of an instance becomes the character that's logged in there.
    Returns the number of characters changed."""
    changed = 0
    for ch in settings.characters:
        e = None
        if ch.kingdom is None and ch.name == "Logged-in character" and active is not None:
            if active.instance == ch.instance:
                e = active
        elif ch.kingdom is not None:
            e = next((x for x in entries if x.instance == ch.instance and x.kingdom == ch.kingdom
                      and any(CH.same_name(ch.name, n) for n in [x.name, *x.aka])), None)
        if e is None:
            continue
        before = (ch.name, ch.kingdom, ch.tag, ch.power)
        ch.name, ch.kingdom = e.name, e.kingdom
        ch.tag = e.tag or ch.tag
        ch.power = e.power or ch.power
        changed += before != (ch.name, ch.kingdom, ch.tag, ch.power)
    return changed


def in_autopilot(settings, e):
    return any(c.instance == e.instance and c.kingdom == e.kingdom and CH.same_name(c.name, e.name)
               for c in settings.characters)


def to_csv(entries):
    import csv
    import io
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["Player ID", "Name", "Alliance", "Kingdom", "Level", "Power", "Instance", "Last seen",
                "Earlier names"])
    for e in entries:
        w.writerow([e.player_id, e.name, e.tag, e.kingdom if e.kingdom is not None else "", e.level, e.power,
                    e.instance, e.seen, "; ".join(e.aka)])
    return buf.getvalue()
