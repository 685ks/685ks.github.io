"""Build a bot: click-together blocks that run one after another on each instance, saved as
templates. One template can be the startup bot: it runs when the app opens, before Autopilot.

A template (saved in app\\builder.json):

    {"id": "t1", "name": "Morning start", "instances": [],   # empty = every instance set to Start
     "filter": {"match": "all", "rules": [{"field": "level", "op": "<", "value": "TC 25"}]},
     "blocks": [{"id": "b1", "type": "start_instance"},
                {"id": "b2", "type": "vpn_connect", "tries": 3, "retry_wait": 10, "on_fail": "stop"},
                {"id": "b3", "type": "vpn_unique", "on_fail": "next"},
                {"id": "b4", "type": "job", "params": {"job": "intel"}}]}

Each block either works or fails. "tries" runs it again on a failure (waiting "retry_wait" s
in between). Then "on_ok" / "on_fail" says what's next: "next" (the block below), "stop"
(end this instance's run as failed), "finish" (end it as done) or "goto:<block id>" (jump, e.g.
back up to retry a whole stretch). A run gives up after MAX_STEPS blocks so a jump can't loop
for ever.

A filter (smart filter) picks the accounts a template is for, from the Characters catalogue:
level (TC 1..30, then TG 1..), kingdom, alliance, power, name, instance. With a filter the
template runs once per matching account on each instance, logging that account in before its
first in-game block; instances without a matching account are skipped. Without one it runs
once per instance for whoever is logged in. The startup list (data["startup"]) runs those
templates in order on every instance, then starts Autopilot when data["then_autopilot"] is on.

The blocks reuse what the app already has: the emulator launcher, the Proton VPN steps of the
learned-skills runner (connect with Android's OK dialog, a different server per instance), the
Autopilot jobs (intel, claim, ...) with the instance's own Autopilot settings, and installed
learned skills."""
import copy
import json
import re
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path

from kscommand import core
from kscommand import learned as L

PATH = core.ROOT / "builder.json"
KINGSHOT = "com.run.tower.defense"
PROTON = "ch.protonvpn.android"
MAX_STEPS = 200
ROUTES = ("next", "stop", "finish")


# ---------------------------------------------------------------- the blocks
@dataclass
class Param:
    key: str
    label: str
    kind: str  # "int" | "text" | "bool" | "choice" | "job" | "skill"
    default: object
    lo: int = 0
    hi: int = 999
    choices: list = field(default_factory=list)


@dataclass
class Block:
    type: str
    title: str
    group: str
    about: str
    params: list = field(default_factory=list)
    tries: int = 1  # defaults for a new block of this type
    retry_wait: int = 5
    on_fail: str = "stop"
    device: bool = True  # needs the instance running


JOB_TITLES = {"intel": "Do intels", "claim": "Claim rewards", "rewards": "Quests and free rewards",
              "train": "Train troops", "research": "Academy research", "hunt": "Hunt beasts",
              "gather": "Gather resources", "terrors": "Terror rallies", "alliance": "Alliance help",
              "city": "City chores", "build": "Building upgrades", "arena": "Arena", "blizzard": "Blizzard Brawl"}

BLOCKS = [
    Block("start_instance", "Activate instance", "Instance",
          "Starts the emulator instance (BlueStacks, MuMu or your shortcut) and waits for Android to boot, "
          "without opening the game. Already running: carries on.", device=False),
    Block("close_instance", "Close instance", "Instance", "Closes the emulator instance.", device=False),
    Block("open_proton", "Open Proton", "Proton VPN", "Opens the Proton VPN app.",
          [Param("missing_ok", "No Proton on this instance counts as done", "bool", True)]),
    Block("vpn_connect", "Connect Proton", "Proton VPN",
          "Presses Connect (and Android's one-time OK) until the VPN is up. Already connected: done at once.",
          [Param("timeout", "Give up after (s)", "int", 60, 10, 600)], tries=3, retry_wait=10),
    Block("vpn_unique", "Unique server check", "Proton VPN",
          "Reads the server (e.g. Switzerland #11). If another instance is on the same one, presses Change "
          "server until they differ. Fails when it can't get a free server.",
          [Param("changes", "Change server up to (times)", "int", 4, 1, 10)], on_fail="next"),
    Block("vpn_check", "VPN connected?", "Proton VPN", "Works when a VPN is connected right now, fails when not."),
    Block("open_kingshot", "Open Kingshot", "Kingshot",
          "Opens Kingshot and waits until it's in front, then lets the loading screen finish.",
          [Param("skills", "Run the 'Before Kingshot opens' learned skills first", "bool", False),
           Param("settle", "Loading time (s)", "int", 25, 0, 180)]),
    Block("kingshot_check", "Kingshot open?", "Kingshot", "Works when Kingshot is in front, fails when not."),
    Block("job", "Autopilot job", "Kingshot",
          "Runs one Autopilot job once, with this instance's Autopilot settings for it.",
          [Param("job", "Job", "job", "intel")]),
    Block("skill", "Learned skill", "Kingshot", "Runs one of your learned skills (from Teacher lessons).",
          [Param("skill", "Skill", "skill", "")]),
    Block("open_app", "Open an app", "Android", "Opens any app by its package name.",
          [Param("package", "Package", "text", PROTON)]),
    Block("close_app", "Close an app", "Android", "Force-closes an app.",
          [Param("package", "Package", "text", KINGSHOT)]),
    Block("back", "Press Back", "Android", "Presses Android's Back button."),
    Block("home", "Go to home screen", "Android", "Presses Android's Home button."),
    Block("wait", "Wait", "Other", "Waits a while.", [Param("seconds", "Seconds", "int", 10, 1, 3600)],
          device=False),
    Block("message", "Send a message", "Other", "Writes a line to the activity feed (and Telegram, when set up).",
          [Param("text", "Message", "text", "Ready")], device=False),
]
BY_TYPE = {b.type: b for b in BLOCKS}
GROUPS = ["Instance", "Proton VPN", "Kingshot", "Android", "Other"]


def title(block):
    """What a block in a template is called: the job/skill name for those blocks."""
    kind = BY_TYPE.get(block.get("type"))
    if not kind:
        return block.get("type", "?")
    p = block.get("params") or {}
    if kind.type == "job":
        return JOB_TITLES.get(p.get("job"), kind.title)
    if kind.type == "skill" and p.get("skill"):
        sk = next((s for s in L.installed().get("skills", []) if s.get("id") == p["skill"]), None)
        return sk.get("title", p["skill"]) if sk else p["skill"]
    return kind.title


def new_block(btype, existing=(), **params):
    kind = BY_TYPE[btype]
    used = {b.get("id") for b in existing}
    n = 1
    while f"b{n}" in used:
        n += 1
    p = {x.key: x.default for x in kind.params}
    p.update(params)
    return {"id": f"b{n}", "type": btype, "params": p, "tries": kind.tries, "retry_wait": kind.retry_wait,
            "on_ok": "next", "on_fail": kind.on_fail}


def problems(tpl):
    """What's wrong with a template, as sentences (empty when it can run)."""
    out = []
    blocks = tpl.get("blocks") or []
    if not blocks:
        out.append("Add at least one block.")
    ids = {b.get("id") for b in blocks}
    for i, b in enumerate(blocks, 1):
        if b.get("type") not in BY_TYPE:
            out.append(f"Block {i}: unknown block {b.get('type')!r}.")
            continue
        for key in ("on_ok", "on_fail"):
            r = b.get(key, "next")
            if r not in ROUTES and not (r.startswith("goto:") and r[5:] in ids):
                out.append(f"Block {i} ({title(b)}): it jumps to a block that isn't there any more.")
        if b["type"] == "skill" and not (b.get("params") or {}).get("skill"):
            out.append(f"Block {i}: pick which learned skill to run.")
    for r in (tpl.get("filter") or {}).get("rules", []):
        why = rule_problem(r)
        if why:
            out.append(why)
    return out


# ---------------------------------------------------------------- smart filters
FIELDS = {"level": "Level", "kingdom": "Kingdom", "alliance": "Alliance", "power": "Power", "name": "Name",
          "instance": "Instance"}
NUMBER_OPS = ["<", "<=", "=", ">=", ">", "!="]
TEXT_OPS = ["is", "is not", "contains"]
OP_WORDS = {"<": "below", "<=": "at most", "=": "is", ">=": "at least", ">": "above", "!=": "isn't"}


def ops_for(field_):
    return TEXT_OPS if field_ in ("alliance", "name", "instance") else NUMBER_OPS


def level_rank(value):
    """'TC 25' -> 25, 'TG 1' -> 31 (Truegold comes after TC 30), '25' -> 25, else None."""
    m = re.fullmatch(r"\s*(tc|tg|town center|truegold)?\s*(\d+)\s*", str(value), re.I)
    if not m:
        return None
    n = int(m.group(2))
    return 30 + n if (m.group(1) or "").lower() in ("tg", "truegold") else n


def entry_rank(e):
    return 30 + e.tg if getattr(e, "tg", 0) else getattr(e, "tc", 0) or None


def parse_power(value):
    """'50M', '1.2b', '350k', '12,345,678' -> int, else None."""
    m = re.fullmatch(r"\s*([\d.,]+)\s*([kmb]?)\s*", str(value), re.I)
    if not m:
        return None
    try:
        n = float(m.group(1).replace(",", ""))
    except ValueError:
        return None
    return int(n * {"": 1, "k": 1e3, "m": 1e6, "b": 1e9}[m.group(2).lower()])


def _compare(have, op, want):
    if have is None or want is None:
        return False
    return {"<": have < want, "<=": have <= want, "=": have == want, ">=": have >= want, ">": have > want,
            "!=": have != want}.get(op, False)


def rule_matches(rule, e):
    f, op, v = rule.get("field"), rule.get("op"), rule.get("value", "")
    if f == "level":
        return _compare(entry_rank(e), op, level_rank(v))
    if f == "power":
        return _compare(e.power or None, op, parse_power(v))
    if f == "kingdom":
        try:
            return _compare(e.kingdom, op, int(str(v).strip().lstrip("#")))
        except ValueError:
            return False
    have = {"alliance": e.tag, "name": e.name, "instance": e.instance}.get(f, "") or ""
    have, want = have.strip().lower(), str(v).strip().lower()
    if f == "name":  # earlier names count too
        names = [have] + [a.lower() for a in getattr(e, "aka", [])]
        hit = any(want in n for n in names) if op == "contains" else want in names
        return hit if op != "is not" else not hit
    if op == "contains":
        return want in have
    return (have == want) if op == "is" else (have != want)


def matches(flt, e):
    rules = [r for r in (flt or {}).get("rules", []) if r.get("field") in FIELDS]
    if not rules:
        return True
    hits = (rule_matches(r, e) for r in rules)
    return any(hits) if (flt or {}).get("match") == "any" else all(hits)


def has_filter(tpl):
    return bool([r for r in (tpl.get("filter") or {}).get("rules", []) if r.get("field") in FIELDS])


def accounts(tpl, instance, entries):
    """Catalogue entries on `instance` the template is for (in catalogue order)."""
    return [e for e in entries if e.instance == instance and matches(tpl.get("filter"), e)]


def describe(flt):
    """'Level below TC 25 and Alliance is not ABC' (empty without rules)."""
    parts = []
    for r in (flt or {}).get("rules", []):
        if r.get("field") not in FIELDS:
            continue
        op = OP_WORDS.get(r.get("op"), r.get("op"))
        parts.append(f"{FIELDS[r['field']]} {op} {r.get('value', '')}".strip())
    return f" {'or' if (flt or {}).get('match') == 'any' else 'and'} ".join(parts)


def rule_problem(rule):
    f, v = rule.get("field"), rule.get("value", "")
    if f == "level" and level_rank(v) is None:
        return f"Level '{v}' isn't a level: write it like TC 25 or TG 1."
    if f == "power" and parse_power(v) is None:
        return f"Power '{v}' isn't a number: write it like 50M or 350k."
    if f == "kingdom" and not str(v).strip().lstrip("#").isdigit():
        return f"Kingdom '{v}' isn't a number."
    return None


# ---------------------------------------------------------------- templates on disk
def starter():
    """The example from Ks's request: activate, Proton with retries, unique server, Kingshot, intels."""
    blocks = []
    for btype, params, extra in (("start_instance", {}, {}),
                                 ("open_proton", {}, {}),
                                 ("vpn_connect", {}, {"tries": 3}),
                                 ("vpn_unique", {}, {"on_fail": "next"}),
                                 ("open_kingshot", {}, {}),
                                 ("job", {"job": "intel"}, {"on_fail": "next"})):
        b = new_block(btype, blocks, **params)
        b.update(extra)
        blocks.append(b)
    return {"id": "t1", "name": "Morning start", "instances": [], "filter": {"match": "all", "rules": []},
            "blocks": blocks}


def load(path=None):
    path = Path(path or PATH)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        data = None
    if not isinstance(data, dict) or not isinstance(data.get("templates"), list):
        data = {"templates": [starter()], "startup": [], "then_autopilot": True}
    if not isinstance(data.get("startup"), list):
        data["startup"] = [data["startup"]] if data.get("startup") else []
    data.setdefault("then_autopilot", True)
    for t in data["templates"]:
        t.setdefault("filter", {"match": "all", "rules": []})
        t.setdefault("instances", [])
    return data


def save(data, path=None):
    path = Path(path or PATH)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    tmp.replace(path)


def new_template(data, name="New bot"):
    used = {t["id"] for t in data["templates"]}
    n = 1
    while f"t{n}" in used:
        n += 1
    tpl = {"id": f"t{n}", "name": name, "instances": [], "filter": {"match": "all", "rules": []}, "blocks": []}
    data["templates"].append(tpl)
    return tpl


def duplicate(data, tpl):
    copy_ = new_template(data, f"{tpl['name']} (copy)")
    copy_.update({k: copy.deepcopy(v) for k, v in tpl.items() if k not in ("id", "name")})
    return copy_


def find(data, tid):
    return next((t for t in data["templates"] if t["id"] == tid), None)


# ---------------------------------------------------------------- running
class Failed(Exception):
    pass


class Env:
    """What the blocks need from the app. The Hub fills these in; tests pass fakes."""

    def __init__(self, launcher=None, log=print, notify=None, before_game=None, job_params=None, record=None,
                 device_fn=None, discover=None, sleep=None, clock=time.monotonic, switch=None, active=None):
        self.launcher = launcher
        self.log = log
        self.notify = notify or (lambda text: None)
        self.before_game = before_game  # (name, serial) -> False when a required skill failed
        self.job_params = job_params or (lambda name, job, account: {})
        self.record = record or (lambda name, job, n, account: None)
        self.switch = switch or switch_account  # (device, entry, log) -> True when that account is logged in
        self.active = {} if active is None else active  # instance -> key of the account logged in (Autopilot's)
        self.device_fn = device_fn
        self.discover = discover  # name -> serial or None (instances with Kingshot open)
        self.sleep = sleep
        self.clock = clock


class Run:
    """One template on one instance. status(block id, state, text) reports progress:
    state is running | ok | fail."""

    def __init__(self, tpl, name, env, serial=None, stop=None, status=None, account=None):
        self.tpl, self.name, self.env = tpl, name, env
        self.account = account  # catalogue Entry the run is for (smart filter), or None: whoever is logged in
        self.serial = serial
        self.stop = stop or threading.Event()
        self.status = status or (lambda bid, state, text: None)
        self._dev = None

    def log(self, text):
        who = f" · {self.account.label}" if self.account else ""
        self.env.log(f"[{self.name}{who}] {text}")

    def ensure_account(self):
        """Log the run's account in (once) before an in-game block."""
        e = self.account
        if e is None or self.env.active.get(self.name) == account_key(self.name, e):
            return
        self.log(f"logging in as {e.label}")
        if not self.env.switch(self.device(), e, self.log):
            self.env.active.pop(self.name, None)
            raise Failed(f"couldn't log in as {e.label}")
        self.env.active[self.name] = account_key(self.name, e)

    def wait(self, seconds):
        if self.env.sleep:
            self.env.sleep(seconds)
        elif self.stop.wait(max(0.0, seconds)):
            raise L.Stop(False, "stopped")
        if self.stop.is_set():
            raise L.Stop(False, "stopped")

    # ---- the device
    def device(self):
        if self._dev is not None:
            return self._dev
        if not self.serial and self.env.launcher:
            self.serial = self.env.launcher.serial(self.name)
        if not self.serial and self.env.discover:
            self.serial = self.env.discover(self.name)
        if not self.serial:
            raise Failed(f"{self.name} isn't running: put Activate instance first")
        if self.env.device_fn:
            dev = self.env.device_fn(self.name, self.serial)
        else:
            from intel_adb import adb as A
            dev = A.Device(self.name, self.serial)
        self._dev = guard(dev, self.stop)
        return self._dev

    def foreground(self):
        try:
            return self.device().foreground_package()
        except Exception:  # noqa: BLE001
            return None

    def steps(self, steps, label, skill_id="builder"):
        """Play learned-skill steps (the Proton VPN logic lives there)."""
        skill = {"id": skill_id, "title": label, "steps": steps}
        runner = L.Runner(skill, self.device(), log=lambda t: self.log(t.strip()), stop=self.stop,
                          **({"sleep": self.env.sleep} if self.env.sleep else {}),
                          clock=self.env.clock)
        ok, msg = runner.run()
        if not ok:
            raise Failed(msg.split(": ", 1)[-1])
        return msg.split(": ", 1)[-1]

    # ---- playing
    def run(self):
        """Plays the template. Returns (ok, message)."""
        blocks = self.tpl.get("blocks") or []
        where = {b["id"]: i for i, b in enumerate(blocks)}
        i, count, last = 0, 0, "nothing to do"
        try:
            while i < len(blocks):
                count += 1
                if count > MAX_STEPS:
                    return False, f"stopped after {MAX_STEPS} blocks: the jumps go round in circles"
                b = blocks[i]
                ok, last = self.attempt(b, i + 1)
                if self.stop.is_set():
                    raise L.Stop(False, "stopped")
                route = b.get("on_ok", "next") if ok else b.get("on_fail", "stop")
                if route == "next":
                    i += 1
                elif route == "stop":
                    return False, f"{title(b)}: {last}"
                elif route == "finish":
                    return True, f"finished at {title(b)}"
                elif route.startswith("goto:") and route[5:] in where:
                    i = where[route[5:]]
                else:
                    i += 1
        except L.Stop as e:
            return e.ok, str(e)
        except BaseException as e:  # engine.Cancelled from a guarded tap/screenshot: Stop was pressed
            if type(e).__name__ == "Cancelled":
                return False, "stopped"
            raise
        return True, "done"

    def attempt(self, b, n):
        tries = max(1, int(b.get("tries", 1)))
        name = title(b)
        msg = ""
        for k in range(1, tries + 1):
            if self.stop.is_set():
                raise L.Stop(False, "stopped")
            self.status(b["id"], "running", f"try {k} of {tries}" if tries > 1 else "")
            self.log(f"{n}. {name}" + (f" (try {k} of {tries})" if tries > 1 else ""))
            try:
                msg = self.do(b) or "done"
                self.status(b["id"], "ok", msg)
                self.log(f"   {name}: {msg}")
                return True, msg
            except Failed as e:
                msg = str(e)
            except L.Stop as e:
                if str(e) == "stopped":
                    raise
                msg = str(e)
            except Exception as e:  # noqa: BLE001  (Cancelled is a BaseException and goes up)
                msg = f"error: {e}"
            self.log(f"   {name} failed: {msg}")
            self.status(b["id"], "fail", msg)
            if k < tries:
                self.wait(float(b.get("retry_wait", 5)))
        return False, msg

    def do(self, b):
        t, p = b["type"], b.get("params") or {}
        env = self.env
        if t == "start_instance":
            if not env.launcher or not env.launcher.target(self.name):
                if self.serial or (env.discover and env.discover(self.name)):
                    return "already running"
                raise Failed(f"don't know how to start {self.name}: add it in Settings → Start and close instances")
            serial = env.launcher.boot(self.name, stop=self.stop)
            if serial is None:
                raise L.Stop(False, "stopped") if self.stop.is_set() else Failed("didn't start")
            self.serial, self._dev = serial or self.serial, None
            return "running"
        if t == "close_instance":
            if not env.launcher or not env.launcher.close(self.name):
                raise Failed("couldn't close it")
            self.serial, self._dev = None, None
            return "closed"
        if t == "wait":
            self.wait(float(p.get("seconds", 10)))
            return f"waited {p.get('seconds', 10)} s"
        if t == "message":
            text = str(p.get("text", "")).replace("{instance}", self.name)
            env.notify(f"[{self.name}] {text}")
            return text
        dev = self.device()
        if t in ("open_proton", "open_app"):
            pkg = PROTON if t == "open_proton" else p.get("package", "")
            if "package:" not in self.adb("shell", "pm", "path", pkg):
                if t == "open_proton" and p.get("missing_ok", True):
                    return "Proton VPN isn't installed here - skipped"
                raise Failed(f"{pkg} isn't installed")
            self.adb("shell", "monkey", "-p", pkg, "-c", "android.intent.category.LAUNCHER", "1", timeout=20)
            self.wait(3)
            return "opened"
        if t == "close_app":
            self.adb("shell", "am", "force-stop", p.get("package", KINGSHOT))
            return "closed"
        if t == "vpn_connect":
            if "package:" not in self.adb("shell", "pm", "path", PROTON):
                raise Failed("Proton VPN isn't installed here")
            self.steps([vpn_connect_step(int(p.get("timeout", 60)))], "Connect Proton", "proton_vpn")
            return "connected"
        if t == "vpn_unique":
            self.steps([vpn_unique_step(int(p.get("changes", 4)))], "Unique server", "proton_vpn")
            return "server not shared with another instance"
        if t == "vpn_check":
            if L.Runner({"id": "builder", "steps": []}, dev).vpn_connected():
                return "connected"
            raise Failed("no VPN connected")
        if t == "kingshot_check":
            if self.foreground() == KINGSHOT:
                return "open"
            raise Failed("Kingshot isn't in front")
        if t == "open_kingshot":
            return self.open_kingshot(p)
        if t == "back":
            dev.back()
            return "pressed"
        if t == "home":
            self.adb("shell", "input", "keyevent", "3")
            return "pressed"
        if t == "job":
            return self.job(p.get("job", "intel"))
        if t == "skill":
            sk = next((s for s in L.installed().get("skills", []) if s.get("id") == p.get("skill")), None)
            if not sk:
                raise Failed(f"learned skill {p.get('skill')!r} isn't installed (press Update on the Teacher page)")
            if self.foreground() == KINGSHOT:
                self.ensure_account()
            ok, msg = L.Runner(sk, dev, log=lambda t_: self.log(t_.strip()), stop=self.stop).run()
            if not ok:
                raise Failed(msg)
            return msg.split(": ", 1)[-1]
        raise Failed(f"unknown block {t!r}")

    def adb(self, *args, timeout=15):
        return (self.device()._adb(*args, timeout=timeout) or b"").decode(errors="ignore")

    def open_kingshot(self, p):
        if self.foreground() == KINGSHOT:
            return "already open"
        if p.get("skills") and self.env.before_game:
            if self.env.before_game(self.name, self.serial) is False:
                raise Failed("a required learned skill failed, so Kingshot stays closed")
        end = self.env.clock() + 120
        tries = 0
        while self.env.clock() < end:
            if self.foreground() == KINGSHOT:
                self.wait(float(p.get("settle", 25)))
                return "open"
            if tries % 5 == 0:  # (re)open every ~15 s; the first one can land mid-boot
                self.adb("shell", "monkey", "-p", KINGSHOT, "-c", "android.intent.category.LAUNCHER", "1",
                         timeout=20)
            tries += 1
            self.wait(3)
        raise Failed("Kingshot didn't come to the front within 2 min")

    def job(self, job):
        from autopilot import engine
        runner = engine.DEFAULT_RUNNERS.get(job)
        if not runner:
            raise Failed(f"no Autopilot job called {job!r}")
        if self.foreground() != KINGSHOT:
            raise Failed("Kingshot isn't open: put Open Kingshot first")
        self.ensure_account()
        params = self.env.job_params(self.name, job, self.account)
        dev = self.device()
        acc = self.account

        class Who:  # the bits of a Character the jobs read
            key = account_key(self.name, acc) if acc else f"{self.name}/builder"
            tag = acc.tag if acc else ""
        try:
            if job == "terrors":
                n = runner(dev, Who, params, self.log, int(params.get("per_day", 10)))
            else:
                n = runner(dev, Who, params, self.log)
        except engine.Cancelled:
            raise L.Stop(False, "stopped") from None
        self.env.record(self.name, job, int(n or 0), self.account)
        return f"{n or 0} done"


def account_key(instance, e):
    """The same key Autopilot gives the character (config.Character.key)."""
    return f"{instance}/{e.name}" if e.kingdom is None else f"{instance}/{e.kingdom}/{e.name}"


def switch_account(dev, e, log):
    """Log in as catalogue entry e through Settings -> Characters (Autopilot's switcher)."""
    from autopilot.characters import TEMPLATE_DIR, Switcher
    from intel_adb.vision import Vision
    sw = Switcher(dev, Vision(TEMPLATE_DIR), sleep=getattr(dev, "isleep", time.sleep), log=log)
    return sw.switch(e.name, e.kingdom, tag=e.tag, power=e.power)


def plan(templates, instance, entries):
    """[(template, account or None)] to run on `instance`, in order: a template with a smart
    filter once per matching account, one without once."""
    out = []
    for t in templates:
        if t.get("instances") and instance not in t["instances"]:
            continue
        if has_filter(t):
            out += [(t, e) for e in accounts(t, instance, entries)]
        else:
            out.append((t, None))
    return out


def run_instance(templates, name, env, entries, stop=None, status=None, serial=None):
    """Every planned (template, account) on one instance. status(tid, block id, state, text).
    Returns [(template name, account label or "", ok, message)]."""
    out = []
    stop = stop or threading.Event()
    todo = plan(templates, name, entries)
    if not todo:
        env.log(f"[{name}] no template applies here (smart filters match no account on it)")
    for t, acc in todo:
        if stop.is_set():
            break
        run = Run(t, name, env, serial=serial, stop=stop, account=acc,
                  status=(lambda bid, st, text, tid=t["id"]: status(tid, bid, st, text)) if status else None)
        ok, msg = run.run()
        serial = run.serial or serial
        who = acc.label if acc else ""
        env.log(f"[{name}{' · ' + who if who else ''}] {t['name']}: {'done' if ok else 'stopped'} - {msg}")
        out.append((t["name"], who, ok, msg))
    return out


def vpn_connect_step(timeout=60):
    """Until the VPN is up: accept Android's VPN dialog, press Connect (from the Proton lesson)."""
    tap_connect = {"do": "tap", "text": ["Connect", "Quick connect"], "package": PROTON, "timeout": 0,
                   "cooldown": 10, "else": "continue"}
    if (L.ROOT / "templates" / "proton_vpn" / "connect.png").is_file():
        tap_connect["on"] = "connect"  # the lesson's picture of the button, when the text can't be read
    return {"do": "until", "vpn": True, "ui": ["Disconnect"], "package": PROTON, "timeout": timeout, "every": 2,
            "say": f"didn't connect within {timeout} s",
            "steps": [{"do": "tap", "text": ["OK", "Allow"], "package": "com.android.vpndialogs", "timeout": 0,
                       "else": "continue"}, tap_connect]}


def vpn_unique_step(changes=4):
    """A Proton server no other instance is on (update 2's "distinct" step), failing when it can't."""
    return {"do": "distinct", "key": "vpn_server", "label": "VPN server", "pattern": r".+ #\d+",
            "package": PROTON, "vpn": True, "tries": changes, "settle": 30,
            "steps": [{"do": "until", "ui": ["Change server"], "package": PROTON, "timeout": 6, "every": 1,
                       "else": "continue",
                       "steps": [{"do": "tap", "text": ["Fastest free server", "Fastest server"], "package": PROTON,
                                  "timeout": 0, "cooldown": 3, "else": "continue"}]},
                      {"do": "tap", "text": ["Change server"], "package": PROTON, "timeout": 3,
                       "else": "continue"}]}


def guard(dev, stop):
    """Every screenshot / tap ends the run the moment Stop is pressed (like an Autopilot session),
    and jobs get an isleep that does the same."""
    from autopilot.engine import Cancelled

    def checked(fn):
        def wrapper(*a, **k):
            if stop.is_set():
                raise Cancelled()
            return fn(*a, **k)
        return wrapper
    for name in ("screencap", "tap", "back", "swipe", "type_text"):
        if hasattr(dev, name):
            setattr(dev, name, checked(getattr(dev, name)))

    def isleep(seconds):
        if stop.wait(max(0.0, seconds)):
            raise Cancelled()
    dev.isleep = isleep
    return dev


def instances_for(tpl, targets, open_now):
    """Instance names a template runs on: its own list, else every instance set to Start plus
    every one open now."""
    if tpl.get("instances"):
        return list(tpl["instances"])
    names = [t.name for t in targets if t.start]
    return names + [n for n in open_now if n not in names]

