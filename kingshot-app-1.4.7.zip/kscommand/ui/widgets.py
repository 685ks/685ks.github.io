"""Small animated widgets: toggle switch, pulsing status dot, glowing hero button, count-up
numbers, bar chart, toasts, page fade, cards."""


from PySide6.QtCore import (Property, QEasingCurve, QParallelAnimationGroup, QPoint, QPointF,
                            QPropertyAnimation, QRectF, QSize, Qt, QTimer, QVariantAnimation)
from PySide6.QtGui import QColor, QFont, QLinearGradient, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import (QAbstractButton, QFrame, QGraphicsDropShadowEffect,
                               QGraphicsOpacityEffect, QHBoxLayout, QLabel, QPushButton,
                               QSizePolicy, QVBoxLayout, QWidget)

from kscommand.ui.theme import C, T_BAR, T_FOCUS, T_HOVER, T_POP, T_SHEET, accent, ease, hop, tint

STATUS_COLOURS = {"running": C["ok"], "idle": C["faint"], "stopped": C["bad"], "starting": C["warn"],
                  "offline": C["bad"], "online": C["info"]}


def label(text, obj=None, wrap=False):
    lb = QLabel(text)
    if obj:
        lb.setObjectName(obj)
    lb.setWordWrap(wrap)
    return lb


def heading(text):
    """Panel title row: an 8px accent pin, then the title (design system `.ph`)."""
    w = QWidget()
    h = QHBoxLayout(w)
    h.setContentsMargins(0, 0, 0, 0)
    h.setSpacing(10)
    pin = QFrame()
    pin.setObjectName("pin")
    pin.setFixedSize(8, 8)
    h.addWidget(pin, 0, Qt.AlignVCenter)
    w.title = label(text, "h2")
    h.addWidget(w.title)
    h.addStretch()
    return w


def no_emoji(text):
    """Drops colour-emoji characters (pictographs, dingbat emoji, variation selector 16) from text
    the window shows; bot and engine messages carry them for Telegram."""
    return "".join(ch for ch in text if not (0x1F000 <= ord(ch) <= 0x1FAFF or 0x2600 <= ord(ch) <= 0x27BF
                                             or ord(ch) in (0xFE0F, 0x200D, 0x23F0, 0x23F1, 0x23F3)))


def monogram(text, size=26):
    """First letter in a tinted square. Stands in for emoji: Qt 6.8 can crash drawing Windows'
    colour emoji font, so nothing in the window uses one."""
    lb = QLabel((text.strip() or "?")[0].upper())
    lb.setFixedSize(size, size)
    lb.setAlignment(Qt.AlignCenter)
    lb.setStyleSheet(f"background: {tint(C['accent'], 0.14)}; color: {C['accent']}; border-radius: {size // 3}px;"
                     f" font-size: {round(size * 0.5)}px; font-weight: 600;")
    return lb


def chip(text, kind=""):
    return label(text, {"ok": "chipOk", "warn": "chipWarn", "bad": "chipBad"}.get(kind, "chip"))


class Card(QFrame):
    """Rounded panel that lifts (shadow grows) under the mouse."""

    def __init__(self, parent=None, hover=True, pad=18, spacing=10):
        super().__init__(parent)
        self.setObjectName("card")
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(pad, pad, pad, pad)
        self.lay.setSpacing(spacing)
        self._shadow = QGraphicsDropShadowEffect(self)
        self._shadow.setColor(QColor(0, 0, 0, 150))
        self._shadow.setOffset(0, 14)
        self._shadow.setBlurRadius(28)
        self.setGraphicsEffect(self._shadow)
        self._anim = QPropertyAnimation(self._shadow, b"blurRadius", self)
        self._anim.setDuration(T_HOVER)
        self._anim.setEasingCurve(ease())
        self._hover = hover

    def enterEvent(self, e):
        if self._hover:
            self._anim.stop()
            self._anim.setEndValue(48)
            self._anim.start()
        super().enterEvent(e)

    def leaveEvent(self, e):
        if self._hover:
            self._anim.stop()
            self._anim.setEndValue(28)
            self._anim.start()
        super().leaveEvent(e)


class Toggle(QAbstractButton):
    """iOS-style switch with a sliding knob."""

    def __init__(self, checked=False, parent=None, accent_name="Gold"):
        super().__init__(parent)
        self.setCheckable(True)
        self.setChecked(checked)
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedSize(44, 24)
        self.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self._pos = 1.0 if checked else 0.0
        self._accent = accent(accent_name)
        self._anim = QPropertyAnimation(self, b"knob", self)
        self._anim.setDuration(T_HOVER)
        self._anim.setEasingCurve(ease())
        self.toggled.connect(self._go)

    def _go(self, on):
        self._anim.stop()
        self._anim.setEndValue(1.0 if on else 0.0)
        self._anim.start()

    def getKnob(self):
        return self._pos

    def setKnob(self, v):
        self._pos = v
        self.update()

    # Not "pos": that name would shadow QWidget's own pos property, which Qt reads as a QPoint.
    knob = Property(float, getKnob, setKnob)

    def sizeHint(self):
        return QSize(44, 24)

    def setMaximumWidth(self, w):  # callers that size every field alike must not stretch a switch
        super().setMaximumWidth(44)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(0, 0, self.width(), self.height())
        off, on1 = QColor(C["focus"]), QColor(self._accent[0])
        track = QColor(
            round(off.red() + (on1.red() - off.red()) * self._pos),
            round(off.green() + (on1.green() - off.green()) * self._pos),
            round(off.blue() + (on1.blue() - off.blue()) * self._pos))
        if not self.isEnabled():
            track.setAlpha(90)
        edge = QColor(C["line"]) if self._pos < 0.5 else QColor(self._accent[0])
        p.setPen(QPen(edge, 1))
        p.setBrush(track)
        p.drawRoundedRect(r.adjusted(0.5, 0.5, -0.5, -0.5), 12, 12)
        d = self.height() - 8
        x = 4 + (self.width() - d - 8) * self._pos
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(C["on_accent"] if self._pos > 0.5 else C["muted"]))
        p.drawEllipse(QRectF(x, 4, d, d))


class PulseDot(QWidget):
    """Status dot; a soft halo breathes around it while 'running'."""

    def __init__(self, status="idle", size=12, parent=None):
        super().__init__(parent)
        self.setFixedSize(size * 2, size * 2)
        self._size = size
        self._phase = 0.0
        self._anim = QVariantAnimation(self, startValue=0.0, endValue=1.0, duration=1600, loopCount=-1,
                                       easingCurve=ease())
        self._anim.valueChanged.connect(self._tick)
        self.set_status(status)

    def _tick(self, v):
        self._phase = v
        self.update()

    def set_status(self, status):
        self.status = status
        self.colour = QColor(STATUS_COLOURS.get(status, C["faint"]))
        if status in ("running", "starting"):
            self._anim.start()
        else:
            self._anim.stop()
            self._phase = 0.0
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        c = QPointF(self.width() / 2, self.height() / 2)
        r = self._size / 2
        if self._anim.state() == QVariantAnimation.Running:
            halo = QColor(self.colour)
            halo.setAlphaF(0.45 * (1 - self._phase))
            p.setPen(Qt.NoPen)
            p.setBrush(halo)
            hr = r + r * 1.1 * self._phase
            p.drawEllipse(c, hr, hr)
        p.setPen(Qt.NoPen)
        p.setBrush(self.colour)
        p.drawEllipse(c, r * 0.8, r * 0.8)


class HeroButton(QPushButton):
    """The design system's primary button (`.go`): light fill, dark text, white on hover, scale .98
    on press. While 'active' it turns into a tinted stop button and a light sweeps along its bottom
    edge, the site's busy state."""

    def __init__(self, text, accent_name=None, parent=None):
        super().__init__(text, parent)
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumHeight(54)
        self.setMinimumWidth(240)
        self._accent = accent(accent_name)
        self.active = False
        self._sweep_x = 0.0
        self._hover = 0.0
        self._press = 0.0
        f = QFont(self.font())
        f.setPixelSize(15)
        f.setWeight(QFont.DemiBold)
        self.setFont(f)
        self._shadow = QGraphicsDropShadowEffect(self, blurRadius=40, offset=QPoint(0, 14),
                                                 color=QColor(0, 0, 0, 170))
        self.setGraphicsEffect(self._shadow)
        self._sweep = QVariantAnimation(self, startValue=-0.3, endValue=1.3, duration=1100, loopCount=-1,
                                        easingCurve=ease())
        self._sweep.valueChanged.connect(self._set_sweep)
        self._hov = QVariantAnimation(self, duration=T_HOVER, easingCurve=ease())
        self._hov.valueChanged.connect(self._set_hover)
        self._prs = QVariantAnimation(self, duration=120, easingCurve=ease())
        self._prs.valueChanged.connect(self._set_press)

    def _set_sweep(self, v):
        self._sweep_x = v
        self.update()

    def _set_hover(self, v):
        self._hover = v
        self.update()

    def _set_press(self, v):
        self._press = v
        self.update()

    def _animate(self, anim, cur, to):
        anim.stop()
        anim.setStartValue(float(cur))
        anim.setEndValue(float(to))
        anim.start()

    def enterEvent(self, e):
        self._animate(self._hov, self._hover, 1.0)
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._animate(self._hov, self._hover, 0.0)
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        self._animate(self._prs, self._press, 1.0)
        super().mousePressEvent(e)

    def mouseReleaseEvent(self, e):
        self._animate(self._prs, self._press, 0.0)
        super().mouseReleaseEvent(e)

    def set_active(self, on, text):
        self.active = on
        self.setText(text)
        if on:
            self._sweep.start()
        else:
            self._sweep.stop()
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        k = 1 - 0.02 * self._press
        r = QRectF(r.center().x() - r.width() * k / 2, r.center().y() - r.height() * k / 2,
                   r.width() * k, r.height() * k)
        path = QPainterPath()
        path.addRoundedRect(r, 12, 12)
        if self.active:
            bad = QColor(C["bad"])
            fill = QColor(bad)
            fill.setAlphaF(0.07 + 0.05 * self._hover)
            p.fillPath(path, fill)
            edge = QColor(bad)
            edge.setAlphaF(0.4 + 0.3 * self._hover)
            p.setPen(QPen(edge, 1))
            p.drawPath(path)
            # light sweeping along the bottom edge
            p.save()
            p.setClipPath(path)
            sx = r.left() + r.width() * self._sweep_x
            g = QLinearGradient(QPointF(sx - 70, 0), QPointF(sx + 70, 0))
            g.setColorAt(0, QColor(255, 255, 255, 0))
            g.setColorAt(0.5, bad)
            g.setColorAt(1, QColor(255, 255, 255, 0))
            p.fillRect(QRectF(r.left(), r.bottom() - 2, r.width(), 2), g)
            p.restore()
            p.setPen(bad)
        else:
            base, white = QColor(C["text"]), QColor("#ffffff")
            fill = QColor(round(base.red() + (white.red() - base.red()) * self._hover),
                          round(base.green() + (white.green() - base.green()) * self._hover),
                          round(base.blue() + (white.blue() - base.blue()) * self._hover))
            p.fillPath(path, fill)
            p.setPen(QColor(C["on_accent"]))
        p.setFont(self.font())
        p.drawText(r, Qt.AlignCenter, self.text())


class CountLabel(QLabel):
    """A number that counts up/down to its new value."""

    def __init__(self, value=0, suffix="", parent=None):
        super().__init__(parent)
        self.setObjectName("statValue")
        self._value = float(value)
        self.suffix = suffix
        tabular(self)
        self._anim = QVariantAnimation(self, duration=T_POP, easingCurve=ease())
        self._anim.valueChanged.connect(self._show)
        self._show(value)

    def _show(self, v):
        self._value = float(v)
        self.setText(f"{round(self._value):,}{self.suffix}")

    def set_value(self, v):
        if isinstance(v, str):
            self._anim.stop()
            self.setText(v)
            return
        if round(self._value) == v:
            return
        self._anim.stop()
        self._anim.setStartValue(self._value)
        self._anim.setEndValue(float(v))
        self._anim.start()


class StatTile(Card):
    def __init__(self, title, value=0, suffix="", glyph="", parent=None):
        super().__init__(parent, pad=18, spacing=6)
        top = QHBoxLayout()
        top.addWidget(label(title.upper(), "statLabel"))
        top.addStretch()
        if glyph:
            g = QLabel()
            g.setPixmap(line_icon(GLYPH_ICONS.get(glyph, glyph), 18, C["accent"]))
            top.addWidget(g)
        self.lay.addLayout(top)
        self.value = CountLabel(value, suffix)
        self.lay.addWidget(self.value)
        self.sub = label("", "faint")
        self.lay.addWidget(self.sub)


class BarChart(QWidget):
    """Vertical bars with labels; bars grow in when data changes."""

    def __init__(self, parent=None, accent_name="Gold"):
        super().__init__(parent)
        self.setMinimumHeight(200)
        self.data = []  # [(label, value)]
        self._t = 1.0
        self._accent = accent(accent_name)
        self._anim = QVariantAnimation(self, startValue=0.0, endValue=1.0, duration=T_BAR, easingCurve=ease())
        self._anim.valueChanged.connect(self._set_t)

    def _set_t(self, v):
        self._t = v
        self.update()

    def set_data(self, data):
        self.data = list(data)
        self._anim.stop()
        self._anim.start()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        if not self.data:
            p.setPen(QColor(C["muted"]))
            p.drawText(self.rect(), Qt.AlignCenter, "No activity yet")
            return
        top, bottom = 22, 26
        peak = max(v for _, v in self.data) or 1
        n = len(self.data)
        slot = w / n
        bw = min(46, slot * 0.6)
        p.setPen(QPen(QColor(C["line2"]), 1, Qt.DashLine))
        for i in range(1, 4):
            y = top + (h - top - bottom) * i / 4
            p.drawLine(0, round(y), w, round(y))
        f = QFont(self.font())
        f.setPixelSize(11)
        p.setFont(f)
        for i, (lab, v) in enumerate(self.data):
            bh = (h - top - bottom) * (v / peak) * self._t
            x = slot * i + (slot - bw) / 2
            r = QRectF(x, h - bottom - bh, bw, bh)
            g = QLinearGradient(r.topLeft(), r.bottomLeft())
            g.setColorAt(0, QColor(self._accent[0]))
            g.setColorAt(1, QColor(self._accent[1]))
            path = QPainterPath()
            path.addRoundedRect(r, 5, 5)
            p.fillPath(path, g)
            p.setPen(QColor(C["faint"]))
            p.drawText(QRectF(slot * i, h - bottom + 4, slot, bottom - 4), Qt.AlignHCenter | Qt.AlignTop, lab)
            if v:
                p.setPen(QColor(C["text"]))
                p.drawText(QRectF(slot * i, h - bottom - bh - 18, slot, 16), Qt.AlignCenter, f"{round(v * self._t)}")


class Ring(QWidget):
    """Donut showing a share (0..1) with a caption in the middle."""

    def __init__(self, size=120, parent=None, accent_name="Gold"):
        super().__init__(parent)
        self.setFixedSize(size, size)
        self.share, self.caption, self.sub = 0.0, "", ""
        self._shown = 0.0
        self._accent = accent(accent_name)
        self._anim = QVariantAnimation(self, duration=T_BAR, easingCurve=ease())
        self._anim.valueChanged.connect(self._set)

    def _set(self, v):
        self._shown = v
        self.update()

    def set_share(self, share, caption, sub=""):
        self.share, self.caption, self.sub = share, caption, sub
        self._anim.stop()
        self._anim.setStartValue(0.0)
        self._anim.setEndValue(float(share))
        self._anim.start()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        m = 10
        r = QRectF(m, m, self.width() - 2 * m, self.height() - 2 * m)
        p.setPen(QPen(QColor(C["focus"]), 10, Qt.SolidLine, Qt.RoundCap))
        p.drawArc(r, 0, 360 * 16)
        g = QLinearGradient(r.topLeft(), r.bottomRight())
        g.setColorAt(0, QColor(self._accent[0]))
        g.setColorAt(1, QColor(self._accent[1]))
        pen = QPen(g, 10, Qt.SolidLine, Qt.RoundCap)
        p.setPen(pen)
        p.drawArc(r, 90 * 16, -round(360 * 16 * self._shown))
        p.setPen(QColor(C["text"]))
        f = QFont(self.font())
        f.setPixelSize(24)
        f.setWeight(QFont.Bold)
        f.setLetterSpacing(QFont.PercentageSpacing, 98)
        p.setFont(f)
        p.drawText(r.adjusted(0, -10, 0, -10), Qt.AlignCenter, self.caption)
        f.setPixelSize(10)
        f.setWeight(QFont.DemiBold)
        f.setLetterSpacing(QFont.PercentageSpacing, 120)
        f.setCapitalization(QFont.AllUppercase)
        p.setFont(f)
        p.setPen(QColor(C["faint"]))
        p.drawText(r.adjusted(0, 24, 0, 24), Qt.AlignCenter, self.sub)


class Toast(QFrame):
    """Message that slides up from the bottom-right corner of `host` and fades away."""
    _stack = []

    def __init__(self, host, text, kind="info", ms=3800):
        super().__init__(host)
        text = no_emoji(text).strip()
        self.setObjectName("toast")
        lay = QHBoxLayout(self)
        lay.setContentsMargins(14, 10, 16, 10)
        dot = PulseDot({"ok": "running", "bad": "stopped", "warn": "starting"}.get(kind, "online"), 9)
        lay.addWidget(dot)
        t = label(text, wrap=True)
        t.setFixedWidth(min(340, t.fontMetrics().horizontalAdvance(text) + 8))
        lay.addWidget(t)
        self.adjustSize()
        sh = QGraphicsDropShadowEffect(self, blurRadius=60, offset=QPoint(0, 22), color=QColor(0, 0, 0, 200))
        self.setGraphicsEffect(sh)
        from shiboken6 import isValid
        Toast._stack = [x for x in Toast._stack if isValid(x) and x.isVisible()]
        y_off = sum(x.height() + 10 for x in Toast._stack)
        Toast._stack.append(self)
        end = QPoint(host.width() - self.width() - 24, host.height() - self.height() - 24 - y_off)
        self.move(end + QPoint(0, 16))
        self.show()
        self.raise_()
        a = QPropertyAnimation(self, b"pos", self, duration=T_SHEET, easingCurve=ease())
        a.setEndValue(end)
        a.start()
        QTimer.singleShot(ms, self._leave)

    def _leave(self):
        a = QPropertyAnimation(self, b"pos", self, duration=T_FOCUS, easingCurve=QEasingCurve.InCubic)
        a.setEndValue(self.pos() + QPoint(self.width() + 40, 0))
        a.finished.connect(self.deleteLater)
        a.start()


def fade_in(widget, ms=T_SHEET):
    eff = QGraphicsOpacityEffect(widget)
    widget.setGraphicsEffect(eff)
    a = QPropertyAnimation(eff, b"opacity", widget, duration=ms, easingCurve=ease())
    a.setStartValue(0.0)
    a.setEndValue(1.0)
    a.finished.connect(lambda: widget.setGraphicsEffect(None))
    a.start()
    return a


def slide_fade_in(widget, dy=16, ms=T_SHEET + 120):
    """Page entrance: rise 16px into place. No opacity effect: a page-wide effect nested over
    the cards' shadows balloons memory on Windows, and replacing it mid-animation crashed."""
    prev = getattr(widget, "_entrance", None)
    if prev is not None:
        prev.stop()
        widget.move(widget._entrance_end)
    end = widget.pos()
    m = QPropertyAnimation(widget, b"pos", widget, duration=ms, easingCurve=ease())
    m.setStartValue(end + QPoint(0, dy))
    m.setEndValue(end)
    widget._entrance, widget._entrance_end = m, end
    m.start()
    return m


class Spinner(QWidget):
    """Three outlined diamonds hopping in turn: the design system's busy state."""

    def __init__(self, size=18, parent=None):
        super().__init__(parent)
        self.setFixedSize(round(size * 2.6), size)
        self._t = 0.0
        self._curve = hop()
        self._anim = QVariantAnimation(self, startValue=0.0, endValue=1.0, duration=1100, loopCount=-1)
        self._anim.valueChanged.connect(self._step)

    def start(self):
        self.show()
        self._anim.start()

    def stop(self):
        self._anim.stop()
        self.hide()

    def _step(self, v):
        self._t = v
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        h = self.height()
        d = h * 0.26
        p.setPen(QPen(QColor(C["accent"]), 1.4))
        p.setBrush(Qt.NoBrush)
        for i in range(3):
            phase = (self._t - i * 0.16) % 1.0
            lift = self._curve.valueForProgress(min(phase * 2, 1.0)) if phase < 0.5 else \
                1 - self._curve.valueForProgress((phase - 0.5) * 2)
            cx = d + 2 + i * (self.width() - 2 * d - 4) / 2
            cy = h * 0.62 - lift * h * 0.3
            dia = QPainterPath()
            dia.moveTo(cx, cy - d)
            dia.lineTo(cx + d, cy)
            dia.lineTo(cx, cy + d)
            dia.lineTo(cx - d, cy)
            dia.closeSubpath()
            p.drawPath(dia)


def hline():
    f = QFrame()
    f.setFixedHeight(1)
    f.setStyleSheet(f"background: {C['line2']};")
    return f


def expanding():
    w = QWidget()
    w.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
    return w


def crown_pixmap(size=64, accent_name=None):
    """The app mark: a light crown on a dark glass tile with a hairline frame (window/tray icon)."""
    from PySide6.QtGui import QPixmap
    a1, _ = accent(accent_name)
    pm = QPixmap(size, size)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    r = QRectF(0.5, 0.5, size - 1, size - 1)
    g = QLinearGradient(r.topLeft(), r.bottomRight())
    g.setColorAt(0, QColor("#1a2230"))
    g.setColorAt(1, QColor(C["panel"]))
    path = QPainterPath()
    path.addRoundedRect(r, size * 0.24, size * 0.24)
    p.fillPath(path, g)
    p.setPen(QPen(QColor(255, 255, 255, 40), max(1.0, size / 64)))
    p.drawPath(path)
    s = size
    cg = QLinearGradient(QPointF(0, 0.2 * s), QPointF(0, 0.8 * s))
    cg.setColorAt(0, QColor(C["text"]))
    cg.setColorAt(1, QColor(a1))
    crown = QPainterPath()
    pts = [(0.22, 0.68), (0.18, 0.34), (0.37, 0.50), (0.50, 0.27), (0.63, 0.50), (0.82, 0.34), (0.78, 0.68)]
    crown.moveTo(pts[0][0] * s, pts[0][1] * s)
    for x, y in pts[1:]:
        crown.lineTo(x * s, y * s)
    crown.closeSubpath()
    p.fillPath(crown, cg)
    p.fillRect(QRectF(0.22 * s, 0.72 * s, 0.56 * s, 0.065 * s), QColor(a1))
    p.setPen(Qt.NoPen)
    p.setBrush(QColor(C["text"]))
    for x, y in ((0.18, 0.32), (0.50, 0.245), (0.82, 0.32)):
        p.drawEllipse(QPointF(x * s, y * s), s * 0.042, s * 0.042)
    p.end()
    return pm


def tabular(widget):
    """Tabular figures for numbers (font-variant-numeric: tabular-nums), where Qt supports it."""
    try:
        f = QFont(widget.font())
        f.setFeature(QFont.Tag("tnum"), 1)
        widget.setFont(f)
    except (AttributeError, TypeError):
        pass


GLYPH_ICONS = {"🖥": "screen", "⚡": "bolt", "🤖": "cpu", "⏱": "clock"}


def line_icon(kind, size=18, colour=None):
    """Hairline icons drawn in code, so the UI doesn't depend on the system's emoji font."""
    from PySide6.QtGui import QPixmap
    pm = QPixmap(size * 2, size * 2)
    pm.setDevicePixelRatio(2)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    p.scale(size / 24, size / 24)
    pen = QPen(QColor(colour or C["muted"]), 1.7, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)
    p.setPen(pen)
    p.setBrush(Qt.NoBrush)
    path = QPainterPath()

    def poly(*pts, close=False):
        path.moveTo(*pts[0])
        for pt in pts[1:]:
            path.lineTo(*pt)
        if close:
            path.closeSubpath()

    if kind == "home":
        poly((4, 11), (12, 4), (20, 11))
        poly((6, 9.5), (6, 20), (18, 20), (18, 9.5))
        poly((10, 20), (10, 14), (14, 14), (14, 20))
    elif kind in ("auto", "cpu"):
        path.addRoundedRect(QRectF(6, 6, 12, 12), 2.5, 2.5)
        path.addRoundedRect(QRectF(9.5, 9.5, 5, 5), 1, 1)
        for t in (9, 12, 15):
            poly((t, 3), (t, 6))
            poly((t, 18), (t, 21))
            poly((3, t), (6, t))
            poly((18, t), (21, t))
    elif kind == "bots":
        poly((4, 4), (14, 14))
        poly((4, 4), (8, 4))
        poly((4, 4), (4, 8))
        poly((20, 4), (10, 14))
        poly((20, 4), (16, 4))
        poly((20, 4), (20, 8))
        poly((7, 15), (11, 19))
        poly((17, 15), (13, 19))
        poly((5, 19), (7, 17))
        poly((19, 19), (17, 17))
    elif kind == "gift":
        path.addRoundedRect(QRectF(4, 9, 16, 4), 1, 1)
        poly((5.5, 13), (5.5, 20), (18.5, 20), (18.5, 13))
        poly((12, 9), (12, 20))
        path.moveTo(12, 9)
        path.cubicTo(9, 3, 5, 6, 8, 9)
        path.moveTo(12, 9)
        path.cubicTo(15, 3, 19, 6, 16, 9)
    elif kind == "stats":
        poly((4, 20), (20, 20))
        for x, top in ((7, 13), (12, 7), (17, 10)):
            path.addRoundedRect(QRectF(x - 1.6, top, 3.2, 20 - top - 2), 1, 1)
    elif kind == "map":
        poly((3, 6), (9, 4), (15, 6), (21, 4), (21, 18), (15, 20), (9, 18), (3, 20), close=True)
        poly((9, 4), (9, 18))
        poly((15, 6), (15, 20))
    elif kind == "logs":
        path.addRoundedRect(QRectF(5, 3, 14, 18), 2.5, 2.5)
        for y in (8, 12, 16):
            poly((8.5, y), (15.5 if y != 16 else 12.5, y))
    elif kind == "settings":
        path.addEllipse(QPointF(12, 12), 3, 3)
        import math
        for i in range(8):
            a = i * math.pi / 4
            poly((12 + 6.2 * math.cos(a), 12 + 6.2 * math.sin(a)), (12 + 8.6 * math.cos(a), 12 + 8.6 * math.sin(a)))
        path.addEllipse(QPointF(12, 12), 6.2, 6.2)
    elif kind == "teach":
        path.addEllipse(QPointF(12, 12), 8.5, 8.5)
        p.drawPath(path)
        path = QPainterPath()
        p.setBrush(QColor(colour or C["muted"]))
        path.addEllipse(QPointF(12, 12), 3.6, 3.6)
    elif kind == "chars":  # two people
        path.addEllipse(QPointF(9.5, 8.5), 3.4, 3.4)
        path.moveTo(3.5, 19.5)
        path.cubicTo(3.5, 14.5, 15.5, 14.5, 15.5, 19.5)
        path.moveTo(15.5, 5.6)
        path.cubicTo(19.5, 5.6, 19.5, 11.6, 15.5, 11.6)
        path.moveTo(17.8, 14.4)
        path.cubicTo(19.6, 15.2, 20.5, 16.8, 20.5, 19.5)
    elif kind == "build":  # three stacked bricks
        for x, y in ((4, 14), (12, 14), (8, 7)):
            path.addRoundedRect(QRectF(x, y, 8, 5.5), 1.2, 1.2)
            path.addEllipse(QPointF(x + 2.6, y - 1), 0.9, 0.9)
            path.addEllipse(QPointF(x + 5.4, y - 1), 0.9, 0.9)
    elif kind == "screen":
        path.addRoundedRect(QRectF(3, 5, 18, 12), 2, 2)
        poly((9, 20), (15, 20))
        poly((12, 17), (12, 20))
    elif kind == "bolt":
        poly((13, 3), (5, 13.5), (11.5, 13.5), (10.5, 21), (19, 10), (12.5, 10), close=True)
    elif kind == "clock":
        path.addEllipse(QPointF(12, 12), 8.5, 8.5)
        poly((12, 7.5), (12, 12), (15, 14))
    else:
        path.addEllipse(QPointF(12, 12), 3, 3)
    p.drawPath(path)
    p.end()
    return pm
